/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */










/***********************************************************************************************/
/* ssp_dbg.c                                                                                   */
/* debug functions. The debug messages are logged in a file if any is specified. Otherwise,    */
/* they are printed to standard error.                                                         */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: Nov 4, 2000                                                                        */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>

#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/time.h>
#include <string.h>

#ifdef USE_DMALLOC
#include <dmalloc.h>
#endif

/* DEBUG_open ----------------------------------------------------------------------------------
   Opens a log file or standard error...
--------------------------------------------------------------------------------------------- */
void DEBUG_open(FILE** f, char *f_name) { 
#ifdef DEBUG_MSG
  if(f_name != NULL) {
    *f = fopen(f_name, "w");
    if(!(*f)) {
      exit(fprintf(stderr, "Could not open file: %s. %s\n", f_name, strerror(errno)));
    }
  }
  else {
    *f = fdopen(2, "w");
  }
#endif
}

/* DEBUG_close --------------------------------------------------------------------------------
   Close the log file
--------------------------------------------------------------------------------------------- */
void DEBUG_close(FILE** f) {
#ifdef DEBUG_MSG
  int ret;

  if(*f) {
    ret = fclose(*f);
    if(ret != 0) {
      exit(fprintf(stderr, "Closing file failed.  %s\n", strerror(errno)));
    }

    *f = NULL;
  }
#endif
}

/* SSP_Enc_create ------------------------------------------------------------------------------
   It returns a pointer to the SSP_Enc if the encryption algorithm is support, NULL otherwise.
-----------------------------------------------------------------------------------------------*/
void DEBUG_enter(FILE *f, char *fcn_name) {
#ifdef DEBUG_MSG
  if(f) {
    fprintf(f, "%s: ENTER\n", fcn_name);
    fflush(f);
  }
#endif
}

/* SSP_Enc_create ------------------------------------------------------------------------------
   It returns a pointer to the SSP_Enc if the encryption algorithm is support, NULL otherwise.
-----------------------------------------------------------------------------------------------*/
void DEBUG_leave(FILE *f, char *fcn_name, int ret) {
#ifdef DEBUG_MSG
  if(f) {
    fprintf(f, "%s: LEAVE, returning %d\n", fcn_name, ret);
    fflush(f);
  }
#endif
}










