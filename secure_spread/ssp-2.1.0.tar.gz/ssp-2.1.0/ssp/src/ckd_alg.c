/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */










/***********************************************************************************************/
/* ckd_alg.c                                                                                   */
/* Implements the CKD group key management algorithm.                                          */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: Aug. 10, 2002                                                                      */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <stdutil/stdhash.h>
#include <stdutil/stdarr.h>

#include "ssp_info.h"
#include "scatter.h"
#include "scatter_cryptor.h"
#include "ssp.h"
#include "utility.h"
#include "ssp_dbg.h"
#include "ssp_p.h"
#include "ssp_error.h"

#include "ckd_api.h"
#include "error.h"

#include "fl.h"

#include "ckd_alg.h"

#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif

extern FILE *f_dbg;


/* CKD_Alg_init  -------------------------------------------------------------------------------
   It initializes a CKD_Alg data structure
---------------------------------------------------------------------------------------------- */
static void CKD_Alg_init(CKD_Alg *ckd) {
  ckd->ctx = 0;
  stddll_construct(&(ckd->msg_deque), sizeof(SSP_Msg*));
  ckd->first_trans = SSP_TRUE; 
  ckd->vs_trans = SSP_FALSE;
  ckd->wait_for_sec_fl_ok = SSP_FALSE;
  ckd->kl_got_fl_req = SSP_FALSE;
  ckd->first_cascaded_memb = SSP_TRUE;
  ckd->vs_set = 0;
  stdhash_construct(&ckd->vs_set_hash, sizeof(char*), 0,grp_name_ptr_eq, grp_name_ptr_hashcode);
  ckd->curr_memb_msg = 0;
  ckd->state = CKD_WAIT_FOR_SELF_JOIN;
}

/* CKD_Alg_destroy -----------------------------------------------------------------------------
   It frees any memory used by CKD_Alg.
---------------------------------------------------------------------------------------------- */
static void CKD_Alg_destroy(CKD_Alg *ckd) {
  stddll_it lit;
  SSP_Msg *msg = 0;
  
  for(stddll_begin(&(ckd->msg_deque), &lit); !stddll_it_is_end(&lit); stddll_it_next(&lit)) {
    msg = *(SSP_Msg**) stddll_it_val(&lit);
    SSP_Msg_free(&msg);
  }
  stddll_destruct(&(ckd->msg_deque));
  
  clq_destroy_ctx(&ckd->ctx);

  if(ckd->vs_set) {
    free(ckd->vs_set);
    ckd->vs_set = NULL;
  }
  stdhash_destruct(&ckd->vs_set_hash);
}

/* CKD_Alg_create  ------------------------------------------------------------------------------
   It allocates and initializes a CKD_Alg data structure. It returns a pointer to the newly 
   created object.
---------------------------------------------------------------------------------------------- */
CKD_Alg * CKD_Alg_create() {
  CKD_Alg * ckd = (CKD_Alg*) malloc(sizeof(CKD_Alg));
    
  if(!ckd) {
    ssp_err_quit("CKD_Alg_create: malloc failed \n");
  }
  CKD_Alg_init(ckd);

  return ckd;
}

/* CKD_Alg_free -------------------------------------------------------------------------------
   It frees a CKD_Alg data structure.
---------------------------------------------------------------------------------------------- */
void CKD_Alg_free(CKD_Alg **clq) {
  if (*clq) {
    CKD_Alg_destroy(*clq);
    free(*clq);
    *clq = NULL;
  } 
}

/* ============================  helper functions  =========================================== */


/* copy_key  ------------------------------------------------------------------------------------
   Helper function that copies the key from the cliques context in the encryption info.
-----------------------------------------------------------------------------------------------*/
static int copy_key(SSP_Grp *grp) {
  CKD_Alg *ckd = (CKD_Alg*)(grp->ka->info);
  
  memcpy(grp->enc->key, ckd->ctx->group_secret_hash, grp->enc->key_len);

  ON_DEBUG (
    { 
      int i;
      fprintf(f_dbg, "The key is: 0x");
      for (i = 0; i < grp->enc->key_len; i++){
        fprintf(f_dbg, "%02X", ((unsigned char*)(grp->enc->key))[i]);
      }
      fprintf(f_dbg, "\n");
    }
  )

  return 0;
}


/* msg_2_tk  -----------------------------------------------------------------------------------
   This function converts a spread message into a ckd token.
-----------------------------------------------------------------------------------------------*/
static void msg_2_tk(SSP_Msg *msg, CLQ_TOKEN *tk) {
  int err;

  if(Is_r_msg(msg->msg_type) || Is_new_share_msg(msg->msg_type) || Is_key_msg(msg->msg_type)) {
    tk->length = msg->msg_len;     
  }
  else {
    ssp_err_quit("msg_2_tk: Unknown token type\n");
  }

  if((tk->t_data = (unsigned char*) malloc(tk->length * sizeof(unsigned char))) == NULL) {
    ssp_err_quit("msg_2_tk: malloc failed\n");  
  }

  if((err = scat_get2((char*)tk->t_data, msg->scat, -1, 0, 0, tk->length)) != tk->length) {
    ssp_err_quit("msg_2_tk: scat_get2 failed\n");
  }
}

/* controller_left_group  ----------------------------------------------------------------------
   This function checks if the controller of the group left/crashed. 
-----------------------------------------------------------------------------------------------*/
static int controller_left_group(SSP_Grp *grp) {
  CKD_Alg    *ckd = (CKD_Alg *)grp->ka->info;	
  stdhash    *curr_memb = &grp->curr_membs_hash;
  stdhash_it  hit_find;
  char       *controller = ckd_get_controller_name(ckd->ctx);
    
  return stdhash_it_is_end(stdhash_find(curr_memb, &hit_find, &controller));
}

/* first_user -----------------------------------------------------------------------------------
   This function handles the key agreement when the group contains only one user. 
   It returns void, it fails if cliques fails.
---------------------------------------------------------------------------------------------- */
static void first_user(SSP_Con *con, SSP_Grp *grp) {
  int       err;
  CKD_Alg   *ckd = (CKD_Alg *)grp->ka->info;	
  char      *joiner = (char*)grp->curr_membs; 

  DEBUG_enter(f_dbg, "first_user");

  clq_destroy_ctx(&ckd->ctx);
  if((err = clq_first_user(&ckd->ctx, joiner, grp->name)) < 0){
    ssp_err_quit("first_user: clq_first_user failed  %d\n", err);
  }

  copy_key(grp);
  stddll_push_back(&con->deliv_deque, &ckd->curr_memb_msg);
  ckd->state = CKD_SECURE;
  grp->ka->key_state = ESTABLISH;
  ckd->first_cascaded_memb = SSP_TRUE;
  ckd->first_trans = SSP_TRUE; 
 
  (*grp->enc->chg_key_fcn)(grp->enc->key, grp->enc->key_len, grp->enc->info);    
  
  DEBUG_leave(f_dbg, "first_user", 0);
}

/* start_alg -----------------------------------------------------------------------------------
   This function is invoked when a cascading membership happens and the group contains more 
   than one member. It returs nothing and it exists if either cliques call or FL_unicast fails.
   Right now is not doing anything, since CKD supports only join and leave.
--------------------------------------------------------------------------------------------- */
static void start_alg(SSP_Con *con, SSP_Grp *grp) {
  DEBUG_enter(f_dbg, "start_alg");
  DEBUG_leave(f_dbg, "start_alg", 0);
}

/* handle_leave -------------------------------------------------------------------------------
   This function handles a leave.
   It returs nothing and it exists if either cliques call or FL_multicast fails.
--------------------------------------------------------------------------------------------- */
static void handle_leave(SSP_Con *con, SSP_Grp *grp, stdarr *leave_set) {
  CKD_Alg       *ckd = (CKD_Alg *)grp->ka->info;	
  CLQ_TOKEN     *tk_out = 0; 
  enum MSG_TYPE msg_type = INVALID;
  int           err, type;
  char          *leave_ptr;
  stdarr_it     ait;
  
  DEBUG_enter(f_dbg, "handle_leave");

  if(controller_left_group(grp)) {
    ckd->state = CKD_WAIT_FOR_R;
    type = CKD_R;
  }
  else {
    ckd->state = CKD_WAIT_FOR_KEY;
    type = CKD_KEY;
  }

  /* cliques processing */
  leave_ptr = *(char**)stdarr_it_val(stdarr_begin(leave_set, &ait));
  if ((err = ckd_proc_event(&ckd->ctx, leave_ptr, CKD_LEAVE, &msg_type, &tk_out)) != OK) {
    ssp_err_quit("handle_leave: ckd_proc_event failed %d\n", err);
  } 
  ON_DEBUG(fprintf(f_dbg, "ckd_proc_event returned: %d, token: %p\n", err, tk_out);)

  /* send the token */
  if (tk_out != 0) {
    if ((err = FL_multicast(con->mbox, CKD_SERVICE_TYPE, grp->name, type, tk_out->length, 
			    tk_out->t_data)) < 0) {
      FL_error(err);
      ssp_err_quit("handle_leave: FL_multicast failed %d\n", err);
    }
    clq_destroy_token(&tk_out);
    ON_DEBUG(fprintf(f_dbg, "multicated %d bytes\n", err);)
  }

  DEBUG_leave(f_dbg, "handle_leave", 0);
}


/* handle_join --------------------------------------------------------------------------------
   This function handles a join.
   It returs nothing and it exists if either cliques call or FL_multicast fails.
--------------------------------------------------------------------------------------------- */
static void handle_join(SSP_Con *con, SSP_Grp *grp, stdarr *join_set) {
  CKD_Alg       *ckd = (CKD_Alg *)grp->ka->info;
  CLQ_TOKEN     *tk_out = 0;
  enum MSG_TYPE msg_type = INVALID;
  char          *join_ptr;
  int           err;
  stdarr_it     ait;

  DEBUG_enter(f_dbg, "handle_join");

  /* cliques processing */
  join_ptr = *(char**)stdarr_it_val(stdarr_begin(join_set, &ait));
  if ((err = ckd_proc_event(&ckd->ctx, join_ptr, CKD_JOIN, &msg_type, &tk_out)) != OK) {
    ssp_err_quit("handle_join: ckd_proc_event failed %d\n", err);
  }

  /* send the token out */
  if (tk_out != 0) {
    if ((err = FL_multicast(con->mbox, CKD_SERVICE_TYPE, grp->name, CKD_R, tk_out->length, 
			    tk_out->t_data)) < 0) {
      FL_error(err);
      ssp_err_quit("handle_join: FL_multicast failed %d\n", err);
    }
    clq_destroy_token(&tk_out);
  }
  ckd->state = CKD_WAIT_FOR_R;
  
  DEBUG_leave(f_dbg, "handle_join", 0);
}


/* handle_data_msg ----------------------------------------------------------------------------- 
   This function specifies the actions taken by the state machine if the message received was
   a data message (message received from the flush layer).
-----------------------------------------------------------------------------------------------*/
static int handle_data_msg(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CKD_Alg *ckd) {
  int ret = DONT_DELIV_MSG;
  
  DEBUG_enter(f_dbg, "handle_data_msg");

  switch(ckd->state) {
  case CKD_SECURE:
    ssp_err_quit("handle_data_msg: this message should not be here");
    break;
    
  case CKD_WAIT_FOR_R:
  case CKD_WAIT_FOR_NEW_SHARE:
  case CKD_WAIT_FOR_SELF_JOIN:
    ssp_err_quit("handle_data_msg: no data message should be received in this state");
    break;

  case CKD_WAIT_FOR_KEY:
    stddll_push_back(&ckd->msg_deque, &msg);
    break;

  case CKD_WAIT_FOR_CASCADING_MEMBERSHIP:
  case CKD_WAIT_FOR_MEMBERSHIP:
    ret = DELIV_MSG;
    break;
  }

  DEBUG_leave(f_dbg, "handle_data_msg", ret);
  return ret;
}


/* handle_r ------------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a 'R' message.
---------------------------------------------------------------------------------------------- */
static int handle_r(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CKD_Alg *ckd) {
  int        ret = DONT_DELIV_AND_FREE_MSG, err;
  CLQ_TOKEN  tk_in = {0};
  CLQ_TOKEN  *tk_out = 0; 

  DEBUG_enter(f_dbg, "handle_r");

  switch(ckd->state) {
  case CKD_WAIT_FOR_R:
    msg_2_tk(msg, &tk_in);
    
    if ((err = ckd_comp_new_share(ckd->ctx, &tk_in, &tk_out)) != OK) {
      ssp_err_quit("handle_r: ckd_comp_new_share failed %d\n", err);
    }
    
    if (tk_out != 0) {
      if ((err = FL_unicast(con->mbox, CKD_SERVICE_TYPE, grp->name, ckd_get_controller_name(ckd->ctx), 
			    CKD_NEW_SHARE, tk_out->length, tk_out->t_data)) < 0) {
	FL_error(err);
	ssp_err_quit("handle_r: FL_multicast failed\n");
      }
      clq_destroy_token(&tk_out);
    } 

    if (!strcmp(ckd_get_controller_name(ckd->ctx), con->priv_name)) { /* controller */
      ckd->state = CKD_WAIT_FOR_NEW_SHARE;
    } 
    else { 
      ckd->state = CKD_WAIT_FOR_KEY;
    }
    break;
    
  case CKD_SECURE:
  case CKD_WAIT_FOR_KEY:
  case CKD_WAIT_FOR_NEW_SHARE:
    ssp_err_quit("handle_r: key in wrong state!");
    break;

  case CKD_WAIT_FOR_CASCADING_MEMBERSHIP:
    ret = DONT_DELIV_AND_FREE_MSG;
    break;

  case CKD_WAIT_FOR_SELF_JOIN:
  case CKD_WAIT_FOR_MEMBERSHIP:
    break;
  }
  
  DEBUG_leave(f_dbg, "handle_r", ret);
  return ret;
}


/* handle_new_share ----------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a 'new share' message.
---------------------------------------------------------------------------------------------- */
static int handle_new_share(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CKD_Alg *ckd) {
  int        ret = DONT_DELIV_AND_FREE_MSG, err;
  CLQ_TOKEN  tk_in = {0}; 
  CLQ_TOKEN  *tk_out = 0; 
 
  DEBUG_enter(f_dbg, "handle_new_share");

  switch(ckd->state) {
  case CKD_WAIT_FOR_NEW_SHARE:
    msg_2_tk(msg, &tk_in);
   
    if ((err = ckd_generates_key(ckd->ctx, msg->sender, &tk_in, &tk_out)) != OK) {
      ssp_err_quit("handle_new_share: ckd_generates_key failed %d\n", err);
    }
    
    if (tk_out != 0) { /* multicast */
      if ((err = FL_multicast(con->mbox,  CKD_KL_TYPE, grp->name, CKD_KEY, 
			      tk_out->length, tk_out->t_data)) < 0) {
	FL_error(err);
	ssp_err_quit("handle_new_share: multicast failed %d\n", err);
      }
      
      ckd->state = CKD_WAIT_FOR_KEY;
      clq_destroy_token(&tk_out);
    } 
    break;
    
  case CKD_SECURE:
  case CKD_WAIT_FOR_KEY:
  case CKD_WAIT_FOR_R:
    ssp_err_quit("handle_new_share: key in wrong state!");
    break;

  case CKD_WAIT_FOR_CASCADING_MEMBERSHIP:
    ret = DONT_DELIV_AND_FREE_MSG;
    break;

  case CKD_WAIT_FOR_SELF_JOIN:
  case CKD_WAIT_FOR_MEMBERSHIP:
    break;

  }
  
  DEBUG_leave(f_dbg, "handle_new_share", ret);
  return ret;
}


/* handle_key ----------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a key message.
---------------------------------------------------------------------------------------------- */
static int handle_key(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CKD_Alg *ckd) {
  int        ret = DONT_DELIV_AND_FREE_MSG, err;
  CLQ_TOKEN  tk_in = {0}; 
  SSP_Msg    *msg_tmp;
  stddll_it  lit;

  DEBUG_enter(f_dbg, "handle_key");

  switch(ckd->state) {
  case CKD_WAIT_FOR_KEY:
    if(ckd->vs_trans == SSP_FALSE) {
      msg_2_tk(msg, &tk_in);

      if ((err = ckd_get_session_key(ckd->ctx, &tk_in)) != OK) {
	ssp_err_quit("handle_key: ckd_get_session_key failed %d\n", err);
      }	

      /* getting ready to install ...*/
      copy_key(grp);      
      grp->ka->key_state = ESTABLISH;      
      (*grp->enc->chg_key_fcn)(grp->enc->key, grp->enc->key_len, grp->enc->info);
     
      if(Is_caused_network_mess(ckd->curr_memb_msg->serv_type)) {
	set_vs_set_memb_msg(ckd->curr_memb_msg, grp); 
      }

      /* move all the message in the connection queue, first the new secure memb. */
      stddll_push_back(&con->deliv_deque, &ckd->curr_memb_msg);
      for(stddll_begin(&(ckd->msg_deque), &lit); !stddll_it_is_end(&lit); 
	  stddll_it_next(&lit)) {
	msg_tmp = *(SSP_Msg**) stddll_it_val(&lit);
	if(Is_encrypt_mess_type(msg_tmp->msg_type)) {   
	  if(Dec_Scat(msg_tmp->scat, grp->enc->dec_fcn, grp->enc->block_size, grp->enc->info, 
		      (unsigned int) msg_tmp->msg_len, &msg->msg_type, msg->endian_mism) < 0) {
	    ssp_err_quit("handle_key: Dec_Scat failed!\n");
	  }
	} 
	if(Is_reg_memb_mess(msg_tmp->serv_type)) {
	  ssp_err_quit("handle_key: membeship message in the ka queue\n ");
	}
	stddll_push_back(&con->deliv_deque, &msg_tmp);
      }

      ckd->state = CKD_SECURE;
      ckd->first_trans = SSP_TRUE;
      ckd->first_cascaded_memb = SSP_TRUE;
      stddll_clear(&(ckd->msg_deque));
      if(ckd->kl_got_fl_req == SSP_TRUE) {
	ckd->wait_for_sec_fl_ok = SSP_TRUE;
	gen_and_push_msg(con, grp, FLUSH_REQ_MESS); /* push flush request in the connection queue */
      }
      if(tk_in.t_data) {
	free(tk_in.t_data);
	tk_in.t_data = NULL;
      } 
    }
    /* key agreement internal messages should not be delivered to the app. */
    if(ret > 0) {
      ret = DONT_DELIV_AND_FREE_MSG;
    }
    
    break;
    
  case CKD_SECURE:
  case CKD_WAIT_FOR_R:
  case CKD_WAIT_FOR_NEW_SHARE:
    ssp_err_quit("handle_key: key in wrong state!");
    break;

  case CKD_WAIT_FOR_CASCADING_MEMBERSHIP:
    ret = DONT_DELIV_AND_FREE_MSG;
    break;

  case CKD_WAIT_FOR_SELF_JOIN:
  case CKD_WAIT_FOR_MEMBERSHIP:
    break;
  }
  
  DEBUG_leave(f_dbg, "handle_key", ret);
  return ret;
}

/* handle_trans ---------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a transitional message.
---------------------------------------------------------------------------------------------- */
static int handle_trans(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CKD_Alg *ckd) {
  int ret = DONT_DELIV_MSG;

  DEBUG_enter(f_dbg, "handle_trans");

  switch(ckd->state) {
  case CKD_SECURE:
    ckd->first_trans = SSP_FALSE;
    ckd->vs_trans = SSP_TRUE;
    ret = DELIV_MSG;
    break;

  case CKD_WAIT_FOR_R:
  case CKD_WAIT_FOR_NEW_SHARE:
  case CKD_WAIT_FOR_CASCADING_MEMBERSHIP:
  case CKD_WAIT_FOR_MEMBERSHIP:
    if(ckd->first_trans == SSP_TRUE) {
      ckd->first_trans = SSP_FALSE;
      ret = DELIV_MSG;
    }
    ckd->vs_trans = SSP_TRUE;
    break;
  
  case CKD_WAIT_FOR_KEY:
    if(ckd->first_trans == SSP_TRUE) {
      ckd->first_trans = SSP_FALSE;
      ret = DELIV_MSG;
    }
    ckd->state = CKD_WAIT_FOR_CASCADING_MEMBERSHIP;
    ckd->vs_trans = SSP_TRUE;
    break; 

  case CKD_WAIT_FOR_SELF_JOIN:
    ssp_err_quit("handle_trans: trans received in wrong state, %d!\n", ckd->state);
    break;
  }
  
  DEBUG_leave(f_dbg, "handle_trans", ret);
  return ret;
}


/* handle_memb ----------------------------------------------------------------------------------
  This function specifies the actions taken by the state machine if the message received was
  a group membership.

  Some comments:
      a member in the WAIT_FOR_SELF_JOIN can receive 2 type of events: a membership due to its 
      own join (a join event) or a membership due to a network event (in this case the joinee 
      is on the list of new added members. Flush delivers this special network in some cases:
      -  a partiton happen after the join and before the new membership is delivered
      -  the join happened while a previous partition was processed, so the two events are
         combined in one
      -  somebody left immediately after my join. Since flush membership deliveries are based
         on gathering flush_oks from old members, if the guy that left did not send his 
         flush_ok, the two events will be combined. Note that if he managed to send his
         flush_ok, then the join will be delivered first, then the leave.
---------------------------------------------------------------------------------------------- */
static int handle_memb(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CKD_Alg *ckd) {
  int    ret = DONT_DELIV_MSG, was_leave = 0, err = 0;
  stdarr join_set;
  stdarr leave_set;

  DEBUG_enter(f_dbg, "handle_memb");
  
  stdarr_construct(&leave_set, sizeof(char*));
  stdarr_construct(&join_set, sizeof(char*));

  switch(ckd->state) {
  case CKD_SECURE:
  case CKD_WAIT_FOR_R:
  case CKD_WAIT_FOR_NEW_SHARE:
  case CKD_WAIT_FOR_KEY: 
    ssp_err_quit("handle_memb: memb received in wrong state, %d!\n", ckd->state);
    break;
    
  case CKD_WAIT_FOR_CASCADING_MEMBERSHIP:
    /* right now cascaded not supported, just exit */
    ssp_err_quit("Cascaded membership happend, not handled yet.\n");

    if(ckd->first_cascaded_memb == SSP_TRUE) {
      ckd->first_cascaded_memb = SSP_FALSE;
      init_vs_set(grp); 
    }
    was_leave = upd_vs_set_and_get_join_leave_set(grp, msg->serv_type, &join_set, &leave_set);
    if (was_leave  && (ckd->first_trans == SSP_TRUE)) {
      ckd->first_trans = SSP_FALSE;
      gen_and_push_msg(con, grp, TRANSITION_MESS);
    }

    ckd->curr_memb_msg = msg; /* delay delivery of memb  */
    ckd->curr_memb_msg->serv_type = REG_MEMB_MESS | CAUSED_BY_NETWORK; /* memb. collapsed  */

    grp->ka->key_state = NOT_ESTABLISH;
    if(stdhash_size(&grp->curr_membs_hash) > 1) {
      start_alg(con, grp);
    }
    else {
      first_user(con, grp);
    }
    ret = DONT_DELIV_MSG;
    ckd->vs_trans = SSP_FALSE;
    break;

  case CKD_WAIT_FOR_SELF_JOIN:
    grp->ka->key_state = NOT_ESTABLISH;
    
    init_vs_set(grp); 
    was_leave = upd_vs_set_and_get_join_leave_set(grp, msg->serv_type, &join_set, &leave_set);
    ckd->first_cascaded_memb = SSP_FALSE;
    
    ckd->curr_memb_msg = msg;  /* delay delivery of memb  */

    if(stdhash_size(&grp->curr_membs_hash) > 1) {
      if(Is_reg_memb_mess(msg->serv_type)) {
	if(Is_caused_join_mess(msg->serv_type)) {
	  if((err = clq_new_user(&ckd->ctx, con->priv_name, grp->name, FALSE)) < 0) {
	    ssp_err_quit("handle_memb: clq_new_user failed %d\n", err);  	
	  }
	  ckd->state = CKD_WAIT_FOR_R;	
	}	      
	else if(Is_caused_leave_mess(msg->serv_type) || Is_caused_disconnect_mess(msg->serv_type)) {
	  ssp_err_quit("handle_memb: leave or disconnect in the wrong state %d\n", 
		       ckd->state);
	}
	else if(Is_caused_network_mess(msg->serv_type)) {
	  ssp_err_quit("handle_memb: network in self join, not handled yet %d\n", err);  
	}
      }
    }
    else {
      first_user(con, grp);
    }
    ckd->vs_trans = SSP_FALSE;
    break;
    
  case CKD_WAIT_FOR_MEMBERSHIP:
    grp->ka->key_state = NOT_ESTABLISH;
    ckd->first_cascaded_memb = SSP_FALSE;
    
    init_vs_set(grp); 
    was_leave = upd_vs_set_and_get_join_leave_set(grp, msg->serv_type, &join_set, &leave_set);
    
    ckd->curr_memb_msg = msg; /* delay delivery of memb  */
    
    if(stdhash_size(&grp->curr_membs_hash) > 1) {
      if(stdarr_size(&leave_set) > 1) { /* count the NULL too */
	if(stdarr_size(&join_set) <= 1) {  /* only partition or leave, count the NULL too  */
	  if(Is_caused_leave_mess(msg->serv_type)) { /* if I am here I am an old member */
	    handle_leave(con, grp, &leave_set);
	  }
	  else {
	    handle_leave(con, grp, &leave_set); /* leave and partition are similar */
	  }	 
	}
	else {
	  ssp_err_quit("handle_memb: combined leave and merge not handle yet\n");
	}
      }
      else { /*  merge &  join */
	if(Is_caused_join_mess(msg->serv_type)) { /* if I am here I am an old member */
	  handle_join(con, grp, &join_set);
	}
	else {
	  ssp_err_quit("handle_memb: merge not handle yet\n");	  
	}
      }
    }  
    else { /* alone  */
      first_user(con, grp);
    }
    ckd->vs_trans = SSP_FALSE;
    break;
  }

  stdarr_destruct(&leave_set);  
  stdarr_destruct(&join_set);      

  DEBUG_leave(f_dbg, "handle_memb", ret);
  return ret;
}
 

/* handle_fl_req -------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a flush request message.
---------------------------------------------------------------------------------------------- */
static int handle_fl_req(SSP_Con *con, SSP_Grp *grp, SSP_Msg *mess, CKD_Alg *ckd) {
  int ret = DONT_DELIV_AND_FREE_MSG;

  DEBUG_enter(f_dbg, "handle_fl_req");

  switch(ckd->state) {
  case CKD_SECURE:
    ckd->wait_for_sec_fl_ok = SSP_TRUE;
    ret = DELIV_MSG; 
    break;

  case CKD_WAIT_FOR_R:
  case CKD_WAIT_FOR_NEW_SHARE:
  case CKD_WAIT_FOR_KEY:
    ssp_err_quit("Cascading membership happend, not handled yet.");
    break;
  
  case CKD_WAIT_FOR_SELF_JOIN:
  case CKD_WAIT_FOR_MEMBERSHIP:
  case CKD_WAIT_FOR_CASCADING_MEMBERSHIP:
    ssp_err_quit("handle_fl_req: fl_req received in wrong state, not possible !");
    break;

  }

  DEBUG_leave(f_dbg, "handle_fl_req", ret);
  return ret;
}


/* ============================  wrapper functions for CKD  ==================================== */

/* CKD_handles_mess ------------------------------------------------------------------------------
   This function specifies if a spread message is used or not by the key agreement algorithm.
   All the messages specified here will be redirected by spread to CKD_Comp_Key_Wrapper;
   In this case, all the membership messages (including transitional messages) are send,
   Also the regular messages used internal by the key agreement algorithm 
   and regular messages received between having a stable key, are sent here.
-----------------------------------------------------------------------------------------------*/
int CKD_handles_msg(SSP_Msg *msg, SSP_Grp *grp) {
  service serv_type = msg->serv_type;
  int     msg_type  = msg->msg_type;
  
  return  !Is_regular_mess(serv_type) ||  grp->ka->key_state == NOT_ESTABLISH ||
    msg_type == CKD_R || msg_type == CKD_NEW_SHARE  || msg_type == CKD_KEY;
}


/* CKD_handle_recv ----------------------------------------------------------------------------
   This function is implementing the state machine for the key agreement algorithm. 
   It returns 1 if the message must be delivered by the SSP, 0 otherwise. The SSP can check if 
   the key agreement finished by looking and Key_State.
-----------------------------------------------------------------------------------------------*/
int CKD_handle_recv(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg) {
  int  ret = DELIV_MSG;
  CKD_Alg *ckd = (CKD_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "CKD_handle_recv");
  
  if(Is_regular_mess(msg->serv_type)) {
    if(Is_r_msg(msg->msg_type)) {
      ret = handle_r(con, grp, msg, ckd);
    }
    else if(Is_new_share_msg(msg->msg_type)) {
      ret = handle_new_share(con, grp, msg, ckd);
    }
    else if(Is_key_msg(msg->msg_type)) {
      ret = handle_key(con, grp, msg, ckd);
    }
    else {
      ret = handle_data_msg(con, grp, msg, ckd);
    }
  }
  else if(Is_flush_req_mess(msg->serv_type)) {
    ret = handle_fl_req(con, grp, msg, ckd);
  }
  else if(Is_membership_mess(msg->serv_type)) {
    if(Is_self_leave_mess(msg->serv_type)) {
      ;
    }
    else if(Is_transition_mess(msg->serv_type)) {
      ret = handle_trans(con, grp, msg, ckd);
    }
    else {
      ret = handle_memb(con, grp, msg, ckd);
    }
  }

  DEBUG_leave(f_dbg, "CKD_handle_recv", ret);
  return ret;  
}

/* CKD_handle_fl_ok ----------------------------------------------------------------------------
   This function specifies the action taken by the key agreement state machine if a flush
   ok event happen. This is actually Secure_Flush_Ok, sent by the user using SSP_Flush, 
   which does not sent the flush okinvoking directlly FL_flush, but calls this function to 
   handle it.
-----------------------------------------------------------------------------------------------*/
int CKD_handle_fl_ok(SSP_Con *con, SSP_Grp *grp){
  int  ret = DELIV_MSG;
  CKD_Alg *ckd = (CKD_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "CKD_handle_fl_ok");
  
  switch(ckd->state) {
  case CKD_SECURE:
    if(ckd->wait_for_sec_fl_ok == SSP_TRUE) {
      ckd->wait_for_sec_fl_ok = SSP_FALSE;      
      if ((ret = FL_flush(con->mbox, grp->name)) == CONNECTION_CLOSED || ret == ILLEGAL_SESSION) {
	FL_error(ret);
	goto end;
      }
      ckd->state = CKD_WAIT_FOR_MEMBERSHIP;
    }
    else {
      ret = FLUSH_OK_ALREADY_SENT;
    }
    break;
    
  case CKD_WAIT_FOR_R:
  case CKD_WAIT_FOR_NEW_SHARE:
  case CKD_WAIT_FOR_KEY:
  case CKD_WAIT_FOR_CASCADING_MEMBERSHIP:
  case CKD_WAIT_FOR_MEMBERSHIP:
  case CKD_WAIT_FOR_SELF_JOIN:
    ret = FLUSH_OK_ALREADY_SENT;
    break;    
  }
  
 end:
  DEBUG_leave(f_dbg, "CKD_handle_fl_ok", ret);
  return ret;
  
}

/* CKD_handle_send ----------------------------------------------------------------------------
   This function specifies the actions taken by the key agreement state machine, if the event
   that happen is a 'user' message. The event is caused by a user calling SSP_scat_multicast
   or SSP_multicast. Right now this function is not handling the sending, it just allows the
   sending of the message or not. The user is not allowed to send messages while the key 
   agreement is performing.
-----------------------------------------------------------------------------------------------*/
int CKD_handle_send(SSP_Con *con, SSP_Grp *grp) {
  int  ret = DELIV_MSG;
  CKD_Alg *ckd = (CKD_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "CKD_handle_send");

  switch(ckd->state) {
  case CKD_SECURE:
    ret = SEND_MSG;
    break;

  case CKD_WAIT_FOR_R:
  case CKD_WAIT_FOR_NEW_SHARE:
  case CKD_WAIT_FOR_KEY:
  case CKD_WAIT_FOR_CASCADING_MEMBERSHIP:
  case CKD_WAIT_FOR_MEMBERSHIP:
  case CKD_WAIT_FOR_SELF_JOIN:
    ret = DONT_SEND_MSG;
    break;
  }

  DEBUG_leave(f_dbg, "CKD_handle_send", ret);
  return ret;

}














