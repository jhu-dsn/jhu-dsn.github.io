/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */










/***********************************************************************************************/
/* clq_alg.c                                                                                   */
/* Implements the GDH group  key agreement algorithm.                                          */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: July 9, 1999                                                                       */
/* Modified: Jun 30, 2000 by Cristina Nita-Rotaru                                              */
/* Modified: Nov 3, 2000 by Cristina Nita-Rotaru - alg robust                                  */
/* Modified: Feb. 15, 2001 by CNR - CKD implem.                                                */
/* Modified: Aug. 10, 2002 by CNR - separate CKD from GDH                                      */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "clq_alg.h"
#include "ssp_info.h"
#include "scatter.h"
#include "scatter_cryptor.h"
#include "ssp.h"
#include "utility.h"
#include "ssp_dbg.h"
#include "ssp_p.h"
#include "ssp_error.h"

#include <stdutil/stdhash.h>

#include "clq_merge.h"
#include "clq_api_misc.h"
#include "ckd_api.h"
#include "error.h"

#include "fl.h"

#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif

extern FILE *f_dbg;

/* ============================  cliques algorithm specific  ================================= */

/* CLQ_Alg_init  -------------------------------------------------------------------------------
   It initializes a CLQ_Alg data structure
---------------------------------------------------------------------------------------------- */
static void CLQ_Alg_init(CLQ_Alg *clq) {
  clq->ctx = 0;
  stddll_construct(&(clq->msg_deque), sizeof(SSP_Msg*));
  clq->first_trans = SSP_TRUE; 
  clq->vs_trans = SSP_FALSE;
  clq->wait_for_sec_fl_ok = SSP_FALSE;
  clq->kl_got_fl_req = SSP_FALSE;
  clq->first_cascaded_memb = SSP_TRUE;
  clq->vs_set = 0;
  stdhash_construct(&clq->vs_set_hash, sizeof(char*), 0, grp_name_ptr_eq, grp_name_ptr_hashcode);
  clq->curr_memb_msg = 0;
  clq->state = CLQ_WAIT_FOR_SELF_JOIN; 
}

/* CLQ_Alg_destroy -----------------------------------------------------------------------------
   It frees any memory used by CLQ_Alg.
---------------------------------------------------------------------------------------------- */
static void CLQ_Alg_destroy(CLQ_Alg *clq) {
  stddll_it lit;
  SSP_Msg *msg = 0;
  
  for(stddll_begin(&(clq->msg_deque), &lit); !stddll_it_is_end(&lit); stddll_it_next(&lit)) {
    msg = *(SSP_Msg**) stddll_it_val(&lit);
    SSP_Msg_free(&msg);
  }
  stddll_destruct(&(clq->msg_deque));

  clq_destroy_ctx(&clq->ctx);

  if(clq->vs_set) {
    free(clq->vs_set);
    clq->vs_set = NULL;
  }
  stdhash_destruct(&clq->vs_set_hash);  
}

/* CLQ_Alg_create  ------------------------------------------------------------------------------
   It allocates and initializes a CLQ_Alg data structure. It returns a pointer to the newly
   created object.
---------------------------------------------------------------------------------------------- */
CLQ_Alg * CLQ_Alg_create() {
  CLQ_Alg * clq = (CLQ_Alg*) malloc(sizeof(CLQ_Alg));
    
  if(!clq) {
    ssp_err_quit("CLQ_Alg_create: malloc failed \n");
  }
  CLQ_Alg_init(clq);

  return clq;
}

/* CLQ_Alg_free ---------------------------------------------------------------------------------
   It frees a CLQ_Alg data structure.
---------------------------------------------------------------------------------------------- */
void CLQ_Alg_free(CLQ_Alg **clq) {
  if (*clq) {
    CLQ_Alg_destroy(*clq);
    free(*clq);
    *clq = NULL;
  } 
}

/* ============================  helper functions  =========================================== */

/* copy_key  ------------------------------------------------------------------------------------
   Helper function that copies the key from the cliques context in the encryption info.
-----------------------------------------------------------------------------------------------*/
static int copy_key(SSP_Grp *grp) {
  CLQ_Alg *clq = (CLQ_Alg*)(grp->ka->info);
  
  memcpy(grp->enc->key, clq->ctx->group_secret_hash, grp->enc->key_len);
  
  ON_DEBUG (
    { 
      int i;
      fprintf(f_dbg, "The key is: 0x");
      for (i = 0; i < grp->enc->key_len; i++){
        fprintf(f_dbg, "%02X", ((unsigned char*)(grp->enc->key))[i]);
      }
      fprintf(f_dbg, "\n");
    }
  )

  return 0;
}

/* msg_2_tk  -----------------------------------------------------------------------------------
   This function copies a spread message into a cliques token. For a partial token or
   final token it attaches the service in the beginning.
---------------------------------------------------------------------------------------------- */
static void msg_2_tk(SSP_Msg *msg, CLQ_TOKEN *tk, service *serv) {
  int err, length = 0, offset = 0;

  if(Is_partial_token_msg(msg->msg_type) || Is_final_token_msg(msg->msg_type)) {
    length = msg->msg_len - sizeof(service);
    offset = sizeof(service);

    err = scat_get2((char*)serv, msg->scat, -1, 0, 0, sizeof(service));
    if(err != sizeof(service)) {
      ssp_err_quit("msg_2_tk: scat_get2 failed\n");
    }
  }
  else if(Is_fact_out_msg(msg->msg_type) || Is_key_list_msg(msg->msg_type)) {
    length = msg->msg_len; 
    offset = 0;
  }
  else {
    ssp_err_quit("msg_2_tk: Unknown token type\n");
  }

  tk->length = length; 
  tk->t_data = (unsigned char*) malloc(tk->length * sizeof(unsigned char));
  if(!tk->t_data) {
    ssp_err_quit("msg_2_tk: malloc failed\n");  
  }

  err = scat_get2((char*)tk->t_data, msg->scat, -1, 0, offset, tk->length);
  if(err != tk->length) {
    ssp_err_quit("msg_2_tk: scat_get2 failed\n");
  }
}


/* tk_2_msg  -----------------------------------------------------------------------------------
   It converts a token to a message. It allocates a buffer if necessary. Alloc specifies if 
   the function allocated or not new memory and set the buf pointer:
   alloc   1, then memory was allocated and the caller needs to free it
   alloc   0, then memory was not allocated, the fuction just set the pointer.
   It returns the length of the message.
---------------------------------------------------------------------------------------------- */
static int tk_2_msg(char **buf, CLQ_TOKEN *tk, int16 msg_type, service serv_type, int *alloc) {
  int msg_len;

  if(Is_partial_token_msg(msg_type) || Is_final_token_msg(msg_type)) {
    *buf = (unsigned char*) malloc(tk->length * sizeof(unsigned char) + sizeof(service));
    if(!(*buf)) {
      ssp_err_quit("tk_2_msg: malloc failed\n");  
    }
    *alloc = 1;
    memcpy(*buf, &serv_type, sizeof(service));
    memcpy(*buf + sizeof(service), tk->t_data, tk->length);
    msg_len = tk->length + sizeof(service);
  }
  else if(Is_fact_out_msg(msg_type) || Is_key_list_msg(msg_type)) {
    msg_len = tk->length;
    *buf = tk->t_data;
    *alloc = 0;
  }
  else {
    ssp_err_quit("tk_2_msg: Unknown token type\n");
  }

  return msg_len;
}


/* move_msg_con_deque  --------------------------------------------------------------------------
   This function is called when a secure memb. will be installed. It moves all the messages 
   from the key agreement queue in the connection delivery queue.
---------------------------------------------------------------------------------------------- */
static void move_msg_con_deque(SSP_Con *con, SSP_Grp *grp) {
  CLQ_Alg     *clq = (CLQ_Alg *)grp->ka->info;	
  SSP_Msg     *msg_tmp;
  stddll_it   lit;
  
  DEBUG_enter(f_dbg, "move_msg_con_deque");

  for(stddll_begin(&(clq->msg_deque), &lit); !stddll_it_is_end(&lit); stddll_it_next(&lit)) {
    msg_tmp = *(SSP_Msg**) stddll_it_val(&lit);
    if(Is_encrypt_mess_type(msg_tmp->msg_type)) {   
      if(Dec_Scat(msg_tmp->scat, grp->enc->dec_fcn, grp->enc->block_size, grp->enc->info, 
		  (unsigned int) msg_tmp->msg_len, &msg_tmp->msg_type, msg_tmp->endian_mism) < 0) {
	ssp_err_quit("move_msg_con_deque: Dec_Scat failed!\n");
      }
    } 
    if(Is_reg_memb_mess(msg_tmp->serv_type)) {
      ssp_err_quit("move_msg_con_deque: membership message in the ka queue\n ");
    }
    stddll_push_back(&con->deliv_deque, &msg_tmp);
  }
  stddll_clear(&(clq->msg_deque));

  DEBUG_leave(f_dbg, "move_msg_con_deque", 0);
}


/* ============================  state machine functions for cliques  ======================== */

/* first_user -----------------------------------------------------------------------------------
   This function handles the key agreement when the group contains only one user. 
   It returns void, it fails if cliques fails.
---------------------------------------------------------------------------------------------- */
static void first_user(SSP_Con *con, SSP_Grp *grp) {
  int       err;
  CLQ_Alg   *clq = (CLQ_Alg *)grp->ka->info;	
  char      *joiner = (char*)grp->curr_membs; 

  DEBUG_enter(f_dbg, "first_user");

  clq_destroy_ctx(&clq->ctx);
  if((err = clq_first_user(&clq->ctx, joiner, grp->name)) < 0){
    ssp_err_quit("first_user: clq_first_user failed  %d\n", err);
  }

  copy_key(grp);
  stddll_push_back(&con->deliv_deque, &clq->curr_memb_msg);
  clq->state = CLQ_SECURE;
  grp->ka->key_state = ESTABLISH;
  clq->first_cascaded_memb = SSP_TRUE;
  clq->first_trans = SSP_TRUE; 
  (*grp->enc->chg_key_fcn)(grp->enc->key, grp->enc->key_len, grp->enc->info);    
  
  DEBUG_leave(f_dbg, "first_user", 0);
}


/* start_alg -----------------------------------------------------------------------------------
   This function is invoked when a cascading membership happens and the group contains more 
   than one member. It returs nothing and it exists if either cliques call or FL_unicast fails.
--------------------------------------------------------------------------------------------- */
static void start_alg(SSP_Con *con, SSP_Grp *grp) {
  int        err;
  CLQ_Alg    *clq = (CLQ_Alg *)grp->ka->info;	
  char       *chosen_name=0, *tmp = 0;
  stdarr     merge_set;
  stdhash    *curr = &grp->curr_membs_hash;
  stdhash_it hit;	
  stdarr_it  ait;
  char       **merge_set_ptr=0;
  CLQ_TOKEN  *tk_out = NULL;
  int        msg_len;
  char       *msg_buf = 0;
  int        alloc = 0;

  DEBUG_enter(f_dbg, "start_alg");

  stdarr_construct(&merge_set, sizeof(char*));
  clq_destroy_ctx(&clq->ctx);
  choose(&chosen_name, grp);
  if(strcmp(chosen_name, con->priv_name) == 0) {
    if((err = clq_first_user(&clq->ctx, con->priv_name, grp->name)) < 0){
      ssp_err_quit("start_alg: clq_first_user failed  %d\n", err);
    }  

    for(stdhash_begin(curr, &hit); !stdhash_it_is_end(&hit); stdhash_it_next(&hit)) {
      char *name = *(char**)stdhash_it_key(&hit);
   
      if(strcmp(name, con->priv_name) != 0) {
	stdarr_push_back(&merge_set, stdhash_it_key(&hit));
      }
    }
    stdarr_push_back(&merge_set, &tmp);        /* NULL terminate for CLQs */

    merge_set_ptr = (char**)stdarr_it_val(stdarr_begin(&merge_set, &ait));
    if(((err = clq_update_key(clq->ctx, merge_set_ptr, NULL, &tk_out)) < 0) || !tk_out) {
      ssp_err_quit("start_alg: clq_update_key failed %d\n", err);
    }   

    msg_len = tk_2_msg(&msg_buf, tk_out, CLQ_PARTIAL_TOKEN, clq->curr_memb_msg->serv_type, 
		       &alloc);
    if((err = FL_unicast(con->mbox, CLQ_SERVICE_TYPE, grp->name, clq_get_next_username(clq->ctx),
			 CLQ_PARTIAL_TOKEN, msg_len, msg_buf)) < 0) {
      FL_error(err);
      ssp_err_quit("start_alg: FL_unicast failed %d\n", err);
    }

    clq->state = CLQ_WAIT_FOR_FINAL_TOKEN;
    
    ON_DEBUG(
      fprintf(f_dbg, "------>  %s I am chosen\n", con->priv_name);
      fprintf(f_dbg, "This is the merge list:\n");
      for (stdarr_begin(&merge_set, &ait); !stdarr_it_is_end(&ait); stdarr_it_next(&ait)) { 
	fprintf(f_dbg, "%s\n", *(char**) stdarr_it_val(&ait));
      }
      fprintf(f_dbg, "partial token sent to %s, move to CLQ_WAIT_FOR_FINAL_TOKEN state\n", 
	      clq_get_next_username(clq->ctx));
    )
  }
  else {
    if((err = clq_new_user(&clq->ctx, con->priv_name, grp->name, FALSE)) < 0) {
      ssp_err_quit("start_alg: clq_new_user failed %d\n", err);  	
    }
    clq->state = CLQ_WAIT_FOR_PARTIAL_TOKEN;

    ON_DEBUG(
      fprintf(f_dbg, "--------------------> %s I am not chosen\n", con->priv_name);
      fprintf(f_dbg, "erase clq ctx, move to CLQ_WAIT_FOR_PARTIAL_TOKEN state\n");
    )
  }
  
  if(alloc && msg_buf) {
    free(msg_buf);
  }
  clq_destroy_token(&tk_out);
  stdarr_destruct(&merge_set);

  DEBUG_leave(f_dbg, "start_alg", 0);
}

/* handle_leave_or_partition -------------------------------------------------------------------
   This function handles a leave or a partition (the fast way clq_leave + broadcast)
   It returs nothing and it exists if either cliques call or FL_unicast fails.

   Note: all the members can call clq_leave, only for the controller the function will
   return a valid token.
--------------------------------------------------------------------------------------------- */
static void handle_leave_or_partition(SSP_Con *con, SSP_Grp *grp, stdarr *leave_set) {
  int        err, alloc = 0;
  CLQ_Alg    *clq = (CLQ_Alg *)grp->ka->info;	
  char       **leave_set_ptr;
  CLQ_TOKEN  *tk_out = 0;
  stdarr_it  ait;
  int        msg_len;
  char*      msg_buf=0;

  DEBUG_enter(f_dbg, "handle_leave_or_partition");
  
  leave_set_ptr = (char**)stdarr_it_val(stdarr_begin(leave_set, &ait));
  if((err = clq_leave(&clq->ctx, leave_set_ptr, &tk_out, 1)) < 0 && err != NOT_CONTROLLER) {
    ssp_err_quit("handle_leave_or_partition: clq_leave failed %d\n", err);
  }

  if(tk_out) {
    msg_len = tk_2_msg(&msg_buf, tk_out, CLQ_KEY_LIST, clq->curr_memb_msg->serv_type, &alloc);
    if ((err = FL_multicast(con->mbox, CLQ_KL_TYPE, grp->name, CLQ_KEY_LIST, msg_len, msg_buf))
	< 0) {
      FL_error(err);
      ssp_err_quit("handle_leave_or_partition: FL_multicast failed %d\n", err);
    }
  }
  clq->state = CLQ_WAIT_FOR_KEY_LIST;
  
  if(alloc && msg_buf) {
    free(msg_buf);
  }
  clq_destroy_token(&tk_out);

  DEBUG_leave(f_dbg, "handle_leave_or_partition", 0);
}


/* handle_merge_and_partition -----------------------------------------------------------------
   This function handles a combined event, parition + merge
   It returs nothing and it exists if cliques call fail.
--------------------------------------------------------------------------------------------- */
static void handle_merge_and_partition(SSP_Con *con, SSP_Grp *grp, stdarr *merge_set, 
				      stdarr *leave_set) {
  int        err, alloc = 0;
  CLQ_Alg    *clq = (CLQ_Alg *)grp->ka->info;	
  char       **leave_set_ptr = 0;
  char       **merge_set_ptr = 0; 
  CLQ_TOKEN  *tk_out = 0;
  stdarr_it  ait;
  int        msg_len;
  char       *msg_buf = 0;

  DEBUG_enter(f_dbg, "handle_merge_and_partition");
  
  if(is_old_member(grp)) {
    ON_DEBUG(fprintf(f_dbg, " ------------- OLD member ----------- \n");)
   
    /* first remove the leave list  */
    leave_set_ptr = (char**)stdarr_it_val(stdarr_begin(leave_set, &ait));
    if((err = clq_leave(&clq->ctx, leave_set_ptr, &tk_out, 0)) < 0 && err != NOT_CONTROLLER) {
      ssp_err_quit("handle_leave_or_partition: clq_leave failed %d\n", err);
    }
    
    /* now start the merge  */
    if(tk_out) {
      clq_destroy_token(&tk_out);
      
      merge_set_ptr = (char**)stdarr_it_val(stdarr_begin(merge_set, &ait));
      if((err = clq_update_key(clq->ctx, merge_set_ptr, NULL, &tk_out)) < 0 
	 && err != NOT_CONTROLLER ) {  
	ssp_err_quit("handle_merge_and_partition: clq_update_key failed %d\n", err);
      }  
      
      if(tk_out) {
	msg_len = tk_2_msg(&msg_buf, tk_out, CLQ_PARTIAL_TOKEN, 
			   clq->curr_memb_msg->serv_type, &alloc);
	if((err = FL_unicast(con->mbox, CLQ_SERVICE_TYPE, grp->name, 
			     clq_get_next_username(clq->ctx), 
			     CLQ_PARTIAL_TOKEN, msg_len, msg_buf)) < 0) {
	  FL_error(err);
	  ssp_err_quit("handle_merge_and_partition: FL_unicast failed %d\n", err);  	
	}
      }
    }
    clq->state = CLQ_WAIT_FOR_FINAL_TOKEN;
  }
  else {
    ON_DEBUG(fprintf(f_dbg, " ------------- NEW member ----------- \n");)
    clq_destroy_ctx(&clq->ctx);
    if((err = clq_new_user(&clq->ctx, con->priv_name, grp->name, FALSE)) < 0) {
      ssp_err_quit("handle_merge_and_partition: clq_new_user failed %d\n", err);  	
    }
    clq->state = CLQ_WAIT_FOR_PARTIAL_TOKEN;	
  }

  if(alloc && msg_buf) {
    free(msg_buf);
  }
  clq_destroy_token(&tk_out);

  DEBUG_leave(f_dbg, "handle_leave_or_partition", 0);
}


/* start_merge -------------------------------------------------------------------------------
   This function starts a merge algorithm. It is called when the member executing the 
   algorithm is the controller. Join is handled as a particular case of merge.
   
   It returns nothing, it fails if either cliques or flush calls failed.
------------------------------------------------------------------------------------------- */
static void start_merge(SSP_Con *con, SSP_Grp *grp, stdarr *merge_set) {
  int        err, alloc = 0;
  CLQ_Alg    *clq = (CLQ_Alg *)grp->ka->info;	
  char       **merge_set_ptr;
  CLQ_TOKEN  *tk_out = 0;
  stdarr_it  ait;
  int        msg_len;
  char       *msg_buf = 0;

  DEBUG_enter(f_dbg, "start_merge");
  
  merge_set_ptr = (char**)stdarr_it_val(stdarr_begin(merge_set, &ait));
  if((err = clq_update_key(clq->ctx, merge_set_ptr, NULL, &tk_out)) < 0 
     && err != NOT_CONTROLLER ) {  
    ssp_err_quit("start_alg: clq_update_key failed %d\n", err);
  }   

  if(tk_out) {
    msg_len = tk_2_msg(&msg_buf, tk_out, CLQ_PARTIAL_TOKEN, clq->curr_memb_msg->serv_type, 
		       &alloc);
    if((err = FL_unicast(con->mbox, CLQ_SERVICE_TYPE, grp->name, 
			 clq_get_next_username(clq->ctx), 
			 CLQ_PARTIAL_TOKEN, msg_len, msg_buf)) < 0) {
      SSP_disconnect(con->mbox);
      goto end;
    }
    ON_DEBUG(fprintf(f_dbg, "partial token sent to %s  \n", clq_get_next_username(clq->ctx));)
  }
  clq->state = CLQ_WAIT_FOR_FINAL_TOKEN;
  ON_DEBUG(fprintf(f_dbg, "move to WAIT_FOR_FINAL_TOKEN state\n");)
  
 end:
  if(alloc && msg_buf) {
    free(msg_buf);
  }
  clq_destroy_token(&tk_out);
  
  DEBUG_leave(f_dbg, "start_merge", 0);
}


/* handle_merge ------------------------------------------------------------------------------
   This function starts a merge algorithm. It is called when the member executing the 
   algorithm is the controller. Join is handled as a particular case of merge.
   
   It returns nothing, it fails if either cliques or flush calls failed.
------------------------------------------------------------------------------------------- */
static void handle_merge(SSP_Con *con, SSP_Grp *grp, stdarr *merge_set) {
  int        err;
  CLQ_Alg    *clq = (CLQ_Alg *)grp->ka->info;  
  
  DEBUG_enter(f_dbg, "handle_merge");
  
  if(is_old_member(grp)) {
    ON_DEBUG(fprintf(f_dbg, " ------------- OLD member ----------- \n");)
    start_merge(con, grp, merge_set);
  }
  else {
    ON_DEBUG(fprintf(f_dbg, " ------------- NEW member ----------- \n");)
    clq_destroy_ctx(&clq->ctx);
    if((err = clq_new_user(&clq->ctx, con->priv_name, grp->name, FALSE)) < 0) {
      ssp_err_quit("handle_merge: clq_new_user failed %d\n", err);  	
    }
    clq->state = CLQ_WAIT_FOR_PARTIAL_TOKEN;	
  } 
  
  DEBUG_leave(f_dbg, "handle_merge", 0);
}


/* handle_data_msg ----------------------------------------------------------------------------- 
   This function specifies the actions taken by the state machine if the message received was
   a data message (message received from the flush layer).
--------------------------------------------------------------------------------------------- */
static int handle_data_msg(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CLQ_Alg *clq) {
  int ret = DONT_DELIV_MSG;
  
  DEBUG_enter(f_dbg, "handle_data_msg");

  switch(clq->state) {
  case CLQ_SECURE:
    ssp_err_quit("handle_data_msg: this message should not be here");
    break;
    
  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
  case CLQ_WAIT_FOR_FINAL_TOKEN:
  case CLQ_COLLECT_FACT_OUTS:
  case CLQ_WAIT_FOR_SELF_JOIN:
    ssp_err_quit("handle_data_msg: no message should be received in this state");
    break;

  case CLQ_WAIT_FOR_KEY_LIST:
    stddll_push_back(&clq->msg_deque, &msg);
    break;

  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
  case CLQ_WAIT_FOR_MEMBERSHIP:
    ret = DELIV_MSG;
    break;

  }

  DEBUG_leave(f_dbg, "handle_data_msg", ret);
  return ret;
}


/* handle_trans ---------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a transitional message.
---------------------------------------------------------------------------------------------- */
static int handle_trans(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CLQ_Alg *clq) {
  int ret = DONT_DELIV_MSG;

  DEBUG_enter(f_dbg, "handle_trans");

  switch(clq->state) {
  case CLQ_SECURE:
    clq->first_trans = SSP_FALSE;
    clq->vs_trans = SSP_TRUE;
    ret = DELIV_MSG;
    break;

  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
  case CLQ_WAIT_FOR_FINAL_TOKEN:
  case CLQ_COLLECT_FACT_OUTS:
  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
  case CLQ_WAIT_FOR_MEMBERSHIP:
    if(clq->first_trans == SSP_TRUE) {
      clq->first_trans = SSP_FALSE;
      ret = DELIV_MSG;
    }
    clq->vs_trans = SSP_TRUE;
    break;
  
  case CLQ_WAIT_FOR_KEY_LIST:
    if(clq->first_trans == SSP_TRUE) {
      clq->first_trans = SSP_FALSE;
      ret = DELIV_MSG;
    }
    clq->state = CLQ_WAIT_FOR_CASCADING_MEMBERSHIP;
    clq->vs_trans = SSP_TRUE;
    break; 

  case CLQ_WAIT_FOR_SELF_JOIN:
    ssp_err_quit("handle_trans: trans received in wrong state, %d!\n", clq->state);
    break;
  }
  
  DEBUG_leave(f_dbg, "handle_trans", ret);
  return ret;
}


/* handle_memb ----------------------------------------------------------------------------------
  This function specifies the actions taken by the state machine if the message received was
  a group membership.

  Some comments:
      a member in the WAIT_FOR_SELF_JOIN can receive 2 events: a membership due to its own join
      (a join event) or a membership due to a network event (in this case the joinee is on the
      list of new added members. Flush delivers this special network in some cases:
      -  a partiton happen after the join and before the new membership is delivered
      -  the join happened while a previous partition was processed, so the two events are
         combined in one
      -  somebody left immediately after my join. Since flush membership deliveries are based
         on gathering flush_oks from old members, if the guy that left did not send his 
         flush_ok, the two events will be combined. Note that if he managed to send his
         flush_ok, then the join will be delivered first, then the leave.
---------------------------------------------------------------------------------------------- */
static int handle_memb(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CLQ_Alg *clq) {
  int    ret = DONT_DELIV_MSG, was_leave = 0, err = 0;
  stdarr join_set;
  stdarr leave_set;

  DEBUG_enter(f_dbg, "handle_memb");
  
  stdarr_construct(&leave_set, sizeof(char*));
  stdarr_construct(&join_set, sizeof(char*));

  switch(clq->state) {
  case CLQ_SECURE:
  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
  case CLQ_WAIT_FOR_FINAL_TOKEN:
  case CLQ_COLLECT_FACT_OUTS:
  case CLQ_WAIT_FOR_KEY_LIST: 
    ssp_err_quit("handle_memb: memb received in wrong state, %d!\n", clq->state);
    break;

  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
    if(clq->first_cascaded_memb == SSP_TRUE) {
      clq->first_cascaded_memb = SSP_FALSE;
      init_vs_set(grp); 
    }
    was_leave = upd_vs_set_and_get_join_leave_set(grp, msg->serv_type, &join_set, &leave_set);
    if (was_leave  && (clq->first_trans == SSP_TRUE)) {
      clq->first_trans = SSP_FALSE;
      gen_and_push_msg(con, grp, TRANSITION_MESS);
    }

    if(clq->curr_memb_msg != NULL) { /* free prev. memb that we were trying to install  */
      SSP_Msg_free(&(clq->curr_memb_msg));
    }
    clq->curr_memb_msg = msg; /* delay delivery of memb  */

    /* cascaded occured, so memberships will be collapsed, deliver a NETWORK */
    clq->curr_memb_msg->serv_type = REG_MEMB_MESS | CAUSED_BY_NETWORK;

    grp->ka->key_state = NOT_ESTABLISH;
    if(stdhash_size(&grp->curr_membs_hash) > 1) {
      start_alg(con, grp);
    }
    else {
      first_user(con, grp);
    }
    ret = DONT_DELIV_MSG;
    clq->vs_trans = SSP_FALSE;
    break;

  case CLQ_WAIT_FOR_SELF_JOIN:
    grp->ka->key_state = NOT_ESTABLISH;
    
    init_vs_set(grp); 
    was_leave = upd_vs_set_and_get_join_leave_set(grp, msg->serv_type, &join_set, &leave_set);
    clq->first_cascaded_memb = SSP_FALSE;
    
    clq->curr_memb_msg = msg;  /* delay delivery of memb  */

    if(stdhash_size(&grp->curr_membs_hash) > 1) {
      if(Is_reg_memb_mess(msg->serv_type)) {
	if(Is_caused_join_mess(msg->serv_type)) {
	  if((err = clq_new_user(&clq->ctx, con->priv_name, grp->name, FALSE)) < 0) {
	    ssp_err_quit("handle_memb: clq_new_user failed %d\n", err);  	
	  }
	  clq->state = CLQ_WAIT_FOR_PARTIAL_TOKEN;	
	}	      
	else if(Is_caused_leave_mess(msg->serv_type) || 
		Is_caused_disconnect_mess(msg->serv_type)) {
	  ssp_err_quit("handle_memb: leave or disconnect in the wrong state %d\n", clq->state);
	}
	else if(Is_caused_network_mess(msg->serv_type)) {
	  char *chosen_name = NULL;
	  choose(&chosen_name, grp);
	  
	  if(!strcmp(chosen_name, con->priv_name)) {
	    /* need to add only new members, I just joined so I don't need to remove anybody */
	    if((err = clq_first_user(&clq->ctx, con->priv_name, grp->name)) < 0){
	      ssp_err_quit("handle_memb: clq_first_user failed  %d\n", err);
	    }
	    start_merge(con, grp, &join_set);
	  }
	   else {
	     if((err = clq_new_user(&clq->ctx, con->priv_name, grp->name, FALSE)) < 0) {
	       ssp_err_quit("handle_memb: clq_new_user failed %d\n", err);  	
	     }
	     clq->state = CLQ_WAIT_FOR_PARTIAL_TOKEN;
	   }
	}
      }
    }
    else {
      first_user(con, grp);
    }
    clq->vs_trans = SSP_FALSE;
    break;
    
  case CLQ_WAIT_FOR_MEMBERSHIP:
    grp->ka->key_state = NOT_ESTABLISH;
    clq->first_cascaded_memb = SSP_FALSE;
    
    init_vs_set(grp); 
    was_leave = upd_vs_set_and_get_join_leave_set(grp, msg->serv_type, &join_set, &leave_set);
    
    clq->curr_memb_msg = msg; /* delay delivery of memb  */
    
    if(stdhash_size(&grp->curr_membs_hash) > 1) {
      if(stdarr_size(&leave_set) > 1) { /* count the NULL too */
	if(stdarr_size(&join_set) <= 1) {  /* only partition or leave, count the NULL too  */
	  handle_leave_or_partition(con, grp, &leave_set);
	}
	else {
	  handle_merge_and_partition(con, grp, &join_set, &leave_set);
	}
      }
      else { /*  merge &  join */
	if(Is_caused_join_mess(msg->serv_type)) { /* if I am here I am an old member */
	  start_merge(con, grp, &join_set);
	}
	else {
	  handle_merge(con, grp, &join_set);
	}
      }
    }  
    else { /* alone  */
      first_user(con, grp);
    }
    clq->vs_trans = SSP_FALSE;
    break;
  }

  stdarr_destruct(&leave_set);  
  stdarr_destruct(&join_set);      

  DEBUG_leave(f_dbg, "handle_memb", ret);
  return ret;
}


/* handle_partial_token -------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a partial token message.
   IMPORTANT: all members need to call update_key. The controller passes a merge_list and an
   output token and the others are passing a input and an output token. This needs to be passed
   from the controller to each of the new members. The last member (which in the current cliques
   implementation becomes the new group controller) needs also to call clq_update_keu BEFORE
   checking if he is the last member or not. That is beacuse clq_update_key also sets the list
   of memebrs of the group.
---------------------------------------------------------------------------------------------- */
static int handle_partial_token(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CLQ_Alg *clq) {
  int        ret = DONT_DELIV_AND_FREE_MSG, err, alloc = 0;
  CLQ_TOKEN  *tk_out = 0;
  CLQ_TOKEN  tk_in = {0};  
  int        msg_len;
  char       *msg_buf = 0;
  service    serv;

  DEBUG_enter(f_dbg, "handle_partial_token");
  
  switch(clq->state) {
  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
    msg_2_tk(msg, &tk_in, &serv);
 
    /* update the service type for the current membership handled */
    if(Is_caused_network_mess(serv) && Is_caused_join_mess(clq->curr_memb_msg->serv_type)) {
      clq->curr_memb_msg->serv_type = serv;
    }

    if(((err = clq_update_key(clq->ctx, NULL, &tk_in, &tk_out)) < 0 && err != NOT_CONTROLLER) || !tk_out) {
      ssp_err_quit("handle_partial_token: clq_update_key failed %d  %p\n", err, tk_out); 
    }

    ON_TEST_CASCADING (sleep(TIMEOUT_CASCADING);)

    if(clq->ctx->me->next != NULL) { /* I am not the new controller, pass the token to next */
      msg_len = tk_2_msg(&msg_buf, tk_out, CLQ_PARTIAL_TOKEN, clq->curr_memb_msg->serv_type, 
			 &alloc);
      if((ret = FL_unicast(con->mbox, CLQ_SERVICE_TYPE, grp->name, 
			   clq_get_next_username(clq->ctx), 
			   CLQ_PARTIAL_TOKEN, msg_len, msg_buf)) < 0) {
	FL_error(ret);
	ssp_err_quit("handle_partial_token: FL_unicast %d\n", ret); 
      }

      clq->state = CLQ_WAIT_FOR_FINAL_TOKEN;
      ON_DEBUG(fprintf(f_dbg, "partial token sent to %s, move to WAIT_FOR_FINAL_TOKEN state\n",
		       clq_get_next_username(clq->ctx));)
    }
    else { /* I am the new controller, this is the final token, multicast it with SELF_DISCARD */
      msg_len = tk_2_msg(&msg_buf, tk_out, CLQ_FINAL_TOKEN, clq->curr_memb_msg->serv_type, 
			 &alloc);
      if((ret = FL_multicast(con->mbox, CLQ_SERVICE_TYPE | SELF_DISCARD, grp->name, 
			     CLQ_FINAL_TOKEN, msg_len, msg_buf)) < 0) {
	FL_error(ret);
	ssp_err_quit("handle_partial_token: FL_multicast %d\n", ret); 
      }
      clq->state = CLQ_COLLECT_FACT_OUTS;

      if(ret > 0){ /* if the sending succeded, return DONT_DELIVER_MSG  */
	ret = DONT_DELIV_AND_FREE_MSG;
      }

      ON_DEBUG(fprintf(f_dbg, "final token sent to group, move to COLLECT_FACT_OUTS state\n");)
    }
  
    if(alloc && msg_buf) {
      free(msg_buf);
    }

    if(tk_in.t_data) {
      free(tk_in.t_data);
      tk_in.t_data = NULL;
    }
    clq_destroy_token(&tk_out);

    break;

  case CLQ_SECURE:
  case CLQ_WAIT_FOR_FINAL_TOKEN:
  case CLQ_COLLECT_FACT_OUTS:
  case CLQ_WAIT_FOR_KEY_LIST:
    ssp_err_quit("handle_partial_token: partial token in wrong state!");
    break;

  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
    ret = DONT_DELIV_AND_FREE_MSG;
    break;

  case CLQ_WAIT_FOR_SELF_JOIN:
  case CLQ_WAIT_FOR_MEMBERSHIP:
    break;
  }

  DEBUG_leave(f_dbg, "handle_partial_token", ret);
  return ret;
}


/* handle_final_token --------------------------------------------------------------------------
  This function specifies the actions taken by the state machine if the message received was
  a final token message.
  IMPORTANT: the new controller must not call clq_factor_out function. 
---------------------------------------------------------------------------------------------- */
static int handle_final_token(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CLQ_Alg *clq) {
  int        ret = DONT_DELIV_AND_FREE_MSG, err, alloc = 0;
  CLQ_TOKEN  *tk_out = 0;
  CLQ_TOKEN  tk_in = {0}; 
  int        msg_len;
  char       *msg_buf = 0;
  service    serv;

  DEBUG_enter(f_dbg, "handle_final_token");

  switch(clq->state) {
  case CLQ_WAIT_FOR_FINAL_TOKEN:
    if(clq->ctx->me->next != NULL) { /* I am not the new gc, call factor out */
      msg_2_tk(msg, &tk_in, &serv);

      /* update the service type for the current membership handled */
      if(Is_caused_network_mess(serv) && Is_caused_join_mess(clq->curr_memb_msg->serv_type)) {
	clq->curr_memb_msg->serv_type = serv;
      }

      if((err = clq_factor_out(clq->ctx, &tk_in, &tk_out)) < 0 || !tk_out) {
	ssp_err_quit("handle_final_token: clq_factor_out failed %d\n", err);
      }

      ON_TEST_CASCADING(sleep(TIMEOUT_CASCADING);)

      msg_len = tk_2_msg(&msg_buf, tk_out, CLQ_FACT_OUT, clq->curr_memb_msg->serv_type, &alloc);
      if ((ret = FL_unicast(con->mbox, CLQ_SERVICE_TYPE, grp->name, 
			    clq_get_controller_name(clq->ctx), 
			    CLQ_FACT_OUT, msg_len, msg_buf)) < 0) {
	FL_error(ret);
	ssp_err_quit("handle_final_token: FL_unicast failed %d\n", ret);
      }
      clq->state = CLQ_WAIT_FOR_KEY_LIST;
      clq->kl_got_fl_req = SSP_FALSE;
      if(ret > 0) {
	ret = DONT_DELIV_AND_FREE_MSG;
      }

      ON_DEBUG(fprintf(f_dbg, "factor out sent to gc %s, move to WAIT_FOR_KEY_LIST state\n", 
		       clq_get_controller_name(clq->ctx));)
	
      clq_destroy_token(&tk_out);

      if(tk_in.t_data) {
	free(tk_in.t_data);
	tk_in.t_data = NULL;
      } 
      
      if(alloc && msg_buf) {
	free(msg_buf);
      }
    }
    break;
    
  case CLQ_SECURE:
  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
  case CLQ_COLLECT_FACT_OUTS:
  case CLQ_WAIT_FOR_KEY_LIST:
    ssp_err_quit("handle_final_token: final token in wrong state!");
    break;

  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
    ret = DONT_DELIV_AND_FREE_MSG;
    break;

  case CLQ_WAIT_FOR_SELF_JOIN:
  case CLQ_WAIT_FOR_MEMBERSHIP:
    break;
  }  

  DEBUG_leave(f_dbg, "handle_final_token", ret);
  return ret;
}


/* handle_fact_out ------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a factor out message.
   IMPORTANT: only the new group controller should be in this state. clq_merge needs to be 
   for every factor out merge received. When the expected number of factor out messages was
   received, clq_merge outputs a valid token. 
---------------------------------------------------------------------------------------------- */
static int handle_fact_out(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CLQ_Alg *clq) {
  int        ret = DONT_DELIV_AND_FREE_MSG, err, alloc = 0;
  CLQ_TOKEN  *tk_out = 0;
  CLQ_TOKEN  tk_in = {0}; 
  int        msg_len;
  char*      msg_buf = 0;
  service    serv;

  DEBUG_enter(f_dbg, "handle_fact_out");
  
  switch(clq->state) {
  case CLQ_COLLECT_FACT_OUTS:
    if((strcmp(clq_get_controller_name(clq->ctx), con->priv_name) == 0) &&
        clq->vs_trans == SSP_FALSE) {
      msg_2_tk(msg, &tk_in, &serv);

      if((err = clq_merge(clq->ctx, msg->sender, &tk_in, &tk_out)) < 0) {
	ssp_err_quit("handle_fact_out: clq_merge failed %d\n", err);
      }    

      if(tk_out) { /* KEY_LIST ready  */
	ON_TEST_CASCADING(sleep(TIMEOUT_CASCADING);)

	msg_len = tk_2_msg(&msg_buf, tk_out, CLQ_KEY_LIST, clq->curr_memb_msg->serv_type, 
			   &alloc);
	if ((ret = FL_multicast(con->mbox, CLQ_KL_TYPE, grp->name, CLQ_KEY_LIST, msg_len, 
				msg_buf)) < 0) {
	  FL_error(ret);
	  ssp_err_quit("handle_fact_out: FL_multicast failed %d\n", ret);
	}

	ON_DEBUG(fprintf(f_dbg, "key list sent to groups, move to WAIT_FOR_KEY_LIST state\n");)
	clq->state = CLQ_WAIT_FOR_KEY_LIST;
	clq->kl_got_fl_req = SSP_FALSE;	
      }

      if(ret > 0) {
	ret = DONT_DELIV_AND_FREE_MSG;
      }

      if(tk_in.t_data) {
	free(tk_in.t_data);
	tk_in.t_data = NULL;
      }

      if(alloc && msg_buf) {
	free(msg_buf);
      }
      
      clq_destroy_token(&tk_out);      
    }

    break;
    
  case CLQ_SECURE:
  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
  case CLQ_WAIT_FOR_FINAL_TOKEN:
  case CLQ_WAIT_FOR_KEY_LIST:
    ssp_err_quit("handle_fact_out: fact_out received in wrong state!\n");
    break;

  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
    ret = DONT_DELIV_AND_FREE_MSG;
    break;

  case CLQ_WAIT_FOR_SELF_JOIN:
  case CLQ_WAIT_FOR_MEMBERSHIP:
    break;

  }

  DEBUG_leave(f_dbg, "handle_fact_out", ret);
  return ret;
}

/* handle_key_list -----------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a key list message.
---------------------------------------------------------------------------------------------- */
static int handle_key_list(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CLQ_Alg *clq) {
  int        ret = DONT_DELIV_AND_FREE_MSG, err;
  CLQ_TOKEN  tk_in = {0}; 
  service    serv;

  DEBUG_enter(f_dbg, "handle_key_list");

  switch(clq->state) {
  case CLQ_WAIT_FOR_KEY_LIST:
    if(clq->vs_trans == SSP_FALSE) {
      msg_2_tk(msg, &tk_in, &serv);

      if((err = clq_update_ctx(clq->ctx, &tk_in)) < 0) {
	ssp_err_quit("handle_key_list: clq_update_ctx failed %d!\n", err);
      }      

      copy_key(grp);      
      grp->ka->key_state = ESTABLISH;      
      (*grp->enc->chg_key_fcn)(grp->enc->key, grp->enc->key_len, grp->enc->info);
     
      /* in case of a cascading due to a join, the joiner starts in WAIT_FOR_SELF_JOIN 
         and it never knows it it was a cascading or not so he deliveres JOIN while 
         all the other members of the group will deliver NETWORK. That's why each
         members that passes along the partial token attaches also its group event,
	 and if it was join is upgraded to network. With the final token broadcast
	 everybody agreed to deliver that group event type.
      */
      if(Is_caused_network_mess(clq->curr_memb_msg->serv_type)) {
	set_vs_set_memb_msg(clq->curr_memb_msg, grp); 
      }

      /* first put the new secure memb in the connection queue */
      stddll_push_back(&con->deliv_deque, &clq->curr_memb_msg);
      move_msg_con_deque(con, grp);

      clq->state = CLQ_SECURE;
      clq->first_trans = SSP_TRUE;
      clq->first_cascaded_memb = SSP_TRUE;

      if(clq->kl_got_fl_req == SSP_TRUE) {
	clq->wait_for_sec_fl_ok = SSP_TRUE;
	gen_and_push_msg(con, grp, FLUSH_REQ_MESS); /* push flush request in the conn. queue */
      }
      if(tk_in.t_data) {
	free(tk_in.t_data);
	tk_in.t_data = NULL;
      } 
    }

    if(ret > 0) {
      ret = DONT_DELIV_AND_FREE_MSG;
    }
    break;
    
  case CLQ_SECURE:
  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
  case CLQ_WAIT_FOR_FINAL_TOKEN:
  case CLQ_COLLECT_FACT_OUTS:
    ssp_err_quit("handle_key_list: key list in wrong state!");
    break;

  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
    ret = DONT_DELIV_AND_FREE_MSG;
    break;

  case CLQ_WAIT_FOR_SELF_JOIN:
  case CLQ_WAIT_FOR_MEMBERSHIP:
    break;

  }
  
  DEBUG_leave(f_dbg, "handle_key_list", ret);
  return ret;
}

/* handle_fl_req -------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a flush request message.
---------------------------------------------------------------------------------------------- */
static int handle_fl_req(SSP_Con *con, SSP_Grp *grp, SSP_Msg *mess, CLQ_Alg *clq) {
  int ret = DONT_DELIV_AND_FREE_MSG;

  DEBUG_enter(f_dbg, "handle_fl_req");

  switch(clq->state) {
  case CLQ_SECURE:
    clq->wait_for_sec_fl_ok = SSP_TRUE;
    ret = DELIV_MSG; 
    break;

  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
  case CLQ_WAIT_FOR_FINAL_TOKEN:
  case CLQ_COLLECT_FACT_OUTS:
  case CLQ_WAIT_FOR_KEY_LIST:
    if ((ret = FL_flush(con->mbox, grp->name)) < 0) {
      FL_error(ret);
      ssp_err_quit("handle_fl_req: FL_flush failed %d!\n", ret);
    }
    clq->state = CLQ_WAIT_FOR_CASCADING_MEMBERSHIP;
    ON_DEBUG(fprintf(f_dbg, "Flush ok sent\n");)

    ret = DONT_DELIV_AND_FREE_MSG;
    break;
  
  case CLQ_WAIT_FOR_SELF_JOIN:
  case CLQ_WAIT_FOR_MEMBERSHIP:
  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
    ssp_err_quit("handle_fl_req: fl_req received in wrong state, not possible !");
    break;

  }

  DEBUG_leave(f_dbg, "handle_fl_req", ret);
  return ret;
}

/* ============================  wrapper functions for cliques  ============================== */

/* CLQ_handles_mess -----------------------------------------------------------------------------
   This function specifies if a spread message is used or not by the key agreement algorithm.
   All the messages specified here will be redirected by spread to CLQ_Comp_Key_Wrapper;
   In this case, all the membership messages (including transitional messages) are sended,
   Also the regular messages used internal by the key agreement algorithm (CLQ... messages)
   and regular messages received between having a stable key, are sent here.
-----------------------------------------------------------------------------------------------*/
int CLQ_handles_msg(SSP_Msg *msg, SSP_Grp *grp) {
  service serv_type = msg->serv_type;
  int     msg_type  = msg->msg_type;
  
  return  !Is_regular_mess(serv_type) ||  
    grp->ka->key_state == NOT_ESTABLISH ||
    msg_type == CLQ_PARTIAL_TOKEN || msg_type == CLQ_FINAL_TOKEN  || 
    msg_type == CLQ_FACT_OUT || msg_type == CLQ_KEY_LIST;
}


/* CLQ_handle_recv ----------------------------------------------------------------------------
   This function is implementing the state machine for the key agreement algorithm. 
   It returns 1 if the message must be delivered by the SSP, 0 otherwise. The SSP can check if 
   the key agreement finished by looking and Key_State.
-----------------------------------------------------------------------------------------------*/
int CLQ_handle_recv(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg) {
  int  ret = DELIV_MSG;
  CLQ_Alg *clq = (CLQ_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "CLQ_handle_recv");
  
  if(Is_regular_mess(msg->serv_type)) {
    if(Is_partial_token_msg(msg->msg_type)) {
      ret = handle_partial_token(con, grp, msg, clq);
    }
    else if(Is_final_token_msg(msg->msg_type)) {
      ret = handle_final_token(con, grp, msg, clq);
    }
    else if(Is_fact_out_msg(msg->msg_type)) {
      ret = handle_fact_out(con, grp, msg, clq);
    }
    else if(Is_key_list_msg(msg->msg_type)) {
      ret = handle_key_list(con, grp, msg, clq);
    }
    else {
      ret = handle_data_msg(con, grp, msg, clq);
    }
  }
  else if(Is_flush_req_mess(msg->serv_type)) {
    ret = handle_fl_req(con, grp, msg, clq);
  }
  else if(Is_membership_mess(msg->serv_type)) {
    if(Is_self_leave_mess(msg->serv_type)) {
      ;
    }
    else if(Is_transition_mess(msg->serv_type)) {
      ret = handle_trans(con, grp, msg, clq);
    }
    else {
      ret = handle_memb(con, grp, msg, clq);
    }
  }

  DEBUG_leave(f_dbg, "CLQ_handle_recv", ret);
  return ret;  
}

/* CLQ_handle_fl_ok ----------------------------------------------------------------------------
   This function specifies the action taken by the key agreement state machine if a flush
   ok event happen. This is actually Secure_Flush_Ok, sent by the user using SSP_Flush, 
   which does not sent the flush okinvoking directlly FL_flush, but calls this function to 
   handle it.
--------------------------------------------------------------------------------------------- */
int CLQ_handle_fl_ok(SSP_Con *con, SSP_Grp *grp){
  int  ret = DELIV_MSG;
  CLQ_Alg *clq = (CLQ_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "CLQ_handle_fl_ok");
  
  switch(clq->state) {
  case CLQ_SECURE:
    if(clq->wait_for_sec_fl_ok == SSP_TRUE) {
      clq->wait_for_sec_fl_ok = SSP_FALSE;      
      if ((ret = FL_flush(con->mbox, grp->name)) < 0) {
	FL_error(ret);
	goto end;
      }
      clq->state = CLQ_WAIT_FOR_MEMBERSHIP;
    }
    else {
      ret = FLUSH_OK_ALREADY_SENT;
    }
    break;
    
  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
  case CLQ_WAIT_FOR_FINAL_TOKEN:
  case CLQ_WAIT_FOR_KEY_LIST:
  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
  case CLQ_COLLECT_FACT_OUTS:
  case CLQ_WAIT_FOR_MEMBERSHIP:
  case CLQ_WAIT_FOR_SELF_JOIN:
    ret = FLUSH_OK_ALREADY_SENT;
    break;    
  }
  
 end:
  DEBUG_leave(f_dbg, "CLQ_handle_fl_ok", ret);
  return ret;
  
}

/* CLQ_handle_send ----------------------------------------------------------------------------
   This function specifies the actions taken by the key agreement state machine, if the event
   that happen is a 'user' message. The event is caused by a user calling SSP_scat_multicast
   or SSP_multicast. Right now this function is not handleing the sending, it just allows the
   sending of the message or not. As a general idea, the user is not allowed to send messages
   while the key agreement is performing.
-------------------------------------------------------------------------------------------- */
int CLQ_handle_send(SSP_Con *con, SSP_Grp *grp) {
  int  ret = DELIV_MSG;
  CLQ_Alg *clq = (CLQ_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "CLQ_handle_send");

  switch(clq->state) {
  case CLQ_SECURE:
    ret = SEND_MSG;
    break;

  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
  case CLQ_WAIT_FOR_FINAL_TOKEN:
  case CLQ_WAIT_FOR_KEY_LIST:
  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
  case CLQ_COLLECT_FACT_OUTS:
  case CLQ_WAIT_FOR_SELF_JOIN:
  case CLQ_WAIT_FOR_MEMBERSHIP:
    ret = DONT_SEND_MSG;
    break;
  }

  DEBUG_leave(f_dbg, "CLQ_handle_send", ret);
  return ret;

}















