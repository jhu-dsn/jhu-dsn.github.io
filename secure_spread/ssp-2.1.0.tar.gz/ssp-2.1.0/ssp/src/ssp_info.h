/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */










/***********************************************************************************************/
/* ssp_info.h                                                                                  */
/* Connection, group and message info                                                          */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: June 23, 1999                                                                      */
/* Modified: Jun 23, 2000 by Cristina Nita-Rotaru                                              */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#ifndef _SSP_INFO_H_
#define _SSP_INFO_H_

#include <stdutil/stddefines.h>
#include <stdutil/stderror.h>
#include <stdutil/stddll.h>
#include <stdutil/stdhash.h>

#include "sp.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
  SSP_FALSE, SSP_TRUE
} SSP_Bool;


#define DELIV_MSG               10
#define DONT_DELIV_MSG          11
#define DONT_DELIV_AND_FREE_MSG 12    
#define SEND_MSG                13
#define DONT_SEND_MSG           14    


/* Spread message info  ------------------------------------------------------------------------
   This data structure models a message with the information provided by Flush library.
--------------------------------------------------------------------------------------------- */
typedef struct {
  mailbox  mbox;
  service  serv_type;           
  char     *sender;
  int      max_num_grps; 
  int      num_grps;
  char     (*grps)[MAX_GROUP_NAME];
  int16    msg_type;
  int      endian_mism;
  int      msg_len;
  scatter  *scat;
  group_id gid;                 /* valid only for membership messages */
} SSP_Msg;
  
void SSP_Msg_init(SSP_Msg *msg);
SSP_Msg *SSP_Msg_create(mailbox mbox, service *serv_type, char sender[MAX_GROUP_NAME], 
			int max_grps, int *num_grps, char grps[][MAX_GROUP_NAME],
			int16 *msg_type, int *endian_mism, int msg_len, 
			char src_grps[][MAX_GROUP_NAME], scatter *src_scat, 
			int fixed_elem_size, int realloc);
void SSP_Msg_free(SSP_Msg **msg);
  
/* Encryption info  ----------------------------------------------------------------------------
   init_fcn, change_key_fcn, encrypt_fcn and decrypt_fcn are wrappers for functions
   specific to an algorithm, while crypt_info is auxiliary data required by the     
   encryption algorithm. Look in init_encrypt.c to see how can you initialize/destroy such
   a structure.
------------------------------------------------------------------------------------------- */
typedef struct dummy_SSP_Enc {
  int             name;
  unsigned char   *key;
  int             key_len;
  unsigned char   block_size;
  void            *info;
  unsigned int    (*init_fcn)(unsigned char*, unsigned int, void *void_info);
  unsigned int    (*chg_key_fcn)(unsigned char*, unsigned int, void *void_info);
  unsigned int    (*enc_fcn)(char*, unsigned int, void*, int);
  unsigned int    (*dec_fcn)(char*, unsigned int, void*, int);
} SSP_Enc;
  
void SSP_Enc_set(SSP_Enc *enc, int name, unsigned char *key, int key_len, int block_size, void *info,
		 unsigned int (*init_fcn)(unsigned char*, unsigned int, void *),
		 unsigned int (*chg_key_fcn)(unsigned char*, unsigned int, void *),
		 unsigned int (*enc_fcn)(char*, unsigned int, void*, int),
		 unsigned int (*dec_fcn)(char*, unsigned int, void*, int));
void SSP_Enc_print_key(SSP_Enc *enc);  
  
  
/* Key agreement  -----------------------------------------------------------------------------
   This data structure models the information required by the key agreement. The functions
   alg_needs_mess_fcn and comp_key_fcn need to be implemented by the key agreement code.
   Look in init_key_alg.c to see how can you initialize, destroy such a structure.
--------------------------------------------------------------------------------------------- */
typedef enum { 
  ESTABLISH, NOT_ESTABLISH
} SSP_Key_State;
  
  /* fake conection and group structures */
struct f_SSP_Con;
struct f_SSP_Grp;
  
typedef struct dummy_SSP_Ka {
  int            name;
  SSP_Key_State  key_state; 
  unsigned int   key_len;
  void           *info;
  char           (*vs_membs)[MAX_GROUP_NAME];
  stdhash        vs_membs_hash;
  int            (*handles_msg_fcn)(SSP_Msg*, struct f_SSP_Grp *);
  int            (*handle_recv_fcn)(struct f_SSP_Con*, struct f_SSP_Grp*, SSP_Msg*);
  int            (*handle_fl_ok_fcn)(struct f_SSP_Con*, struct f_SSP_Grp*);
  int            (*handle_send_fcn)(struct f_SSP_Con*, struct f_SSP_Grp*);
}SSP_Ka;
  
void SSP_Ka_set(SSP_Ka *ka, int name, void* info, unsigned int key_len,
		int (*handles_msg_fcn)(SSP_Msg*, struct f_SSP_Grp*),
		int (*handle_recv_fcn)(struct f_SSP_Con*, struct f_SSP_Grp*, SSP_Msg*),
		int (*handle_fl_ok_fcn)(struct f_SSP_Con*, struct f_SSP_Grp*),
		int (*handle_send_fcn)(struct f_SSP_Con*, struct f_SSP_Grp*));
  

/* Group info  ---------------------------------------------------------------------------------
   This data structure keeps information about a group. curr_mems and last_membs are used to
   determine in case a network happened, who left anf who added tht group. 
--------------------------------------------------------------------------------------------- */
typedef enum {
  LEAVE_CALLED, JOIN_CALLED, ACTIVE, FLUSH_OK_SENT
} Grp_State;

typedef struct f_SSP_Grp {
  char*     name;
  group_id  gid;
  int       num_membs;
  int       num_vs_membs;
  char      (*curr_membs)[MAX_GROUP_NAME];
  char      (*prev_membs)[MAX_GROUP_NAME];
  char      (*vs_membs)[MAX_GROUP_NAME];   /* vs set, valid only for a network event */  
  stdhash   prev_membs_hash;  
  stdhash   curr_membs_hash;
  stdhash   vs_membs_hash;                 /* vs set hash, valid only for a network */
  char*     joiner;                        /* joiner, valid only for a join event */
  char*     leaver;                        /* leaver, valid only for a leave event */
  SSP_Enc   *enc;
  SSP_Ka    *ka;
  Grp_State state;                         /* state machine */

} SSP_Grp;
  
stdbool grp_name_ptr_eq(const void *strptr1, const void *strptr2);
size_t grp_name_ptr_hashcode(const void *strptr);


/* Connection info  ----------------------------------------------------------------------------
   This data structure keeps information about the connection.
--------------------------------------------------------------------------------------------- */
typedef struct f_SSP_Con {
  mailbox mbox;
  int     priority;
  int     grp_notify;
  char    *daemon_name;
  char    *con_name;
  char    *priv_name;  
  SSP_Enc *enc;
  stdhash grps_hash;
  stddll  deliv_deque;
} SSP_Con;
  
SSP_Con * SSP_Con_create(mailbox mbox, int priority, int grp_memb, char *spread, 
			 char *private, char *priv_grp);
void     SSP_Con_free(SSP_Con **con);
void     SSP_Con_delGrp(SSP_Con *con, const char *g_name);
SSP_Grp *SSP_Con_addGrp(SSP_Con *con, const char *g_name);
SSP_Grp *SSP_Con_getGrp(SSP_Con *con, const char *g_name);
  
  
#ifdef __cplusplus
}
#endif

#endif /* _SSP_INFO_H_ */









