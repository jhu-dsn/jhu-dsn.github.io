/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */










/***********************************************************************************************/
/* ssp.h                                                                                       */
/* Secure spread interface                                                                     */
/*                                                                                             */       
/* Cristina Nita-Rotaru                                                                        */
/* Created: June 22, 1999                                                                      */
/* Modified: Jun 29, 2000 by Cristina Nita-Rotaru                                              */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#ifndef _SSP_H_
#define _SSP_H_

#include "fl.h"

#ifdef __cplusplus
extern "C" {
#endif    

#define ENCRYPT_MESS          0x08000000 
#define Is_encrypt_mess(type) (type & ENCRYPT_MESS)

#define DECRYPT_FAILED            -50
#define ENCRYPT_FAILED            -51
#define GROUP_NOT_SECURE          -52
#define ENCRYPTION_NOT_SUPPORTED  -53
#define KEY_AGR_NOT_SUPPORTED     -54
#define FLUSH_OK_ALREADY_SENT     -55
#define NOT_ALLOWED_TO_SEND       -56
#define INVALID_PARAM             -57

#define SSP_MAX_SCATTER_ELEMENTS (FL_MAX_SCATTER_ELEMENTS - 1)

#ifndef Is_self_leave_mess
#define Is_self_leave_mess(service) \
     ((service & CAUSED_BY_LEAVE) && !(service & (REG_MEMB_MESS | TRANSITION_MESS)))
#endif
 
#ifndef Is_private_group
#define Is_private_group(name) ((int) strchr(name, '#'))
#endif

#define BD_GROUP   '1'
#define CKD_GROUP  '2'
#define GDH_GROUP  '3'
#define STR_GROUP  '4'
#define TGDH_GROUP '5'


#ifndef Group_uses_BD
#define Group_uses_BD(group_name)     (group_name[0] == BD_GROUP) 
#endif
 
#ifndef Group_uses_CKD
#define Group_uses_CKD(group_name)    (group_name[0] == CKD_GROUP) 
#endif

#ifndef Group_uses_GDH
#define Group_uses_GDH(group_name)    (group_name[0] == GDH_GROUP) 
#endif

#ifndef Group_uses_STR
#define Group_uses_STR(group_name)    (group_name[0] == STR_GROUP) 
#endif

#ifndef Group_uses_TGDH
#define Group_uses_TGDH(group_name)   (group_name[0] == TGDH_GROUP) 
#endif

/* Interface routines */
int   SSP_version(int *major_version, int *minor_version, int *patch_version);
int   SSP_connect(char *spread_name, char *private_name, int priority, 
		  int group_membership, mailbox *mbox, char *private_group);
int   SSP_disconnect(mailbox mbox);
int   SSP_join(mailbox mbox, char *group);
int   SSP_leave(mailbox mbox, char *group);
int   SSP_get_key(mailbox mbox, const char *group, char* key, int * key_len); 
int   SSP_flush(mailbox mbox, const char *group);
int   SSP_multicast(mailbox mbox, service service_type, char *group, int16 mess_type, 
		    int mess_len, char *mess );
int   SSP_scat_multicast(mailbox mbox, service service_type, char *group, int16 mess_type,
			 scatter *scat_mess );
int   SSP_receive(mailbox mbox, service *service_type, char sender[MAX_GROUP_NAME],
		  int max_groups, int *num_groups, char groups[][MAX_GROUP_NAME],
                  int16 *mess_type, int *endian_mismatch,int max_mess_len, char *mess, 
		  int *more_messes );
int   SSP_scat_receive(mailbox mbox, service *service_type, char sender[MAX_GROUP_NAME],
                       int max_groups, int *num_groups, char groups[][MAX_GROUP_NAME],
                       int16 *mess_type, int *endian_mismatch, scatter *scat_mess,
		       int *more_messes);
int   SSP_signed_multicast(mailbox mbox, service service_type, char *target_group,
                           char *signing_group, int16 mess_type, int mess_len, char *mess);
int   SSP_signed_scat_multicast(mailbox mbox, service service_type, char *target_group,
                                char *signing_group, int16 mess_type, scatter *scat_mess);
int   SSP_verify_group_member(mailbox mbox, char *group, char *member_name, int challenge);
int   SSP_poll(mailbox mbox);
void  SSP_error(int error);

#ifdef __cplusplus
}
#endif

#endif /* _SSP_H_ */



