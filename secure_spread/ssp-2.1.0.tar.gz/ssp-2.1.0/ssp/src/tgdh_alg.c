/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */










/***********************************************************************************************/
/* tgdh_alg.c                                                                                  */
/* Implements TGDH protocol                                                                    */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: Feb 15, 2001                                                                       */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include <stdutil/stdhash.h>
#include <stdutil/stdarr.h>

#include "scatter.h"
#include "scatter_cryptor.h"
#include "ssp.h"
#include "utility.h"
#include "ssp_dbg.h"
#include "ssp_p.h"
#include "ssp_error.h"

#include "error.h"
#include "tgdh_api_misc.h"

#include "fl.h"

#include "tgdh_alg.h"

#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif

extern FILE *f_dbg;

/* ==================================  TGDH algorithm specific  ============================= */

/* TGDH_Alg_init  -------------------------------------------------------------------------------
   It initializes a TGDH_Alg data structure
---------------------------------------------------------------------------------------------- */
static void TGDH_Alg_init(TGDH_Alg *tgdh) {
  tgdh->ctx = 0;
  stddll_construct(&(tgdh->msg_deque), sizeof(SSP_Msg*));
  tgdh->ts_delivered_to_app = SSP_FALSE;
  tgdh->vs_ts_received = SSP_FALSE;
  tgdh->num_vs_membs = 0;
  tgdh->wait_for_sec_fl_ok = SSP_FALSE;
  tgdh->state = TGDH_WAIT_FOR_SELF_JOIN;
  tgdh->num_old_tree_msgs = 0;
  tgdh->curr_memb_msg = 0;
  tgdh->curr_grp_op = TGDH_NONE;    
  tgdh->tk = 0;
}

/* TGDH_Alg_destroy -----------------------------------------------------------------------------
   It frees any memory used by TGDH_Alg.
---------------------------------------------------------------------------------------------- */
static void TGDH_Alg_destroy(TGDH_Alg *tgdh) {
  stddll_it lit;
  SSP_Msg *msg;
  
  for(stddll_begin(&(tgdh->msg_deque), &lit); !stddll_it_is_end(&lit); stddll_it_next(&lit)) {
    msg = *(SSP_Msg**) stddll_it_val(&lit);
    SSP_Msg_free(&msg);
  }
  stddll_destruct(&(tgdh->msg_deque));
  
  tgdh_destroy_ctx(&tgdh->ctx, 1);
  tgdh_destroy_token(&tgdh->tk);
}

/* TGDH_Alg_create  ------------------------------------------------------------------------------
   It allocates and initializes a TGDH_Alg data structure. It returns a pointer to the newly 
   created object.
---------------------------------------------------------------------------------------------- */
TGDH_Alg * TGDH_Alg_create() {
  TGDH_Alg * tgdh = (TGDH_Alg*) malloc(sizeof(TGDH_Alg));
    
  if(!tgdh) {
    ssp_err_quit("TGDH_Alg_create: malloc failed\n");
  }
  TGDH_Alg_init(tgdh);

  return tgdh;
}

/* TGDH_Alg_free -------------------------------------------------------------------------------
   Given a pointer pointer to a TGDH_Alg data structure, it frees it and sets the pointer 
   to NULL.
---------------------------------------------------------------------------------------------- */
void TGDH_Alg_free(TGDH_Alg **tgdh) {
  if (*tgdh) {
    TGDH_Alg_destroy(*tgdh);
    free(*tgdh);
    *tgdh = NULL;
  } 
}


/* tgdh_tk_list_remove --------------------------------------------------------------------------
   Remove one item from a token list.
---------------------------------------------------------------------------------------------- */
static TOKEN_LIST *tgdh_tk_list_remove(TOKEN_LIST **tk_list) {
  TOKEN_LIST *tmp_token;

  if((*tk_list) == NULL) {
    return NULL;
  }

  (*tk_list)->token = NULL;
  if((*tk_list)->next){
    tmp_token = (*tk_list)->next;
    tmp_token->end = (*tk_list)->end;
  }
  else{
    tmp_token = NULL;
  }

  if((*tk_list) != NULL) {
    free((*tk_list));
  }
  (*tk_list) = NULL;

  return tmp_token;

}

/* tgdh_tk_list_remove_all ---------------------------------------------------------------------
   Remove all items from a token list. Returns NULL.
---------------------------------------------------------------------------------------------- */
static TOKEN_LIST *tgdh_tk_list_remove_all(TOKEN_LIST *tk_list) {
  while(tk_list != NULL){
    tk_list = tgdh_tk_list_remove(&tk_list);
  }
  return NULL;
}


/* tgdh_tk_list_add -----------------------------------------------------------------------------
   Adds a token to a token list and returns a pointer to the list if succeeded. On failure
   returns NULL. If the passed list is NULL, memory is allocated.  
---------------------------------------------------------------------------------------------- */
static TOKEN_LIST *tgdh_tk_list_add(TOKEN_LIST *tk_list, CLQ_TOKEN *tk) {
  TOKEN_LIST *tmp_list = NULL;

  if(tk == NULL) {
    return NULL;
  }  

  if(tk_list == NULL) {
    if((tk_list = (TOKEN_LIST *) calloc(sizeof(TOKEN_LIST), 1)) == NULL) {
      ssp_err_quit("tgdh_tk_list_add: calloc failed\n");  
    }
    tk_list->token = tk;
    tk_list->end = tk_list;
    tk_list->next = NULL;
  }
  else{
    if(tk_list->end != tk_list){
      if(tk_list->next == NULL){
        tgdh_tk_list_remove_all(tk_list);
        return NULL;
      }
    }
    else{
      if(tk_list->end->next != NULL){
        tgdh_tk_list_remove_all(tk_list);
        return NULL;
      }
    }
    if((tmp_list = (TOKEN_LIST *) calloc(sizeof(TOKEN_LIST), 1)) == NULL) {
      ssp_err_quit("tgdh_tk_list_add: calloc1 failed\n");  
    }
    tmp_list->token = tk;
    tk_list->end->next = tmp_list;
    tk_list->end = tmp_list;
    tmp_list->next = NULL;
    tmp_list->end = NULL;
  }

  return tk_list;
}


/* reset_vs_data  -------------------------------------------------------------------------------
   This function clears variables used to track the cascaded vs memebrships while trying to
   install a secure membership. It needs to be called everytime the algorithm moves to the
   SECURE state.
-----------------------------------------------------------------------------------------------*/
static void reset_vs_data(TGDH_Alg *tgdh) {
  tgdh->num_vs_membs = 0;
  tgdh->ts_delivered_to_app = SSP_FALSE;
  tgdh->vs_ts_received = SSP_FALSE;
}

/* copy_key  ------------------------------------------------------------------------------------
   Helper function that copies the key from the tgdh context in the encryption info.
-----------------------------------------------------------------------------------------------*/
static int copy_key(SSP_Grp *grp) {
  TGDH_Alg *tgdh = (TGDH_Alg*)(grp->ka->info);

  memcpy(grp->enc->key, tgdh->ctx->group_secret_hash, grp->enc->key_len);

  return 0;
}

/* msg_2_tk  -----------------------------------------------------------------------------------
   This function converts a spread message into a tgdh token. The service(event type) is 
   packed in the message too.
-----------------------------------------------------------------------------------------------*/
static void msg_2_tk(SSP_Msg *msg, CLQ_TOKEN *tk, service *serv) {
  int err, length, offset;

  if(Is_old_tree_msg(msg->msg_type) || Is_new_tree_msg(msg->msg_type)) {
    length = msg->msg_len - sizeof(service);
    offset = sizeof(service);

    if((err = scat_get2((char*)serv, msg->scat, -1, 0, 0, sizeof(service))) != sizeof(service)) {
      ssp_err_quit("msg_2_tk: scat_get2 failed\n");
    }
    
    tk->length = length; 
  
    if((tk->t_data = (unsigned char*) malloc(tk->length * sizeof(unsigned char))) == NULL){
      ssp_err_quit("msg_2_tk: malloc failed\n");  
    }
    
    if((err = scat_get2((char*)tk->t_data, msg->scat, -1, 0, offset, tk->length)) != tk->length) {
      ssp_err_quit("msg_2_tk: scat_get2 failed\n");
    }
  }
  else {
    ssp_err_quit("msg_2_tk: Unknown token type\n");
  }
}


/* tk_2_msg  -----------------------------------------------------------------------------------
   Converts a token to a spread message. It returns the size of the message.
--------------------------------------------------------------------------------------------- */
static int tk_2_msg(char **buf, CLQ_TOKEN *tk, int16 msg_type, service serv_type) {
  int msg_len;

  if(Is_old_tree_msg(msg_type) || Is_new_tree_msg(msg_type)) {
    *buf = (unsigned char*) malloc(tk->length * sizeof(unsigned char) + sizeof(service));
    if(!(*buf)) {
      ssp_err_quit("tk_2_msg: malloc failed\n");  
    }
    memcpy(*buf, &serv_type, sizeof(service));
    memcpy(*buf + sizeof(service), tk->t_data, tk->length);
    msg_len = tk->length + sizeof(service);
  }
  else {
    ssp_err_quit("tk_2_msg: Unknown token type\n");
  }

  return msg_len;
}

/* move_msg_con_deque  --------------------------------------------------------------------------
   This function is called when a secure memb. will be installed. It moves all the messages 
   from the ka queue in the connection delivery queue.
---------------------------------------------------------------------------------------------- */
static void move_msg_con_deque(SSP_Con *con, SSP_Grp *grp) {
  TGDH_Alg    *tgdh = (TGDH_Alg *)grp->ka->info;	
  SSP_Msg     *msg_tmp;
  stddll_it   lit;
  
  for(stddll_begin(&(tgdh->msg_deque), &lit); !stddll_it_is_end(&lit); stddll_it_next(&lit)) {
    msg_tmp = *(SSP_Msg**) stddll_it_val(&lit);
    if(Is_encrypt_mess_type(msg_tmp->msg_type)) {   
      if(Dec_Scat(msg_tmp->scat, grp->enc->dec_fcn, grp->enc->block_size, grp->enc->info, 
		  (unsigned int) msg_tmp->msg_len, &msg_tmp->msg_type, msg_tmp->endian_mism) < 0) {
	ssp_err_quit("move_msg_con_deque: Dec_Scat failed!\n");
      }
    } 
    if(Is_reg_memb_mess(msg_tmp->serv_type)) {
      ssp_err_quit("move_msg_con_deque: membership message in the ka queue\n ");
    }
    stddll_push_back(&con->deliv_deque, &msg_tmp);
  }
  stddll_clear(&(tgdh->msg_deque));
}

/* first_user -----------------------------------------------------------------------------------
   This function handles the key agreement when the group contains only one user. 
   It returns void, it fails if tgdh fails.
---------------------------------------------------------------------------------------------- */
static void first_user(SSP_Con *con, SSP_Grp *grp) {
  int        ret_tgdh;
  TGDH_Alg   *tgdh = (TGDH_Alg *)grp->ka->info;	
  char       *joiner = (char*)grp->curr_membs; 

  DEBUG_enter(f_dbg, "first_user");

  tgdh_destroy_ctx(&tgdh->ctx, 1);
  if((ret_tgdh = tgdh_new_member(&tgdh->ctx, joiner, grp->name)) < 0) {
    ssp_err_quit("first_user: tgdh_new_member failed  %d\n", ret_tgdh);
  }
  copy_key(grp);
  stddll_push_back(&con->deliv_deque, &tgdh->curr_memb_msg);
  tgdh->state = TGDH_SECURE;
  grp->ka->key_state = ESTABLISH;
  reset_vs_data(tgdh);
  (*grp->enc->chg_key_fcn)(grp->enc->key, grp->enc->key_len, grp->enc->info);    
  
  DEBUG_leave(f_dbg, "first_user", 0);
}


/* handle_leave_or_partition -------------------------------------------------------------------
   This function handles a leave or a partition (tgdh_cascade + broadcast)
   It returs nothing and exists if either tgdh call or FL_unicast fails.

   Note: all the members can call tgdh_cascade, only the sponsor will return a token.
--------------------------------------------------------------------------------------------- */
static void handle_leave_or_partition(SSP_Con *con, SSP_Grp *grp, stdarr *leave_set) {
  int         ret_tgdh, ret_fl;
  TGDH_Alg    *tgdh = (TGDH_Alg *)grp->ka->info;	
  char        **leave_set_ptr;
  CLQ_TOKEN   *tk_out = 0;
  stdarr_it   ait;
  int         msg_len;
  char*       msg_buf=0;

  DEBUG_enter(f_dbg, "handle_leave_or_partition");
  
  leave_set_ptr = (char**)stdarr_it_val(stdarr_begin(leave_set, &ait));
  if((ret_tgdh = tgdh_cascade(&tgdh->ctx, grp->name, leave_set_ptr, NULL, &tk_out)) < 0) {
    ssp_err_quit("handle_leave_or_partition: tgdh_cascade failed %d\n", ret_tgdh);
  }

  if(tk_out) {
    msg_len = tk_2_msg(&msg_buf, tk_out, TGDH_NEW_TREE, tgdh->curr_memb_msg->serv_type);
    if ((ret_fl = FL_multicast(con->mbox, TGDH_NEW_TREE_TYPE, grp->name, TGDH_NEW_TREE, 
			    msg_len, msg_buf)) < 0) {
      FL_error(ret_fl);
      ssp_err_quit("handle_leave_partition: FL_multicast failed  %d\n", ret_fl);
    }
    ON_DEBUG(fprintf(f_dbg, "handle_leave_partition: mulicasted %d bytes\n", ret_fl));
  }
  tgdh->state = TGDH_WAIT_FOR_NEW_TREE;
  
  if(msg_buf) {
    free(msg_buf);
  }
  tgdh_destroy_token(&tk_out);
  
  DEBUG_leave(f_dbg, "handle_leave_or_partition", 0);
}


/* handle_merge -------------------------------------------------------------------------------
   This function starts a merge algorithm. Join is handled as a particular case of merge.
   
   It returns nothing, it fails if either tgdh or flush calls failed.
--------------------------------------------------------------------------------------------- */
static void handle_merge(SSP_Con *con, SSP_Grp *grp, stdarr *merge_set, int is_self_join) {
  int         ret_tgdh, ret_fl;
  TGDH_Alg    *tgdh = (TGDH_Alg *)grp->ka->info;  
  CLQ_TOKEN   *tk_out = 0;
  int         msg_len;
  char        *msg_buf = 0;

  DEBUG_enter(f_dbg, "handle_merge");
  
  if(is_self_join) {
    if((ret_tgdh = tgdh_new_member(&tgdh->ctx, con->priv_name, grp->name)) < 0) {
      ssp_err_quit("first_user: tgdh_new_member failed  %d\n", ret_tgdh);
    }
    ON_DEBUG(fprintf(f_dbg, "Self_join, ctx created\n");)
  }

  if((ret_tgdh = tgdh_merge_req(tgdh->ctx, con->priv_name, grp->name, NULL, &tk_out)) < 0) {
    ssp_err_quit("handle_merge: tgdh_merge_request failed %d\n", ret_tgdh);
  }

  if(tk_out) {
    msg_len = tk_2_msg(&msg_buf, tk_out, TGDH_OLD_TREE, tgdh->curr_memb_msg->serv_type);
    if ((ret_fl = FL_multicast(con->mbox, TGDH_OLD_TREE_TYPE, grp->name, TGDH_OLD_TREE, 
			    msg_len, msg_buf)) < 0) {
      FL_error(ret_fl);
      ssp_err_quit("handle_merge: FL_multicast failed %d\n", ret_fl);
    }
    ON_DEBUG(fprintf(f_dbg, "TGDH_OLD_TREE (%d bytes) multicasted\n", ret_fl);)
  }
  tgdh->state = TGDH_WAIT_FOR_OLD_TREE;
  tgdh->num_old_tree_msgs = 0;
  
  if(msg_buf) {
    free(msg_buf);
  }
  tgdh_destroy_token(&tk_out);
  
  DEBUG_leave(f_dbg, "handle_merge", 0);
}

/* handle_data_msg ----------------------------------------------------------------------------- 
   This function specifies the actions taken by the state machine if the message received was
   a data message (message received from the flush layer).
-----------------------------------------------------------------------------------------------*/
static int handle_data_msg(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, TGDH_Alg *tgdh) {
  int ret = DONT_DELIV_MSG;
  
  DEBUG_enter(f_dbg, "handle_data_msg");

  switch(tgdh->state) {
  case TGDH_SECURE:
    ssp_err_quit("handle_data_msg: this message should not be here\n");
    break;
    
  case TGDH_WAIT_FOR_OLD_TREE:
  case TGDH_WAIT_FOR_SELF_JOIN:
    ssp_err_quit("handle_data_msg: no message should be received in this state\n");
    break;

  case TGDH_WAIT_FOR_NEW_TREE:
    stddll_push_back(&tgdh->msg_deque, &msg);
    break;

  case TGDH_WAIT_FOR_MEMBERSHIP:
    ret = DELIV_MSG;
    break;
  }

  DEBUG_leave(f_dbg, "handle_data_msg", ret);
  return ret;
}


/* handle_trans ---------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a transitional message.
---------------------------------------------------------------------------------------------- */
static int handle_trans(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, TGDH_Alg *tgdh) {
  int ret = DONT_DELIV_MSG;

  DEBUG_enter(f_dbg, "handle_trans");

  switch(tgdh->state) {
  case TGDH_SECURE:
    if(tgdh->ts_delivered_to_app == SSP_FALSE) {
      tgdh->ts_delivered_to_app = SSP_TRUE;
      ret = DELIV_MSG;
    }
    break;

  case TGDH_WAIT_FOR_OLD_TREE:
  case TGDH_WAIT_FOR_NEW_TREE:
  case TGDH_WAIT_FOR_MEMBERSHIP:
    if(tgdh->ts_delivered_to_app == SSP_FALSE) {
      tgdh->ts_delivered_to_app = SSP_TRUE;
      ret = DELIV_MSG;
    }
    if(tgdh->num_vs_membs > 0) {
      tgdh->vs_ts_received = SSP_TRUE;
    }
    break;
    
  case TGDH_WAIT_FOR_SELF_JOIN:
    ssp_err_quit("handle_trans: trans received in wrong state, %d!\n", tgdh->state);
    break;
  }
  
  DEBUG_leave(f_dbg, "handle_trans", ret);
  return ret;
}


/* handle_memb ----------------------------------------------------------------------------------
  This function specifies the actions taken by the state machine if the message received was
  a group membership.

  Some comments:
      a member in the WAIT_FOR_SELF_JOIN can receive 2 events: a membership due to its own join
      (a join event) or a membership due to a network event (in this case the joinee is on the
      list of new added members. Flush delivers this special network in some cases:
      -  a partiton happen after the join and before the new membership is delivered
      -  the join happened while a previous partition was processed, so the two events are
         combined in one
      -  somebody left immediately after my join. Since flush membership deliveries are based
         on gathering flush_oks from old members, if the guy that left did not send his 
         flush_ok, the two events will be combined. Note that if he managed to send his
         flush_ok, then the join will be delivered first, then the leave.
---------------------------------------------------------------------------------------------- */
static int handle_memb(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, TGDH_Alg *tgdh) {
  int    ret = DONT_DELIV_MSG, was_leave = 0;
  stdarr join_set;
  stdarr leave_set;


  DEBUG_enter(f_dbg, "handle_memb");
  
  stdarr_construct(&leave_set, sizeof(char*));
  stdarr_construct(&join_set, sizeof(char*));

  switch(tgdh->state) {
  case TGDH_SECURE:
  case TGDH_WAIT_FOR_OLD_TREE:
  case TGDH_WAIT_FOR_NEW_TREE:
    ssp_err_quit("handle_memb: memb received in wrong state, %d!\n", tgdh->state);
    break;

  case TGDH_WAIT_FOR_SELF_JOIN:
    grp->ka->key_state = NOT_ESTABLISH;
    tgdh->num_vs_membs++;

    init_vs_set(grp); 
    was_leave = upd_vs_set_and_get_join_leave_set(grp, msg->serv_type, &join_set, &leave_set);
    
    if(tgdh->curr_memb_msg != NULL) { /* free prev. memb that we were trying to install  */
      SSP_Msg_free(&(tgdh->curr_memb_msg));
    }
    tgdh->curr_memb_msg = msg;  /* delay delivery of memb  */
    tgdh->curr_grp_op = TGDH_ADD;

    if(stdhash_size(&grp->curr_membs_hash) > 1) {
      if(Is_reg_memb_mess(msg->serv_type)) {
	if(Is_caused_join_mess(msg->serv_type)) {
	  handle_merge(con, grp, &join_set, 1); /* self_join */
	}	      
	else if(Is_caused_leave_mess(msg->serv_type) || Is_caused_disconnect_mess(msg->serv_type)) {
	  ssp_err_quit("handle_memb: leave or disconnect in the wrong state %d\n", tgdh->state);
	  ;
	}
	else if(Is_caused_network_mess(msg->serv_type)) {
	  ssp_err_quit("handle_memb: network in self join, not supported yet %d\n", tgdh->state);
	}
      }
    }
    else {
      first_user(con, grp);
    }
    break;
    
  case TGDH_WAIT_FOR_MEMBERSHIP:
    grp->ka->key_state = NOT_ESTABLISH;
    tgdh->num_vs_membs++;
    
    if(tgdh->num_vs_membs == 1) { /* first vs memb from a possible cascaded vs membs */
      init_vs_set(grp); 
    }
    was_leave = upd_vs_set_and_get_join_leave_set(grp, msg->serv_type, &join_set, &leave_set);
    
    if (was_leave  && (tgdh->ts_delivered_to_app == SSP_FALSE)) { 
      tgdh->ts_delivered_to_app = SSP_TRUE;
      gen_and_push_msg(con, grp, TRANSITION_MESS);
    }

    if((tgdh->num_vs_membs > 1) && tgdh->curr_memb_msg != NULL) { /* free prev. memb that we were trying to install  */
      SSP_Msg_free(&(tgdh->curr_memb_msg));
    }
    tgdh->curr_memb_msg = msg; /* delay delivery of memb  */
    
    if(stdhash_size(&grp->curr_membs_hash) > 1) {
      if(stdarr_size(&leave_set) > 1) { /* count the NULL too */
	if(stdarr_size(&join_set) <= 1) {  /* only partition or leave, count the NULL too  */
	  tgdh->curr_grp_op = TGDH_SUBTRACT;
	  handle_leave_or_partition(con, grp, &leave_set);
	}
	else {
	  tgdh->curr_grp_op = TGDH_BOTH;
	  ssp_err_quit("handle_memb: combined leave and merge not handle yet\n");
	}
      }
      else { /*  merge &  join */
	tgdh->curr_grp_op = TGDH_ADD;
	handle_merge(con, grp, &join_set, 0); /* join or merge but nor self_join */
      }
    }  
    else { /* alone  */
      first_user(con, grp);
    }
    break;
  }

  stdarr_destruct(&leave_set);  
  stdarr_destruct(&join_set);      

  DEBUG_leave(f_dbg, "handle_memb", ret);
  return ret;
}


/* handle_old_tree -------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   an old tree message.
---------------------------------------------------------------------------------------------- */
static int handle_old_tree(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, TGDH_Alg *tgdh) {
  int         ret = DONT_DELIV_AND_FREE_MSG;
  CLQ_TOKEN   *tk_out = 0;
  CLQ_TOKEN   *tk_in;  
  TOKEN_LIST  *tk_in_list = NULL;
  int         ret_tgdh, ret_fl;
  int         msg_len;
  char        *msg_buf = 0;
  service     serv;

  DEBUG_enter(f_dbg, "handle_old_tree");

  switch(tgdh->state) {
  case TGDH_WAIT_FOR_OLD_TREE:
    if((tk_in = (CLQ_TOKEN*)malloc(sizeof(CLQ_TOKEN))) == NULL) {
      ssp_err_quit("handle_old_tree: malloc failed \n");
    }

    msg_2_tk(msg, tk_in, &serv);
    tgdh->num_old_tree_msgs++;
    if(tgdh->num_old_tree_msgs == 2) { /* got both */
      if(tgdh->vs_ts_received == SSP_TRUE) { /* everybody abandons, wait for Fl_req to move to MEMB. */
	tgdh_destroy_token(&tgdh->tk);
	tgdh->num_old_tree_msgs = 0;
	tgdh_destroy_token(&tk_in);
      }
      else { /* can apply both messages */
        /* build the list of tokens */
	tk_in_list = tgdh_tk_list_add(tk_in_list, tgdh->tk);
	tk_in_list = tgdh_tk_list_add(tk_in_list, tk_in);
	if((ret_tgdh = tgdh_cascade(&tgdh->ctx, grp->name, NULL, tk_in_list, &tk_out)) < 0) {
	  ssp_err_quit("handle_old_tree: tgdh_cascade failed 1 %d\n", ret_tgdh);
	}
	ON_DEBUG(fprintf(f_dbg, "tgdh_cascade returned:  %d\n", ret_tgdh);)
	  
	if(tk_out) {
	  msg_len = tk_2_msg(&msg_buf, tk_out, TGDH_NEW_TREE, tgdh->curr_memb_msg->serv_type);
	  if ((ret_fl = FL_multicast(con->mbox, TGDH_NEW_TREE_TYPE, grp->name, TGDH_NEW_TREE, 
				  msg_len, msg_buf)) < 0) {
	    FL_error(ret_fl);
	    ssp_err_quit("handle_old_tree: FL_multicast failed %d\n", ret_fl);
	  }
	  
	  if(msg_buf) {
	    free(msg_buf);
	    msg_buf = 0;
	  }
	  tgdh_destroy_token(&tk_out);
	  ON_DEBUG(fprintf(f_dbg, "TGDH_NEW_TREE (%d bytes) multicasted\n", ret_fl);)
	}
	
	tgdh_destroy_token(&tgdh->tk);
	tgdh_destroy_token(&tk_in);
	tgdh_tk_list_remove_all(tk_in_list);

	tgdh->state = TGDH_WAIT_FOR_NEW_TREE;
      }
    }
    else if(tgdh->num_old_tree_msgs == 1){ /* save the token, wait for the other one  */
      tgdh->tk = tk_in;
    }
    else {
      ssp_err_quit("handle_old_tree: protocol in wrong state\n");
    }
    break;

  case TGDH_SECURE:
  case TGDH_WAIT_FOR_NEW_TREE:
    ON_DEBUG(fprintf(f_dbg, "handle_old_tree:  DROPPING MESSAGE ========== \n ");)
    break;
  
  case TGDH_WAIT_FOR_SELF_JOIN:
    ssp_err_quit("handle_old_tree: old tree msg in wrong state\n");
    break;

  case TGDH_WAIT_FOR_MEMBERSHIP:
    if(tgdh->curr_grp_op == TGDH_ADD) { /* current event was additive so I might get two old tree msgs here */
      if((tk_in = (CLQ_TOKEN*)malloc(sizeof(CLQ_TOKEN))) == NULL) {
	ssp_err_quit("handle_old_tree: malloc failed \n");
      }
      
      msg_2_tk(msg, tk_in, &serv);
      tgdh->num_old_tree_msgs++;
      if(tgdh->num_old_tree_msgs == 2) { /* got both */
	if(tgdh->vs_ts_received == SSP_TRUE) { /* everybody abandons, wait for Fl_req to move to MEMB. */
	  tgdh_destroy_token(&tgdh->tk);
	  tgdh->num_old_tree_msgs = 0;
	  tgdh_destroy_token(&tk_in);
	}
	else { /* can apply both messages, but drop the token */
          /* build the list of tokens */
	  tk_in_list = tgdh_tk_list_add(tk_in_list, tgdh->tk);
	  tk_in_list = tgdh_tk_list_add(tk_in_list, tk_in);
	  if((ret_tgdh = tgdh_cascade(&tgdh->ctx, grp->name, NULL, tk_in_list, &tk_out)) < 0) {
	    ssp_err_quit("handle_old_tree: tgdh_cascade failed 2 %d \n", ret_tgdh);
	  }
	  if(tk_out) {
	    tgdh_destroy_token(&tk_out);
	  }
	  
	  ON_DEBUG(fprintf(f_dbg, "tgdh_cascade returned:  %d\n", ret_tgdh);)	 
	}
	
	tgdh_destroy_token(&tgdh->tk);
	tgdh_destroy_token(&tk_in);
	tgdh_tk_list_remove_all(tk_in_list);
      }
      else if(tgdh->num_old_tree_msgs == 1){ /* save the token, wait for the other one  */
	tgdh->tk = tk_in;
      }
      else {
	ssp_err_quit("handle_old_tree: protocol in wrong state\n");
      }  
    }
    else {
      ON_DEBUG(fprintf(f_dbg, "Dropping old tree msg in WAIT_FOR_MEMBERSHIP\n") );
    }    
    break;
  }

  DEBUG_leave(f_dbg, "handle_old_tree", ret);
  return ret;
}


/* handle_new_tree --------------------------------------------------------------------------
  This function specifies the actions taken by the state machine if the message received was
  a new tree message.

  All the members call tgdh_cascade either in the second step of join/merge/leave when one
  tgdh_cascade call should be enough, or in the partition case when more than one round of
  tgdh cascade and NEW_TREE messages might be needed. 

  NOTE: in case of a cascading due to a join, the joiner starts in WAIT_FOR_SELF_JOIN 
        and it never knows it it was a cascading or not so he deliveres JOIN while 
        all the other members of the group will deliver NETWORK. That's why each
        members that passes along the partial token attaches also its group event,
        and if it was join is upgraded to network. With the final token broadcast
        everybody agreed to deliver that group event type.
---------------------------------------------------------------------------------------------- */
static int handle_new_tree(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, TGDH_Alg *tgdh) {
  int         ret = DONT_DELIV_AND_FREE_MSG, ret_tgdh, ret_fl;
  CLQ_TOKEN   *tk_out = 0;
  CLQ_TOKEN   tk_in = {0}; 
  TOKEN_LIST  tk_in_list[1];
  int         msg_len;
  char        *msg_buf=0;
  service     serv;

  DEBUG_enter(f_dbg, "handle_new_tree");

  switch(tgdh->state) {
  case TGDH_WAIT_FOR_NEW_TREE:
    msg_2_tk(msg, &tk_in, &serv);

    if(tgdh->vs_ts_received == SSP_TRUE) {
      ON_DEBUG(fprintf(f_dbg, "vs_ts_received is TRUE\n");) /* everybody abandons, wait to get the Fl_req */
    }                                               /* and then move to MEMB. */
    else {
      /* update the service type for the current membership handled */
      if(Is_caused_network_mess(serv) && Is_caused_join_mess(tgdh->curr_memb_msg->serv_type)) {
	tgdh->curr_memb_msg->serv_type = serv;
      }
      
      tk_in_list->token = &tk_in;
      tk_in_list->next = NULL;
      if((ret_tgdh = tgdh_cascade(&tgdh->ctx, grp->name, NULL, tk_in_list, &tk_out)) < 0) {
	ssp_err_quit("handle_new_tree: tgdh_cascade failed %d\n", ret_tgdh);
      }
      ON_DEBUG(fprintf(f_dbg, "tgdh cascade returned %d  token_out is %p \n", ret_tgdh, tk_out);)
	
      /* if a token was output need to send it */
      if(tk_out) {	
	msg_len = tk_2_msg(&msg_buf, tk_out, TGDH_NEW_TREE, tgdh->curr_memb_msg->serv_type);
	if ((ret_fl = FL_multicast(con->mbox, TGDH_NEW_TREE_TYPE, grp->name, TGDH_NEW_TREE, 
				msg_len, msg_buf)) < 0) {
	  FL_error(ret_fl);
	  ssp_err_quit("handle_new_tree: FL_multicast failed %d\n", ret_fl);
	}
      }
      if(ret_tgdh == OK) {     /* I'm done and I know that the others will be able */
	copy_key(grp);         /* to compute the key out of the token I just sent */
	grp->ka->key_state = ESTABLISH;      
	(*grp->enc->chg_key_fcn)(grp->enc->key, grp->enc->key_len, grp->enc->info);
	
	if(tgdh->num_vs_membs > 1) { /* collapsed memb, deliv. NETWORK  */
	  tgdh->curr_memb_msg->serv_type = REG_MEMB_MESS | CAUSED_BY_NETWORK;
	}
	
	if(Is_caused_network_mess(tgdh->curr_memb_msg->serv_type)) { /* update vs. */
	  set_vs_set_memb_msg(tgdh->curr_memb_msg, grp); 
	}
	
	  /* first put the new secure memb in the connection queue */
	stddll_push_back(&con->deliv_deque, &tgdh->curr_memb_msg);
	move_msg_con_deque(con, grp);
	
	tgdh->state = TGDH_SECURE;
	reset_vs_data(tgdh);
	
	if(tk_in.t_data) {
	  free(tk_in.t_data);
	  tk_in.t_data = NULL;
	} 
      }
    }
    
  break;
    
  case TGDH_SECURE:
    ON_DEBUG(fprintf(f_dbg, "handle_new_tree, dropping tree ========= x\n");)
    break;

  case TGDH_WAIT_FOR_OLD_TREE:
  case TGDH_WAIT_FOR_SELF_JOIN:
    ssp_err_quit("handle_new_tree: new tree in wrong state!\n");
    break;

  case TGDH_WAIT_FOR_MEMBERSHIP:
    ssp_err_quit("Dropping new tree msg in WAIT_FOR_MEMBERSHIP\n");
    break;
  }  

  if(msg_buf) {
    free(msg_buf);
  }
  
  if(tk_in.t_data) {
    free(tk_in.t_data);
    tk_in.t_data = NULL;
  } 
  tgdh_destroy_token(&tk_out);
  
  DEBUG_leave(f_dbg, "handle_new_tree", ret);
  return ret;
}

/* handle_fl_req -------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a flush request message.
   
   If a flush_req was answered and then the alg moves to TGDH_WAIT_FOR_MEMBERSHIP in any of the
   TGDH_WAIT_FOR_OLD_TREE or TGDH_WAIT_FOR_NEW_TREE states, then it means that a cascaded
   membership happen, and when the protocol finishes, a NETWORK will be delivered to the 
   application.
---------------------------------------------------------------------------------------------- */
static int handle_fl_req(SSP_Con *con, SSP_Grp *grp, SSP_Msg *mess, TGDH_Alg *tgdh) {
  int ret = DONT_DELIV_AND_FREE_MSG;

  DEBUG_enter(f_dbg, "handle_fl_req");

  switch(tgdh->state) {
  case TGDH_SECURE:
    tgdh->wait_for_sec_fl_ok = SSP_TRUE;
    ret = DELIV_MSG; 
    break;

  case TGDH_WAIT_FOR_OLD_TREE:
  case TGDH_WAIT_FOR_NEW_TREE:
    if ((ret = FL_flush(con->mbox, grp->name)) < 0) {
      FL_error(ret);
      ssp_err_quit("handle_fl_req: FL_multicast failed %d!\n", ret);
    }
    tgdh->state = TGDH_WAIT_FOR_MEMBERSHIP;
    ret = DONT_DELIV_AND_FREE_MSG;
    break;
    
  case TGDH_WAIT_FOR_SELF_JOIN:
  case TGDH_WAIT_FOR_MEMBERSHIP:
    ssp_err_quit("handle_fl_req: fl_req received in wrong state, not possible !\n");
    break;
  }

  DEBUG_leave(f_dbg, "handle_fl_req", ret);
  return ret;
}


/* ============================  wrapper functions for tgdh  =================================== */

/* TGDH_handles_mess -----------------------------------------------------------------------------
   This function specifies if a spread message is used or not by the key agreement algorithm.
   All the messages specified here will be redirected by spread to TGDH_Comp_Key_Wrapper;
   In this case, all the membership messages (including transitional messages) are sended,
   Also the regular messages used internal by the key agreement algorithm and regular messages 
   received between having a stable key, are sent here.
----------------------------------------------------------------------------------------------- a*/
int TGDH_handles_msg(SSP_Msg *msg, SSP_Grp *grp) {
  service serv_type = msg->serv_type;
  int     msg_type  = msg->msg_type;
  
  return  !Is_regular_mess(serv_type) || grp->ka->key_state == NOT_ESTABLISH ||
    msg_type == TGDH_OLD_TREE || msg_type == TGDH_NEW_TREE;
}


/* TGDH_handle_recv ----------------------------------------------------------------------------
   This function is implementing the state machine for the key agreement algorithm. 
   It returns 1 if the message must be delivered by the SSP, 0 otherwise. The SSP can check if 
   the key agreement finished by looking and Key_State.
-----------------------------------------------------------------------------------------------*/
int TGDH_handle_recv(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg) {
  int  ret = DELIV_MSG;
  TGDH_Alg *tgdh = (TGDH_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "TGDH_handle_recv");
  
  if(Is_regular_mess(msg->serv_type)) {
    if(Is_old_tree_msg(msg->msg_type)) {
      ret = handle_old_tree(con, grp, msg, tgdh);
    }
    else if(Is_new_tree_msg(msg->msg_type)) {
      ret = handle_new_tree(con, grp, msg, tgdh);
    }
    else {
      ret = handle_data_msg(con, grp, msg, tgdh);
    }
  }
  else if(Is_flush_req_mess(msg->serv_type)) {
    ret = handle_fl_req(con, grp, msg, tgdh);
  }
  else if(Is_membership_mess(msg->serv_type)) {
    if(Is_self_leave_mess(msg->serv_type)) {
      ;
    }
    else if(Is_transition_mess(msg->serv_type)) {
      ret = handle_trans(con, grp, msg, tgdh);
    }
    else {
      ret = handle_memb(con, grp, msg, tgdh);
    }
  }

  DEBUG_leave(f_dbg, "TGDH_handle_recv", ret);
  return ret;  
}

/* TGDH_handle_fl_ok ----------------------------------------------------------------------------
   This function specifies the action taken by the key agreement state machine if a flush
   ok event happen. This is actually Secure_Flush_Ok, sent by the user using SSP_Flush, 
   which does not sent the flush okinvoking directlly FL_flush, but calls this function to 
   handle it.
-----------------------------------------------------------------------------------------------*/
int TGDH_handle_fl_ok(SSP_Con *con, SSP_Grp *grp){
  int  ret = DELIV_MSG;
  TGDH_Alg *tgdh = (TGDH_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "TGDH_handle_fl_ok");
  
  switch(tgdh->state) {
  case TGDH_SECURE:
    if(tgdh->wait_for_sec_fl_ok == SSP_TRUE) {
      tgdh->wait_for_sec_fl_ok = SSP_FALSE;      
      if ((ret = FL_flush(con->mbox, grp->name)) < 0) {
	FL_error(ret);
	goto end;
      }
      tgdh->state = TGDH_WAIT_FOR_MEMBERSHIP;
    }
    else {
      ret = FLUSH_OK_ALREADY_SENT;
    }
    break;
    
  case TGDH_WAIT_FOR_SELF_JOIN:
  case TGDH_WAIT_FOR_MEMBERSHIP:
  case TGDH_WAIT_FOR_OLD_TREE:
  case TGDH_WAIT_FOR_NEW_TREE:
    ret = FLUSH_OK_ALREADY_SENT;
    break;    
  }
  
 end:
  DEBUG_leave(f_dbg, "TGDH_handle_fl_ok", ret);
  return ret;  
}

/* TGDH_handle_send ----------------------------------------------------------------------------
   This function specifies the actions taken by the key agreement state machine, if the event
   that happen is a 'user' message. The event is caused by a user calling SSP_scat_multicast
   or SSP_multicast. Right now this function allows or not the sending of the 'user' messages. 
   The user is not allowed to send messages while the key agreement is performing.
--------------------------------------------------------------------------------------------- */
int TGDH_handle_send(SSP_Con *con, SSP_Grp *grp) {
  int  ret = DELIV_MSG;
  TGDH_Alg *tgdh = (TGDH_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "TGDH_handle_send");

  switch(tgdh->state) {
  case TGDH_SECURE:
    ret = SEND_MSG;
    break;

  case TGDH_WAIT_FOR_SELF_JOIN:
  case TGDH_WAIT_FOR_MEMBERSHIP:
  case TGDH_WAIT_FOR_OLD_TREE:
  case TGDH_WAIT_FOR_NEW_TREE:
    ret = DONT_SEND_MSG;
    break;
  }

  DEBUG_leave(f_dbg, "TGDH_handle_send", ret);
  return ret;
}




