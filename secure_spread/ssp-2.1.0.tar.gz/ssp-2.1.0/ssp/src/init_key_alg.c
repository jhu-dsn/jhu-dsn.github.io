/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */










/***********************************************************************************************/
/* init_key_alg.c                                                                              */
/* These functions create and destroy SSP_Key_Alg, with the data specific to a key             */
/* agreement algorithm.                                                                        */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: July 9, 1999                                                                       */
/* Modified: Jun 23 by Cristina Nita-Rotaru                                                    */
/* Modified: Jun 23 by Cristina Nita-Rotaru, separate CKD from GDH                             */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#include <stdlib.h>
#include <assert.h>

#include "clq_alg.h"
#include "ckd_alg.h"
#include "tgdh_alg.h"
#include "bd_alg.h"
#include "str_alg.h"
#include "ssp_error.h"

#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif


/* SSP_Ka_create -------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------*/
SSP_Ka* SSP_Ka_create(unsigned int key_len, int alg) {
  SSP_Ka *ka = (SSP_Ka*)malloc(sizeof(SSP_Ka));
  
  if(!ka) {
    ssp_err_quit("SSP_Ka_create: malloc failed 1\n");   
  }

  if(alg == SSP_CLIQUES_ALG) {
    CLQ_Alg *clq = CLQ_Alg_create();
    SSP_Ka_set(ka, SSP_CLIQUES_ALG, clq, key_len, CLQ_handles_msg, CLQ_handle_recv, 
	       CLQ_handle_fl_ok, CLQ_handle_send);
  }
  else if(alg == SSP_CKD_ALG) {
    CKD_Alg *ckd = CKD_Alg_create();
    SSP_Ka_set(ka, SSP_CKD_ALG, ckd, key_len, CKD_handles_msg, CKD_handle_recv, 
	       CKD_handle_fl_ok, CKD_handle_send);
  }
  else if(alg == SSP_TGDH_ALG) {
    TGDH_Alg *tgdh = TGDH_Alg_create();
    SSP_Ka_set(ka, SSP_TGDH_ALG, tgdh, key_len, TGDH_handles_msg, TGDH_handle_recv, 
	       TGDH_handle_fl_ok, TGDH_handle_send);
  }
  else if(alg == SSP_BD_ALG) {
    BD_Alg *bd = BD_Alg_create();
    SSP_Ka_set(ka, SSP_BD_ALG, bd, key_len, BD_handles_msg, BD_handle_recv, 
	       BD_handle_fl_ok, BD_handle_send);
  }
  else if(alg == SSP_STR_ALG) {
    STR_Alg *str = STR_Alg_create();
    SSP_Ka_set(ka, SSP_STR_ALG, str, key_len, STR_handles_msg, STR_handle_recv, 
	       STR_handle_fl_ok, STR_handle_send);
  }
  else {
    free(ka);
    ka = NULL;
  }

  return ka;
}


/* SSP_Ka_destroy ------------------------------------------------------------------------------
   It frees any memory allocated by a SSP_Ka data structure. 
-----------------------------------------------------------------------------------------------*/
void SSP_Ka_destroy(SSP_Ka *ka) {
  assert(ka != NULL);
  
  if (ka->name == SSP_CLIQUES_ALG) {
    CLQ_Alg *clq = (CLQ_Alg *)(ka->info);
    CLQ_Alg_free(&clq);
    ka->info = NULL;
  }
  else if (ka->name == SSP_CKD_ALG) {
    CKD_Alg *ckd = (CKD_Alg *)(ka->info);
    CKD_Alg_free(&ckd);
    ka->info = NULL;
  }
  else if (ka->name == SSP_TGDH_ALG) {
    TGDH_Alg *tgdh = (TGDH_Alg *)(ka->info);
    TGDH_Alg_free(&tgdh);
    ka->info = NULL;
  }
  else if (ka->name == SSP_BD_ALG) {
    BD_Alg *bd = (BD_Alg *)(ka->info);
    BD_Alg_free(&bd);
    ka->info = NULL;
  }
  else if (ka->name == SSP_STR_ALG) {
    STR_Alg *str = (STR_Alg *)(ka->info);
    STR_Alg_free(&str);
    ka->info = NULL;
  }
}








