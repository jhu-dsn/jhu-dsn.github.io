/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */










/***********************************************************************************************/
/* bd_alg.c                                                                                    */
/* Implements BD protocol                                                                      */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: March 20, 2001                                                                     */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "bd_alg.h"
#include "ssp_info.h"
#include "scatter.h"
#include "scatter_cryptor.h"
#include "fl.h"
#include "ssp.h"
#include "utility.h"
#include "ssp_dbg.h"

#include <stdutil/stddefines.h>
#include <stdutil/stderror.h>
#include <stdutil/stddll.h>
#include <stdutil/stdhash.h>
#include <stdutil/stdarr.h>

#include "ssp_p.h"
#include "ssp_error.h"

#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif

#include "error.h"
#include "bd_api_misc.h"

extern FILE *f_dbg;

/* ==================================  BD  algorithm specific  ============================= */

/* BD_Alg_init  -------------------------------------------------------------------------------
   It initializes a BD_Alg data structure.
---------------------------------------------------------------------------------------------- */
static void BD_Alg_init(BD_Alg *bd) {
  bd->ctx = 0;
  stddll_construct(&(bd->msg_deque), sizeof(SSP_Msg*));
  bd->ts_delivered_to_app = SSP_FALSE;
  bd->vs_ts_received = SSP_FALSE;
  bd->num_vs_membs = 0;
  bd->wait_for_sec_fl_ok = SSP_FALSE;
  bd->curr_memb_msg = 0;
  bd->state = BD_WAIT_FOR_SELF_JOIN;
  bd->num_xi_messages = 0;
}

/* BD_Alg_destroy -----------------------------------------------------------------------------
   It frees any memory dynamically allocated for a BD_Alg structure.
---------------------------------------------------------------------------------------------- */
static void BD_Alg_destroy(BD_Alg *bd) {
  stddll_it lit;
  SSP_Msg *msg;
  
  for(stddll_begin(&(bd->msg_deque), &lit); !stddll_it_is_end(&lit); stddll_it_next(&lit)) {
    msg = *(SSP_Msg**) stddll_it_val(&lit);
    SSP_Msg_free(&msg);
  }
  stddll_destruct(&(bd->msg_deque));
  bd_destroy_ctx(&bd->ctx);
}

/* BD_Alg_create  ------------------------------------------------------------------------------
   It allocates and initializes a BD_Alg data structure. It returns a pointer to the newly 
   created object.
---------------------------------------------------------------------------------------------- */
BD_Alg * BD_Alg_create() {
  BD_Alg * bd = (BD_Alg*) malloc(sizeof(BD_Alg));
    
  if(!bd) {
    ssp_err_quit("BD_Alg_create: malloc failed\n");
  }
  BD_Alg_init(bd);

  return bd;
}

/* BD_Alg_free -------------------------------------------------------------------------------
   Given a pointer pointer to a BD_Alg object, it frees it and sets the content to NULL.
---------------------------------------------------------------------------------------------- */
void BD_Alg_free(BD_Alg **bd) {
  if (*bd) {
    BD_Alg_destroy(*bd);
    free(*bd);
    *bd = NULL;
  } 
}

/* reset_vs_data  -------------------------------------------------------------------------------
   This function clears variables used to track the cascaded vs memebrships while trying to
   install a secure membership. It needs to be called everytime the algorithm moves to the
   SECURE state.
-----------------------------------------------------------------------------------------------*/
static void reset_vs_data(BD_Alg *bd) {
  bd->num_vs_membs = 0;
  bd->ts_delivered_to_app = SSP_FALSE;
  bd->vs_ts_received = SSP_FALSE;
  bd->num_xi_messages = 0;
}

/* copy_key  ------------------------------------------------------------------------------------
   Helper function that copies the key from the bd context in the encryption info.
-----------------------------------------------------------------------------------------------*/
static int copy_key(SSP_Grp *grp) {
  BD_Alg *bd = (BD_Alg*)(grp->ka->info);
  
  memcpy(grp->enc->key, bd->ctx->group_secret_hash, grp->enc->key_len);

  ON_DEBUG (
    {
      int i;
      fprintf(f_dbg, "The key is: 0x");
      for (i = 0; i < grp->enc->key_len; i++){
	fprintf(f_dbg, "%02X", ((unsigned char*)(grp->enc->key))[i]);
      }
      fprintf(f_dbg, "\n");
    }
  )

  return 0;
}

/* msg_2_tk  -----------------------------------------------------------------------------------
   This function copies a spread message into a bd token. The necessary memory for the data
   in the bd token is allocated.
-----------------------------------------------------------------------------------------------*/
static void msg_2_tk(SSP_Msg *msg, CLQ_TOKEN *tk, service *serv) {
  int err, length, offset;

  if(Is_Zi_msg(msg->msg_type) || Is_Xi_msg(msg->msg_type)) {
    length = msg->msg_len - sizeof(service);
    offset = sizeof(service);
    
    if((err = scat_get2((char*)serv, msg->scat, -1, 0, 0, sizeof(service))) != sizeof(service)) {
      ssp_err_quit("msg_2_tk: scat_get2 failed\n");
    }
    
    tk->length = length; 

    if((tk->t_data = (unsigned char*) malloc(tk->length * sizeof(unsigned char))) == NULL) {
      ssp_err_quit("msg_2_tk: malloc failed\n");  
    }
    
    if((err = scat_get2((char*)tk->t_data, msg->scat, -1, 0, offset, tk->length)) != tk->length) {
      ssp_err_quit("msg_2_tk: scat_get2 failed\n");
    }
  }
  else {
    ssp_err_quit("msg_2_tk: Unknown token type\n");
  }
}


/* tk_2_msg  -----------------------------------------------------------------------------------
   This function converts a bd token to a spread message. It allocates a buffer if necessary
   and puts the data that will be multicasted in it. The service is first embedded in the
   message.
   Returns the length of the message
-----------------------------------------------------------------------------------------------*/
static int tk_2_msg(char **buf, CLQ_TOKEN *tk, int16 msg_type, service serv_type) {
  int msg_len;

  if(Is_Zi_msg(msg_type) || Is_Xi_msg(msg_type)) {
    *buf = (unsigned char*) malloc(tk->length * sizeof(unsigned char) + sizeof(service));
    if(!(*buf)) {
      ssp_err_quit("tk_2_msg: malloc failed\n");  
    }
    memcpy(*buf, &serv_type, sizeof(service));
    memcpy(*buf + sizeof(service), tk->t_data, tk->length);
    msg_len = tk->length + sizeof(service);
  }
  else {
    ssp_err_quit("tk_2_msg: Unknown token type\n");
  }

  return msg_len;
}


/* move_msg_con_deque  ---------------------------------------------------------------------------
   This function is called when a secure memb. will be installed. It moves all the messages from 
   the ka queue in the connection delivery queue, getting them ready for delivery to the user.
   Messages that were encryted, can be decrypted now before moved to the connection queue.
   These encrypted messages, are messages sent by fast clients who already completed the current
   ley agreement and sent messages to the group. 
----------------------------------------------------------------------------------------------- */
static void move_msg_con_deque(SSP_Con *con, SSP_Grp *grp) {
  BD_Alg      *bd = (BD_Alg *)grp->ka->info;	
  SSP_Msg     *msg_tmp = NULL;
  stddll_it   lit;
  
  for(stddll_begin(&(bd->msg_deque), &lit); !stddll_it_is_end(&lit); stddll_it_next(&lit)) {
    msg_tmp = *(SSP_Msg**) stddll_it_val(&lit);
    if(Is_encrypt_mess_type(msg_tmp->msg_type)) {   
      if(Dec_Scat(msg_tmp->scat, grp->enc->dec_fcn, grp->enc->block_size, grp->enc->info, 
		  (unsigned int) msg_tmp->msg_len, &msg_tmp->msg_type, msg_tmp->endian_mism) < 0) {
	ssp_err_quit("move_msg_con_deque: Dec_Scat failed!\n"); 
      }
    } 
    if(Is_reg_memb_mess(msg_tmp->serv_type)) {
      ssp_err_quit("move_msg_con_deque: membership message in the ka queue should not happen.\n");
    }
    stddll_push_back(&con->deliv_deque, &msg_tmp);
  }
  stddll_clear(&(bd->msg_deque));
}

/* first_user -----------------------------------------------------------------------------------
   This function handles the key agreement when the group contains only one user. 
   It returns void, it fails if bd fails. 
---------------------------------------------------------------------------------------------- */
static void first_user(SSP_Con *con, SSP_Grp *grp) {
  int       err;
  BD_Alg    *bd = (BD_Alg *)grp->ka->info;	
  char      *joiner = (char*)grp->curr_membs; 

  DEBUG_enter(f_dbg, "first_user");

  bd_destroy_ctx(&bd->ctx);
  if((err = bd_new_member(&bd->ctx, joiner, grp->name)) < 0){
    ssp_err_quit("first_user: bd_new_user failed  %d\n", err);
  }
  
  /* mark the membership is ready, by moving it in the connection delivery queue */
  stddll_push_back(&con->deliv_deque, &bd->curr_memb_msg);
  bd->state = BD_SECURE;
  grp->ka->key_state = ESTABLISH;
  reset_vs_data(bd);

  (*grp->enc->chg_key_fcn)(grp->enc->key, grp->enc->key_len, grp->enc->info);    
  
  DEBUG_leave(f_dbg, "first_user", 0);
}

/* handle_event -------------------------------------------------------------------------------
   This function starts the key agreement algorithm. BD has only one protocol, no matter what
   type of event changed the group.
--------------------------------------------------------------------------------------------- */
static void handle_event(SSP_Con *con, SSP_Grp *grp) {
  int         err, i;
  BD_Alg      *bd = (BD_Alg *)grp->ka->info;  
  CLQ_TOKEN   *tk_out = 0;
  int         msg_len = 0;
  char        *msg_buf = 0, *tmp=0;
  char        **curr_memb_ptr = 0;
  stdarr      curr_memb_set;
  stdarr_it   ait;

  DEBUG_enter(f_dbg, "handle_event");

  /* build the list with the current memb. in the form required by Cliques lib. */
  stdarr_construct(&curr_memb_set, sizeof(char*));  
  for (i = 0; i < grp->num_membs; ++i){
    char *p = grp->curr_membs[i];
    stdarr_push_back(&curr_memb_set, &p);
  }
  stdarr_push_back(&curr_memb_set, &tmp);
  curr_memb_ptr = (char**)stdarr_it_val(stdarr_begin(&curr_memb_set, &ait));
 
  /* allocate the bd_context, if needed */
  if(bd->ctx == NULL) {
    if((err = bd_new_member(&bd->ctx, con->priv_name, grp->name)) < 0){
      ssp_err_quit("handle_event: bd_new_user failed  %d\n", err);
    }
  }

  /* start the key agreement */
  err = bd_membership_req(bd->ctx, con->priv_name, grp->name, curr_memb_ptr, &tk_out, 1);
  if(err < 0) {
    ssp_err_quit("handle_event: bd_membership_req failed  %d\n", err);
  }

  if(tk_out != NULL) {
    msg_len = tk_2_msg(&msg_buf, tk_out, BD_Zi, bd->curr_memb_msg->serv_type);
    if((err = FL_multicast(con->mbox, BD_Zi_TYPE | SELF_DISCARD, grp->name, BD_Zi, msg_len, msg_buf)) < 0) {
      FL_error(err);
      ssp_err_quit("handle_event: FL_multicast failed %d\n.", err);
      goto end;
    }
    ON_DEBUG(fprintf(f_dbg, "BD_Zi (%d bytes) multicasted\n", err);)
    bd->state = BD_WAIT_FOR_Zi;
  }
  else {
    ssp_err_quit("handle_event: bd_membership_req did not fail but it did not generate token %d\n", err);
  }

 end:
  stdarr_destruct(&curr_memb_set);  
  if(msg_buf) {
    free(msg_buf);
  }
  bd_destroy_token(&tk_out);
  
  DEBUG_leave(f_dbg, "handle_event", 0);
}


/* handle_Zi -----------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   an Zi message.

   Each member calls bd_compute_xi for each Zi message. The maximum number of Zi messages is
   n-1, where n is the size of the group. Some members might need less than n-1 messages to
   compute Xi. 
---------------------------------------------------------------------------------------------- */
static int handle_Zi(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, BD_Alg *bd) {
  int        ret = DONT_DELIV_AND_FREE_MSG;
  CLQ_TOKEN  *tk_out = 0;
  CLQ_TOKEN  *tk_in = 0;  
  int        err;
  int        msg_len;
  char       *msg_buf = 0;
  service    serv;

  DEBUG_enter(f_dbg, "handle_Zi");

  /* current membership was abandoned */
  if(bd->curr_memb_msg == NULL) {
    goto end;
  }  

  switch(bd->state) {
  case BD_WAIT_FOR_Zi:
    tk_in = (CLQ_TOKEN*)malloc(sizeof(CLQ_TOKEN));
    msg_2_tk(msg, tk_in, &serv);

    /* update the service type for the current membership handled */
    if(Is_caused_network_mess(serv) && Is_caused_join_mess(bd->curr_memb_msg->serv_type)) {
      bd->curr_memb_msg->serv_type = serv;
    }

    if((err = bd_compute_xi(bd->ctx, con->priv_name, grp->name, tk_in, &tk_out)) < 0) {
      ssp_err_quit("handle_Zi: bd_compute_Xi failed\n");
    }
    
    if(tk_out) {
      msg_len = tk_2_msg(&msg_buf, tk_out, BD_Xi, bd->curr_memb_msg->serv_type);
      if ((err = FL_multicast(con->mbox, BD_Xi_TYPE | SELF_DISCARD, grp->name, BD_Xi, 
			      msg_len, msg_buf)) < 0) {
        FL_error(err);
	ssp_err_quit("handle_Zi: FL_multicast failed %d!\n", err);
	goto end;
      }
      bd->state = BD_WAIT_FOR_Xi;
      ON_DEBUG(fprintf(f_dbg, "BD_Xi (%d bytes) multicasted\n", err);)
    }
    break;

  case BD_WAIT_FOR_Xi:
    ON_DEBUG(fprintf(f_dbg, "dropping Zi message in Xi state\n");)
    break;

  case BD_WAIT_FOR_MEMBERSHIP:
    if(bd->num_vs_membs == 0) { /* first memb */
      ssp_err_quit("handle_Zi: Zi in illegal state!\n");
    }
    else if(bd->num_vs_membs > 0) { /* cascaded memb. */
      ON_DEBUG(fprintf(f_dbg, "handle_Zi: dropping Zi in Membership state!\n");)
    }
    break;

  case BD_WAIT_FOR_SELF_JOIN:
  case BD_SECURE:
    ssp_err_quit("handle_Zi: Zi in illegal state!\n");
    break;
  }

 end:

  bd_destroy_token(&tk_in);
  bd_destroy_token(&tk_out);
  if(msg_buf) {
    free(msg_buf);
  }

  DEBUG_leave(f_dbg, "handle_Zi", ret);
  return ret;
}


/* handle_Xi --------------------------------------------------------------------------------
  This function specifies the actions taken by the state machine if the message received was
  a Xi message.

  All the members call bd_compute_key for any Xi message received. The maximum number of Xi
  is n-1 where n is the size of the group. Some members might need less that n-1 Xi messages
  to compute the key, however you need to wait for n-1 X1 messages for synchronization reasons,
  to make sure that if I install the new secure membership, everybody installs.

  It is possible that a Xi message is received while performing the first round: Zi (because
  some members finished faster and they already muticasted Xi, before I managed to compute
  Zi, multicast it and move to BD_WAIT_FOR_XI. In this case it can be applied immediately,
  since the second round is just multiplication.

  NOTE: in case of a cascading due to a join, the joiner starts in WAIT_FOR_SELF_JOIN 
        and it never knows if it was a cascading or not so he deliveres JOIN while 
        all the other members of the group will deliver NETWORK. That's why each
        members that passes along the Xi or Zi messages attaches also its group event,
        and if it was join it upgrades it to network. 
---------------------------------------------------------------------------------------------- */
static int handle_Xi(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, BD_Alg *bd) {
  int         ret = DONT_DELIV_AND_FREE_MSG, err;
  CLQ_TOKEN   *tk_in = 0; 
  service     serv;

  DEBUG_enter(f_dbg, "handle_Xi");

  /* current memb. was abandoned  */
  if(bd->curr_memb_msg == NULL) {
    goto end;
  }  

  /* mark that I got a Xi message */
  bd->num_xi_messages ++;

  switch(bd->state) {
  case BD_WAIT_FOR_Xi:
    tk_in = (CLQ_TOKEN*)malloc(sizeof(CLQ_TOKEN));
    msg_2_tk(msg, tk_in, &serv);

    /* update the service type for the current membership handled */
    if(Is_caused_network_mess(serv) && Is_caused_join_mess(bd->curr_memb_msg->serv_type)) {
      bd->curr_memb_msg->serv_type = serv;
    }

    if((err = bd_compute_key(bd->ctx, con->priv_name, grp->name, tk_in)) < 0) {
      ssp_err_quit("handle_Xi: bd_compute_key failed\n");    
    } 

    /* key is computed and everybody will be able to install (I got n-1 Xi messages) */
    if(err == OK && (bd->num_xi_messages == (stdhash_size(&grp->curr_membs_hash) - 1))) { 
      copy_key(grp);      
      grp->ka->key_state = ESTABLISH;      
      (*grp->enc->chg_key_fcn)(grp->enc->key, grp->enc->key_len, grp->enc->info);
      
      if(Is_caused_network_mess(bd->curr_memb_msg->serv_type)) { /* update vs. */
	set_vs_set_memb_msg(bd->curr_memb_msg, grp); 
      }
      
      /* first put the new secure memb in the connection queue, then move all msgs */
      stddll_push_back(&con->deliv_deque, &bd->curr_memb_msg);
      move_msg_con_deque(con, grp);
      bd->state = BD_SECURE;
      reset_vs_data(bd);
    }
    break;
    
  case BD_WAIT_FOR_Zi:
    tk_in = (CLQ_TOKEN*)malloc(sizeof(CLQ_TOKEN));
    msg_2_tk(msg, tk_in, &serv);
    
    if((err = bd_compute_key(bd->ctx, con->priv_name, grp->name, tk_in)) < 0) {
      ssp_err_quit("handle_Xi: bd_compute_key failed\n");    
    }     
    break;
    
  case BD_SECURE:
  case BD_WAIT_FOR_SELF_JOIN:
    ssp_err_quit("handle_Zi: Zi in illegal state!\n");
    break;
   
  case BD_WAIT_FOR_MEMBERSHIP:
   if(bd->num_vs_membs == 1) { /* first memb */
      ssp_err_quit("handle_Zi: Zi in illegal state!\n");
    }
    else if(bd->num_vs_membs > 1) { /* cascaded memb. */
      ON_DEBUG(fprintf(f_dbg, "handle_Zi: dropping Zi in Membership state!\n");)
    }
    break;
  }  

 end:
  bd_destroy_token(&tk_in);

  DEBUG_leave(f_dbg, "handle_Xi", ret);
  return ret;
}


/* handle_data_msg ----------------------------------------------------------------------------- 
   This function specifies the actions taken by the state machine if the message received was
   a data message (message received from the flush layer).
-----------------------------------------------------------------------------------------------*/
static int handle_data_msg(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, BD_Alg *bd) {
  int ret = DONT_DELIV_MSG;
  
  DEBUG_enter(f_dbg, "handle_data_msg");

  switch(bd->state) {
  case BD_SECURE:
    ssp_err_quit("handle_data_msg: this message should not be here");
    break;
    
  case BD_WAIT_FOR_SELF_JOIN:
    ssp_err_quit("handle_data_msg: no message should be received in this state");
    break;

  case BD_WAIT_FOR_MEMBERSHIP:
  case BD_WAIT_FOR_Zi:
  case BD_WAIT_FOR_Xi:
    ret = DELIV_MSG;
    break;

  }

  DEBUG_leave(f_dbg, "handle_data_msg", ret);
  return ret;
}


/* handle_trans ---------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a transitional message.
---------------------------------------------------------------------------------------------- */
static int handle_trans(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, BD_Alg *bd) {
  int ret = DONT_DELIV_MSG;

  DEBUG_enter(f_dbg, "handle_trans");

  switch(bd->state) {
  case BD_SECURE:
    if(bd->ts_delivered_to_app == SSP_FALSE) {
      bd->ts_delivered_to_app = SSP_TRUE;
      ret = DELIV_MSG;
    }
    break;

  case BD_WAIT_FOR_MEMBERSHIP:
    if(bd->ts_delivered_to_app == SSP_FALSE) {
      bd->ts_delivered_to_app = SSP_TRUE;
      ret = DELIV_MSG;
    }
    break;
  
  case BD_WAIT_FOR_Zi:
   if(bd->ts_delivered_to_app == SSP_FALSE) {
      bd->ts_delivered_to_app = SSP_TRUE;
      ret = DELIV_MSG;
    }
    if(bd->num_vs_membs > 0) {
      bd->vs_ts_received = SSP_TRUE;
    }
    break;

  case BD_WAIT_FOR_Xi:
    if(bd->ts_delivered_to_app == SSP_FALSE) {
      bd->ts_delivered_to_app = SSP_TRUE;
      ret = DELIV_MSG;
    }
    if(bd->num_vs_membs > 0) {
      bd->vs_ts_received = SSP_TRUE;
    }

    /* abandon current memb. wait for Flush_Request  */
    SSP_Msg_free(&(bd->curr_memb_msg));
    bd->curr_memb_msg = NULL;

  case BD_WAIT_FOR_SELF_JOIN:
    ssp_err_quit("handle_trans: trans received in wrong state, %d!\n", bd->state);
    break;
  }
  
  DEBUG_leave(f_dbg, "handle_trans", ret);
  return ret;
}


/* handle_memb ----------------------------------------------------------------------------------
  This function specifies the actions taken by the state machine if the message received was
  a group membership.

  Some comments:
      a member in the WAIT_FOR_SELF_JOIN can receive 2 types of events: a membership due to its 
      own join (a join event) or a membership due to a network event (in this case the joinee 
      is on the list of new added members. Flush delivers this special network in some cases:
      -  a partiton happen after the join and before the new membership is delivered
      -  the join happened while a previous partition was processed, so the two events are
         combined in one
      -  somebody left immediately after my join. Since flush membership deliveries are based
         on gathering flush_oks from old members, if the guy that left did not send his 
         flush_ok, the two events will be combined. Note that if he managed to send his
         flush_ok, then the join will be delivered first, then the leave.
---------------------------------------------------------------------------------------------- */
static int handle_memb(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, BD_Alg *bd) {
  int    ret = DONT_DELIV_MSG;
  int    was_leave = 0;
  stdarr leave_set;
  stdarr join_set;

  DEBUG_enter(f_dbg, "handle_memb");
  
  stdarr_construct(&leave_set, sizeof(char*));
  stdarr_construct(&join_set, sizeof(char*));

  switch(bd->state) {
  case BD_SECURE:
  case BD_WAIT_FOR_Zi:
  case BD_WAIT_FOR_Xi:
    ssp_err_quit("handle_memb: membership  received in wrong state, %d!\n", bd->state);
    break;

  case BD_WAIT_FOR_SELF_JOIN:
    grp->ka->key_state = NOT_ESTABLISH;
    bd->num_vs_membs++;
    bd->num_xi_messages = 0;
    
    init_vs_set(grp); 
    was_leave = upd_vs_set_and_get_join_leave_set(grp, msg->serv_type, &join_set, &leave_set);

    if(bd->curr_memb_msg != NULL) { /* free prev. memb that we were trying to install  */
      SSP_Msg_free(&(bd->curr_memb_msg));
    }
    bd->curr_memb_msg = msg;  /* delay delivery of the current memb. till the key is computed  */

    if(stdhash_size(&grp->curr_membs_hash) > 1) { /* not the only one in the group */
      if(Is_reg_memb_mess(msg->serv_type)) {
	if(Is_caused_join_mess(msg->serv_type)) {
	  handle_event(con, grp); /* self_join */
	}	      
	else if(Is_caused_leave_mess(msg->serv_type) || Is_caused_disconnect_mess(msg->serv_type)) {
	  ssp_err_quit("handle_memb: leave or disconnect in the wrong state %d\n", bd->state);
	  ;
	}
	else if(Is_caused_network_mess(msg->serv_type)) {
	  handle_event(con, grp); 
	}
      }
    }
    else { /* it's just me in the group */
      first_user(con, grp);
    }
    break;
    
  case BD_WAIT_FOR_MEMBERSHIP:
    grp->ka->key_state = NOT_ESTABLISH;
    bd->num_vs_membs++;
    bd->num_xi_messages = 0;    

    if(bd->num_vs_membs == 1) { /* first vs memb from a possible cascaded vs membs */
      init_vs_set(grp); 
    }

    was_leave = upd_vs_set_and_get_join_leave_set(grp, msg->serv_type, &join_set, &leave_set);
    
    if (was_leave  && (bd->ts_delivered_to_app == SSP_FALSE)) { 
      bd->ts_delivered_to_app = SSP_TRUE;
      gen_and_push_msg(con, grp, TRANSITION_MESS);
    }

    /* free prev. memb that we were trying to install  */
    if((bd->num_vs_membs > 1) && bd->curr_memb_msg != NULL) { 
      SSP_Msg_free(&(bd->curr_memb_msg));
    }

    bd->curr_memb_msg = msg; /* delay delivery of current memb, till the key is computed  */
  
    /* cascaded occured, so memberships will be collapsed, deliver a NETWORK */
    if(bd->num_vs_membs > 1) {
      bd->curr_memb_msg->serv_type = REG_MEMB_MESS | CAUSED_BY_NETWORK;
    }    

    if(stdhash_size(&grp->curr_membs_hash) > 1) { /* not the only one in the group */
      handle_event(con, grp); 
    }  
    else { /* alone in the group */
      first_user(con, grp);
    }
    break;
  }

  stdarr_destruct(&leave_set);  
  stdarr_destruct(&join_set);      

  DEBUG_leave(f_dbg, "handle_memb", ret);
  return ret;
}



/* handle_fl_req -------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a flush request message.
   
   If a flush_req was answered and then the alg moves to BD_WAIT_FOR_MEMBERSHIP from either 
   BD_WAIT_FOR_Xi or BD_WAIT_FOR_Zi states, then it means that a cascaded membership happened, 
   and when the protocol finishes, a NETWORK will be delivered to the application.
---------------------------------------------------------------------------------------------- */
static int handle_fl_req(SSP_Con *con, SSP_Grp *grp, SSP_Msg *mess, BD_Alg *bd) {
  int ret = DONT_DELIV_AND_FREE_MSG;

  DEBUG_enter(f_dbg, "handle_fl_req");

  switch(bd->state) {
  case BD_SECURE:
    bd->wait_for_sec_fl_ok = SSP_TRUE;
    ret = DELIV_MSG; 
    break;
  
  case BD_WAIT_FOR_Zi:
  case BD_WAIT_FOR_Xi:
    if ((ret = FL_flush(con->mbox, grp->name)) == CONNECTION_CLOSED || ret == ILLEGAL_SESSION) {
      FL_error(ret);
      ssp_err_quit("handle_fl_req: FL_flush failed!\n");
      goto end;
    }
    bd->state = BD_WAIT_FOR_MEMBERSHIP;
    ret = DONT_DELIV_AND_FREE_MSG;
    break;

  case BD_WAIT_FOR_SELF_JOIN:
  case BD_WAIT_FOR_MEMBERSHIP:
    ssp_err_quit("handle_fl_req: fl_req received in wrong state, not possible !");
    break;

  }
 
 end:
  DEBUG_leave(f_dbg, "handle_fl_req", ret);
  return ret;
}


/* ============================  wrapper functions for bd  =================================== */

/* BD_handles_mess ------------------------------------------------------------------------------
   This function specifies if a spread message is used or not by the key agreement algorithm.
   All the messages specified here will be redirected by spread to BD_Comp_Key_Wrapper;
   In this case, all the membership messages (including transitional messages) are sended,
   Also the regular messages used internal by the key agreement algorithm (Zi and Xi... messages)
   and regular messages received between having a stable key, are sent here.
-----------------------------------------------------------------------------------------------*/
int BD_handles_msg(SSP_Msg *msg, SSP_Grp *grp) {
  service serv_type = msg->serv_type;
  int     msg_type  = msg->msg_type;
  
  return !Is_regular_mess(serv_type) || grp->ka->key_state == NOT_ESTABLISH ||
    msg_type == BD_Zi || msg_type == BD_Xi;
}


/* BD_handle_recv ----------------------------------------------------------------------------
   This function is implementing the state machine for the key agreement algorithm. 
   It returns 1 if the message must be delivered by the SSP, 0 otherwise. The SSP can check if 
   the key agreement finished by looking at the Key_State variable (see ssp.c).
-----------------------------------------------------------------------------------------------*/
int BD_handle_recv(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg) {
  int  ret = DELIV_MSG;
  BD_Alg *bd = (BD_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "BD_handle_recv");
  
  if(Is_regular_mess(msg->serv_type)) {
    if(Is_Zi_msg(msg->msg_type)) {
      ret = handle_Zi(con, grp, msg, bd);
    }
    else if(Is_Xi_msg(msg->msg_type)) {
      ret = handle_Xi(con, grp, msg, bd);
    }
    else {
      ret = handle_data_msg(con, grp, msg, bd);
    }
  }
  else if(Is_flush_req_mess(msg->serv_type)) {
    ret = handle_fl_req(con, grp, msg, bd);
  }
  else if(Is_membership_mess(msg->serv_type)) {
    if(Is_self_leave_mess(msg->serv_type)) {
      ;
    }
    else if(Is_transition_mess(msg->serv_type)) {
      ret = handle_trans(con, grp, msg, bd);
    }
    else {
      ret = handle_memb(con, grp, msg, bd);
    }
  }

  DEBUG_leave(f_dbg, "BD_handle_recv", ret);
  return ret;  
}

/* BD_handle_fl_ok ----------------------------------------------------------------------------
   This function specifies the action taken by the key agreement state machine if a flush
   ok event happen. This is actually Secure_Flush_Ok, sent by the user using SSP_Flush, 
   which does not sent the flush ok invoking directlly FL_flush, but calls this function to 
   handle it.
-----------------------------------------------------------------------------------------------*/
int BD_handle_fl_ok(SSP_Con *con, SSP_Grp *grp){
  int  ret = DELIV_MSG;
  BD_Alg *bd = (BD_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "BD_handle_fl_ok");
  
  switch(bd->state) {
  case BD_SECURE:
    if(bd->wait_for_sec_fl_ok == SSP_TRUE) {
      bd->wait_for_sec_fl_ok = SSP_FALSE;      
      if ((ret = FL_flush(con->mbox, grp->name)) < 0) {
	FL_error(ret);
	goto end;
      }
      bd->state = BD_WAIT_FOR_MEMBERSHIP;
    }
    else {
      ret = FLUSH_OK_ALREADY_SENT;
    }
    break;
    
  case BD_WAIT_FOR_SELF_JOIN:
  case BD_WAIT_FOR_MEMBERSHIP:
  case BD_WAIT_FOR_Zi:
  case BD_WAIT_FOR_Xi:
    ret = FLUSH_OK_ALREADY_SENT;
    break;    
  }
  
 end:
  DEBUG_leave(f_dbg, "BD_handle_fl_ok", ret);
  return ret;
  
}

/* BD_handle_send ----------------------------------------------------------------------------
   This function specifies the actions taken by the key agreement state machine, if the event
   that happen is a 'user' message. The event is caused by a user calling SSP_scat_multicast
   or SSP_multicast. Right now this function is not handleing the sending, it just allows the
   sending of the message or not. The user is not allowed to send messages while the key 
   agreement is performing.
------------------------------------------------------------------------------------------- */
int BD_handle_send(SSP_Con *con, SSP_Grp *grp) {
  int  ret = DELIV_MSG;
  BD_Alg *bd = (BD_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "BD_handle_send");

  switch(bd->state) {
  case BD_SECURE:
    ret = SEND_MSG;
    break;

  case BD_WAIT_FOR_SELF_JOIN:
  case BD_WAIT_FOR_MEMBERSHIP:
  case BD_WAIT_FOR_Zi:
  case BD_WAIT_FOR_Xi:
    ret = DONT_SEND_MSG;
    break;
  }

  DEBUG_leave(f_dbg, "BD_handle_send", ret);
  return ret;
}













