/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */










/***********************************************************************************************/
/* ckd_alg.h                                                                                   */
/* Implements the CKD key management algorithm                                                 */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: August 10, 2002                                                                    */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/


#ifndef _CKD_ALG_H_
#define _CKD_ALG_H_

#include <stdutil/stddefines.h>
#include <stdutil/stderror.h>
#include <stdutil/stddll.h>
#include <stdutil/stdarr.h>

#include "ssp_info.h"
#include "clq_api.h"


#define SSP_CKD_ALG 1

typedef enum {
  CKD_SECURE,
  CKD_WAIT_FOR_R,
  CKD_WAIT_FOR_NEW_SHARE,
  CKD_WAIT_FOR_KEY,
  CKD_WAIT_FOR_CASCADING_MEMBERSHIP,
  CKD_WAIT_FOR_MEMBERSHIP,
  CKD_WAIT_FOR_SELF_JOIN
} CKD_Alg_State;

typedef struct {
  CKD_Alg_State state;
  stddll        msg_deque;
  CLQ_CONTEXT   *ctx;
  SSP_Bool      first_trans; 
  SSP_Bool      vs_trans;
  SSP_Bool      first_cascaded_memb;
  SSP_Bool      wait_for_sec_fl_ok;
  SSP_Bool      kl_got_fl_req;
  char          (*vs_set)[MAX_GROUP_NAME];
  stdhash       vs_set_hash;
  SSP_Msg       *curr_memb_msg;
} CKD_Alg;

CKD_Alg *CKD_Alg_create();
void CKD_Alg_free(CKD_Alg **clq);

#define CKD_R                      ((int16) -32746)
#define CKD_NEW_SHARE              ((int16) -32745)
#define CKD_KEY                    ((int16) -32744)

#define Is_r_msg(type)             (type == CKD_R)
#define Is_new_share_msg(type)     (type == CKD_NEW_SHARE)
#define Is_key_msg(type)           (type == CKD_KEY)

#define CKD_SERVICE_TYPE           FIFO_MESS
#define CKD_KL_TYPE                AGREED_MESS   /* key list is sent agreed  */

/* wrapper fcn that implement the "generic" key_alg interface */
int  CKD_handles_msg(SSP_Msg *msg, SSP_Grp *grp);
int  CKD_handle_recv(SSP_Con *conn, SSP_Grp *grp, SSP_Msg *msg);
int  CKD_handle_fl_ok(SSP_Con *conn, SSP_Grp *grp);
int  CKD_handle_send(SSP_Con *con, SSP_Grp *grp);

#endif /* _CKD_ALG_H_*/



















