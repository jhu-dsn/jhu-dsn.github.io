/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */










/***********************************************************************************************/
/* bd_alg.h                                                                                    */
/* Implements BD protocol                                                                      */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: Mar 20, 2001                                                                       */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#ifndef _BD_ALG_H_
#define _BD_ALG_H_

#include <stdutil/stddefines.h>
#include <stdutil/stderror.h>
#include <stdutil/stddll.h>
#include <stdutil/stdarr.h>
#include "ssp_info.h"
#include "bd_api.h"


#define SSP_BD_ALG 3

typedef enum {
  BD_SECURE,
  BD_WAIT_FOR_SELF_JOIN,
  BD_WAIT_FOR_MEMBERSHIP,
  BD_WAIT_FOR_Zi,
  BD_WAIT_FOR_Xi
} BD_Alg_State;

typedef struct dummy_BD_Alg {
  BD_Alg_State  state;                /* state machine */
  stddll        msg_deque;            /* msgs deque */
  BD_CONTEXT    *ctx;                 /* key agreement context specific */
  SSP_Bool      ts_delivered_to_app;  /* marks that a ts was delivered to the app */
  SSP_Bool      vs_ts_received;       /* marks that a vs ts was received while doing key agreemet */
  int           num_vs_membs;         /* counter for intermediary vs, if no cascaded occurred, is 1  */
  SSP_Bool      wait_for_sec_fl_ok;   /* marks that a Fl_Req was delivered to the app, wait for Fl_Ok */
  SSP_Msg       *curr_memb_msg;       /* the memb. that we try to install  */
  int           num_xi_messages;      /* number of xi messages */
} BD_Alg;

BD_Alg *BD_Alg_create();
void BD_Alg_free(BD_Alg **str);

/* spread message types used by BD algorithm */
#define BD_Zi                 ((int16) -32741)
#define BD_Xi                 ((int16) -32740)

#define Is_Zi_msg(type)       (type == BD_Zi)
#define Is_Xi_msg(type)       (type == BD_Xi)
 
#define BD_Zi_TYPE            AGREED_MESS
#define BD_Xi_TYPE            AGREED_MESS   

/* wrapper fcns that implement the "generic" key_alg interface */
int  BD_handles_msg(SSP_Msg *msg, SSP_Grp *grp);
int  BD_handle_recv(SSP_Con *conn, SSP_Grp *grp, SSP_Msg *msg);
int  BD_handle_fl_ok(SSP_Con *conn, SSP_Grp *grp);
int  BD_handle_send(SSP_Con *con, SSP_Grp *grp);


#endif /* _BD_ALG_H_*/



















