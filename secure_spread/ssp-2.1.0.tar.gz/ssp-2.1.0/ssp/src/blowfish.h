/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */










/********************* blowfish.h ********************/

/* $Id: blowfish.h,v 1.1.1.1 1999/10/21 17:40:05 crisn Exp $*/
/* updated by John Schultz 1999/06/23 16:41 */

#ifndef INC_BLOWFISH_H
#define INC_BLOWFISH_H

#ifdef __i386__
#ifndef ORDER_DCBA
#define ORDER_DCBA
#endif
#endif

#ifdef __sparc__
#ifndef ORDER_ABCD
#define ORDER_ABCD
#endif
#endif

#ifdef __sgi
#ifndef ORDER_ABCD
#define ORDER_ABCD
#endif
#endif

#define bf_N  16          /* used by P array */

#define UWORD_32bits  unsigned long
#define UWORD_16bits  unsigned short
#define UBYTE_08bits  unsigned char

void Blowfish_initialize(UWORD_32bits bf_P[bf_N + 2], UWORD_32bits bf_S[4][256]);
void Blowfish_change_key(UBYTE_08bits key[], UBYTE_08bits kbytes, 
			 UWORD_32bits bf_P[bf_N + 2], UWORD_32bits bf_S[4][256]);
void Blowfish_encipher(void *xl, void *xr, UWORD_32bits bf_P[bf_N + 2], 
		       UWORD_32bits bf_S[4][256]);
void Blowfish_decipher(void *xl, void *xr, UWORD_32bits bf_P[bf_N + 2], 
		       UWORD_32bits bf_S[4][256]);

union aword 
{
  UWORD_32bits word;
  UBYTE_08bits byte[4];
  struct {
#ifdef ORDER_ABCD         /* big endian - alpha, sparc */
    unsigned int byte0:8;
    unsigned int byte1:8;
    unsigned int byte2:8;
    unsigned int byte3:8;
#endif
#ifdef ORDER_DCBA         /* little endian - x86 */
    unsigned int byte3:8;
    unsigned int byte2:8;
    unsigned int byte1:8;
    unsigned int byte0:8;
#endif
#ifdef ORDER_BCDA         /* mangled endian - vax */
    unsigned int byte1:8;
    unsigned int byte0:8;
    unsigned int byte3:8;
    unsigned int byte2:8;
#endif
  } w;
};

#endif /* INC_BLOW_FISH_H */




