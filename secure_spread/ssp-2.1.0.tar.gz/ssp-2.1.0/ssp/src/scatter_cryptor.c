/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */










/***********************************************************************************************/
/* scatter_cryptor.c                                                                           */
/* Generic functions for encrypting a scatter, using a generic blockcipher based algorithm.    */
/*                                                                                             */
/* John Schultz                                                                                */
/* Created: June 23, 1999                                                                      */
/* Modified: June 2001, CNR: error handling                                                    */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ssp_error.h"
#include "scatter_cryptor.h"

#ifdef USE_DMALLOC
#include <dmalloc.h>
#endif

/* scatter_dencrypt_block: this function will encrypt or decrypt one block of data from 
   the source scatter. On success, it dencrypts one block  of data, returns block_size, 
   and changes e_index and b_index to refer to the next "legal" byte after the block it 
   just dencrypted.  If it returns a number less than the block_size but >= 0 then this 
   indicates that there wasn't an entire block left in the source scatter structure. In 
   this case, the scatter and the passed parameters are uneffected, and the number returned 
   is the number of bytes left in the scatter structure.  If it returns a number less than 
   zero this indicates there was an error in the structure of the source scatter.

   **Note: the block scatter parameter is a scatter passed by the caller that contains at 
   least one element, and that the first element  has a buffer of a least block_size bytes 
   length.  The first block_size bytes of element 0 will be overwritten.

   Parameters: 
   scat:         the scatter containing the block to be dencrypted
   e_index:      the element index of where the data to be dencrypted begins in 
                 the scatter element array
   b_index:      the offset in the scatter element's buffer where the data to be dencrypted 
                 begins
   block:        a scatter that is used as temporary storage (see Note above)
   dencrypt:     the function that actually encrypts or decrypts the data
   block_size:   the size of blocks that dencrypt works on, and the amount of data to be 
                 encrypted
   encrypt_info: information that dencrypt needs to function
   endian:       a boolean that dencrypt needs
*/

static int scatter_dencrypt_block(scatter *scat, unsigned int *e_index, unsigned int *b_index, 
				  scatter *block, 
				  unsigned int (*dencrypt)(char*, unsigned int, void*, int), 
				  unsigned char block_size, void *dencrypt_info, int endian) {
  
  unsigned int e_index_tmp = *e_index, b_index_tmp = *b_index;
  int ret, blockLeft = block_size, blockInd = 0;
  
  if (block->num_elements < 1 || block->elements[0].len < block_size || !block->elements[0].buf) {
    ssp_err_quit("scatter_dencrypt_block: bad scatter block passed\n");
  }
  
  if ((ret = scat_skip(scat, &e_index_tmp, &b_index_tmp, 0, block_size)) != block_size) {
    return ret;
  }
  
  ret = scat_get(block, -1, 0, 0, scat, *e_index, 0, *b_index, block_size);
  
  if (ret != block_size) {
    ssp_err_quit("scatter_dencrypt_block: scat_get from src failed!\n");
  }
  
  while (blockLeft) {
    ret = (*dencrypt)(block->elements[0].buf + blockInd, blockLeft, dencrypt_info, endian);
    if (ret > blockLeft || ret < 1) {
      ssp_err_quit("scatter_dencrypt_block: encrypt returned an illegal value(%d)!\n", ret);
    }
    
    blockLeft -= ret;
    blockInd  = block_size - blockLeft;    
  }
  
  ret = scat_get(scat, *e_index, 0, *b_index, block, -1, 0, 0, block_size);
  
  if (ret != block_size) {
    ssp_err_quit("scatter_dencrypt_block: scatter_extract from src failed!\n");
  }
  
  *e_index = e_index_tmp;
  *b_index = b_index_tmp;
  
  return block_size;
}

/*
  Enc_Scat: this fcn encrypts a scatter structure.  On success it attaches the passed  mess_type 
  to the message, encrypts the scatter in place, sets org_size to what the original capacity of 
  the scatter was before encryption, and returns the new capacity after encryption.  For zero 
  capacity scatters, zero is returned.  A NULL scat is considered a zero capacity scatter.  On 
  error, this fcn returns a value less than zero.  This can only be caused by an illegal 
  structure in the passed scatter structure.

    **Note: if this fcn returns and the return value is _greater than zero_, then 
    scat->num_elements has been incremented by one, and a buffer has been malloc'ed 
    by this fcn and placed into the last scatter element. This buffer _must_ be freed 
    by the caller (if you don't want a memory leak).

  Parameters: 
  scat:       the scatter to be encrypted in place
  encrypt:    the function that actually encrypts data
  block_size: the size of blocks that encrypt works on
  info:       information that encrypt needs to function
  mess_len:   to return the original capacity in
  mess_type:  a message_type to be attached to the message
  endian:     a boolean that the encrypt fcn uses
*/
int Enc_Scat(scatter *scat, unsigned int (*encrypt)(char*, unsigned int, void*, int), 
	     unsigned char block_size, void *info, unsigned int *mess_len, 
	     int16 mess_type, int endian) {

  int num_elems, i, j, currLeft, currSize, currInd = 0, totSize = 0, encryptSize = 0, ret;
  scatter block_scat;
  char *block;
  
  /* Nothing is done for zero capacity messages */
  if (!scat || (num_elems = scat->num_elements) == 0) { 
    return 0;
  }
  else if (num_elems < 0 || num_elems > MAX_CLIENT_SCATTER_ELEMENTS) {
    return ILLEGAL_MESSAGE;
  }
  
  for (i = 0; i < num_elems && !scat->elements[i].len; ++i);    
  /* Catch any other zero capacity messages */
  if (i == num_elems) {
    return 0;
  }
  
  if (block_size == 0) {                                         
    /* make sure the block size is a positive number */
    block_size = 1;
  }

  block = (char*) malloc(block_size);
  block_scat.num_elements    = 1;
  block_scat.elements[0].len = block_size;
  block_scat.elements[0].buf = block;

  if (!block) {
    ssp_err_quit("Enc_Scat: malloc failed\n");
  }

  for (j = i; i < num_elems; i = j) {
    if ((currSize = scat->elements[i].len) < 0) { /* check the current element's length */
      encryptSize = ILLEGAL_MESSAGE;              /* return an error */
      goto Enc_Scat_end;
    }
    
    currLeft = currSize - currInd;

    /* currInd might not be zero, because of scatter_dencrypt_block */
    if (currLeft < 0) {
      ssp_err_quit("Enc_Scat: got a negative currLeft(%d)\n", currLeft);
    }

    while (i == j) {
      if (currLeft >= block_size) {               
	/* if the current element's buffer has a block or more left */
	ret = (*encrypt)(scat->elements[j].buf + currInd, currLeft, info, endian);
	
	if (ret > currLeft || ret < 1) {
	  ssp_err_quit("Enc_Scat: (*encrypt) returned an illegal value!\n");
	}
	currLeft -= ret;
	currInd   = currSize - currLeft;
	totSize   = encryptSize += ret;
	/* j doesn't change here, if currLeft == 0 now, then j and currInd will be updated on 
	   next while loop iteration */
      }
      else if (currLeft > 0) {      
	/* if the current element's buffer has some data left but less than a block */
	if ((ret = scatter_dencrypt_block(scat, (unsigned int*)&j, (unsigned int*)&currInd, 
					  &block_scat, encrypt,
					  block_size, info, endian)) == block_size) {
	  totSize = encryptSize += ret;
	  if (j == i) {   
	    /* j and currInd are updated by scatter_dencrypt_block: 
	       j changes -> breaks out of while loop */
	    ssp_err_quit("Enc_Scat: after scatter_dencrypt_block: j(%d) == i(%d)!\n", j, i);
	  }
	}
	else if (ret >= 0) {                     
	  /* scatter_dencrypt_block said there wasn't an entire block left in the scatter */
	  totSize = encryptSize + ret;           /* compute the capacity of the scatter */
	  goto Enc_Scat_break_out;        /* break out of both loops */
	}
	else {
	  encryptSize = ret;
	  goto Enc_Scat_end;              
	  /* an error was returned by scatter_dencrypt_block, return an error */
	}
      }
      else if (currLeft == 0) {                  
	/* if there is no more data in the current element's buffer, then go to the next 
	   element */
	++j;
	currInd = 0;
      }
      else ssp_err_quit("Enc_Scat: currLeft(%d) is less than zero!\n", currLeft);
    }
  }

 Enc_Scat_break_out:
  {
    unsigned char diff;
    int curr_cap, toAdd, bufSize, num_blocks;
    char *toAddBuf;

    /* at this point, totSize == scatter_capacity(scat),
       encryptSize is the number of bytes we have 
       encrypted so far, and j and currInd ref to last place we stopped encrypting */
    *mess_len = totSize;

    if (totSize != (curr_cap = scat_cap(scat)) || curr_cap < 0) {
      ssp_err_quit("Enc_Scat: totSize(%d) != capacity(scat)(%d)!\n", 
		   totSize, curr_cap);
    }

    /* tack on mess_type and padding to make the capacity a multiple of the block_size */
    toAdd = sizeof(int16) + sizeof(unsigned char);
    if ((diff = (totSize + toAdd) % block_size)) {
      diff = block_size - diff;
    }

    bufSize  = toAdd + diff;
    toAddBuf = (char*) malloc(bufSize);
    
    if (!toAddBuf) {
      ssp_err_quit("Enc_Scat: malloc failed!\n");
    }
    
    /* store the message type and the diff so that decrypt can determine the amount of data 
       is in the message */
    memcpy(toAddBuf + bufSize - toAdd, &mess_type, sizeof(int16));
    memcpy(toAddBuf + bufSize - sizeof(unsigned char), &diff, sizeof(unsigned char));

    scat->elements[num_elems].len = bufSize;
    scat->elements[num_elems].buf = toAddBuf;
    num_elems = ++scat->num_elements;

    if ((curr_cap = scat_cap(scat)) % block_size || curr_cap < 0) {
      ssp_err_quit("Enc_Scat: curr_cap(%d) is not a multiple of the "
		   "block_size or is negative\n", curr_cap);
    }
    
    totSize += bufSize;
    if (totSize != curr_cap || (totSize - encryptSize) % block_size) {
      ssp_err_quit("Enc_Scat: totSize(%d) != curr_cap(%d), or "
		   "totSize - encryptSize(%d) mod block_size(%d)\n", 
		   totSize, curr_cap, encryptSize, block_size);
    }

    /* encrypt whatever was left and the new stuff we tacked on */
    num_blocks = (totSize - encryptSize) / block_size;

    for (i = 0; i < num_blocks; ++i) {
      ret = scatter_dencrypt_block(scat, (unsigned int*)&j, (unsigned int*)&currInd, 
				   &block_scat, encrypt, block_size, info, endian);
      encryptSize += ret;

      if (ret != block_size) {
	ssp_err_quit("Enc_Scat: scatter_dencrypt_block(%d) != "
		     "block_size(%d) at clean up portion!\n", ret, block_size);
      }
    }
  }

 Enc_Scat_end:
  free(block);  /* free the temporary block we were using */

  return encryptSize;
}

/*
  Dec_Scat: this fcn decrypts the first mess_len bytes of a scatter structure that was encrypted 
  using Encrypt_Scatter.  On success it sets the passed mess_type to the original message type, 
  decrypts the scatter in place, and returns the new capacity after decryption (the actual amount 
  of original data).  For zero length messages zero is returned. On error, this fcn returns a 
  value less than zero. This can be caused by an illegal structure in the passed scatter structure
  or if the message length is not a multiple of the block_size, this second error should only 
  occur if the passed scatter wasn't encrypted using Encrypt_Scatter.

  Parameters: 
  scat:       the scatter to be decrypted in place
  mess_len:   the size of the message to decrypt, should be a multiple of the block_size
  decrypt:    the function that actually decrypts data
  block_size: the size of blocks that decrypt works on
  info:       information that encrypt needs to function
  mess_type:  a message_type to be read out of the message
  endian: a boolean indicating if the endianness of the encrypting machine is opposite mine.  

*/
int Dec_Scat(scatter *scat, unsigned int (*decrypt)(char*, unsigned int, void*, int), 
	     unsigned char block_size, void *info, unsigned int mess_len, int16 *mess_type, 
	     int endian) {
  
  int num_elems, i, j, currLeft, currSize, currInd = 0, ret;
  int org_mess_len = mess_len, j_tmp, currInd_tmp;
  scatter block_scat;
  char *block;
  
  if (mess_len == 0) { /* Zero length messages: return 0 */
    return 0;
  }
  
  if (block_size == 0) {
    block_size = 1;
  }
  
  if ((num_elems = scat->num_elements) < 0 || num_elems > MAX_CLIENT_SCATTER_ELEMENTS || 
      mess_len % block_size) {
    return ILLEGAL_MESSAGE;
  }

  block = (char*) malloc(block_size);
  block_scat.num_elements    = 1;
  block_scat.elements[0].len = block_size;
  block_scat.elements[0].buf = block;

  if (!block) {
    ssp_err_quit("Dec_Scat: malloc failed\n");
  }

  for (i = j = 0; i < num_elems && mess_len; i = j)  {
    if ((currSize = scat->elements[i].len) < 0) { /* check the current element's length */
      ret = ILLEGAL_MESSAGE;                      /* return an error */
      goto Dec_Scat_end;
    }
    else if (mess_len < currSize) {
      currSize = mess_len;
    }

    currLeft = currSize - currInd; 
               
    /* currInd might not be zero, because of scatter_dencrypt_block */
    if (currLeft < 0) {
      ssp_err_quit("Dec_Scat: got a negative currLeft(%d)\n", currLeft);
    }
    
    while (i == j) {
      if (currLeft >= block_size) {                 
	/* if the current element's buffer has a block or more left */
	ret = (*decrypt)(scat->elements[j].buf + currInd, currLeft, info, endian);
	
	if (ret > mess_len || ret > currLeft || ret < 1) {
	  ssp_err_quit("Dec_Scat: (*decrypt) returned an "
		       "illegal value(%d), mess_len(%d), currLeft(%d)!\n",
		       ret, mess_len, currLeft);
	}

	currLeft -= ret;
	mess_len -= ret;
	
	if (mess_len == 0) {
	  goto Dec_Scat_break_out;
	}

	currInd   = currSize - currLeft;
	/* j doesn't change here, if currLeft == 0 now, then j and currInd will 
	   be updated on next while loop iteration */
      }
      else if (currLeft > 0) {                     
	/* if the current element's buffer has some data left but less than a block */
	j_tmp = j;
	currInd_tmp = currInd;

	if ((ret = scatter_dencrypt_block(scat, (unsigned int*)&j_tmp, 
					  (unsigned int*)&currInd_tmp, &block_scat, 
					  decrypt, block_size, info, endian)) != block_size) {

	  if (ret >= 0) {
	    ssp_err_quit("scatter_dencrypt_block returned a BUFFER_TOO_SHORT(%d) or something\n", 
			 ret);
	  }
	  goto Dec_Scat_end;               
	  /*  an error was returned by scatter_dencrypt_block, return an error */
	}

	else if (mess_len < block_size) {
	  ssp_err_quit("Dec_Scat: something wrong w/ mess_len and scatter structure\n");
	}
	mess_len -= block_size;
	
	if (mess_len == 0) {
	  goto Dec_Scat_break_out;
	}
	
	j       = j_tmp;
	currInd = currInd_tmp;
      }
      else if (currLeft == 0) {                   
	/* if there is no more data in the current element's buffer, 
	   then go to the next element */
	++j;
	currInd = 0;
      }
      else ssp_err_quit("Dec_Scat: currLeft(%d) is less than zero!\n", currLeft);
    }
  }

 Dec_Scat_break_out:
  {
    unsigned char diff;

    if (mess_len) {
      ssp_err_quit("Dec_Scat: after decrypt loop mess_len(%d) not zero!\n", mess_len);
    }
    
    /* at this point j and currInd still reference to the beginning of the last block */
    /* 
       if ((ret = scatter_skip(scat, &j, &currInd, 0, block_size - sizeof(read_out))) 
       != sizeof(read_out))
      ssp_err_quit("scatter_skip failed to get stuff off of end\n");
    */
    if ((ret = scat_get2((char*) mess_type, scat, -1, 0, 
			 org_mess_len - sizeof(int16) - sizeof(unsigned char), 
			 sizeof(int16))) != sizeof(int16)) {
      ssp_err_quit("Dec_Scat: scatter_extract2 failed!\n");
    }

    if ((ret = scat_get2((char*) &diff, scat, -1, 0, org_mess_len - sizeof(unsigned char), 
			 sizeof(unsigned char))) != sizeof(unsigned char)) {
      ssp_err_quit("Dec_Scat: scat_get2 failed!\n");
    }
    
    if (endian) {
      *mess_type = Flip_int16(*mess_type);
    }

    ret = org_mess_len - diff - sizeof(int16) - sizeof(unsigned char);
  }
 Dec_Scat_end:
  free(block); /* free the temporary block we were using */
 
  return ret;
}



