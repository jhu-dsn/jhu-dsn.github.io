/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */










/***********************************************************************************************/
/* ssp_flooder.c                                                                               */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* This code is inspired from flooder.c comming with the Spread Toolkit distribution.          */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "ssp.h"


#define	MAX_BYTES	 100000
#define MAX_FILENAME     32
#define Scatter_group    "flooder_scat"
#define Multicast_group  "flooder_multicast"
#define NUM_GROUPS        5


static	char	User[80];
static	char	Spread_name[80];
static  char    Spread_group[80];
static	char	Private_group[MAX_GROUP_NAME];
static	mailbox	Mbox;
static	int	Num_bytes;
static	int	Num_messages;
static  int     Rate;
static	int	Read_only, Write_only, Test_Scatter;
static  int     Scat_bytes[2];

static int      Save_in_file;
static char     Filename[MAX_FILENAME];


void Usage(int argc, char *argv[]);
void Join(char *group_name);

int main(int argc, char *argv[]) {
  int	  ret;

  char    mess[MAX_BYTES], mess2[MAX_BYTES] ;
  char    recv_mess[MAX_BYTES], recv_mess2[MAX_BYTES];
  char    ret_groups[NUM_GROUPS][MAX_GROUP_NAME];
  int16	  dummy_mess_type;
  int	  dummy_endian_mismatch;
  int     service_type, num_groups, more_messes;
  scatter mesg_scat, recv_scat;
  char    sender[MAX_GROUP_NAME];

  int	  i,j;
  sp_time start_time, end_time, duration, time_now;
  sp_time new_duration, duration_now, delay_now, last_time;
  int     time_msg, time_byte;
  int     int_delay; 
  float   rate_now, last_rate, report_rate;
  float   time_spent;     
  
  FILE* file = NULL ;
  
  Rate = -1;
  
  Usage(argc, argv);
  
  if(Save_in_file) {
    if((file = fopen(Filename, "w")) == NULL) {
      fprintf(stderr, "Error in opening the file %s\n", Filename);
      Save_in_file = 0;
    }		
  }

  /* connecting to the relevant Spread daemon, no need for group info */
  printf("flooder: connecting to %s\n", Spread_name);
  if((ret = SSP_connect(Spread_name, User, 0, 0, &Mbox, Private_group)) < 0) {
    SSP_error(ret);
    exit(1) ;
  }

  /* Mark the data being sent */
  for(i = 0; i < (MAX_BYTES / 4); i++){
    mess[i*4] = 49;
    mess[i*4 + 1] = 49;
    mess[i*4 + 2] = 49;
    mess[i*4 + 3] = 49;
  }
  if(Test_Scatter){
    for(i = 0; i < (MAX_BYTES / 4 ); i++){
      mess2[i*4] = 50;
      mess2[i*4 + 1] = 50;
      mess2[i*4 + 2] = 50;
      mess2[i*4 + 3] = 50;
    }
    mesg_scat.num_elements = 2;
    mesg_scat.elements[0].len = Scat_bytes[0];
    mesg_scat.elements[0].buf = mess;
    mesg_scat.elements[1].len = Scat_bytes[1];
    mesg_scat.elements[1].buf = mess2;
    
  }
  
  /* 
   * Joining the process group.
   * you can not multicast or receive encrypted messsage 
   * if you are not part of a group
   */
  
  if(Read_only) {
    printf("flooder: Only receiving messages\n");
    if(Test_Scatter) {
      Join(Scatter_group);
    }
    else {
      Join(Spread_group);
    }
  }
  else if(Write_only) {
    Join(Multicast_group);
    printf("flooder: starting  multicast of %d messages, %d bytes"
	   " each (self discarding).\n", Num_messages, Num_bytes);
  }
  else {
    if(Test_Scatter) {
      Join(Scatter_group);
    }
    else {
      Join(Spread_group);
    }
    printf("flooder: starting  multicast of %d messages, %d bytes each.\n", 
	   Num_messages, Num_bytes);
  }
  if(!Read_only) {
    sleep(5);
    start_time = E_get_time();
    last_time =  E_get_time();
  }
  
  for(i=1; i <= Num_messages; i++) {
    /* multicast a message unless Read_only */
    if(!Read_only) {
#if 0
      /* Mark the data being sent as from this message */
      /* To use this the SP_mcast type must be FIFO not RELIABLE becuase
       * otherwise we can legally get them out of order and can't check 
       * whether we missed any because of that */
      for(j = 0; j < (128 / 4); j++){
	*((int *) &mess[j*4]) = (int) i;
      }
#endif 
      if(Rate > 0) {
	if(i%50 == 0){
	  time_now = E_get_time();
	  duration_now  = E_sub_time(time_now, start_time);
	  
	  rate_now = Num_bytes;
	  rate_now = rate_now * (i-1) * 8 * 1000;
	  rate_now = rate_now / (duration_now.sec*1000000 + duration_now.usec);
	  
	  if(rate_now > Rate) {
	    new_duration  = E_sub_time(time_now, last_time);
	    last_rate = Num_bytes;
	    last_rate = last_rate * 50 * 8 * 1000;
	    last_rate = last_rate/(new_duration.sec*1000000 + new_duration.usec);
	    int_delay = Num_bytes;
	    int_delay = int_delay * 50 * 8 * 1000;
	    int_delay = int_delay/Rate; 
	    int_delay = int_delay - (new_duration.sec*1000000 + new_duration.usec);
	    
	    
	    delay_now.sec = (int_delay/1000000);
	    delay_now.usec = int_delay - delay_now.sec;
	    E_delay(delay_now);
	    last_time = E_get_time();
	  }
	}
      }
      
      if(Test_Scatter) {
	ret = SSP_scat_multicast(Mbox, RELIABLE_MESS | ENCRYPT_MESS, Scatter_group, i, &mesg_scat);
      } 
      else {
	ret = SSP_multicast(Mbox, RELIABLE_MESS | ENCRYPT_MESS, Spread_group, i, Num_bytes, mess);
      }
      if(ret != Num_bytes) {
	if(ret < 0){
	  SSP_error( ret );
	  exit(1);
	}
	printf("sent a different message %d -> %d\n", Num_bytes, ret );
      }
      if(Test_Scatter){
	printf("sent scatter with messtype = 0x%x, ret = %d, %d elements, "
	       "len1=%d, len2=%d\n", i, ret, mesg_scat.num_elements, 
	       mesg_scat.elements[0].len, mesg_scat.elements[1].len);
	for(j=0; j< mesg_scat.elements[0].len ; j++) {
	  printf(" %c .", mesg_scat.elements[0].buf[j]);
	}       
	printf("\n");
	for(j=0; j< mesg_scat.elements[1].len; j++) {
	  printf(" %c .", mesg_scat.elements[1].buf[j]);
	}
	printf("\n");
      }           
      
    }
    
    /* receive a message (Read_only) or one of my messages */
    if(Read_only || ( i > 50 && !Write_only ) || ( Test_Scatter && !Write_only)) {
      do {
	if(Test_Scatter) {
	  memset(recv_mess, 0, MAX_BYTES);
	  memset(recv_mess2, 0, MAX_BYTES);
	  recv_scat.num_elements = 2;
	  recv_scat.elements[0].len = Scat_bytes[0];
	  recv_scat.elements[0].buf = recv_mess;
	  recv_scat.elements[1].len = Scat_bytes[1];
	  recv_scat.elements[1].buf = recv_mess2;
	  
	  ret = SSP_scat_receive(Mbox, &service_type, sender, NUM_GROUPS, &num_groups, 
				 ret_groups, &dummy_mess_type, 
				 &dummy_endian_mismatch, &recv_scat, &more_messes);
	} 
	else {
	  ret = SSP_receive(Mbox, &service_type, sender, NUM_GROUPS, &num_groups, 
			    ret_groups, &dummy_mess_type, &dummy_endian_mismatch, 
			    sizeof(recv_mess), recv_mess, &more_messes);
	}
	if(ret < 0) {
	  SSP_error( ret );
	  exit(1);
	} 
	else if (ret == 0) {
	  printf("Got zero length message! i = %d, sender = %s to %d groups "
		 "messtype = 0x%x\n", 
		 i, sender, num_groups, dummy_mess_type);
	}
	if(Read_only && (i == 1)) {
	  start_time = E_get_time();
	  Num_bytes = ret;
	}
	if(Test_Scatter) {
	  printf("Received scatter with messtype = 0x%x, ret = %d, %d elements, "
		 "len1=%d, len2=%d\n", dummy_mess_type, ret, recv_scat.num_elements, 
		 recv_scat.elements[0].len, recv_scat.elements[1].len);
	  for(j=0; j< recv_scat.elements[0].len ; j++) {
	    printf(" %c .", recv_scat.elements[0].buf[j]);
	  }
	  printf("\n");
	  for(j=0; j< recv_scat.elements[1].len ; j++) {
	    printf(" %c .", recv_scat.elements[1].buf[j]);
	  }
	  printf("\n");
	}
	
#if 0
	/* Verify data contents */
	for(j= 0; j < (128 / 4 ); j++) {
	  if ((( i != *((int *) &recv_mess[j*4]) ) && Read_only) ||
	      (((i - 50)  != *((int *) &recv_mess[j*4]) ) && !Read_only) ) {
	    printf("Bad Data in mesg %d at byte %d\n", i, j*4);
	    abort(0);
	  }
	}
#endif
      } while(strcmp(sender, Private_group) != 0  && !Read_only);
    }
    
    /* report some progress... */
    if(i%1000 == 0) {
      printf("flooder: completed %6d messages of %d bytes\n",i, ret);
    }
  }
  end_time = E_get_time();
  duration = E_sub_time(end_time, start_time);
  time_msg = (duration.sec * 1000000 + duration.usec)/(Num_messages - 1);
  if (Num_bytes * (Num_messages -1) > 1024)
    time_byte = (duration.sec * 1000000 + duration.usec)/((Num_bytes * (Num_messages -1)) /1024);
  else 
    time_byte = 0;
  
  time_spent = duration.sec;
  time_spent = time_spent * 1000000 + duration.usec;
  time_spent /= 1000000;
  
  report_rate = Num_bytes;
  report_rate *= (Num_messages -1) * 8 * 1000;
  report_rate /= (duration.sec*1000000 + duration.usec);
  
  
  printf("Finished %d messages %d bytes each.\n", 
	 Num_messages, Num_bytes);
  printf("Duration of flood = %ld sec %ld us.\n", duration.sec, duration.usec);
  printf("Time per message = %d\nTime per Kbyte = %d\nRate: %6.2f Kbits/sec\n",
	 time_msg, time_byte, report_rate);
  printf("%6.2f sec => %6.2f Kbits/sec\n", time_spent, report_rate);

  if(Save_in_file){
    fprintf(file,"Finished %d messages, %d bytes each.\n", 
	    Num_messages, Num_bytes );
    fprintf(file, "Duration of flood = %ld sec %ld us.\n", 
	    duration.sec, duration.usec);
    fprintf(file,"Time per message = %d\nTime per Kbyte = %d\n"
	    "Rate: %6.2f Kbits/sec\n", time_msg, time_byte, report_rate );
    fprintf(file, "%6.2f sec => %6.2f Kbits/sec\n", time_spent, report_rate);
    fclose(file);
  }	
  
  
  return 0;
}

void Usage(int argc, char *argv[]) {
  /* Setting defaults */
  sprintf(User, "flooder");
  sprintf(Spread_group, "flooder");
  sprintf(Spread_name, "4803@localhost");
  Num_bytes    =  1000;
  Num_messages = 10000;
  Read_only    = 0;
  Write_only   = 0;
  Test_Scatter = 0;
  Scat_bytes[0] = 5;
  Scat_bytes[1] = 10;
  Save_in_file = 0;
  
  while(--argc > 0){
    argv++;
    
    if(!strncmp(*argv, "-u", 2) && argc && argv[1]){
      strcpy(User, argv[1]);
      argc--; argv++;
    }
    else if(!strncmp( *argv, "-b", 2) && argc && argv[1]){
      sscanf(argv[1], "%d", &Num_bytes);
      argc--; argv++;
    }
    else if(!strncmp( *argv, "-m", 2) && argc && argv[1]){
      sscanf(argv[1], "%d", &Num_messages);
      argc--; argv++;
    }
    else if(!strncmp( *argv, "-R", 2) && argc && argv[1]){
      sscanf(argv[1], "%d", &Rate);
      argc--; argv++;
    }
    else if(!strncmp( *argv, "-s", 2) && argc && argv[1]){
      strcpy( Spread_name, argv[1] ); 
      argc--; argv++;
    }
    else if(!strncmp( *argv, "-g", 2) && argc && argv[1]){
      strcpy( Spread_group, argv[1] ); 
      argc--; argv++;
    }
    else if(!strncmp( *argv, "-ro", 3)){
      Read_only  = 1;
      Write_only = 0;
    }
    else if(!strncmp( *argv, "-wo", 3)){
      Write_only = 1;
      Read_only  = 0;
    }
    else if(!strncmp( *argv, "-c", 2) && argc && argv[1] && argv[2]){
      Test_Scatter = 1;
      sscanf(argv[1], "%d", &Scat_bytes[0] );
      sscanf(argv[2], "%d", &Scat_bytes[1] );
      Num_bytes = Scat_bytes[0] + Scat_bytes[1];
      argc--; argv++;
      argc--; argv++;
    }
    else if (!strncmp(*argv, "-f", 2) && argc && argv[1]) {
      Save_in_file = 1;
      strcpy(Filename, argv[1]);
      argv += 2;
      argc--;
    }
    else{
      printf( "Usage: flooder\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n",
	      "\t[-u <user name>]     : unique (in this machine) user name",
	      "\t[-m <num messages>]  : number of messages",
	      "\t[-b <num bytes>]     : number of bytes per message 1-100,000",
	      "\t[-R <rate>]          : sending rate (bits/sec)",
	      "\t[-s <spread name>]   : either port or port@machine",
	      "\t[-g <spread group>]  : group to join",
	      "\t[-ro]   		        : read  only (no multicast)",
	      "\t[-wo]   		        : write only (no receive)",
	      "\t[-c <bytes> <bytes>] : test scatter setting bytes per scatter[0/1]",
	      "\t[-f <filename>]      : name of the file where the results will be saved");
      
      exit(1);
    }
  }
}

void Join(char * group_name) {
  int err;
  char     recv_mess[MAX_BYTES];
  char     sender[MAX_GROUP_NAME];
  char     ret_groups[NUM_GROUPS][MAX_GROUP_NAME];
  int16    dummy_mess_type;
  int      dummy_endian_mismatch;
  int      service_type, num_groups, more_messes;

  if ((err = SSP_join(Mbox, group_name)) < 0) {
    SSP_error(err);
    exit(1);
  }
  do { 
    if ((err = SSP_receive(Mbox, &service_type, sender, NUM_GROUPS, 
			   &num_groups, ret_groups, &dummy_mess_type, 
			   &dummy_endian_mismatch, MAX_BYTES, recv_mess, 
			   &more_messes)) < 0) {
      SSP_error(err);
      exit(1);
    }
  } while (!Is_reg_memb_mess(service_type)); 
  
  printf("flooder: membership received\n");
}







