/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */










/***********************************************************************************************/
/* clq_alg.h                                                                                   */
/* Implements the GDH  group key agreement algorithm                                           */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: July 9, 1999                                                                       */
/* Modified: Jun 30, 2000 by CNR                                                               */
/* Modified: Nov 3, 2000 by CNR - basic rob. alg.                                              */
/* Modified: Jan 24, 2001 by CNR - optimized rob. alg                                          */ 
/* Modified: Feb. 15, 2001 by CNR - CKD implem.                                                */
/* Modified: Aug. 10, 2002 by CNR - separate CKD from GDH.                                     */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/


#ifndef _CLQ_ALG_H_
#define _CLQ_ALG_H_

#include <stdutil/stddefines.h>
#include <stdutil/stderror.h>
#include <stdutil/stddll.h>
#include <stdutil/stdarr.h>

#include "ssp_info.h"
#include "clq_api.h"

#define SSP_CLIQUES_ALG 0

typedef enum {
  CLQ_SECURE,
  CLQ_WAIT_FOR_PARTIAL_TOKEN,
  CLQ_WAIT_FOR_FINAL_TOKEN,
  CLQ_WAIT_FOR_KEY_LIST,
  CLQ_WAIT_FOR_CASCADING_MEMBERSHIP,
  CLQ_COLLECT_FACT_OUTS,
  CLQ_WAIT_FOR_SELF_JOIN,
  CLQ_WAIT_FOR_MEMBERSHIP
} CLQ_Alg_State;

typedef struct dummy_CLQ_Alg {
  CLQ_Alg_State state;
  stddll        msg_deque;
  CLQ_CONTEXT   *ctx;
  SSP_Bool      first_trans; 
  SSP_Bool      vs_trans;
  SSP_Bool      first_cascaded_memb;
  SSP_Bool      wait_for_sec_fl_ok;
  SSP_Bool      kl_got_fl_req;
  char          (*vs_set)[MAX_GROUP_NAME];
  stdhash       vs_set_hash;
  SSP_Msg       *curr_memb_msg;
} CLQ_Alg;

CLQ_Alg *CLQ_Alg_create();
void CLQ_Alg_free(CLQ_Alg **clq);

/* spread message types used by the GDH algorithm */
#define CLQ_PARTIAL_TOKEN              ((int16) -32750)
#define CLQ_FINAL_TOKEN                ((int16) -32749)
#define CLQ_FACT_OUT                   ((int16) -32748)
#define CLQ_KEY_LIST                   ((int16) -32747)

#define Is_partial_token_msg(type)     (type == CLQ_PARTIAL_TOKEN)
#define Is_final_token_msg(type)       (type == CLQ_FINAL_TOKEN)
#define Is_fact_out_msg(type)          (type == CLQ_FACT_OUT)
#define Is_key_list_msg(type)          (type == CLQ_KEY_LIST)

#define CLQ_SERVICE_TYPE               FIFO_MESS
#define CLQ_KL_TYPE                    AGREED_MESS   /* key list is sent agreed  */

/* wrapper fcn that implement the "generic" key_alg interface */
int  CLQ_handles_msg(SSP_Msg *msg, SSP_Grp *grp);
int  CLQ_handle_recv(SSP_Con *conn, SSP_Grp *grp, SSP_Msg *msg);
int  CLQ_handle_fl_ok(SSP_Con *conn, SSP_Grp *grp);
int  CLQ_handle_send(SSP_Con *con, SSP_Grp *grp);

#endif /* _CLQ_ALG_H_*/



















