/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */










/***********************************************************************************************/
/* ssp_error.c                                                                                 */
/* Error printing messages                                                                     */
/*                                                                                             */
/*                                                                                             */
/* Created: Aug 15, 2001                                                                       */
/* This code is based on R. Stevens code from "Network programming"                            */
/***********************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <errno.h>
#include <string.h>

#define MAX_LINE   4096
#define LOG_ERR    1 
#define LOG_INFO   2


/* ----------------------------------------------------------------------------
   This function prints an error message and returns to caller. Caller specifies
   the errnoflag and level.
   -------------------------------------------------------------------------- */
static void err_doit(int errnoflag, int level, const char *fmt, va_list ap) {
  int errno_save;
  int n;
  char buf[MAX_LINE];

  errno_save = errno;
  vsnprintf(buf, sizeof(buf), fmt, ap);
  n = strlen(buf);

  if(errnoflag) {
    snprintf(buf+n, sizeof(buf)-n-1, ": %s", strerror(errno_save));
  }
  strcat(buf, "\n");
  
  fflush(stdout);
  fputs(buf, stderr);
  fflush(stderr);

  return;
}


/* ----------------------------------------------------------------------------
   Nonfatal error related to a system call. Print a message and return.
   ----------------------------------------------------------------------------- */
void ssp_err_ret(const char *fmt, ...) {
  va_list ap;

  va_start(ap, fmt);
  err_doit(1, LOG_INFO, fmt, ap);
  va_end(ap);

  return;
}


/* ----------------------------------------------------------------------------
   Fatal error related to a system call. Print a message and terminate.
   ----------------------------------------------------------------------------- */
void ssp_err_sys(const char *fmt, ...) {
  va_list ap;

  va_start(ap, fmt);
  err_doit(1, LOG_ERR, fmt, ap);
  va_end(ap);
  exit(1);
}


/* ----------------------------------------------------------------------------
   Fatal error related to a system call. Print a message, dump core and terminate.
   ----------------------------------------------------------------------------- */
void ssp_err_dump(const char *fmt, ...) {
  va_list ap;

  va_start(ap, fmt);
  err_doit(1, LOG_ERR, fmt, ap);
  va_end(ap);
  abort();
  exit(1);
}


/* ----------------------------------------------------------------------------
   Nonfatal error unrelated to a system call. Print a message and return.
   ----------------------------------------------------------------------------- */
void ssp_err_msg(const char *fmt, ...) {
  va_list ap;

  va_start(ap, fmt);
  err_doit(0, LOG_INFO, fmt, ap);
  va_end(ap);

  return;
}


/* ----------------------------------------------------------------------------
   Fatal error unrelated to a system call. Print a message and quit.
   ----------------------------------------------------------------------------- */
void ssp_err_quit(const char *fmt, ...) {
  va_list ap;

  va_start(ap, fmt);
  err_doit(0, LOG_ERR, fmt, ap);
  va_end(ap);
  exit(1);
}
  




