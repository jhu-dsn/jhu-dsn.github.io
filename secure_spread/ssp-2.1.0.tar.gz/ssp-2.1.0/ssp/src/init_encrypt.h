/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */










/* ******************************************************************************************* */
/* init_encrypt.h                                                                              */
/* These functions create snd destroy  SSP_Encrypt_Info, with the data particular to           */
/* an encrypting algorithm. It supports only BLOWFISH for now.                                 */
/*                                                                                             */
/* Cristina Nita-Rotaru and John Schultz                                                       */
/* Created: June 28, 1999                                                                      */
/* Modified: Jun 23 2000 by Cristina Nita-Rotaru                                               */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/* ******************************************************************************************* */

#ifndef _INIT_ENCRYPT_H_
#define _INIT_ENCRYPT_H_

#include "ssp_info.h"

SSP_Enc* SSP_Enc_create(unsigned int key_len, int alg);
void SSP_Enc_destroy(SSP_Enc *enc);

#endif /* _INIT_ENCRYPT_H_ */




