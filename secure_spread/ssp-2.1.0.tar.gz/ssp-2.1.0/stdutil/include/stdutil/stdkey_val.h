#ifndef stdkey_val_h_2000_06_02_02_20_47_jschultz_at_cnds_jhu_edu
#define stdkey_val_h_2000_06_02_02_20_47_jschultz_at_cnds_jhu_edu

/* In the stdutil lib associative data structures, key-value pairs are
   stored in memory exactly like this:

   struct {
     key_type key;
     val_type val;
   }

   Of course, I can't explicitly declare that generic type in ANSI C.
   However, a user can declare that type if they ever want to grab a
   key-value pair as one from an iterator that references to a stdutil
   associative data structure. The address of such a struct can be
   gotten from a standard iterator (which references an associative
   structure) by stdit_val(sit) and also usually by other structure
   specific functions (e.g. stdhash_it_key_val(it)). If elements
   are taken from an associative data structure and put into a
   non-associative data structure (say by a stdit iterator sequence)
   then these structs are the values that are put into that data
   structure.
*/
/* A stdkey_val_info struct is used to specify all the necessary type
   information in order for a stdutil associative data structure to be
   able to function properly (i.e. lay out a key_val pair type in
   memory as described above). The ksize and vsize members represent
   the intrinsic size (sizeof) of the respective types of the keys and
   values that the user wishes to store. The kalign and valign specify
   what kind of alignment the key and value types respectively
   require. Usually, these members are exactly the same as the
   key_size and val_size members, repectively.

   The align members are not the same as their respective size members
   when the keys or values being stored are actually arrays of a
   specific type (e.g. - my key is a fixed size array of
   characters). In this case, the align members should be the size of
   the type that the array contains. For example, let's say that I
   want my key type to be an int and my value type to be a fixed
   length array of NUM_SHORTS shorts. Then this is how I would
   initialize my stdkey_val_info for working with an associative DS:

   #include <stdio.h>
   #include <stdutil/stdhash.h> // the associative DS in question

   #define NUM_SHORTS 17        // constant defined somehow

   typedef struct {             // the key-val type I want to store
     int lookup_key;
     short data[NUM_SHORTS];
   } my_key_val_pair;

   int main(void) {
     stdkey_val_info my_type_info; // used to specify that type to an associative DS
     stdhash my_hash;              // the associative DS in question
     stdhash_it my_it;             // an iterator to make sure it works

     short tmp_data[NUM_SHORTS] = { 5, 27, 18, 20 };  // some junk data
     my_key_val_pair *kvp;
     int i;

     // first I specify the type of key-val pair I want my hash to contain
     my_type_info.key_size      = sizeof(int);
     my_type_info.val_size      = NUM_SHORTS * sizeof(short);
     my_type_info.key_alignment = sizeof(int);
     my_type_info.val_alignment = sizeof(short);

     // now I declare and construct an associative DS using that type info
     stdhash_construct(&my_hash, my_type_info, 0, 0);

     // insert a key-val pair and have my_it ref to it
     stdhash_insert(&my_hash, &my_it, &27, &tmp_data);

     // grab a ptr to the key-val pair out from the iterator
     kvp = (my_key_val_pair*) stdhash_it_key_val(&my_it);

     // this should print key = 27 data[0] = 5 data[1] = 27 data[2] = 18 data[3] = 20
     // followed by thirteen data[4-16] = 0 (of course it will put newlines, etc.)

     printf("key = %d\n", kvp->lookup_key);
     for (i = 0; i < NUM_SHORTS; ++i)
       printf(" data[%d] = %d\n", i, kvp->data[i]);

     return 0;
   }

   In conclusion, the stdkey_val_info allows associative data
   structures to allocate and lay out its key-value pairs
   appropriately in memory as above defined.

   NOTE: most of the associative data structures will allow you to
   have zero length value types, in which case the val_alignment
   should also be zero.  
*/
typedef struct {
  size_t ksize;
  size_t vsize;
  size_t kalign;
  size_t valign;
} stdkey_val_info;

#endif
