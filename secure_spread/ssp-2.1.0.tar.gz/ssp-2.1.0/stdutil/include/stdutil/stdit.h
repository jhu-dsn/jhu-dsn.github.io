#ifndef stdit_h_2000_05_12_16_33_00_jschultz_at_cnds_jhu_edu
#define stdit_h_2000_05_12_16_33_00_jschultz_at_cnds_jhu_edu

#ifdef __cplusplus
extern "C" {
#endif

/* A stdit is a generic iterator that provides a view of a sequence of
   elements. There are three kinds of iterators, each having different
   capabilities and performance. An iterator's type is determined by
   what operations it can support in constant time (on average).

   A forward iterator can reference the next element in its sequence
   in constant time.

   A bidirectional iterator can reference the next or the previous
   element in its sequence in constant time.

   A random access iterator can offset to any element in its sequence
   in constant time. Futhermore, if two random access iterators refer
   to the same sequence, they can be compared in constant time to find
   the difference in their sequence rank.

   Obviously a random access iterator is a bidirectional iterator, and
   a bidirectional iterator is a forward iterator.

   Stdits are initialized by data structures that want to provide this
   standard interface to themselves. Those data structures offer an
   interface to initialize a stdit to reference into themselves. Usually,
   a user would declare a stdit, pass a reference to an initialization
   fcn of the collection that they are interested in, and then use it.  
*/

typedef enum { 
  STD_FORWARD = 0x1, STD_BIDIRECTIONAL = 0x3, STD_RANDOM_ACCESS = 0x7 
} stdit_type;

#include <stdutil/stdit_p.h>

/* Iterator type information */
inline stdit_type stdit_get_type(const stdit *it);
inline stdbool    stdit_is_forward(const stdit *it);
inline stdbool    stdit_is_bidirectional(const stdit *it);
inline stdbool    stdit_is_random_access(const stdit *it);

/* Const Iterator fcns */
inline void    *stdit_val(const stdit *it);
inline size_t  stdit_sizeof_val(const stdit *it);
inline stdbool stdit_equals(const stdit *it1, const stdit *it2);
inline stdbool stdit_is_begin(const stdit *it);
inline stdbool stdit_is_end(const stdit *it);

/* Functionality provided by forward iterators */
inline stdit *stdit_seek_begin(stdit *it);
inline stdit *stdit_seek_end(stdit *it);
inline stdit *stdit_next(stdit *it);
inline stdit *stdit_advance(stdit *it, size_t num_advance);

/* Additional functionality provided by bidirectional iterators */
inline stdit *stdit_prev(stdit *it);
inline stdit *stdit_retreat(stdit *it, size_t num_retreat);

/* Additional functionality provided by random access iterators */
inline stdssize_t stdit_compare(const stdit *it1, const stdit *it2);
inline stdit      *stdit_offset(stdit *it, stdssize_t offset);

#ifdef __cplusplus
}
#endif

#endif
