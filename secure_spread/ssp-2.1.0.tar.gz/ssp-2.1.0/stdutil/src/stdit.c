#ifdef USE_DMALLOC
#include <dmalloc.h>
#endif
#include <stdutil/stderror.h>
#include <stdutil/stdit.h>

/* Iterator type information */
inline stdit_type stdit_get_type(const stdit *it) {
  return it->fcns->type;
}

inline stdbool stdit_is_forward(const stdit *it) {
  return (it->fcns->type & STD_FORWARD) == STD_FORWARD;
}

inline stdbool stdit_is_bidirectional(const stdit *it) {
  return (it->fcns->type & STD_BIDIRECTIONAL) == STD_BIDIRECTIONAL;
}

inline stdbool stdit_is_random_access(const stdit *it) {
  return (it->fcns->type & STD_RANDOM_ACCESS) == STD_RANDOM_ACCESS;
}

/* Iterator query fcns */
inline void *stdit_val(const stdit *it) { 
  return it->fcns->val(it->it);
}

inline size_t stdit_sizeof_val(const stdit *it) {
  return it->fcns->sizeof_val(it->it);
}

inline stdbool stdit_equals(const stdit *it1, const stdit *it2) { 
  return it->fcns->equals(it1->it, it2->it);
}

inline stdbool stdit_is_begin(const stdit *it) {
  return it->fcns->is_begin(it->it), it;
}

inline stdbool stdit_is_end(const stdit *it) {
  return it->fcns->is_end(it->it), it;
}

/* Functionality provided by forward iterators */
/* A forward iterator must implement these fcns */
inline stdit *stdit_seek_begin(stdit *it) {
  return it->fcns->seek_begin(it->it), it;
}

inline stdit *stdit_seek_end(stdit *it) {
  return it->fcns->seek_end(it->it), it;
}

inline stdit *stdit_next(stdit *it) {
  return it->fcns->next(it->it), it;
}

inline stdit *stdit_advance(stdit *it) {
  return it->fcns->advance(it->it), it;
}

/* Optional functions that may be supported by a stdit -- if you call
   one of these functions and it isn't supported by the underlying
   iterator your program will exit.  If you compiled with
   -DSAFE_CHECKS then you will get an error message stating the
   problem and a core dump, otherwise you will seg fault.
*/
/* Functionality provided by bidirectional iterators */
/* A bidirectional iterator must implement these fcns */
inline stdit *stdit_prev(stdit *it) {
#ifdef SAFE_CHECKS
  if (it->fcns->prev == 0)
    EXCEPTION(stdit_prev: this operation is not supported by the underlying iterator);
#endif
  return it->fcns->prev(it->it), it;
}

inline stdit *stdit_retreat(stdit *it, size_t num_retreat) {
#ifdef SAFE_CHECKS
  if (it->fcns->retreat == 0)
    EXCEPTION(stdit_retreat: this operation is not supported by the underlying iterator);
#endif
  return it->fcns->retreat(it->it, num_retreat), it;
}

/* Functionality provided by random access iterators */
/* A random access iterator must implement these fcns */
inline ssize_t stdit_compare(const stdit *it1, const stdit *it2) {
#ifdef SAFE_CHECKS
  if (it->fcns->compare == 0)
    EXCEPTION(stdit_compare: this operation is not supported by the underlying iterator);
#endif
  return it->fcns->compare(it1->it, it2->it);
}

inline stdit *stdit_offset(stdit *it, ssize_t offset) {
#ifdef SAFE_CHECKS
  if (it->fcns->offset == 0)
    EXCEPTION(stdit_offset: this operation is not supported by the underlying iterator);
#endif
  return it->fcns->offset(it->it, offset), it;
}
