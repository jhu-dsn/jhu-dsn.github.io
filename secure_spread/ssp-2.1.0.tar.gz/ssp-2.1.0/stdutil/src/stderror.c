/* Copyright (c) 2000, The Johns Hopkins University
 * All rights reserved.
 *
 * The contents of this file are subject to a license (the ``License'')
 * that is the exact equivalent of the BSD license as of July 23, 1999. 
 * You may not use this file except in compliance with the License. The
 * specific language governing the rights and limitations of the License
 * can be found in the file ``STDUTIL_LICENSE'' found in this 
 * distribution.
 *
 * Software distributed under the License is distributed on an AS IS 
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. 
 *
 * The Original Software is:
 *     The Stdutil Library
 * 
 * Contributors:
 *     Creator - John Lane Schultz (jschultz@cnds.jhu.edu)
 *     The Center for Networking and Distributed Systems
 *         (CNDS - http://www.cnds.jhu.edu)
 */ 

#include <stdlib.h>
#include <stdio.h>

#ifdef USE_DMALLOC
#include <dmalloc.h>
#endif

#include <string.h>
#include <stdarg.h>
#include <errno.h>
#include <stdutil/stddefines.h>
#include <stdutil/stderror.h>

/* Print a message and return to caller. Caller specifies "errnoflag." */
inline static void err_doit(int errnoflag, const char *fmt, va_list ap) {
  int errno_save = errno;

  vfprintf(stderr, fmt, ap);
  if (errnoflag)
    fprintf(stderr, ": %s", strerror(errno_save));
  fprintf(stderr, "\n");
  fflush(stderr);
}

/* Nonfatal error unrelated to a system call. Print a message and return. */
int stderr_msg(const char *fmt, ...) {
  va_list ap;

  va_start(ap, fmt);
  err_doit(0, fmt, ap);
  va_end(ap);
  return 0;
}

/* Nonfatal error related to a system call. Print a message and return. */
int stderr_ret(const char *fmt, ...) {
  va_list ap;

  va_start(ap, fmt);
  err_doit(1, fmt, ap);
  va_end(ap);
  return 0;
}

/* Fatal error unrelated to a system call. Print a message and terminate. */
int stderr_quit(const char *fmt, ...) {
  va_list ap;

  va_start(ap, fmt);
  err_doit(0, fmt, ap);
  va_end(ap);
  exit(1);
  return 0;
}

/* Fatal error unrelated to a system call. Print a message and abort. */
int stderr_abort(const char *fmt, ...) {
  va_list ap;

  va_start(ap, fmt);
  err_doit(0, fmt, ap);
  va_end(ap);
  abort();		/* dump core and terminate */
  exit(1);
  return 0;
}

int stderr_pabort(const char *file_name, unsigned line_num, const char *fmt, ...) {
  int errno_save = errno;
  va_list ap;

  va_start(ap, fmt);
  fprintf(stderr, "pabort: file: %s, line: %u, ", file_name, line_num);
  if (errno_save)
    fprintf(stderr, "errno: %s, ", strerror(errno_save));
  
  fprintf(stderr, "msg: ");
  vfprintf(stderr, fmt, ap);
  fprintf(stderr, "\n");
  fflush(stderr);
  
  va_end(ap);
  abort();
  exit(1);
  return 0;
}

/* Fatal error related to a system call. Print a message and terminate. */
int stderr_sys(const char *fmt, ...) {
  va_list ap;

  va_start(ap, fmt);
  err_doit(1, fmt, ap);
  va_end(ap);
  exit(1);
  return 0;
}

/* Fatal error related to a system call. Print a message and abort. */
int stderr_dump(const char *fmt, ...) {
  va_list ap;

  va_start(ap, fmt);
  err_doit(1, fmt, ap);
  va_end(ap);
  abort();		/* dump core and terminate */
  exit(1);
  return 0;
}
