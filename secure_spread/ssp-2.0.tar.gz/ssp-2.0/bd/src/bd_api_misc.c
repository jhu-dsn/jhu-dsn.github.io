/* CLIQUES Non-Commercial License (covers BD, CLQ, STR and TGDH
libraries).  Copyright (c) 1998-2002 by the University of California,
Irvine.  All rights reserved.

Permission to use, copy, modify, and distribute this software and its
documentation in source and binary forms for lawful non-commercial
purposes and without fee is hereby granted, provided that the above
copyright notice appear in all copies and that both the copyright
notice and this permission notice appear in supporting documentation,
and that any documentation, advertising materials, and other materials
related to such distribution and use acknowledge that the software was
developed by the University of California, Irvine, Information and
Computer Science Department. The name of University of California,
Irvine may not be used to endorse or promote products derived from
this software without specific prior written permission.

THE UNIVERSITY OF CALIFORNIA, IRVINE MAKES NO REPRESENTATIONS ABOUT
THE SUITABILITY OF THIS SOFTWARE FOR ANY PURPOSE.  THIS SOFTWARE IS
PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND
NON-INFRINGEMENT.

IN NO EVENT SHALL UNIVERSITY OF CALIFORNIA, IRVINE OR ANY OTHER
CONTRIBUTOR BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
DAMAGES, WHETHER IN CONTRACT, TORT, OR OTHER FORM OF ACTION, ARISING
OUT OF OR IN CONNECTION WITH, THE USE OR PERFORMANCE OF THIS SOFTWARE.

All questions concerning this software should be directed to
cliques@ics.uci.edu. */



/*********************************************************************
 * bd_api_misc.c                                                     * 
 * Burmester-Desmedt miscellaneous source file.                      * 
 * Date      Tue Nov 21 22:08:07 PST 2000                            *
 * Wrote by:                                                         * 
 * Yongdae Kim                                                       *
 *                                                                   *
 * CLIQUES Project                                                   *
 * Information Sciences Institute                                    *
 * University of Southern California                                 *
 *********************************************************************/

#include <stdio.h>
/* The next three are needed for creat() in bd_gen_params */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <string.h>
#include <unistd.h>
#include <malloc.h>

#ifdef TIMING
/* Needed by getrusgae */
#include <sys/time.h>
#include <sys/resource.h>
#include <unistd.h>

int print=1;


#endif

/* SSL include files */
#include "bio.h"
#include "dsa.h"
#include "bn.h"
#include "rand.h"
#include "md5.h"

/* BD_API include files */
#include "bd_api.h"
#include "bd_api_misc.h"

/* bd_gen_key_set: Generate a pair of public and private key for the
 * user_name.
 * Returns 1 if succeed 0 otherwise.
 * Note: This function should be used in conjuction with
 * bd_read_dsa (i.e. USE_BD_READ_DSA should be defined.)
 */
int bd_gen_key_set(char *user_name) {   
  DSA *pubKey=NULL;
  DSA *privKey=NULL;
  int ok=0;
  char fileName[FN_LENGTH];

#ifdef TIMING  
  double Time=0.0;

  Time=bd_get_time();
#endif
    

#ifdef DEBUG_MISC
    fprintf(ERR_STRM,"Generating key set for user %s ...\n",
	    user_name);
#endif

  if ((privKey=bd_read_dsa((BD_NAME *)NULL,BD_PARAMS))==(DSA*)NULL)  goto end;
  if (!DSA_generate_key(privKey)) goto end;
  if ((pubKey=DSA_new())==(DSA*)NULL) goto end;
  /* Copying the public stuff to pubKey */
  pubKey->pad=privKey->pad;
  pubKey->version=privKey->version;
  pubKey->write_params=privKey->write_params;
  if ((pubKey->p=BN_new())==(BIGNUM*)NULL) goto end;
  if (BN_copy(pubKey->p,privKey->p) == NULL) goto end;
  if ((pubKey->q=BN_new()) == NULL) goto end;
  if (BN_copy(pubKey->q,privKey->q) == NULL) goto end;
  if ((pubKey->g=BN_new()) == NULL) goto end;
  if (BN_copy(pubKey->g,privKey->g) == NULL) goto end;
  if ((pubKey->pub_key=BN_new()) == NULL) goto end;
  if (BN_copy(pubKey->pub_key,privKey->pub_key) == NULL) goto end;
  pubKey->kinv= NULL; /* Signing pre-calc */
  pubKey->r= NULL;    /* Signing pre-calc */
  pubKey->references=privKey->references;
  pubKey->priv_key=NULL;

#ifdef DEBUG_MISC
  fprintf(ERR_STRM,"Done.\n"); 
#endif

  sprintf (fileName, "%s_%s.%s",PUB_FMT, user_name, FILE_EXT);
  if (!bd_write_dsa(pubKey,PUB_FMT,fileName)) goto end;
  sprintf (fileName, "%s_%s.%s",PRV_FMT, user_name, FILE_EXT);
  if (!bd_write_dsa(privKey,PRV_FMT,fileName)) goto end;
  
  ok=1;
end:

  if (pubKey != NULL) DSA_free (pubKey);
  if (privKey != NULL) DSA_free (privKey);

#ifdef TIMING
  Time=bd_get_time()-Time;
  bd_print_times("bd_gen_key_set",Time);
#endif

  return ok;
}

int bd_print_dsa(DSA *dsa) {
  char *tmp;
  
  if (dsa == NULL) { 
    fprintf(ERR_STRM,"Invalid DSA structure.\n"); 
    return 0;
  }

  fprintf(ERR_STRM,"\n--- begin DSA structure ---\n");
  fprintf(ERR_STRM,"Size: %d\n\n",dsa->p==NULL ? 0: BN_num_bits(dsa->p));
  tmp=BN_bn2hex(dsa->p);
  fprintf(ERR_STRM,"p = %s\n", tmp==NULL ? "n.d.": tmp);
  free(tmp); tmp=BN_bn2hex(dsa->q);
  fprintf(ERR_STRM,"q = %s\n", tmp==NULL ? "n.d.": tmp);
  free(tmp); tmp=BN_bn2hex(dsa->g);
  fprintf(ERR_STRM,"g = %s\n\n", tmp==NULL ? "n.d.": tmp);
  free(tmp); tmp=BN_bn2hex(dsa->priv_key);
  fprintf(ERR_STRM,"secr = %s\n", tmp==NULL ? "n.d.": tmp);
  free(tmp); tmp=BN_bn2hex(dsa->pub_key);
  fprintf(ERR_STRM,"pub  = %s\n", tmp==NULL ? "n.d.": tmp);
  free (tmp);
  fprintf(ERR_STRM,"\n--- end DSA structure ---\n");

  return 1;
}

void bd_print_ctx(char *name, BD_CONTEXT *ctx){

  fprintf(ERR_STRM,"\n--- %s ---\n\t", name);
  if(ctx == NULL) {
    fprintf(ERR_STRM,"CTX for %s is null\t", name);
    return;
  }
  if(ctx->member_name != NULL)
    fprintf(ERR_STRM,"name     = %s\t", ctx->member_name);
  else fprintf(ERR_STRM,"name     = NULL\t");
  if(ctx->group_name != NULL)
    fprintf(ERR_STRM,"group    = %s\t", ctx->group_name);
  else fprintf(ERR_STRM,"group    = NULL\t");
  if(ctx->group_secret != NULL){
    fprintf(ERR_STRM,"grpsecret= ");
    BN_print_fp(ERR_STRM, ctx->group_secret);
    fprintf(ERR_STRM,"\n");
  }
  else fprintf(ERR_STRM,"grpsecret= NULL\n");
  if(ctx->epoch != (int)NULL){
    fprintf(ERR_STRM,"epoch= %d\n", ctx->epoch);
  }
  else fprintf(ERR_STRM,"epoch= NULL\n");

  return;
}

int compare_key(BD_CONTEXT *ctx[], int num) {
  int i=0;
  BIGNUM *tmp_key=NULL;

  for(i=0; i<num; i++){
    if(ctx[i]){
      if(ctx[i]->group_secret){
        tmp_key=ctx[i]->group_secret;
      }
    }
  }
  for(i=0; i<num; i++){
    if(ctx[i] != NULL){
      if(BN_cmp(tmp_key, ctx[i]->group_secret) != 0){
        fprintf(stderr, "()()())(()()()()()()()()()\n");
        return -1;
      }
    }
    else{
    }
  }
  
#ifdef VERBOSE
  fprintf(stderr, "\n\n\nAll right... All keys are same!!!\n");
#endif
  
  return 1;
}

/* bd_write_dsa: Writes the dsa structure into outfile. 
 * oper could be any of the following: 
 * PUB_FMT, PRV_FMT
 * dsa should be a valid pointer.
 * If outfile is NULL, then stdout will be used.
 * Returns 1 if succeed 0 otherwise.
 * Note: This function should be used in conjuction with
 * bd_read_dsa (i.e. USE_BD_READ_DSA should be defined.)
 */
int bd_write_dsa(DSA *dsa, char *oper, char *outfile) {
  BIO *out=NULL;
  int i=0;
  int ok=0;
  char oper_str[30];

  strcpy(oper_str, "Invalid.");
  
  out=BIO_new(BIO_s_file());
  if (out == NULL) {
    fprintf (ERR_STRM,"Error: Could not create bio file.\n");
    goto end;
  }

  /* If this is NULL, then stdout will be used. */
  if(outfile != NULL) { 
    if (BIO_write_filename(out,outfile) <= 0) {
      perror(outfile); 
      goto end;
    }
#ifdef DEBUG_MISC
    fprintf(ERR_STRM,"Creating file %s.\n", outfile);
#endif
  } 
  else BIO_set_fp(out,stdout,BIO_NOCLOSE);

#ifdef DEBUG_MISC
  fprintf(ERR_STRM,"\tWriting DSA "); 
#endif
  
  if(!strcmp(oper,"params")) {
    strcpy (oper_str,"parameters");
    i=i2d_DSAparams_bio(out,dsa);
  }
  else if(!strcmp(oper,PUB_FMT)) {
    strcpy (oper_str,"public key");
    i=i2d_DSAPublicKey_bio(out,dsa);
  }
  else if(!strcmp(oper,PRV_FMT)) {
    strcpy (oper_str,"private key");
    i=i2d_DSAPrivateKey_bio(out,dsa);
  }

#ifdef DEBUG_MISC
  fprintf(ERR_STRM," %s.\n",oper_str);
#endif

  if (!i) {
    fprintf(ERR_STRM,"ERROR: Unable to write DSA %s.\n",oper_str);
    goto end;
  }

  ok = 1;

end:
  if (out != NULL) BIO_free(out);

  return ok;
}


#ifdef TIMING

#define strm stderr

void bd_print_times(char *str, double time) {

  if (print) {
    fprintf (strm, "<- %s\n",str);
    fprintf (strm, " Total Time: %f sec\n", time);
    fprintf (strm, "   %s ->\n",str);
  }
}

/* Old version of bd_print_times that was used in conjunction with
   gettimeof day 6/3/99 Dmn.- */
/*
void bd_print_times(char *str,struct timeval t_initial, struct timeval
		     t_final) {

  if (print) {
  fprintf (strm, "<- %s\n",str);
  fprintf (strm," Total Secs: %ld uSecs: %ld\n",    
	   t_final.tv_usec > t_initial.tv_usec ?
	   t_final.tv_sec-t_initial.tv_sec :
	   t_final.tv_sec-1-t_initial.tv_sec,  
	   t_final.tv_usec > t_initial.tv_usec ?
	   (t_final.tv_usec-t_initial.tv_usec) :
	   (t_final.tv_usec+1000000-t_initial.tv_usec)); 
  fprintf (strm, "   %s ->\n",str);
  }
}
*/

double bd_get_time(void) {
  struct rusage used;
  
  getrusage(RUSAGE_SELF, &used);
  /*
  printf (":%ld %ld %ld %ld:\n", used.ru_utime.tv_sec, used.ru_utime.tv_usec,
	  used.ru_stime.tv_sec, used.ru_stime.tv_usec);
	  */
  return (used.ru_utime.tv_sec + used.ru_stime.tv_sec +
	  (used.ru_utime.tv_usec + used.ru_stime.tv_usec) / 1e6);
}


#endif

/* bd_get_secret: Returns in a static variable with
 * ctx->group_secret_hash 
 */ 
bd_uchar *bd_get_secret(BD_CONTEXT *ctx) {
  static bd_uchar tmp[MD5_DIGEST_LENGTH];

  memcpy (tmp,ctx->group_secret_hash,MD5_DIGEST_LENGTH);

  return tmp;
}

void bd_print_group_secret(BD_CONTEXT *ctx) {
  int i;

  fprintf(ERR_STRM,"Group Secret (MD5): ");
  if (ctx->group_secret_hash == NULL) fprintf (ERR_STRM,"EMPTY");
  else {
    for (i=0; i < MD5_DIGEST_LENGTH; i++) 
      fprintf(ERR_STRM, "%02X",ctx->group_secret_hash[i]);
  }

  fprintf(ERR_STRM,"\n");
}

/* cmp_str: Returns 1 if input1 is greater,
 *          Returns -1 if input2 is greater,
 *          0 otherwise 
 */
int cmp_str(char *input1, char *input2)
{
  int i=0, j=0;
  
  while((int)input1[i] != 0){
    if((int)input2[i] == 0){
      break;
    }
    i++;
  }
  if(((int)input2[i] == 0) && ((int)input1[i] != 0)){
    return 1;
  }
  if((int)input2[i] != 0){
    return -1;
  }
  for(j=i-1; j>-1; j--){
    if((int)input1[j] > (int)input2[j]){
      return 1;
    }
    if((int)input1[j] < (int)input2[j]){
      return -1;
    }
  }

  return 0;
}
