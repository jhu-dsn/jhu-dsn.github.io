/* CLIQUES Non-Commercial License (covers BD, CLQ, STR and TGDH
libraries).  Copyright (c) 1998-2002 by the University of California,
Irvine.  All rights reserved.

Permission to use, copy, modify, and distribute this software and its
documentation in source and binary forms for lawful non-commercial
purposes and without fee is hereby granted, provided that the above
copyright notice appear in all copies and that both the copyright
notice and this permission notice appear in supporting documentation,
and that any documentation, advertising materials, and other materials
related to such distribution and use acknowledge that the software was
developed by the University of California, Irvine, Information and
Computer Science Department. The name of University of California,
Irvine may not be used to endorse or promote products derived from
this software without specific prior written permission.

THE UNIVERSITY OF CALIFORNIA, IRVINE MAKES NO REPRESENTATIONS ABOUT
THE SUITABILITY OF THIS SOFTWARE FOR ANY PURPOSE.  THIS SOFTWARE IS
PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND
NON-INFRINGEMENT.

IN NO EVENT SHALL UNIVERSITY OF CALIFORNIA, IRVINE OR ANY OTHER
CONTRIBUTOR BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
DAMAGES, WHETHER IN CONTRACT, TORT, OR OTHER FORM OF ACTION, ARISING
OUT OF OR IN CONNECTION WITH, THE USE OR PERFORMANCE OF THIS SOFTWARE.

All questions concerning this software should be directed to
cliques@ics.uci.edu. */

/*********************************************************************
 * bd_api.h                                                          * 
 * Broadcast based Group Key Ageement Scheme                         * 
 * Wrote by:                                                         * 
 * Yongdae Kim                                                       *
 *                                                                   *
 * CLIQUES Project                                                   *
 * Information Sciences Institute                                    *
 * University of Southern California                                 *
 *********************************************************************/

#ifndef BD_API_H
#define BD_API_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "openssl/bn.h"
#include "openssl/dsa.h"
#include "openssl/x509.h"
#include "openssl/asn1.h"

#define BD_API_VERSION "0.9"

/* data structures */
typedef char BD_NAME;
#ifndef bd_uchar
typedef unsigned char bd_uchar;
#endif

#define ERR_STRM stderr /* If DEBUG is enable then extra information
			 * will be printed in ERR_STRM 
			 */
#define MAX_LGT_NAME 50 /* Maximum length a CLQ_NAME can have. */

/***************************************************************/
/* Be careful... previously, 32768                             */
/* I changed since for 148 users, we need more than 32768 bytes*/
/***************************************************************/
#define BD_MSG_SIZE 65536
#define INT_SIZE sizeof(int)
#define LENGTH_SIZE 4 /* The length of the size in a token */
#define TOTAL_INT INT_SIZE+LENGTH_SIZE
#define MAX_LIST 200 /* Maximum number of members */ 

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

/* BD_NAME_LIST: Linked list of users */
typedef struct bd_name_list {
  BD_NAME *member_name;
  struct bd_name_list *next;
} BD_NAME_LIST;

/* BD_GM: Group member */
typedef struct bd_gm_st {
  BD_NAME *member_name;
  X509 *cert;   /* X.509 certificate
                 * is not null, only if this is a leaf node
                 */
} BD_GM;

/* BD_NV: Node Values for this node */
typedef struct bd_nv {
  BD_GM *member; /* Member information */
  BIGNUM *z_i;   /* z_i */
  BIGNUM *x_i;   /* x_i */
} BD_NV;

/* member list data structures */
typedef struct member_list {
  struct member_list *prev;   /* Pointer to the previous member */
  struct member_list *next;   /* Pointer to the next member */
  BD_NV *bd_nv;               /* Node values */
} MEMBER_LIST;

/* BD_CONTEXT: BGKA context */
typedef struct bd_context_st {
  BD_NAME     *member_name;
  BD_NAME     *group_name;
  BIGNUM      *group_secret; 
  bd_uchar    *group_secret_hash; /* session_key */
  BIGNUM      *r_i;               /* session random of the member */
  int         num_users;
  MEMBER_LIST *list;              /* Pointer to the first member */
  DSA         *params;
  EVP_PKEY    *pkey;
  uint        epoch;
} BD_CONTEXT;

/* MESSAGE TYPE definitions */
enum BD_MSG_TYPE { BROADCAST_Z,
                   BROADCAST_X,
                   BD_INVALID};

typedef struct bd_token_st {
  uint     length;
  bd_uchar *t_data;
  /*   Consists of
   *   BD_NAME *group_name;
   *   BD_NAME *sender_name;
   *   enum MSG_TYPE msg_type;
   *   time_t timestamp;
   *   int epoch;
   *   NODE_INFO *node_info;
   *   BD_SIGN *sign;
   */
} BD_TOKEN;

typedef struct BD_token_info {
  BD_NAME *group_name;
  enum BD_MSG_TYPE message_type;
  time_t time_stamp;
  BD_NAME *sender_name;
  BIGNUM *key_info;
  uint epoch; 
} BD_TOKEN_INFO;

/* BD_KEY_TYPE definitions, used by bd_read_dsa */
enum BD_KEY_TYPE { BD_PARAMS,
                   BD_PRV,
                   BD_PUB};

/* bd_new_member is called by the new member in order to create its
 *   own context.
 */
int bd_new_member(BD_CONTEXT **ctx, BD_NAME *member_name,
                  BD_NAME *group_name);

/* bd_refresh_session refreshes (or generates, if session random is
   NULL) session random of each user */ 
int bd_refresh_session(BD_CONTEXT *ctx);

/* Main functionality of this function is to broadcast session random
 *   of a user... If flag == 0 (when cascading happens), it will not
 *   refresh the session random. If it is 1, it will refresh the
 *   session random.
 */
int bd_membership_req(BD_CONTEXT *ctx, BD_NAME *member_name,
                      BD_NAME *group_name, BD_NAME *member_list[], 
                      BD_TOKEN **output, int flag);

/* bd_compute_xi computes X_i for other members. I need z_{i+1} and
 *   z_{i-1} to compute my x_i
 */
int bd_compute_xi (BD_CONTEXT *ctx, BD_NAME *member_name, 
                   BD_NAME *group_name, BD_TOKEN *input,
                   BD_TOKEN **output); 

/* bd_compute_key computes key. I need z_{i-1} and all x_i's */
int bd_compute_key (BD_CONTEXT *ctx, BD_NAME *member_name, 
                    BD_NAME *group_name, BD_TOKEN *input); 

/* bd_create_ctx creates the tree context.
 * Preconditions: *ctx has to be NULL.
 */
int bd_create_ctx(BD_CONTEXT **ctx);

/* bd_read_DSA: Reads a DSA structure from disk depending on
 * BD_KEY_TYPE (BD_PARAMS, BD_PRIV, BD_PUB)
 * Returns the structure if succeed otherwise NULL is returned.
 */
DSA *bd_read_dsa(BD_NAME *member_name, enum BD_KEY_TYPE type);

/* bd_rand: Generates a new random number of "params->q" bits, using
 *   the default parameters.
 * Returns: A pointer to a dsa structure where the random value
 *          resides. 
 *          NULL if an error occurs.
 */
BIGNUM *bd_rand (DSA *params);

/* bd_compute_secret_hash: It computes the hash of the group_secret.
 * Preconditions: ctx->group_secret has to be valid.
 */
int bd_compute_secret_hash (BD_CONTEXT *ctx);

/* bd_destroy_ctx frees the space occupied by the current context.
 * Including the group_members_list.
 */
void bd_destroy_ctx (BD_CONTEXT **ctx);

/* Frees a MEMBER_LIST structure */
void bd_free_list(MEMBER_LIST **member_list);

/* Frees a BD_NV structure */
void bd_free_nv(BD_NV **nv);

/* Frees a BD_GM structure */
void bd_free_gm(BD_GM **gm);

/***********************/
/*TREE private functions*/
/***********************/
/* bd_encode using information from the current context, it generates
 * the output token.
 */
int bd_encode(BD_CONTEXT *ctx, BD_TOKEN **output,
              BD_TOKEN_INFO *info, int option);

/* bd_decode using information from the input token, it creates
 * ctx. info is also created here. It contains data recovered from
 * input such as message_type, sender, etc. (See structure for more
 * details) in readable format. 
 */
int bd_decode(BD_TOKEN *input, BD_TOKEN_INFO **info);

/* int_encode: It puts an integer number in stream. Note that the size
 * of the integer number is addded to the stream as well.
 */
/* NOTE: HTONL should be added here */
void bd_int_encode(bd_uchar *stream, uint *pos, uint data);


/* int_decode: It gets an integer number from input->t_data. Note that
 * the size of the integer number is decoded first, and then the
 * actual number is decoded.
 * Returns: 1 succeed.
 *          0 Fails.
 */
int bd_int_decode(const BD_TOKEN *input,uint *pos, uint *data);

/* string_encode: It puts the valid 'c' string into stream. It first
 * stores the message length (including \0) and the the actual
 * message.
 */
void bd_string_encode (bd_uchar *stream, uint *pos, char *data);

/* string_decode: It restores a valid 'c' string from
 * input->t_data. First the string length is decode (this one should
 * have \0 already), and the actual string.
 * Returns: 1 succeed.
 *          0 Fails.
 */
int bd_string_decode (const BD_TOKEN *input, uint *pos, char *data);

/* bn_encode: BIGNUM encoding. */
void bd_bn_encode (bd_uchar *stream, uint *pos, BIGNUM *num);

/* bn_decode: BIGNUM decoding.
 * Preconditions: num has to be different from NULL.
 * Returns: 1 succeed.
 *          0 Fails.
 */
int bd_bn_decode (const BD_TOKEN *input, uint *pos, BIGNUM *num);

/* bd_create_token_info: It creates the info token. */
int bd_create_token_info (BD_TOKEN_INFO **info, BD_NAME *group, 
                           enum BD_MSG_TYPE msg_type, time_t time,
                           BD_NAME *sender/*, uint epoch*/);

/* bd_destroy_token: It frees the memory of the token. */
void bd_destroy_token (BD_TOKEN **token);

/* bd_destroy_token_info: It frees the memory of the token. */
void bd_destroy_token_info (BD_TOKEN_INFO **info);
 
/* bd_search_list finds a member named member_name */
MEMBER_LIST *bd_search_list(MEMBER_LIST *list, BD_NAME *member_name);

/* bd_computable checks whether the member receives all x_i's and z_i
 * returns 1, if enough. Returns 0 otherwise
 */
int bd_computable(MEMBER_LIST *list, BD_NAME *my_name);

/* max: return maximum of a and b */
int max(int a, int b);
/* return log_2 a */
int bd_log2(int a);
/* swap pointer a and b */
void bd_swap(void **a, void **b);

/* bd_read_DSA stuff */
#define BD_COMMON_FILE "public_values.tree"
#define PUB_FMT "pub"
#define PRV_FMT "priv"
#ifdef USE_BD_READ_DSA
#define FILE_EXT "tree"
#else
#define FILE_EXT "pem"
#endif

/* bd_get_cert stuff */
#define DSA_PARAM_CERT "dsa_param.pem"
#define PUB_CERT "cert"
#define CA_CERT_FN "cacert.pem"

/* Macros not implemented in SSL */
#ifndef d2i_DSAPublicKey_bio
#define d2i_DSAPublicKey_bio(bp,x) (DSA *)ASN1_d2i_bio((char *(*)())DSA_new, \
                (char *(*)())d2i_DSAPublicKey,(bp),(unsigned char **)(x))
#endif
#ifndef i2d_DSAPublicKey_bio
#define i2d_DSAPublicKey_bio(bp,x) ASN1_i2d_bio(i2d_DSAPublicKey,(bp), \
                (unsigned char *)(x)) 
#endif

/* Private Macros */

#ifndef MAX
#define MAX(x,y)                        ((x)>(y)?(x):(y))
#endif
#ifndef MIN
#define MIN(x,y)                        ((x)<(y)?(x):(y))
#endif

#endif





