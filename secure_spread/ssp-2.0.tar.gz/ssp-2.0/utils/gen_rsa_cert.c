#include <stdio.h>
#include <stdlib.h>

#define NUMCERT 51
int main()
{
  FILE *fo;
  
  int i=0;
  char command[512];

  fo = fopen("yy", "w");	
  fprintf(fo, "y\n");
  fprintf(fo, "y\n");
  fclose(fo);

  for(i=0; i<NUMCERT; i++){
  fo = fopen("tmp", "w");

    fprintf(fo, "US\n");
    fprintf(fo, "Maryland\n");
    fprintf(fo, "Baltimore\n");
    fprintf(fo, "JHU\n");
    fprintf(fo, "CNDS\n");
    fprintf(fo, "%03d_fog2_new1024",i);
    fprintf(fo, "%03d@fog2\n",i);
    fprintf(fo, ".\n");
    fprintf(fo, ".\n");

    fclose(fo);


    sprintf(command, "openssl req -out %03dfog2_req.pem -days 365 -nodes -newkey rsa:1024 -keyout %03dfog2_priv.pem <tmp",i,i);

    printf("%s\n", command);
    system(command);
    
    sprintf(command, "openssl ca -out %03dfog2_cert.pem -policy policy_anything -infiles %03dfog2_req.pem < yy",i,i);
    
    printf("%s\n", command);
    system(command);

  }

  return 0;
}
