/* CLIQUES Non-Commercial License (covers BD, CLQ, STR and TGDH
libraries).  Copyright (c) 1998-2002 by the University of California,
Irvine.  All rights reserved.

Permission to use, copy, modify, and distribute this software and its
documentation in source and binary forms for lawful non-commercial
purposes and without fee is hereby granted, provided that the above
copyright notice appear in all copies and that both the copyright
notice and this permission notice appear in supporting documentation,
and that any documentation, advertising materials, and other materials
related to such distribution and use acknowledge that the software was
developed by the University of California, Irvine, Information and
Computer Science Department. The name of University of California,
Irvine may not be used to endorse or promote products derived from
this software without specific prior written permission.

THE UNIVERSITY OF CALIFORNIA, IRVINE MAKES NO REPRESENTATIONS ABOUT
THE SUITABILITY OF THIS SOFTWARE FOR ANY PURPOSE.  THIS SOFTWARE IS
PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND
NON-INFRINGEMENT.

IN NO EVENT SHALL UNIVERSITY OF CALIFORNIA, IRVINE OR ANY OTHER
CONTRIBUTOR BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
DAMAGES, WHETHER IN CONTRACT, TORT, OR OTHER FORM OF ACTION, ARISING
OUT OF OR IN CONNECTION WITH, THE USE OR PERFORMANCE OF THIS SOFTWARE.

All questions concerning this software should be directed to
cliques@ics.uci.edu. */



/*********************************************************************
 * str_api.c                                                        * 
 * Broadcast based Group Key Ageement Scheme                         * 
 * Date      Tue Nov 21 22:08:07 PST 2000                            *
 * Wrote by:                                                         * 
 * Yongdae Kim                                                       *
 *                                                                   *
 * CLIQUES Project                                                   *
 * Information Sciences Institute                                    *
 * University of Southern California                                 *
 *********************************************************************/

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <strings.h>
#include <malloc.h>
#include <math.h>

#include <netinet/in.h> /* Needed by htonl and ntohl */

/* SSL include files */
#include "openssl/bn.h"
#include "openssl/bio.h"
#include "openssl/md5.h"
#include "openssl/err.h"
#include "openssl/dsa.h"

/* STR_API include files */
#include "str_api.h"
#include "str_error.h"
#include "str_cert.h" /* str_get_cert is here */

#include "str_sig.h"
#include "str_test_misc.h" 

#include "str_api_misc.h" /* str_get_time is defined here */

#ifdef TIMING
#include "str_test.h"
#endif

/* str_new_member is called by the new member in order to create its
 *   own context. Main functionality of this function is to generate
 *   session random for the member
 */
int str_new_member(STR_CONTEXT **ctx, STR_NAME *member_name,
                    STR_NAME *group_name)
{
  int ret=OK;

  if (member_name == NULL) return INVALID_MEMBER_NAME;
  if ((strlen(member_name) == 0) ||
      (strlen(member_name) > MAX_LGT_NAME)) return INVALID_LGT_NAME;
  if (group_name == NULL) return INVALID_GROUP_NAME;
  if ((strlen(group_name) == 0) ||
      (strlen(group_name) > MAX_LGT_NAME)) return INVALID_LGT_NAME;
  
  if ((ret=str_create_ctx(ctx)) != OK) {goto error;}
  
  (*ctx)->member_name=(STR_NAME *) calloc(sizeof(STR_NAME)*MAX_LGT_NAME,1);
  if (((*ctx)->member_name) == NULL) { ret=MALLOC_ERROR; goto error; }
  strncpy((*ctx)->member_name,member_name,MAX_LGT_NAME);
  (*ctx)->group_name=(STR_NAME *) calloc(sizeof(STR_NAME)*MAX_LGT_NAME,1);
  if (((*ctx)->group_name) == NULL) { ret=MALLOC_ERROR; goto error; }
  strncpy((*ctx)->group_name,group_name,MAX_LGT_NAME);
  /* Get DSA parameters */
  (*ctx)->params=str_read_dsa(NULL,STR_PARAMS);
  if ((*ctx)->params == (DSA *)NULL) { ret=INVALID_DSA_PARAMS; goto error; }
  /* Get user private and public keys */
  (*ctx)->pkey=str_get_pkey(member_name);
  if (((*ctx)->pkey) == (EVP_PKEY*) NULL){
    ret=INVALID_PRIV_KEY;
    goto error;
  }
  
  (*ctx)->root->str_nv=(STR_NV *) calloc(sizeof(STR_NV),1);
  (*ctx)->root->str_nv->member = (STR_GM *) calloc(sizeof(STR_GM),1);
  (*ctx)->root->str_nv->member->member_name=(STR_NAME *)
    calloc(sizeof(STR_NAME)*MAX_LGT_NAME,1); 
  strncpy ((*ctx)->root->str_nv->member->member_name,
           (*ctx)->member_name,MAX_LGT_NAME);
  (*ctx)->root->str_nv->member->cert = NULL;
  
  (*ctx)->root->str_nv->index=1;
  (*ctx)->root->str_nv->num_user=1;
  
  /* I'm only member in my group... So key is same as my session random */
  (*ctx)->root->str_nv->key=str_rand((*ctx)->params);
  
  if (BN_is_zero((*ctx)->root->str_nv->key) ||
      (*ctx)->root->str_nv->key==NULL){
    ret=MALLOC_ERROR;
    goto error;
  }
  /* group_secret is same as key */
  if((*ctx)->group_secret == NULL){
    (*ctx)->group_secret=BN_dup((*ctx)->root->str_nv->key);
    if ((*ctx)->group_secret == (BIGNUM *) NULL) {
      ret=MALLOC_ERROR;
      goto error;
    }
  }
  else{
    BN_copy((*ctx)->group_secret,(*ctx)->root->str_nv->key);
  }
  
  ret=str_compute_secret_hash ((*ctx));
  if (ret!=OK) goto error;
  (*ctx)->root->str_nv->member->cert=NULL;
  
  /* Compute blinded Key */
  (*ctx)->root->str_nv->bkey=
    str_compute_bkey((*ctx)->root->str_nv->key, (*ctx)->params);
  if((*ctx)->root->str_nv->bkey== NULL){
    ret=MALLOC_ERROR;
    goto error;
  }
  (*ctx)->tmp_key = (*ctx)->tmp_bkey = NULL;
  (*ctx)->status = OK;
  
error:
  /* OK... Let's free the memory */
  if (ret!=OK) str_destroy_ctx(&(*ctx),1);
  
  return ret;
}

/* str_merge_req is called by sponsors in both groups 
 *   ctx: context of the caller
 *   member_name: name of the caller
 *   group_name: target group name
 *   output: output token(input token of str_merge)
 */
int str_merge_req (STR_CONTEXT *ctx, STR_NAME *member_name, 
                    STR_NAME *group_name, STR_TOKEN **output)
{
  int ret=OK;
  STR_TOKEN_INFO *info=NULL;
  STR_KEY_TREE *tmp_tree=NULL;
  
  if (ctx == NULL) return CTX_ERROR;
  if (member_name == NULL) return INVALID_MEMBER_NAME;
  if ((strlen(member_name) == 0) ||
      (strlen(member_name) > MAX_LGT_NAME)) return INVALID_LGT_NAME;
  if (group_name == NULL) return INVALID_GROUP_NAME;
  if ((strlen(group_name) == 0) ||
      (strlen(group_name) > MAX_LGT_NAME)) return INVALID_LGT_NAME;

  /* Sponsor is the rightmost member */
  tmp_tree = str_search_member(ctx->root, 3, NULL);
  if(strcmp(ctx->member_name, tmp_tree->str_nv->member->member_name)){
    ret = OK;
    goto error;
  }
  
  /* Creating token info */
  ret=str_create_token_info(&info,ctx->group_name,STR_KEY_MERGE_UPDATE, 
                             time(0),ctx->member_name); 
  if (ret!=OK) goto error;
  
  /* Encoding */
  ret=str_encode(ctx,output,info);
  if (ret!=OK) goto error;
  
  /* sign_message */
  ret=str_sign_message (ctx, *output);
  
error:
  /* OK... Let's free the memory */
  if (ret!=OK) str_destroy_ctx(&ctx, 1);
  if (info != (STR_TOKEN_INFO*)NULL) str_destroy_token_info(&info);
  
  return ret;
}

/* str_cascade is called by every member several times until every
 * member can compute the new group key when any network events occur.
 * o this function handles every membership event, e.g. join, leave,
 *   merge, and partition.
 * o this function handles any cascaded events.
 * o this funciton is str-stabilizing.
 * o sponsors are decided uniquely for every membership event, and
 *   only the sponsors return an output
 *   - ctx: context of the caller
 *   - member_name: name of the caller
 *   - users_leaving: list of the leaving members, used only for
 *       subtractive events
 *   - input: Input token(previous output token of
 *       str_cascade or join or merge request) 
 *   - output: output token(will be used as next input token of
 *       str_cascade) 
 */
int str_cascade(STR_CONTEXT **ctx, STR_NAME *group_name,
                 STR_NAME *users_leaving[],
                 STR_TOKEN *input, STR_TOKEN **output){
  STR_TOKEN_INFO *info=NULL;
  STR_SIGN *sign=NULL;
  STR_CONTEXT *new_ctx=NULL;
  int ret=CONTINUE;
  STR_KEY_TREE *leave_node=NULL, *first=NULL;
  STR_KEY_TREE *tmp_node=NULL, *tmp1_node=NULL, *tmp2_node=NULL;
  STR_KEY_TREE *joiner=NULL, *joinee=NULL;
  
  int i=0;
  int tmp_num=0;
  int result=OK;
  int leaveormerge=0;
  BN_CTX *bn_ctx=BN_CTX_new();
  STR_NAME *sponsor_list[NUM_USERS+1]={NULL};
  int list_counter = 0;
  int new_status=0;
  int max_index=0;
  STR_KEY_TREE *the_sponsor=NULL;
  int new_information=0;
  int no_free=0;
  int need_swap=0;
  int new_key_comp=0;
  char *the_sponsor_name=NULL;
  
  for(i=0; i<NUM_USERS+1; i++){
    sponsor_list[i]=NULL;
  }
  
  /* Doing some error checkings */
  if ((*ctx) == NULL) return CTX_ERROR;
  if (group_name == NULL) return INVALID_GROUP_NAME;
  if ((strlen(group_name) == 0) ||
      (strlen(group_name) > MAX_LGT_NAME)) return INVALID_LGT_NAME;

  i=0;
  if(users_leaving != NULL){
    /* If I have cache and if I receive another membership, remove
       cache */
    if((*ctx)->cache != NULL){
      str_free_tree(&((*ctx)->cache));
    }
    while(users_leaving[i] != NULL){
      leaveormerge=1;
      if(str_remove_sponsor(sponsor_list, users_leaving[i])>0){
        list_counter--;
      }
      /* this is the first call or cascaded leave happens*/
      if(input != NULL) {
        result = INVALID_INPUT_TOKEN;
        printf("This is weird 1\n\n");
        
        goto error;
      }
      /* If my name is in the users_leaving list, then I just exit
       * partition with OK... I will call again to partition out other
       * members
       */
      if(strcmp(users_leaving[i], (*ctx)->member_name)==0){
        goto error;
      }
      (*ctx)->status = CONTINUE;
  
      /* Delete every bkey and key which is related with the leaving
       * members;
       */ 
      tmp1_node=leave_node=str_search_member((*ctx)->root, 4,
                                              users_leaving[i]);
      if(tmp1_node == NULL) {
        result=MEMBER_NOT_IN_GROUP;
        goto error;
      }
      while(tmp1_node != NULL){
        if(tmp1_node->str_nv->bkey != NULL){
          BN_clear_free(tmp1_node->str_nv->bkey);
          tmp1_node->str_nv->bkey = NULL;
        }
        if(tmp1_node->str_nv->key != NULL){
          BN_clear_free(tmp1_node->str_nv->key);
          tmp1_node->str_nv->key = NULL;
        }
        tmp1_node = tmp1_node->parent;
      }
      
      /* Delete the leaving members from the current tree;
       * Pointer handling
       */
      if(leave_node->parent->parent == NULL){ /* If my index is 2 or 3 */
        if(leave_node->str_nv->index % 2 == 0){ /* If my index is 2 */
          if(leave_node->parent != (*ctx)->root){
            result=STR_STRUCTURE_ERROR;
            goto error;
          }
          str_copy_node(leave_node->parent, leave_node->parent->right);
          tmp_node=(*ctx)->root = leave_node->parent->right;
          leave_node->parent->right->parent = NULL;
        }
        else{ /* If my index is 3 */
          if(leave_node->parent != (*ctx)->root){
            result=STR_STRUCTURE_ERROR;
            goto error;
          }
          str_copy_node(leave_node->parent, leave_node->parent->left);
          tmp_node=(*ctx)->root = leave_node->parent->left;
          leave_node->parent->left->parent = NULL;
        }
      }
      else{
        if(leave_node->str_nv->index % 2 == 0){ /* left most leaf node */
          str_copy_node(leave_node->parent, leave_node->parent->right);
          leave_node->parent->parent->left = leave_node->parent->right;
          leave_node->parent->right->parent = leave_node->parent->parent;
          tmp_node = leave_node->parent->right;
        }
        else{
          str_copy_node(leave_node->parent, leave_node->parent->left);
          leave_node->parent->parent->left = leave_node->parent->left;
          leave_node->parent->left->parent = leave_node->parent->parent;
          tmp_node = leave_node->parent->left;
        }
      }
      if(users_leaving[0] != NULL){
        the_sponsor = str_search_member(tmp_node, 3, NULL);
        sponsor_list[list_counter] = the_sponsor->str_nv->member->member_name;
        list_counter++;
      }
      if(tmp_node->left){
        str_update_index(tmp_node->right, 1, tmp_node->str_nv->index);
        str_update_index(tmp_node->left,  0, tmp_node->str_nv->index);
      }
      
      if(leave_node->prev != NULL) 
        leave_node->prev->next = leave_node->next;
      if(leave_node->next != NULL) 
        leave_node->next->prev = leave_node->prev;
      str_free_node(&leave_node->parent);
      str_free_node(&leave_node);

      (*ctx)->root->str_nv->num_user--;
      first = str_search_member((*ctx)->root, 2, NULL);
      if(first == NULL) {
        result=STR_STRUCTURE_ERROR;
        goto error;
      }
      first = str_search_member((*ctx)->root, 2, NULL);
      if(first == NULL) {
        result=STR_STRUCTURE_ERROR;
        goto error;}
      i++;
    }
    
  }

  if(input != NULL){ /* This is not the first call */
    /*****************/
    /*               */
    /* JOIN or MERGE */
    /*               */
    /*****************/
    if(new_ctx != NULL) str_destroy_ctx(&new_ctx,1);
    if(info != NULL) str_destroy_token_info(&info);
    
    result=str_remove_sign(input,&sign);
    if (result != OK) goto error;
        
    /* Decoding the token & creating new_ctx */
    result=str_decode(&new_ctx, input, &info);
    if (result!=OK){
      goto error;
    }

    new_status = new_ctx->status;
    (*ctx)->epoch = MAX((*ctx)->epoch, new_ctx->epoch);
    if (strcmp(info->group_name,group_name)){
      result=GROUP_NAME_MISMATCH;
      goto error;
    }

    switch (info->message_type) { /* There is no leave or join event */
      /********************/
      /*                  */
      /* MEMBERSHIP EVENT */
      /*                  */
      /********************/
      case STR_PROCESS_EVENT:
      {
        if(strcmp(info->sender_name, (*ctx)->member_name)){
          /* Verify signature; */
          result=str_vrfy_sign ((*ctx), new_ctx, input,
                                 info->sender_name, sign);  
          if(result!=OK) goto error;
        }
          
        /* If I receive my token and if I have cache, I'll install my */
        /* cache information to the original tree */
        if((strcmp(info->sender_name, (*ctx)->member_name)==0) &&
           ((*ctx)->cache!= NULL)){
          str_swap((void *)&((*ctx)->cache), (void *)&((*ctx)->root));
          str_free_tree(&((*ctx)->cache));
          if((*ctx)->tmp_key != NULL){
            BN_clear_free((*ctx)->tmp_key);
            (*ctx)->tmp_key = NULL;
          }
          if((*ctx)->tmp_bkey != NULL){
            BN_clear_free((*ctx)->tmp_bkey);
            (*ctx)->tmp_bkey = NULL;
          }
        }
        
        /* This includes second call of partition, update_ctx of */
        /* join and merge operation                              */
        if(new_status == KEY_COMPUTED){ 
          (*ctx)->status = OK; 
          ret = OK; 
#ifdef DEBUG_YD
          if(new_ctx->root->str_nv->bkey == NULL){
            fprintf(stderr, "Sender Name: %s Strange...", info->sender_name);
          }
#endif
          if(strcmp(info->sender_name, (*ctx)->member_name) == 0){
            (*ctx)->status = OK;
            goto error;
          }
        } 

        /* Pointer handling is done above                        */
        if(str_check_useful(new_ctx->root, (*ctx)->root)==1){
          /* Copy new information(if any) to my context;           */
          /* Tree should be same to process the following function */
          str_swap_bkey(new_ctx->root, (*ctx)->root);
        }
        break;
      }
    
      /*****************/
      /*               */
      /* JOIN or MERGE */
      /*               */
      /*****************/
      case STR_KEY_MERGE_UPDATE:
      {
        /* Before merging the tree, we need to verify signature */
        result=str_vrfy_sign ((*ctx), new_ctx, input,
                              info->sender_name, sign);  
        if(result!=OK) goto error;

        (*ctx)->merge_token = ((*ctx)->merge_token + 1) % 2;
        
        if((*ctx)->merge_token == 1){
          (*ctx)->status = CONTINUE;
        }
        leaveormerge = 1;

        if((*ctx)->status != KEY_COMPUTED){
          (*ctx)->status = CONTINUE;
        }
        else{
          if(((*ctx)->root->str_nv->key == NULL) ||
             ((*ctx)->root->str_nv->bkey == NULL)){ 
            (*ctx)->status = CONTINUE;
          }
        }
        if(((*ctx)->merge_token == 1) && ((*ctx)->cache != NULL)){
          str_free_tree(&((*ctx)->cache));
        }


        tmp1_node = str_search_member(new_ctx->root, 4,
                                       (*ctx)->member_name);
        /* If I could find me in the input token, then the input
           token is useless */ 
        if(tmp1_node != NULL){
          ret = (*ctx)->status;
          no_free=1;
          goto error;
        }
        else{
          if((*ctx)->root->str_nv->num_user ==
             new_ctx->root->str_nv->num_user){
            tmp1_node = str_search_member((*ctx)->root, 3, NULL);
            tmp_node = str_search_member(new_ctx->root, 3, NULL);
            if(cmp_str(tmp1_node->str_nv->member->member_name,
                       tmp_node->str_nv->member->member_name)>0){  
              joiner = new_ctx->root;
              joinee = (*ctx)->root;
            }
            else if(cmp_str(tmp1_node->str_nv->member->member_name,
                            tmp_node->str_nv->member->member_name)<0){  
              joiner = (*ctx)->root;
              joinee = new_ctx->root;
            }
            else{
              fprintf(stderr,"strange... two of them are same???\n");
              ret = INVALID_MEMBER_NAME;
              goto error;
            }
          }
          else if((*ctx)->root->str_nv->num_user >
                  new_ctx->root->str_nv->num_user){ 
            joiner = new_ctx->root;
            joinee = (*ctx)->root;
          }
          else{
            joiner = (*ctx)->root;
            joinee = new_ctx->root;
          }
          
          tmp_num=joiner->str_nv->num_user+joinee->str_nv->num_user;
          
          tmp_node = str_merge_tree(joiner, joinee);
          if(joinee->right){
            sponsor_list[list_counter] =
              joinee->right->str_nv->member->member_name;  
          }
          else{
            sponsor_list[list_counter] =
              joinee->str_nv->member->member_name; 
          }
          list_counter++;
          if(tmp_node == NULL) {
            result=STR_MERGE_FAILURE;
            goto error;
          }
          if(tmp_node->parent != NULL){
            result=STR_MERGE_FAILURE;
            goto error;
          }
          
          tmp1_node = joinee->parent;
          while(tmp1_node != NULL){
            if(tmp1_node->str_nv->key != NULL){
              BN_clear_free(tmp1_node->str_nv->key);
              tmp1_node->str_nv->key = NULL;
            }
            if(tmp1_node->str_nv->bkey != NULL){
              BN_clear_free(tmp1_node->str_nv->bkey);
              tmp1_node->str_nv->bkey = NULL;
            }
            tmp1_node = tmp1_node->parent;
          }
          
          (*ctx)->root = tmp_node;
          
          (*ctx)->root->str_nv->num_user = tmp_num;
          if(joinee != (*ctx)->root){
            joinee->str_nv->num_user=0;
          }
          if(joiner->right != (*ctx)->root){
            joiner->right->str_nv->num_user=0;
          }
          
          /* This is very critical line for memory leakage... If you want to
           * delete this line, consider carefully
           */
          str_destroy_ctx(&new_ctx, 0);
        }
        break;
      }
      /* No more cases */
      default:
      {
        result=INVALID_MESSAGE_TYPE;
        goto error;
      }
    }
  }
        
  the_sponsor = NULL;
  
  if(sponsor_list[0] != NULL){
    for(i=0; i<list_counter; i++){
      tmp1_node = str_search_member((*ctx)->root, 4, sponsor_list[i]);
      if(tmp1_node != NULL){
        if(tmp1_node->str_nv->index > max_index){
          the_sponsor = tmp1_node;
          max_index = tmp1_node->str_nv->index;
        }
      }
    }
    the_sponsor_name = the_sponsor->str_nv->member->member_name;
    
    if(the_sponsor->str_nv->bkey != NULL){
      BN_clear_free(the_sponsor->str_nv->bkey);
      the_sponsor->str_nv->bkey = NULL;
    }
    if(the_sponsor->str_nv->key != NULL){
      BN_clear_free(the_sponsor->str_nv->key);
      the_sponsor->str_nv->key = NULL;
    }
    
    tmp_node = the_sponsor->parent;
    while(tmp_node != NULL){
      if(tmp_node->str_nv->bkey != NULL){
        BN_clear_free(tmp_node->str_nv->bkey);
        tmp_node->str_nv->bkey = NULL;
      }
      if(tmp_node->str_nv->key != NULL){
        BN_clear_free(tmp_node->str_nv->key);
        tmp_node->str_nv->key = NULL;
      }
      tmp_node = tmp_node->parent;
    }
  }

  /* If I don't have cache, then I generated a cache... If I 
     don't broadcast token, I'll remove cache... */
  if((*ctx)->cache == NULL){
    (*ctx)->cache = str_dup_tree((*ctx)->root);
  }
  /*  If I have cache, I'll add new information to the cache also... */
  else{
    str_copy_bkey((*ctx)->root, (*ctx)->cache);
  }
  /* Now every computation will be processed on the cache... */
  str_swap((void *)&((*ctx)->cache), (void *)&((*ctx)->root));
  need_swap = 1;

  the_sponsor = str_search_member((*ctx)->root, 4, the_sponsor_name);
  if(the_sponsor != NULL){
    if(strcmp(the_sponsor->str_nv->member->member_name,
              (*ctx)->member_name)== 0){
      new_information = 1;
      new_key_comp = 1;
      the_sponsor->str_nv->key=str_rand((*ctx)->params);
      the_sponsor->str_nv->bkey=
        str_compute_bkey(the_sponsor->str_nv->key, (*ctx)->params);
      if((*ctx)->tmp_key != NULL){
        BN_clear_free((*ctx)->tmp_key);
      }
      (*ctx)->tmp_key = BN_dup(the_sponsor->str_nv->key);
      if((*ctx)->tmp_bkey != NULL){
        BN_clear_free((*ctx)->tmp_bkey);
      }
      (*ctx)->tmp_bkey = BN_dup(the_sponsor->str_nv->bkey);
    }
  }
  
  tmp1_node = str_search_member((*ctx)->root, 4, (*ctx)->member_name);
  if(tmp1_node == NULL){
    result = STR_STRUCTURE_ERROR;
    goto error;
  }

  if((tmp1_node->str_nv->key == NULL) && (leaveormerge== 1)){
    if(((*ctx)->tmp_key != NULL) && ((*ctx)->tmp_bkey != NULL)){
      new_information = 1;
      new_key_comp = 1;
      tmp1_node->str_nv->key = BN_dup((*ctx)->tmp_key);
      if(tmp1_node->str_nv->bkey == NULL){
        tmp1_node->str_nv->bkey = BN_dup((*ctx)->tmp_bkey);
      }
    }
  }

  
  tmp1_node = str_search_member((*ctx)->root, 4, (*ctx)->member_name);
  if(tmp1_node == NULL){
    result = STR_STRUCTURE_ERROR;
    goto error;
  }
  if(tmp1_node != (*ctx)->root){
    while(tmp1_node->parent != NULL){
      if(tmp1_node->parent->str_nv->key == NULL){
        break;
      }
      tmp1_node = tmp1_node->parent;
    }
  }
  if((new_information == 1) || (new_status == KEY_COMPUTED)){
    if(tmp1_node != (*ctx)->root){
      if(tmp1_node->parent->str_nv->key != NULL){
        result = STR_STRUCTURE_ERROR;
        goto error;
      }
      if(tmp1_node->str_nv->index % 2){
        tmp_node = tmp1_node->parent->left;
      }
      else{
        tmp_node = tmp1_node->parent->right;
      }
      while(tmp_node->str_nv->bkey != NULL){
        /* Compute intermediate keys until I can */
        if(tmp1_node->parent->str_nv->key != NULL){
          result=STR_STRUCTURE_ERROR;
          goto error;
        }
        tmp1_node->parent->str_nv->key = BN_new();
        if(tmp1_node->parent->left->str_nv->key != NULL){
          if(tmp1_node->parent->right->str_nv->bkey != NULL){
            new_key_comp = 1;
            result = BN_mod(tmp1_node->parent->left->str_nv->key,
                            tmp1_node->parent->left->str_nv->key,   
                            (*ctx)->params->q, bn_ctx);
            if(result != OK) goto error;
            result=BN_mod_exp(tmp1_node->parent->str_nv->key,
                              tmp1_node->parent->right->str_nv->bkey,
                              tmp1_node->parent->left->str_nv->key,
                              (*ctx)->params->p,bn_ctx);
          }
          else{
          }
        }
        else{
          if(tmp1_node->parent->left->str_nv->bkey != NULL){
            new_key_comp = 1;
            result = BN_mod(tmp1_node->parent->right->str_nv->key,
                            tmp1_node->parent->right->str_nv->key,   
                            (*ctx)->params->q, bn_ctx);
            if(result != OK) goto error;
            result=BN_mod_exp(tmp1_node->parent->str_nv->key,
                              tmp1_node->parent->left->str_nv->bkey,
                              tmp1_node->parent->right->str_nv->key,
                              (*ctx)->params->p,bn_ctx);
          }
        }
        if(result != OK) goto error;
        
        /* Compute bkeys */
        if(tmp1_node->parent->str_nv->bkey != NULL){
          BN_clear_free(tmp1_node->parent->str_nv->bkey);
          tmp1_node->parent->str_nv->bkey=NULL;
        }
        tmp1_node->parent->str_nv->bkey
          =str_compute_bkey(tmp1_node->parent->str_nv->key, (*ctx)->params);
        
        if(tmp1_node->parent->parent == NULL) {
          break;
        }
      else{
        tmp1_node = tmp1_node->parent;
      }
        if(tmp1_node->str_nv->index % 2){
          tmp_node = tmp1_node->parent->left;
        }
        else{
          tmp_node = tmp1_node->parent->right;
        }
      }
      if(the_sponsor != NULL){
        tmp2_node = str_search_member((*ctx)->root, 2, NULL);
        while(tmp2_node->next != NULL){
          if(tmp2_node->str_nv->bkey == NULL){
            break;
          }
          tmp2_node = tmp2_node->next;
        }
      }
    }
  }
  
  if((the_sponsor != NULL)){ 
    if(strcmp((*ctx)->member_name,
              the_sponsor->str_nv->member->member_name)==0){
      new_information = 1;
    }
  }
  
  if((*ctx)->root->str_nv->key != NULL){
    if((*ctx)->status == CONTINUE){
      ret = KEY_COMPUTED;
      (*ctx)->status = KEY_COMPUTED;
    }
    if((*ctx)->root->str_nv->member != NULL){
      if(strcmp((*ctx)->root->str_nv->member->member_name,
                (*ctx)->member_name)==0){
        ret = OK;
        (*ctx)->status = OK;
      }
    }
  }

  if((new_information == 1) && (new_key_comp == 1) && ((*ctx)->status != OK)){
    /* If I have any new information, encode my information to output; */
    if (info != NULL) str_destroy_token_info(&info);
    /* Creating token info */
    result=str_create_token_info(&info, (*ctx)->group_name,
                                 STR_PROCESS_EVENT, time(0),
                                 (*ctx)->member_name);  
    if (result!=OK) goto error;
    result=str_encode((*ctx),output,info);
    if (result!=OK) goto error;
    
    /* Sign output token; */
    result=str_sign_message ((*ctx), *output);
  }
  
error:
  if((new_information == 1) && (new_key_comp == 1) && ((*ctx)->status != OK)){
    /* Since I have useful information, I'll save the useful
       information until I receive my token */
    if(need_swap == 1){
      str_swap((void *)&((*ctx)->cache), (void *)&((*ctx)->root));
    }
  }
  else{
    /* I don't have any useful information */
    if((need_swap == 1) && ((*ctx)->status != OK)){
      str_swap((void *)&((*ctx)->cache), (void *)&((*ctx)->root));
    }
  }
  if(ret == OK){
    if((*ctx)->root->str_nv->key == NULL){
      fprintf(stderr, "Key is NULL, but return is OK\n\n");
    }
    
    BN_copy((*ctx)->group_secret,(*ctx)->root->str_nv->key);
    result=str_compute_secret_hash ((*ctx));
    (*ctx)->epoch++; /* Used inside str_encode */
    if((*ctx)->cache != NULL){
      str_free_tree(&((*ctx)->cache));
    }
  }
        
  if(input != NULL){
    result=str_restore_sign(input,&sign);
  }

  if (result <= 0){
    ret = result;
    if (ctx != NULL) str_destroy_ctx(ctx,1);
  }
  if(input != NULL){
    if (new_ctx != NULL) {
      str_destroy_ctx(&new_ctx,1);
    }
  }
  if (info != NULL) str_destroy_token_info(&info);
  if (bn_ctx != NULL) BN_CTX_free (bn_ctx);

  return ret;
}

/* str_create_ctx creates the str context.
 * Preconditions: *ctx has to be NULL.
 */
int str_create_ctx(STR_CONTEXT **ctx) 
{
  int ret=CTX_ERROR;

  if (*ctx != (STR_CONTEXT *)NULL) return CTX_ERROR;
  /* Creating ctx */
  (*ctx) = (STR_CONTEXT *) calloc(sizeof(STR_CONTEXT), 1);
  if ((*ctx) == NULL) goto error;
  (*ctx)->member_name=NULL;
  (*ctx)->group_name=NULL;
  (*ctx)->root=(STR_KEY_TREE *) calloc(sizeof(STR_KEY_TREE),1);
  if ((*ctx)->root == (STR_KEY_TREE *) NULL) goto error;
  (*ctx)->group_secret_hash=(str_uchar*) calloc (MD5_DIGEST_LENGTH,1);
  if ((*ctx)->group_secret_hash==NULL){
    goto error;
  }
  
  (*ctx)->root->parent=(*ctx)->root->left=(*ctx)->root->right=NULL;
  (*ctx)->root->prev=(*ctx)->root->next=(*ctx)->root->bfs=NULL;
  (*ctx)->params=NULL; 
  (*ctx)->pkey=NULL;
  (*ctx)->epoch=0;
  
  ret=OK;
error:
  if (ret!=OK) str_destroy_ctx (ctx,1);
  
  return ret;
}

/* str_read_dsa: Reads a DSA structure from disk depending on
 * STR_KEY_TYPE (STR_PARAMS, STR_PRV, STR_PUB)
 *
 * Parameters:
 *  member_name
 *   User name requesting key. 
 *   If type is STR_PARAMS then this parameter is not used. 
 *  type
 *   Type of key required.
 *
 * Return: A pointer to a DSA structure with the requested key if
 * succeed, otherwise NULL is returned. 
 *
 * Note: This function can be replaced for one provided by the
 * program using the API. Hence, the keys can be obtained form
 * another media if necessary. The only only condition required is
 * that the function returns a pointer to a DSA structure.
 *
 */
#ifndef USE_STR_READ_DSA
DSA *str_read_dsa(STR_NAME *member_name, 
                   enum STR_KEY_TYPE type) 
{ 
  return (DSA*)str_get_dsa_key (member_name,type);
}
#else
DSA *str_read_dsa(STR_NAME *member_name, 
                   enum STR_KEY_TYPE type) 
{ 
  BIO *in=NULL;
  int ok=0;  
  char infile[50];
  DSA *dsa=NULL;
  
  switch (type) {
    case STR_PRV:
      sprintf (infile, "%s_%s.%s",PRV_FMT, member_name,
               FILE_EXT);  
      break;
    case STR_PUB:
      sprintf (infile, "%s_%s.%s",PUB_FMT, member_name,
               FILE_EXT);  
      break;
    case STR_PARAMS:
      sprintf (infile, COMMON_FILE);
      break;
  }
  
  if(strlen(infile)==0) goto error;
  
  in=BIO_new(BIO_s_file());
  if (in == NULL) { 
    /* ERR_print_errors(bio_err); */
    goto error;
  }
  
  if (BIO_read_filename(in,infile) <= 0) { 
    perror(infile); 
    goto error;
  }
#ifdef DEBUG
  fprintf(ERR_STRM,"Reading file %s.\n", infile);
  fprintf(ERR_STRM,"\tReading DSA ");
#endif
  
  if (type == STR_PARAMS) {
#ifdef DEBUG
    fprintf(ERR_STRM,"parameters\n");
#endif
    d2i_DSAparams_bio(in,&dsa);
  }
  else if(type == STR_PUB) {
#ifdef DEBUG
    fprintf(ERR_STRM,"public key\n");
#endif
    d2i_DSAPublicKey_bio(in,&dsa);
  }
  else if(type == STR_PRV) {
#ifdef DEBUG
    fprintf(ERR_STRM,"private key\n");
#endif
    d2i_DSAPrivateKey_bio(in,&dsa);
  }
  
  if (dsa == NULL) {
#ifdef DEBUG
    fprintf(ERR_STRM,"ERROR: Unable to load DSA structure.\n");
#endif
    /* ERR_print_errors(bio_err); */
    goto error;
  }
  
  ok =1;
  
error:
  
  if (in != NULL) BIO_free(in);
  
  return dsa;
} /* str_read_dsa */
#endif

/* str_compute_bkey: Computes and returns bkey */
BIGNUM *str_compute_bkey (BIGNUM *key, DSA *params)
{
  int ret=OK;
  BIGNUM *new_bkey = BN_new();
  BN_CTX *bn_ctx=BN_CTX_new();
  
  if (bn_ctx == (BN_CTX *) NULL) {ret=MALLOC_ERROR; goto error;}
  if (new_bkey == NULL) {ret=MALLOC_ERROR; goto error;}
  if (key == NULL) {ret=STR_STRUCTURE_ERROR; goto error;}
  
  ret=BN_mod(key,key,params->q, bn_ctx);
  ret=BN_mod_exp(new_bkey,params->g,key,params->p,bn_ctx);
  
error:
  if (bn_ctx != NULL) BN_CTX_free (bn_ctx);
  if (ret!=OK) 
    if (new_bkey != NULL) {
      BN_clear_free(new_bkey);
      new_bkey=NULL;
    }
  
  return new_bkey;
}

/* str_rand: Generates a new random number of "params->q" bits, using
 *   the default parameters.
 * Returns: A pointer to a dsa structure where the random value
 *          resides. 
 *          NULL if an error occurs.
 */
BIGNUM *str_rand (DSA *params) 
{
  /* DSA *Random=NULL; */
  int ret=OK;
  BIGNUM *random=NULL;
  int i=0;
  
  random=BN_new();
  if (random == NULL) { ret=MALLOC_ERROR; goto error;}
  
  /* The following idea was obtained from dsa_key.c (openssl) */
  i=BN_num_bits(params->q);
  for (;;) {
    ret = BN_rand(random,i,1,0);
    if (BN_cmp(random,params->q) >= 0)
      BN_sub(random,random,params->q);
    if (!BN_is_zero(random)) break;
  }
  
error:
  
  if (ret!=OK) 
    if (random != NULL) {
      BN_clear_free(random);
      random=NULL;
    }

  return random;
}

/* str_compute_secret_hash: It computes the hash of the group_secret.
 * Preconditions: ctx->group_secret has to be valid.
 */
int str_compute_secret_hash (STR_CONTEXT *ctx) 
{
  char *tmp_str=NULL;
  
  tmp_str=BN_bn2hex(ctx->group_secret);
  if (tmp_str==NULL) return CTX_ERROR;
  
  MD5((str_uchar *)tmp_str, (unsigned long)strlen(tmp_str), 
      ctx->group_secret_hash);
  
  free(tmp_str);
  
  if (ctx->group_secret_hash == (str_uchar *) NULL) return CTX_ERROR; 
  
  return OK;
}

/* str_destroy_ctx frees the space occupied by the current context.
 * Including the group_members_list.
 *   if flag == 1, delete all context
 *   if flag == 0, delete all except the tree(used for merge)
 */

void str_destroy_ctx (STR_CONTEXT **ctx, int flag) 
{
  
  if ((*ctx) == NULL) return;
  if (((*ctx)->member_name) != NULL) { 
    free((*ctx)->member_name);
    (*ctx)->member_name=NULL;
  }
  if (((*ctx)->group_name) != NULL) { 
    free((*ctx)->group_name);
    (*ctx)->group_name=NULL;
  }
  if (((*ctx)->group_secret) != NULL) {
    BN_clear_free((*ctx)->group_secret);
    (*ctx)->group_secret=NULL;
  }
  if (((*ctx)->group_secret_hash) != NULL) {
    free((*ctx)->group_secret_hash);
    (*ctx)->group_secret_hash=NULL;
  }

  if(flag == 1){
    str_free_tree(&((*ctx)->root));
    (*ctx)->root=NULL;
  }
  
  str_free_tree(&((*ctx)->cache));
  (*ctx)->cache=NULL;
  
  if (((*ctx)->params) != NULL) {
    DSA_free((*ctx)->params);
    (*ctx)->params=NULL;
  }
  if (((*ctx)->pkey) != NULL) {
    EVP_PKEY_free((*ctx)->pkey);
    (*ctx)->pkey=NULL;
  }
  if (((*ctx)->epoch) != (int)NULL) {
    (*ctx)->epoch = (int)NULL;
  }
  if((*ctx)->tmp_key != NULL){
    BN_clear_free((*ctx)->tmp_key);
  }
  if((*ctx)->tmp_bkey != NULL){
    BN_clear_free((*ctx)->tmp_bkey);
  }
  
  free((*ctx));
  (*ctx)=NULL;
  
  return;
}

/***********************/
/*TREE private functions*/
/***********************/

/* str_encode using information from the current context and from
 * token info generates the output token.
 * include_last_partial: If TRUE includes all last_partial_keys,
 * otherwise it includes the partial key of the (controller) first
 * user in ckd. Hence it should be TRUE if called within cliques and
 * FALSE if called from ckd_gnrt_gml.
 *
 * Note: output is created here.
 * Preconditions: *output should be empty (otherwise it will be
 * freed).  
 */
int str_encode(STR_CONTEXT *ctx, STR_TOKEN **output,
		STR_TOKEN_INFO *info) 
{ 
  uint pos=0;
  str_uchar *data;
  
  /* Freeing the output token if necessary */
  if((*output) != NULL) str_destroy_token(output);
  
  /* Do some error checkings HERE !! */
  if (ctx == (STR_CONTEXT *) NULL) return CTX_ERROR;
  /* The token has to match the current group name */
  if (strcmp(info->group_name,ctx->group_name)) return GROUP_NAME_MISMATCH;
  /* Done with error checkings */
  
  data=(str_uchar *) calloc (sizeof(str_uchar)*STR_MSG_SIZE,1);
  if (data==(str_uchar *) NULL) return MALLOC_ERROR;
  
  str_string_encode(data,&pos,info->group_name);
  str_int_encode(data,&pos,info->message_type);
  str_int_encode(data,&pos,info->time_stamp);
  /* Note: info->sender_name is not used here. The name is retreived
   * from ctx.
   */
  str_string_encode(data,&pos,ctx->member_name);
  str_int_encode(data,&pos,ctx->epoch);
  str_int_encode(data,&pos,ctx->status);
  
  str_map_encode(data, &pos, ctx->root);
  
  *output=(STR_TOKEN *) calloc(sizeof(STR_TOKEN),1);
  if (*output == (STR_TOKEN *) NULL) return MALLOC_ERROR;
  (*output)->length=pos;
  (*output)->t_data=data;
  
  return OK;
}

/* Converts tree structure to unsigned character string */
void str_map_encode(str_uchar *stream, uint *pos, STR_KEY_TREE *root)
{
  STR_KEY_TREE *head, *tail;
  int map = 0;        /* If map is 3, index, bkey, member_name
                       * If map is 2, index, member_name
                       * If map is 1, index, bkey
                       * If map is 0, only index
                       */

  head = str_search_member(root, 2, NULL);
  
  while(head != NULL){ 
    if(head->bfs != NULL) head->bfs = NULL;
    head = head->next; 
  } 

  str_int_encode(stream, pos, root->str_nv->num_user);
  head = tail = root;
  
  while(head != NULL){
    if(head->str_nv->member == NULL){
      if(head->str_nv->bkey == NULL){
        map = 0;
      }
      else map = 1;
    }
    else{
      if(head->str_nv->bkey == NULL){
        map = 2;
      }
      else map = 3;
    }
    
    /* Real encoding */
    str_int_encode(stream, pos, map);
    str_int_encode(stream, pos, head->str_nv->index);
    if(head->str_nv->bkey != NULL) 
      str_bn_encode(stream, pos, head->str_nv->bkey);
    if(head->str_nv->member != NULL) 
      str_string_encode(stream, pos, head->str_nv->member->member_name);
    
    /* Queue handling */
    if(head->left){
      tail->bfs = head->left;
      tail = tail->bfs;
    }
    if(head->right){
      tail->bfs = head->right;
      tail = tail->bfs;
    }
    head = head->bfs;
  }
  
  tail = head = NULL;
}

/* str_decode using information from the input token, it creates
 * ctx. info is also created here. It contains data recovered from
 * input such as message_type, sender, etc. (See structure for more
 * details) in readable format. 
 * Preconditions: *ctx has to be NULL.
 * Postconditions: ctx is created. The only valid data in it is
 * group_members_list (first & last), and epoch. All the other
 * variables are NULL. (str_create_ctx behavior)
 */
int str_decode(STR_CONTEXT **ctx, STR_TOKEN *input,
                STR_TOKEN_INFO **info)
{
  uint pos=0;
  int ret=CTX_ERROR;
  
  if (input == NULL){
        printf("This is weird 3\n\n");
        
    return INVALID_INPUT_TOKEN;
  }
  if (input->t_data == NULL){
        printf("This is weird 4\n\n");
        
    return INVALID_INPUT_TOKEN;
  }
  if (input->length <= 0){
        printf("This is weird 5\n\n");
        
    return INVALID_INPUT_TOKEN;
  }
  
  /* Creating token info */
  ret=str_create_token_info(info,"",STR_INVALID,0L,"");
  if (ret!=OK) goto error;
  
  if (ret!=str_create_ctx(ctx)) goto error;
  
  ret=INVALID_INPUT_TOKEN;
  if (!str_string_decode(input,&pos,(*info)->group_name)) 
    goto error;
  if (!str_int_decode(input,&pos,(uint*)&(*info)->message_type)) 
    goto error;
  if (!str_int_decode(input,&pos,(uint *)&(*info)->time_stamp)) 
    goto error;
  if (!str_string_decode(input,&pos,(*info)->sender_name)) 
    goto error;
  /*  (*ctx)->member_name = (STR_NAME *)malloc(sizeof(STR_NAME)*MAX_LGT_NAME);
  strncpy((*ctx)->member_name, (*info)->sender_name, MAX_LGT_NAME);
  */
  
  if (!str_int_decode(input,&pos,&(*ctx)->epoch)) 
    goto error;
  if (!str_int_decode(input,&pos,&(*ctx)->status)) 
    goto error;
  if ((ret=str_map_decode(input,&pos,ctx)) != OK)
    goto error; 
  
  /* Checking after decoding */
  if ((((*info)->sender_name) == NULL) ||
      (((*info)->group_name) == NULL) ||
      ((*ctx)->epoch < 0)){
        printf("This is weird 6\n\n");
        
    ret=INVALID_INPUT_TOKEN;
  }
  
  else
    ret=OK;
  
error:
  
  if (ret != OK) {
        printf("This is weird 7\n\n");
        
    if (info != NULL) str_destroy_token_info(info);
    if (ctx != NULL) str_destroy_ctx(ctx,1);
  }
  
  return ret;
}

/* str_map_decode decode input token to generate tree for the new
 *   tree
 * *tree should be pointer to the root node
 */
int str_map_decode(const STR_TOKEN *input, uint *pos, 
                    STR_CONTEXT **ctx)
{
  int i;
  uint map=0;
  uint tmp_index;
  STR_KEY_TREE *tmp_tree=NULL, *tmp1_tree=NULL;
  int ret=OK;
  
  (*ctx)->root->str_nv = (STR_NV *)calloc(sizeof(STR_NV),1);
  if ((*ctx)->root->str_nv == NULL) 
  {ret=MALLOC_ERROR; goto error;}
  if(!str_int_decode(input, pos, (uint *)&((*ctx)->root->str_nv->num_user))) 
    return 0;
  
  (*ctx)->root->parent = NULL;
  (*ctx)->root->str_nv->member = NULL;
  
  if(!str_int_decode(input, pos, &map)) return 0;
  if(!str_int_decode(input, pos, &tmp_index)) return 0;
  
  (*ctx)->root->str_nv->index = tmp_index;
  (*ctx)->root->str_nv->key = (*ctx)->root->str_nv->bkey = NULL;
  if(map & 0x1){
    (*ctx)->root->str_nv->bkey = BN_new();
#ifdef MEMCHECK
  add_alloc(BKEY);
#endif
    if(!str_bn_decode(input, pos, (*ctx)->root->str_nv->bkey)) return 0;
  }
  if((map >> 1) & 0x1){
    (*ctx)->root->str_nv->member 
      = (STR_GM *)calloc(sizeof(STR_GM),1);
    if((*ctx)->root->str_nv->member == NULL)
    {ret=MALLOC_ERROR; goto error;}
    
    (*ctx)->root->str_nv->member->cert = NULL;
    (*ctx)->root->str_nv->member->member_name = 
      (STR_NAME *)calloc(sizeof(STR_NAME)*MAX_LGT_NAME,1);
    if((*ctx)->root->str_nv->member->member_name == NULL)
    {ret=MALLOC_ERROR; goto error;}
    if(!str_string_decode(input, pos,
                      (*ctx)->root->str_nv->member->member_name))
      return 0; 
  }
  
  for(i=0; i<2 * (*ctx)->root->str_nv->num_user-2; i++){
    if(!str_int_decode(input, pos, &map)) return 0;
    if(!str_int_decode(input, pos, &tmp_index)) return 0;
    tmp_tree=str_search_index((*ctx)->root, tmp_index);
    if(tmp_tree == NULL) return 0;
    tmp_tree->str_nv->member = NULL;
    tmp1_tree = (STR_KEY_TREE *)calloc(sizeof(STR_KEY_TREE),1);
    
    tmp1_tree->parent = tmp_tree;
    if(tmp_index % 2)
      tmp_tree->right = tmp1_tree;
    else tmp_tree->left = tmp1_tree;
    tmp1_tree->str_nv = (STR_NV *)calloc(sizeof(STR_NV),1);
    tmp1_tree->str_nv->member = NULL;
    tmp1_tree->str_nv->key = tmp1_tree->str_nv->bkey = NULL;
    tmp1_tree->str_nv->index = tmp_index;
    tmp1_tree->left=tmp1_tree->right=NULL;
    tmp1_tree->prev=tmp1_tree->next=tmp1_tree->bfs=NULL;
    if(map & 0x1){
      tmp1_tree->str_nv->bkey = BN_new();
#ifdef MEMCHECK
  add_alloc(BKEY);
#endif
      if(!str_bn_decode(input, pos, tmp1_tree->str_nv->bkey)) return 0;
    }
    if((map >> 1) & 0x1){
      tmp1_tree->str_nv->member=(STR_GM *)calloc(sizeof(STR_GM),1);
      tmp1_tree->str_nv->member->member_name = 
        (STR_NAME *)calloc(sizeof(STR_NAME)*MAX_LGT_NAME,1); 
      tmp1_tree->str_nv->member->cert=NULL;
      
      if(!str_string_decode(input, pos, tmp1_tree->str_nv->member->member_name))
        return 0; 
      tmp_tree = str_search_member(tmp1_tree, 0, NULL);
      tmp1_tree->prev = tmp_tree;
      if(tmp_tree != NULL) tmp_tree->next = tmp1_tree;
      tmp_tree = str_search_member(tmp1_tree, 1, NULL);
      tmp1_tree->next = tmp_tree;
      if(tmp_tree != NULL) tmp_tree->prev = tmp1_tree;
      tmp1_tree->bfs = NULL;
    }
  }
  
  error:
  if(ret != OK){
    if((*ctx)->root->str_nv->member != NULL){
      if((*ctx)->root->str_nv->member->member_name != NULL) 
        free((*ctx)->root->str_nv->member->member_name);
      free((*ctx)->root->str_nv->member);
    }
    if((*ctx)->root->str_nv != NULL) free((*ctx)->root->str_nv);
  }
  
  return ret;
}

/* int_encode: It puts an integer number in stream. Note that the size
 * of the integer number is added to the stream as well.
 */
void str_int_encode(str_uchar *stream, uint *pos, uint data) 
{
  int int_size=htonl(INT_SIZE);
  
  data=htonl(data);
  if(LENGTH_SIZE+*pos > STR_MSG_SIZE) { 
    fprintf(stderr, "Problems in int_encode\n"); 
    exit(1); 
  } 
  
  bcopy (&int_size,stream+*pos,LENGTH_SIZE);
  *pos+=LENGTH_SIZE;
  if(INT_SIZE+*pos > STR_MSG_SIZE) { 
    fprintf(stderr, "Problems in str_int_encode\n"); 
    exit(1); 
  } 
  bcopy (&data,stream+*pos,INT_SIZE);
  *pos+=INT_SIZE;
}

/* int_decode: It gets an integer number from input->t_data. Note that
 * the size of the integer number is decoded first, and then the
 * actual number is decoded.
 * Returns: 1 succeed.
 *          0 Fails.
 */
int str_int_decode(const STR_TOKEN *input,uint *pos, uint *data) 
{
  int int_size;

  if (input->length  < LENGTH_SIZE+*pos) return 0;
  bcopy (input->t_data+*pos,&int_size,LENGTH_SIZE);
  int_size=ntohl(int_size);
  *pos+=LENGTH_SIZE;
  if(int_size+*pos > STR_MSG_SIZE) return 0;
  if (input->length  < int_size+*pos) return 0;
  bcopy (input->t_data+*pos,data,int_size);
  *pos+=int_size;
  *data=ntohl(*data);

  return 1;
}

/* str_string_encode: It puts the valid 'c' string into stream. It first
 * stores the message length (including \0) and the the actual
 * message.
 */
void str_string_encode (str_uchar *stream, uint *pos, char *data) 
{
  int str_len=1;
  
  /* Note: we are copying the '/0' also */
  str_len+=strlen(data); 
  str_int_encode(stream,pos,str_len);
  if(str_len+*pos > STR_MSG_SIZE) {
    fprintf(stderr, "Problems in str_encode\n");
    exit(1);
  }

  bcopy (data,stream+*pos,str_len);
  *pos+=str_len;
}

/* str_string_decode: It restores a valid 'c' string from
 * input->t_data. First the string length is decode (this one should
 * have \0 already), and the actual string.
 * Returns: 1 succeed.
 *          0 Fails.
 */
int str_string_decode (const STR_TOKEN *input, uint *pos, char *data) 
{
  uint str_len;

  if (!str_int_decode(input,pos,&str_len)) return 0;
  if(str_len+*pos > STR_MSG_SIZE) return 0; 
  if (input->length  < str_len+*pos) return 0;
  bcopy(input->t_data+*pos,data,str_len);
  *pos+=str_len;

  return 1;
}

/* str_bn_encode: BIGNUM encoding. */
void str_bn_encode (str_uchar *stream, uint *pos, BIGNUM *num) 
{
  uint size;

  size=BN_num_bytes(num);
  assert (size > 0);
  str_int_encode(stream,pos,size);
  BN_bn2bin(num,stream+*pos);
  *pos+=size;
}

/* bn_decode: BIGNUM decoding.
 * Preconditions: num has to be different from NULL.
 * Returns: 1 succeed.
 *          0 Fails.
 */
int str_bn_decode (const STR_TOKEN *input, uint *pos, BIGNUM *num) 
{
  uint size=0;

  if (num == (BIGNUM *) NULL) return 0;
  if (!str_int_decode(input,pos,&size)) return 0;
  if (size <= 0) return 0;
  if (input->length < size+*pos) return 0;
  BN_bin2bn(input->t_data+*pos,size,num);
  *pos+=size;

  return 1;
}

/* str_create_token_info: It creates the info token. */
int str_create_token_info (STR_TOKEN_INFO **info, STR_NAME *group, 
                            enum STR_MSG_TYPE msg_type, time_t time,
                            STR_NAME *sender/*, uint epoch*/) 
{ 
  int ret=MALLOC_ERROR;
  
  /* Creating token information */
  (*info)=(STR_TOKEN_INFO *) calloc (sizeof(STR_TOKEN_INFO),1);
  if ((*info) == NULL) goto error;
  if (group != NULL) {
    (*info)->group_name
      =(STR_NAME *) calloc(sizeof(STR_NAME)*MAX_LGT_NAME,1);
#ifdef MEMCHECK
    add_alloc(GN);
#endif
    if (((*info)->group_name) == NULL) goto error;
    strncpy ((*info)->group_name,group,MAX_LGT_NAME);
  } else (*info)->group_name=NULL;
  (*info)->message_type=msg_type;
  (*info)->time_stamp=time;
  if (sender != NULL) {
    (*info)->sender_name=(STR_NAME *)
      calloc(sizeof(STR_NAME)*MAX_LGT_NAME,1);
#ifdef MEMCHECK
    add_alloc(SN);
#endif
    if (((*info)->sender_name) == NULL) goto error;
    strncpy ((*info)->sender_name,sender,MAX_LGT_NAME);
  }
  else (*info)->sender_name=NULL;

  /*  (*info)->epoch=epoch; */
  
  ret=OK;
error:
  if (ret != OK) str_destroy_token_info(info);

  return ret;
}

/* str_destroy_token: It frees the memory of the token. */
void str_destroy_token (STR_TOKEN **token) {
  if (*token !=(STR_TOKEN *) NULL) {
    if ((*token)->t_data != NULL) {
      free ((*token)->t_data);
      (*token)->t_data=NULL;
    }
    free(*token);
    *token=NULL;
  }
}

/* str_destroy_token_info: It frees the memory of the token. */
void str_destroy_token_info (STR_TOKEN_INFO **info) 
{
  
  if (info == NULL) return;
  if ((*info) == NULL) return;
  if ((*info)->group_name != NULL) {
    free ((*info)->group_name);
#ifdef MEMCHECK
    add_free(GN);
#endif
    (*info)->group_name =NULL;
  }
  if ((*info)->sender_name != NULL) {
    free ((*info)->sender_name);
#ifdef MEMCHECK
    add_free(SN);
#endif
    (*info)->sender_name=NULL;
  }
  free ((*info));
  *info = NULL;
  
}

/* str_merge_tree returns root of a new tree which is the result of
 *   merge of two trees
 */
STR_KEY_TREE *str_merge_tree(STR_KEY_TREE *joiner, STR_KEY_TREE *joinee)
{
  STR_KEY_TREE *tmp_tree=NULL, *tmp_tree1=NULL;
  
  if((joiner->parent != NULL) && (joinee->parent != NULL)) return NULL;
  
  tmp_tree = (STR_KEY_TREE *)calloc(sizeof(STR_KEY_TREE),1);
  if(tmp_tree == NULL) return NULL;
  
  /* setting up pointers for the new node */
  tmp_tree1        = str_search_member(joiner, 2, NULL);
  tmp_tree->parent = tmp_tree1;
  tmp_tree->left   = NULL;
  tmp_tree->right  = NULL;
  if(joinee->right){
    tmp_tree->prev   = joinee->right;
  }
  else{
    tmp_tree->prev = joinee;
  }
  if(tmp_tree1->parent != NULL){
    tmp_tree->next   = tmp_tree1->parent->right;
  }
  else{
    tmp_tree->next = NULL;
  }
  tmp_tree->bfs = NULL;
  joinee->parent      = tmp_tree1;
  if(joinee->right){
    joinee->right->next = tmp_tree;
  }
  else{
    joinee->next = tmp_tree;
  }
  tmp_tree1->left     = joinee;
  tmp_tree1->right    = tmp_tree;
  if(tmp_tree1->parent){
    tmp_tree1->parent->right->prev = tmp_tree;
  }
  
  /* Now, real values for the tmp_tree */
  tmp_tree->str_nv=(STR_NV *)calloc(sizeof(STR_NV),1);
  str_copy_node(tmp_tree1, tmp_tree);
  tmp_tree->str_nv->index = tmp_tree->str_nv->index + 3;

  if(tmp_tree1->left){
    str_update_index(tmp_tree1->left, 0, tmp_tree1->str_nv->index);  
    str_update_index(tmp_tree1->right, 1, tmp_tree1->str_nv->index);
  }

  return joiner;
}


/* str_search_member: returns the pointer of the previous or the next
 *   member or the first or the last member
 *   if option is 0, this will return the pointer to the previous member
 *   if option is 1, this will return the pointer to the next member
 *     in the above two cases, tree is the starting leaf node in this
 *     searching 
 *   if option is 2, this will return the pointer to the left-most
 *      leaf member 
 *   if option is 3, this will return the pointer to the right-most
 *      leaf member 
 *   if option is 4 and member_name is not null, this will return the
 *     pointer to the node with that name
 *   if option is 5, this will return the pointer to the root
 *   if option is 6, this will return the shallowest leaf node
 */
STR_KEY_TREE *str_search_member(STR_KEY_TREE *tree, int option, 
				STR_NAME *member_name )
{
  STR_KEY_TREE *tmp_tree;
  int min_node=100000;
  STR_NAME *the_name=NULL;
  
  tmp_tree = tree;
  
  if(member_name == NULL){
    switch (option) {
      case 0: 
        if(tree->str_nv->member == NULL) return NULL;
        if(tree->str_nv->member->member_name == NULL) return NULL;
        if(tmp_tree->parent == NULL) return NULL;
        if(tmp_tree->parent->left == NULL) return NULL;
        while(tmp_tree->parent->left == tmp_tree){
          tmp_tree = tmp_tree->parent;
          if(tmp_tree->parent == NULL) return NULL;
        }
        tmp_tree = tmp_tree->parent->left;
        while(tmp_tree->str_nv->member == NULL){
          if(tmp_tree->right == NULL) return NULL;
          tmp_tree = tmp_tree->right; 
        }
        if(tmp_tree->str_nv->member->member_name == NULL) return NULL;
        return tmp_tree;
      case 1:
        if(tree->str_nv->member == NULL) return NULL;
        if(tree->str_nv->member->member_name == NULL) return NULL;
        if(tmp_tree->parent == NULL) return NULL;
        if(tmp_tree->parent->right == NULL) return NULL;
        while(tmp_tree->parent->right == tmp_tree){
          tmp_tree = tmp_tree->parent;
          if(tmp_tree->parent == NULL) return NULL;
        }
        tmp_tree = tmp_tree->parent->right;
        while(tmp_tree->str_nv->member == NULL){
          if(tmp_tree->left == NULL) return NULL;
          tmp_tree = tmp_tree->left;
        }
        if(tmp_tree->str_nv->member->member_name == NULL) return NULL;
        return tmp_tree;
      case 2:
        if(tmp_tree->left == NULL) return tmp_tree;
        while(tmp_tree->left != NULL) tmp_tree=tmp_tree->left;
        return tmp_tree;
      case 3:
        if(tmp_tree->right == NULL) return tmp_tree;
        while(tmp_tree->right != NULL) tmp_tree=tmp_tree->right;
        return tmp_tree;
      case 5:
        if(tmp_tree->parent == NULL) return tmp_tree;
        while(tmp_tree->parent != NULL) tmp_tree=tmp_tree->parent;
        return tmp_tree;
      case 6:
        tmp_tree = str_search_member(tmp_tree, 2, NULL);
        while(tmp_tree->next != NULL){
          if(tmp_tree->str_nv->index < min_node){
            min_node = tmp_tree->str_nv->index;
            the_name = tmp_tree->str_nv->member->member_name;
          }
          tmp_tree = tmp_tree->next;
        }
        tmp_tree = str_search_member(tmp_tree, 5, NULL);
        tmp_tree = str_search_member(tmp_tree, 4, the_name);
        if(tmp_tree == NULL){
          fprintf(stderr, "What happened???????\n");
        }
        return tmp_tree;
      default:
        return NULL;
    }
  }
  else{
    if(option==4){
      if(tmp_tree->left == NULL){
        if(strcmp(tmp_tree->str_nv->member->member_name,member_name)==0){
          return tmp_tree;
        }
      }
      tmp_tree = str_search_member(tree, 2, NULL);
      if(tmp_tree == NULL) return NULL;
      
      while(strcmp(tmp_tree->str_nv->member->member_name,
                   member_name)!=0 ){
        if(tmp_tree->next == NULL) return NULL;
        tmp_tree = tmp_tree->next;
      }
      return tmp_tree;
    }
  }
  return NULL;
}

/* str_search_index: Returns the node having the index as a child 
 *   index should be greater than 1
 */
STR_KEY_TREE *str_search_index(STR_KEY_TREE *tree, int index)
{
  int height=0;
  int i;
  STR_KEY_TREE *tmp_tree;
  
  height = index/2;
  
  tmp_tree = tree;
  
  if(index==1) return NULL;
  
  for(i=1; i<height; i++){
     tmp_tree = tmp_tree->left;
  }
  
  return tmp_tree;
}

/* str_update_index: update index of the input tree by 1
 * index 0 is for the left node
 * index 1 is for the right node
 */
void str_update_index(STR_KEY_TREE *tree, int index, int root_index) 
{
  if(tree == NULL) return;

  if(root_index == 1){
    tree->str_nv->index = root_index * 2 + index;
  }
  else{
    tree->str_nv->index = root_index + 2 + index;
  }

  str_update_index(tree->left, 0, tree->str_nv->index);
  str_update_index(tree->right, 1, tree->str_nv->index);
}

/* Frees a STR_TREE structure */
void str_free_tree(STR_KEY_TREE **tree) {
  
  if(tree == NULL) return;
  if((*tree) == NULL) return;

  if((*tree)->left != NULL)
    str_free_tree(&((*tree)->left));
  if((*tree)->right != NULL)
    str_free_tree(&((*tree)->right));
  
  str_free_node(&(*tree));
}

/* Frees a NODE structure */
void str_free_node(STR_KEY_TREE **tree) {

  if(tree == NULL) return;
  if((*tree) == NULL) return;
  
  if((*tree)->str_nv != NULL){
    str_free_nv(&((*tree)->str_nv));
    (*tree)->str_nv = NULL;
  }
  
  free((*tree));
  
  (*tree)=NULL;
}

/* Frees a STR_NV structure */
void str_free_nv(STR_NV **nv) {
  if (nv == NULL) return;
  if ((*nv) == NULL) return;
  if((*nv)->member != NULL){
    str_free_gm(&((*nv)->member));
    (*nv)->member=NULL;
  }
  
  if ((*nv)->key != NULL){
    BN_clear_free((*nv)->key);
#ifdef MEMCHECK
    add_free(KEY);
#endif
  }
  
  if ((*nv)->bkey != NULL){
    BN_clear_free((*nv)->bkey);
#ifdef MEMCHECK
    add_free(BKEY);
#endif
  }
  
  free((*nv));
  (*nv)=NULL;
}

/* Frees a STR_GM structure */
void str_free_gm(STR_GM **gm) {
  if((*gm) == NULL) return;
  if (((*gm)->member_name) != NULL) {
    free ((*gm)->member_name);
    (*gm)->member_name=NULL;
  }
  if (((*gm)->cert) != NULL) {
    X509_free ((*gm)->cert);
    (*gm)->cert=NULL;
  }
  free((*gm));
  (*gm)=NULL;
}

/* return log_2 a */
int str_log2(int a)
{
  int tmp = a;
  int i=-1;
  
  while(tmp > 0){
    i++;
    tmp >>= 1;
  }
  
  return i;
}

/* swap pointer a and b */
void str_swap(void **a, void **b)
{
  void *tmp;

  tmp = *a;
  *a = *b;
  *b = tmp;
}


/* str_copy tree structure, but to finish the real copy, we need to
   call str_dup_tree, which finishes prev and next pointer */  
STR_KEY_TREE *str_copy_tree(STR_KEY_TREE *src)
{
  STR_KEY_TREE *dst=NULL;
  
  if(src != NULL){
    dst = (STR_KEY_TREE *) calloc(sizeof(STR_KEY_TREE), 1);
    if(src->str_nv != NULL){
      dst->str_nv = (STR_NV *) calloc(sizeof(STR_NV), 1);
      dst->str_nv->index = src->str_nv->index;
      dst->str_nv->num_user=src->str_nv->num_user;
      if(src->str_nv->key != NULL){
        dst->str_nv->key = BN_dup(src->str_nv->key);
      }
      if(src->str_nv->bkey != NULL){
        dst->str_nv->bkey = BN_dup(src->str_nv->bkey);
      }
      if(src->str_nv->member != NULL){
        dst->str_nv->member = (STR_GM *) calloc(sizeof(STR_GM),1);
        if(src->str_nv->member->member_name != NULL){
          dst->str_nv->member->member_name=(STR_NAME *)
            calloc(sizeof(STR_NAME)*MAX_LGT_NAME,1);
          strncpy (dst->str_nv->member->member_name,
                   src->str_nv->member->member_name,MAX_LGT_NAME);
        }
        if(src->str_nv->member->cert != NULL){
          dst->str_nv->member->cert = X509_dup(src->str_nv->member->cert);
        }
      }
    }
    dst->left = str_copy_tree(src->left);
    dst->right = str_copy_tree(src->right);
    if(dst->left) {
      dst->left->parent = dst;
    }
    if(dst->right) {
      dst->right->parent = dst;
    }
  }

  return dst;
}

/* str_dup_tree finishes the copy process of one tree to
   another... Mainly, it just handles prev and next pointer */
STR_KEY_TREE *str_dup_tree(STR_KEY_TREE *src)
{
  STR_KEY_TREE *dst=NULL;
  STR_KEY_TREE *tmp1_src=NULL, *tmp1_dst=NULL;
  STR_KEY_TREE *tmp2_src=NULL, *tmp2_dst=NULL;

  dst = str_copy_tree(src);
  if(src != NULL){
    tmp1_src = str_search_member(src, 2, NULL);
    tmp2_src = tmp1_src->next;
    tmp1_dst = str_search_member(dst, 4,
                                  tmp1_src->str_nv->member->member_name);
    while(tmp2_src != NULL){
      tmp2_dst = str_search_member(tmp1_dst, 1, NULL);
      tmp1_dst->next = tmp2_dst;
      tmp2_dst->prev = tmp1_dst;
      tmp2_src = tmp2_src->next;
      tmp1_src = tmp1_src->next;
      tmp1_dst = tmp2_dst;
    }
  }

  return dst;
}

/* str_copy_node copies or changes str_nv values of src node to dst
   node */  
void str_copy_node(STR_KEY_TREE *src, STR_KEY_TREE *dst)
{
  if(src->str_nv != NULL){
    dst->str_nv->index = src->str_nv->index;
    dst->str_nv->num_user=src->str_nv->num_user;
    if(src->str_nv->key != NULL){
      str_swap((void *)&(src->str_nv->key),(void *)&(dst->str_nv->key));
    }
    if(src->str_nv->bkey != NULL){
      str_swap((void *)&(src->str_nv->bkey),(void *)&(dst->str_nv->bkey));
    }
    if(src->str_nv->member != NULL){
      str_swap((void *)&(src->str_nv->member), (void *)&(dst->str_nv->member));
    }
  }
}

/* str_swap_bkey swap my null bkey with meaningful bkey from new token */
void str_swap_bkey(STR_KEY_TREE *src, STR_KEY_TREE *dst) 
{
  if(src->left != NULL){
    str_swap_bkey(src->left, dst->left);
    str_swap_bkey(src->right, dst->right);
  }
  if(src != NULL){
    if(src->str_nv->bkey != NULL){
      if(dst->str_nv->bkey == NULL){
        str_swap((void *)&(src->str_nv->bkey),(void *)&(dst->str_nv->bkey));
      }
    }
  }
}

/* str_copy_bkey copies meaningful bkey from new token to my null
   token, used for cache update */
void str_copy_bkey(STR_KEY_TREE *src, STR_KEY_TREE *dst) 
{
  if(src->left != NULL){
    str_copy_bkey(src->left, dst->left);
    str_copy_bkey(src->right, dst->right);
  }
  if(src != NULL){
    if(src->str_nv->bkey != NULL){
      if(dst->str_nv->bkey == NULL){
        dst->str_nv->bkey = BN_dup(src->str_nv->bkey);
      }
    }
  }
}

/* str_check_useful checks whether new_ctx has useful information
 * If it has, return 1,
 * else, return 0
 */
int str_check_useful(STR_KEY_TREE *newtree, STR_KEY_TREE *mytree) 
{
  STR_KEY_TREE *head_new=NULL, *tail_new=NULL;
  STR_KEY_TREE *head_my=NULL, *tail_my=NULL;

  head_new=tail_new=newtree;
  head_my=tail_my=mytree;

  str_init_bfs(newtree);
  str_init_bfs(mytree); 
  
  while(head_new != NULL){
    if((head_new->str_nv->bkey!=NULL)&&(head_my->str_nv->bkey==NULL)){
      return 1;
    }
    /* Queue handling */
    if(head_new->left){
      tail_new->bfs = head_new->left;
      tail_new = tail_new->bfs;
      tail_my->bfs = head_my->left;
      tail_my = tail_my->bfs;
    }
    if(head_new->right){
      tail_new->bfs = head_new->right;
      tail_new = tail_new->bfs;
      tail_my->bfs = head_my->right;
      tail_my = tail_my->bfs;
    }
    head_new = head_new->bfs;
    head_my = head_my->bfs;
    
  }
  str_init_bfs(newtree);
  str_init_bfs(mytree); 

  return 0;
}

/* str_init_bfs initializes(nullfies) bfs pointers for each node */
void str_init_bfs(STR_KEY_TREE *tree)
{
  if(tree != NULL){
    if(tree->left){
      str_init_bfs(tree->left);
      str_init_bfs(tree->right);
    }
    if(tree != NULL){
      tree->bfs = NULL;
    }
  }
}

/* remove_sponsor: remove the sponsor from the sponsor list */
int str_remove_sponsor(STR_NAME *sponsor_list[], STR_NAME *sponsor)
{
  int i=0, j=0;
  int find = 0;

  if(sponsor_list[0] == NULL) {
    return -1;
  }
  
  for(i=0; i<NUM_USERS+1; i++){
    if(sponsor_list[i] != NULL){
      if(strcmp(sponsor_list[i], sponsor)==0){
        find = 1;
        break;
      }
    }
  }
  for(j=i; j<NUM_USERS-1; j++){
    if(sponsor_list[j] != NULL){
      sponsor_list[j] = sponsor_list[j+1];
    }
  }

  if(find){
    return 1;
  }
  else{
    return -1;
  }
}
