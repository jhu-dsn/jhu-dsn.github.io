/* CLIQUES Non-Commercial License (covers BD, CLQ, STR and TGDH
libraries).  Copyright (c) 1998-2002 by the University of California,
Irvine.  All rights reserved.

Permission to use, copy, modify, and distribute this software and its
documentation in source and binary forms for lawful non-commercial
purposes and without fee is hereby granted, provided that the above
copyright notice appear in all copies and that both the copyright
notice and this permission notice appear in supporting documentation,
and that any documentation, advertising materials, and other materials
related to such distribution and use acknowledge that the software was
developed by the University of California, Irvine, Information and
Computer Science Department. The name of University of California,
Irvine may not be used to endorse or promote products derived from
this software without specific prior written permission.

THE UNIVERSITY OF CALIFORNIA, IRVINE MAKES NO REPRESENTATIONS ABOUT
THE SUITABILITY OF THIS SOFTWARE FOR ANY PURPOSE.  THIS SOFTWARE IS
PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND
NON-INFRINGEMENT.

IN NO EVENT SHALL UNIVERSITY OF CALIFORNIA, IRVINE OR ANY OTHER
CONTRIBUTOR BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
DAMAGES, WHETHER IN CONTRACT, TORT, OR OTHER FORM OF ACTION, ARISING
OUT OF OR IN CONNECTION WITH, THE USE OR PERFORMANCE OF THIS SOFTWARE.

All questions concerning this software should be directed to
cliques@ics.uci.edu. */


/*********************************************************************
 * str_test.c                                                       * 
 * STR test source file.                                            * 
 * Date      Tue Nov 21 22:08:07 PST 2000                            *
 * Wrote by:                                                         * 
 *   Yongdae Kim                                                     *
 *                                                                   *
 * CLIQUES Project                                                   *
 * Information Sciences Institute                                    *
 * University of Southern California                                 *
 *********************************************************************/


#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include <sys/types.h>
#include <time.h>
#include <sys/time.h>

#include "bn.h"
#include "str_api.h"
#include "str_api_misc.h"
#include "str_error.h"

#include "str_test_misc.h"
#include "str_api_misc.h" /* str_get_time is defined here */

#include "str_test.h"

#ifdef TIMING
extern int print;
#endif

#define CMERGE 1
#define CPARTITION 2
#define DEFAULT 10

int main(int argc, char **argv) {
  STR_NAME *user[NUM_USERS+1]={NULL};

  STR_LIST *init_list=NULL;
  
  STR_CONTEXT *ctx[NUM_USERS];
  STR_TOKEN *tmp=NULL;
  TOKEN_LIST *input=NULL;
  STR_TOKEN *output[NUM_USERS+1]={NULL};
  int num_users=NUM_USERS;
  
  int ret=OK, Ret=CONTINUE;
  int i=0, j=0, k=0;
  int num_round=0;
  TOKEN_LIST *curr_token=NULL;
  int round=0;
#ifndef BASIC
  int event=0;
  STR_LIST *list=NULL;
#endif

#ifdef BASIC
  struct timeval used;
#endif

#ifdef BASIC
  int r=0, c=0;
  STR_NAME *users_leaving[NUM_USERS+1] = {NULL};
  STR_NAME *leaving_list[NUM_USERS+1]={NULL};
  STR_NAME *current_list[NUM_USERS+1]={NULL};
#endif
  
#ifdef TIMING
  double Time=0.0;
  double max = 0.0;
  double maxround = 0.0;
  double Now = 0.0;

  print=1;
#endif
#if defined(PROFILE) | defined(TIMING)
  r=0; /* To avoid a warning during compilation */
#endif
  if (!parse_args(argc,argv,&num_users,&num_round)) goto error;
  /*********************************/

  /* All the members will joing the group */
  /* First user joining group */
  for(i=0; i<NUM_USERS+1; i++){
    user[i] = NULL;
    ctx[i]=NULL;
  }
  for(i=0; i<num_users; i++){
    user[i] = (STR_NAME *)malloc(sizeof(STR_NAME)*MAX_LGT_NAME);
    sprintf (user[i],"%03d",i);
  }
  
  ret=str_new_member(&ctx[0],user[0],GROUP_NAME);
#ifndef TIMING
  printf ("str_new_member returns %d \n",ret);
#endif
  if (ret!=1) goto error;

  for(i=0; i<NUM_USERS+1; i++) {
    output[i] = NULL;
  }

  for(i=1; i<num_users; i++){
#ifndef TIMING
    printf("\n\n\n++++++++++user %d'th join start\n",i);
#endif
#ifdef TIMING
    Now=str_gettimeofday();
#endif
    ret=str_new_member(&ctx[i],user[i],GROUP_NAME);
#ifndef TIMING
    printf ("\t:str_new_member of %s returns %d \n",user[i],ret);
#endif
#ifdef TIMING
    max=str_gettimeofday()-Now;
#endif
    if (ret!=1) goto error;
    
    /* New member sends merge request */
    for(j=0; j<i; j++){
#ifdef TIMING
      maxround =0;
      Now=str_gettimeofday();
#endif
      ret=str_merge_req(ctx[j], user[j], GROUP_NAME, &output[0]);
#ifndef TIMING
      printf ("\t::str_merge_req of %s returns %d with output %p\n",
              user[j],ret,output[0]);
#endif
#ifdef TIMING
      Time=str_gettimeofday()-Now;
      maxround=MAX(maxround, Time);
      /*  printf("Duration:  %f\n", Time); */
#endif
      if (ret!=1) goto error;
      if(output[0] != NULL){
        input = add_token(input, output[0]);
      }
      output[0]=NULL;
    }
    if(input == NULL) {
      goto error;
    }
    
    /* Last member in the current group is the sponsor */
#ifdef TIMING
    Now=str_gettimeofday();
#endif
    ret=str_merge_req(ctx[i], user[i], GROUP_NAME, &output[1]);
#ifndef TIMING
    printf ("\t::str_merge_req of %s returns %d with output %p\n",
            user[i],ret,output[1]);
#endif
#ifdef TIMING
    Time=str_gettimeofday()-Now;
    maxround=MAX(maxround, Time);
    max += maxround;
    /*  printf("Duration:  %f\n", Time); */
#endif
    if (ret!=1) goto error;
    if(output[1] == NULL){
      fprintf(stderr, "something wrong!\n\n");
    }
    
    input = add_token(input, output[1]);
    if(input == NULL) {
      goto error;
    }
    output[1] = NULL;

    Ret=2;
#ifdef TIMING
    Time=str_gettimeofday();
#endif
    while(Ret != 1){
      k = 0;
      curr_token = input;
      
      while(curr_token != NULL){
#ifdef TIMING
        maxround = 0;
#endif
        Ret = 1;
        for(j=0; j<=i; j++){
#ifdef TIMING
          Now=str_gettimeofday();
#endif
          ret = str_cascade(&ctx[j], GROUP_NAME, NULL,
                             curr_token->token, &tmp);
#ifndef TIMING
          printf("\t::::str_cascade of %s returns %d with output %p\n",
                 ctx[j]->member_name,ret, tmp);
#endif
#ifdef TIMING
          Time = str_gettimeofday()-Now;
          maxround=MAX(maxround, Time);
          /*  printf("Duration:  %f\n", Time); */
#endif
          
          if(ret <= 0) goto error;
          Ret = MAX(Ret, ret);
          if(tmp != NULL){
            if(output[k] != NULL){
              str_destroy_token(&output[k]);
            }
            output[k] = tmp;
            if(output[k] == NULL) {
              goto error;
            }
            k++;
          }
          tmp=NULL;
        }
        if(Ret == 1) {
          break;
        }
        curr_token = curr_token->next;
      }
#ifdef TIMING
      max += maxround;
#endif

      input = remove_all_token(input);

      for(j=0; j<k; j++){
        input = add_token(input, output[j]);
        output[j] = NULL;
      }
    }
    input=remove_all_token(input);
#ifdef TIMING
    printf("%2d %f\n", i, max);
#endif
  }
  printf ("----------End of Join Event\n");
  check_group_secret(ctx, num_users);
  compare_key(ctx, num_users);

  exit(0);
  
#ifdef BASIC

  printf ("----------Start of Leave Event\n");
  for(i=0; i<NUM_USERS+1; i++){
    users_leaving[i] = NULL;
  }

  k=0;
  Ret = 1;
  for(i=0; i<num_users-2; i++){
    printf("\n\n\n++++++++++user %d'th leave start\n",i);
    users_leaving[0] = user[i];
    str_destroy_ctx(&ctx[i],1);    
    for(j=i+1; j<num_users; j++){
      gettimeofday(&used, 0);
      fprintf(stderr, "Start: %d.%d\n", (int)used.tv_sec, (int)used.tv_usec);
      ret = str_cascade(&ctx[j], GROUP_NAME, users_leaving,
                         NULL, &tmp);
      gettimeofday(&used, 0);
      fprintf(stderr, " End : %d.%d\n", (int)used.tv_sec, (int)used.tv_usec);
      printf("\t::::str_cascade of %s returns %d with output %p\n",
             ctx[j]->member_name,ret, tmp); 
      if(ret <= 0) goto error;
      Ret = MAX(Ret, ret);
      if(tmp != NULL){
        if(output[k] != NULL){
          str_destroy_token(&output[k]);
        }
        output[k] = tmp;
        if(output[k] == NULL) {
        goto error;
        }
        input = add_token(input, output[k]);
        output[k] = NULL;
        k++;
      }
      tmp=NULL;
    }
    curr_token = input;
  

    Ret=2;
    while(Ret != 1){
      k = 0;
      curr_token = input;
      
      do{
        Ret = 1;
        for(j=i+1; j<num_users; j++){
          gettimeofday(&used, 0);
          fprintf(stderr, "Start: %d.%d\n", (int)used.tv_sec, (int)used.tv_usec);
          ret = str_cascade(&ctx[j], GROUP_NAME, NULL,
                             curr_token->token, &tmp);
          printf("\t::::str_cascade of %s returns %d with output %p\n",
                 ctx[j]->member_name,ret, tmp); 
          gettimeofday(&used, 0);
          fprintf(stderr, " End : %d.%d\n", (int)used.tv_sec, (int)used.tv_usec);
          if(ret <= 0) goto error;
          Ret = MAX(Ret, ret);
          if(tmp != NULL){
            if(output[k] != NULL){
              str_destroy_token(&output[k]);
            }
            output[k] = tmp;
            if(output[k] == NULL) {
              goto error;
            }
            k++;
          }
          tmp=NULL;
        }
        if(Ret == 1) {
          break;
        }
        curr_token = curr_token->next;
        users_leaving[0] = NULL;
      } while (curr_token != NULL);

      input = remove_all_token(input);

      for(j=0; j<k; j++){
        input = add_token(input, output[j]);
        output[j] = NULL;
      }
    }
    input=remove_all_token(input);
    
  }
  if (ctx[num_users-2] != NULL) str_destroy_ctx(&ctx[num_users-2],1);
  if (ctx[num_users-1] != NULL) str_destroy_ctx(&ctx[num_users-1],1);
  printf ("----------End of Leave Event\n\n");












  printf ("----------Join all to test partition and merge\n");
  ret=str_new_member(&ctx[0],user[0],GROUP_NAME);
  printf ("str_new_member returns %d \n",ret);
  if (ret!=1) goto error;

  for(i=0; i<NUM_USERS+1; i++) {
    output[i] = NULL;
  }
  
  for(i=1; i<num_users; i++){
    printf("\n\n\n++++++++++user %d'th join start\n",i);
    ret=str_new_member(&ctx[i],user[i],GROUP_NAME);
    printf ("\t:str_new_member of %s returns %d \n",user[i],ret);
    if (ret!=1) goto error;
    
    /* New member sends merge request */
    for(j=0; j<i; j++){
      ret=str_merge_req(ctx[j], user[j], GROUP_NAME, &output[0]);
      printf ("\t::str_merge_req of %s returns %d with output %p\n",
              user[j],ret,output[0]);
      if (ret!=1) goto error;
      if(output[0] != NULL){
        input = add_token(input, output[0]);
      }
      output[0]=NULL;
    }
    if(input == NULL) {
      goto error;
    }
    
    /* Last member in the current group is the sponsor */
    ret=str_merge_req(ctx[i], user[i], GROUP_NAME, &output[1]);
    printf ("\t::str_merge_req of %s returns %d with output %p\n",
            user[i],ret,output[1]);
    if (ret!=1) goto error;
    if(output[1] == NULL){
      fprintf(stderr, "something wrong!\n\n");
    }
    
    input = add_token(input, output[1]);
    if(input == NULL) {
      goto error;
    }
    output[1] = NULL;

    Ret=2;
    while(Ret != 1){
      k = 0;
      curr_token = input;
      
      while(curr_token != NULL){
        Ret = 1;
        for(j=0; j<=i; j++){
          ret = str_cascade(&ctx[j], GROUP_NAME, NULL,
                             curr_token->token, &tmp);
          printf("\t::::str_cascade of %s returns %d with output %p\n",
                 ctx[j]->member_name,ret, tmp); 
          if(ret <= 0) goto error;
          Ret = MAX(Ret, ret);
          if(tmp != NULL){
            if(output[k] != NULL){
              str_destroy_token(&output[k]);
            }
            output[k] = tmp;
            if(output[k] == NULL) {
              goto error;
            }
            k++;
          }
          tmp=NULL;
        }
        if(Ret == 1) {
          break;
        }
        curr_token = curr_token->next;
      }

      input = remove_all_token(input);

      for(j=0; j<k; j++){
        input = add_token(input, output[j]);
        output[j] = NULL;
      }
    }
    input=remove_all_token(input);
  }
  printf ("----------End of Join Event\n\n");

  for(round = 0; round<10; round++){
    printf ("---------- Start of Partition Event\n");
    for(i=0; i<NUM_USERS+1; i++){
      leaving_list[i] = NULL;
      current_list[i] = NULL;
    }
    srand(time(0));
    r=((int) rand()%(int)(num_users+1)); 
    while((r<3) || (r==num_users)) r=((int) rand()%(int)(num_users+1)); 
    usr_lst(leaving_list,r,num_users,&c,user,current_list);
    
    printf ("---------- Start of 1st Partition\n");
    k=0;
    Ret = 1;
    for(i=0; i<c; i++){
      ret = str_cascade(&ctx[atoi(current_list[i])], GROUP_NAME,
                         leaving_list, NULL, &tmp);
      printf("\t::::str_cascade of %s returns %d with output %p\n",
             ctx[atoi(current_list[i])]->member_name,ret, tmp); 
      if(ret <= 0) goto error;
      Ret = MAX(Ret, ret);
      if(tmp != NULL){
        if(output[k] != NULL){
          str_destroy_token(&output[k]);
        }
        output[k] = tmp;
        if(output[k] == NULL) {
          goto error;
        }
        input = add_token(input, output[k]);
        output[k] = NULL;
        k++;
      }
      tmp=NULL;
      curr_token = input;
    }
    
    while(Ret != 1){
      k = 0;
      curr_token = input;
      
      do{
        Ret = 1;
        for(i=0; i<c; i++){
          ret = str_cascade(&ctx[atoi(current_list[i])], GROUP_NAME,
                             NULL, curr_token->token, &tmp);
          printf("\t::::str_cascade of %s returns %d with output %p\n",
                 ctx[atoi(current_list[i])]->member_name,ret, tmp); 
          if(ret <= 0) goto error;
          Ret = MAX(Ret, ret);
          if(tmp != NULL){
            if(output[k] != NULL){
              str_destroy_token(&output[k]);
            }
            output[k] = tmp;
            if(output[k] == NULL) {
              goto error;
            }
            k++;
          }
          tmp=NULL;
        }
        if(Ret == 1) {
          break;
        }
        curr_token = curr_token->next;
      } while (curr_token != NULL);
      
      input = remove_all_token(input);
      
      for(j=0; j<k; j++){
        input = add_token(input, output[j]);
        output[j] = NULL;
      }
    }
    input=remove_all_token(input);
    str_check_list_secret(ctx, current_list, c);
    
    printf ("---------- Start of 2nd Partition\n");
    k=0;
    Ret = 1;
    for(i=0; i<r; i++){
      ret = str_cascade(&ctx[atoi(leaving_list[i])], GROUP_NAME,
                         current_list, NULL, &tmp);
      printf("\t::::str_cascade of %s returns %d with output %p\n",
             ctx[atoi(leaving_list[i])]->member_name,ret, tmp); 
      if(ret <= 0) goto error;
      Ret = MAX(Ret, ret);
      if(tmp != NULL){
        if(output[k] != NULL){
          str_destroy_token(&output[k]);
        }
        output[k] = tmp;
        if(output[k] == NULL) {
          goto error;
        }
        input = add_token(input, output[k]);
        output[k] = NULL;
        k++;
      }
      tmp=NULL;
      curr_token = input;
    }
    
    while(Ret != 1){
      k = 0;
      curr_token = input;
      
      do{
        Ret = 1;
        for(i=0; i<r; i++){
          ret = str_cascade(&ctx[atoi(leaving_list[i])], GROUP_NAME,
                             NULL, curr_token->token, &tmp);
          printf("\t::::str_cascade of %s returns %d with output %p\n",
                 ctx[atoi(leaving_list[i])]->member_name,ret, tmp); 
          if(ret <= 0) goto error;
          Ret = MAX(Ret, ret);
          if(tmp != NULL){
            if(output[k] != NULL){
              str_destroy_token(&output[k]);
            }
            output[k] = tmp;
            if(output[k] == NULL) {
              goto error;
            }
            k++;
          }
          tmp=NULL;
        }
        if(Ret == 1) {
          break;
        }
        curr_token = curr_token->next;
      } while (curr_token != NULL);
      
      input = remove_all_token(input);
      
      for(j=0; j<k; j++){
        input = add_token(input, output[j]);
        output[j] = NULL;
      }
    }
    input=remove_all_token(input);
    str_check_list_secret(ctx, leaving_list, r);
    
    printf("\n\n\n++++++++++Merge start\n");
    
    /* New member sends merge request */
    for(j=0; j<num_users; j++){
      ret=str_merge_req(ctx[j], user[j], GROUP_NAME, &tmp);
      printf ("\t::str_merge_req of %s returns %d with output %p\n",
              user[j],ret,tmp);
      if (ret!=1) goto error;
      if(tmp != NULL){
        input = add_token(input, tmp);
      }
      tmp=NULL;
    }
    if(input == NULL) {
      goto error;
    }
    
    Ret=2;
    while(Ret != 1){
      k = 0;
      curr_token = input;
      
      while(curr_token != NULL){
        Ret = 1;
        for(j=0; j<num_users; j++){
          ret = str_cascade(&ctx[j], GROUP_NAME, NULL,
                             curr_token->token, &tmp);
          printf("\t::::str_cascade of %s returns %d with output %p\n",
                 ctx[j]->member_name,ret, tmp); 
          if(ret <= 0) goto error;
          Ret = MAX(Ret, ret);
          if(tmp != NULL){
            if(output[k] != NULL){
              str_destroy_token(&output[k]);
            }
            output[k] = tmp;
            if(output[k] == NULL) {
              goto error;
            }
            k++;
          }
          tmp=NULL;
        }
        if(Ret == 1) {
          break;
        }
        curr_token = curr_token->next;
      }
      
      input = remove_all_token(input);
      
      for(j=0; j<k; j++){
        input = add_token(input, output[j]);
        output[j] = NULL;
      }
    }
    input=remove_all_token(input);
    
    printf ("----------End of Merge Event\n");
    check_group_secret(ctx, num_users);
    compare_key(ctx, num_users);
    for(i=0; i<num_users; i++){
      if (leaving_list[i] != NULL) free(leaving_list[i]);
      if (current_list[i] != NULL) free(current_list[i]);
    }
  }

#else

















  printf ("---------- Start of Cascaded Event\n");

  list = (STR_LIST *) calloc(sizeof(STR_LIST), 1);
  
  list->num = num_users;
  for(i=0; i<num_users; i++){
    list->list[i] = user[i];
  }

  str_generate_partition(list, ctx);

  init_list = list;
  list = init_list;


  for(round=0; round<2000; round++){
    event = str_generate_random_event(&init_list, list, ctx, round);

    if((event == 10) && (list->token_list != NULL)) {
/*        Ret = process_one_token_list(init_list, list, ctx); */
      Ret = str_process_one_token(init_list, list, ctx);
    }
    
    if(list->next != NULL){
      list = list->next;
    }
    else{
      list = init_list;
    }
    if(round % 100 == 0){
      fprintf(stderr, "round = %d\n", round);
    }
  }

#endif /* End of Basic */  
  
error:
  
  for (i=0; i < NUM_USERS; i++) {
    if (ctx[i] != NULL) str_destroy_ctx(&(ctx[i]), 1);
    if (user[i] != NULL) free(user[i]);
  }
  if(init_list != NULL) str_destroy_list(&init_list);

  return 0;
}

/* This function processes one token list... In Spread state diagram
   notation, this function is called in the NEW_TREE state */
int str_process_one_token_list(STR_LIST *init_list, STR_LIST *list,
                               STR_CONTEXT *ctx[])
{
  int i, k, ret;
  TOKEN_LIST *curr_token=NULL;
  STR_TOKEN *tmp=NULL, *output[NUM_USERS+1]={NULL};
  
  for(i=0; i<NUM_USERS+1; i++) {
    output[i] = NULL;
  }

  k=0;
  curr_token = list->token_list;

  do{
    list->status = 0;
    for(i=0; i<list->num; i++){
      ret = str_cascade(&ctx[atoi(list->list[i])], GROUP_NAME,
                         NULL, curr_token->token, &tmp);
      printf("\t::::str_cascade of %s returns %d with output %p\n",
             list->list[i],ret, tmp);  
      if(ret <= 0) exit(1);
      if(((list->status > 1) && (ret == OK)) &&
         ((list->status == OK) && (ret > 1))){ 
        fprintf(stderr, "WHATTTTT????\n");
      }
      list->status = MAX(list->status, ret);
      if(tmp != NULL){
        if(output[k] != NULL){
          str_destroy_token(&output[k]);
        }
        output[k] = tmp;
        if(output[k] == NULL) {
          exit(1);
        }
        k++;
      }
      tmp=NULL;
    }
    if(list->status == 1) {
      break;
    }
    curr_token = curr_token->next;
  } while (curr_token != NULL);
  
    
  list->token_list = remove_all_token(list->token_list);
    
  for(i=0; i<k; i++){
    list->token_list = add_token(list->token_list, output[i]);
    output[i] = NULL;
  }

  if(list->status == OK){
    str_check_list_secret(ctx, list->list, list->num);
  }

  return list->status;
}

/* This function processes single token... In Spread state diagram
   notation, this function is called in the NEW_TREE state */
int str_process_one_token(STR_LIST *init_list, STR_LIST *list,
                      STR_CONTEXT *ctx[])
{
  int i, k, ret;
  STR_TOKEN *tmp=NULL, *output[NUM_USERS+1]={NULL};
  
  for(i=0; i<NUM_USERS+1; i++) {
    output[i] = NULL;
  }

  k=0;
  list->status = 0;
  for(i=0; i<list->num; i++){
    ret = str_cascade(&ctx[atoi(list->list[i])], GROUP_NAME,
                       NULL, list->token_list->token, &tmp);
    printf("\t::::str_cascade of %s returns %d with output %p\n",
           list->list[i],ret, tmp);  
    if(ret <= 0) exit(1);
    if(((list->status > 1) && (ret == OK)) &&
       ((list->status == OK) && (ret > 1))){ 
      fprintf(stderr, "WHATTTTT????\n");
    }
    list->status = MAX(list->status, ret);
    if(tmp != NULL){
      if(output[k] != NULL){
        str_destroy_token(&output[k]);
      }
      output[k] = tmp;
      if(output[k] == NULL) {
        exit(1);
      }
      k++;
    }
    tmp=NULL;
  }
  list->token_list = remove_token(&(list->token_list));
  if(k>1){
    fprintf(stderr, "Strange!!!");
  }
    
  for(i=0; i<k; i++){
    list->token_list = add_token(list->token_list, output[i]);
    output[i] = NULL;
  }

  if(list->status == OK){
    str_check_list_secret(ctx, list->list, list->num);
  }

  return list->status;
}

/* This function generates a random event for the current group */
int str_generate_random_event(STR_LIST **init_list, STR_LIST *list,
                              STR_CONTEXT *ctx[], int seed)
{
  int num_group=0, event=0;
  STR_LIST *tmp_list=NULL;

  tmp_list = (*init_list);
  while(tmp_list != NULL){
    tmp_list = tmp_list->next;
    num_group++;
  }

  srand(time(0) + seed);
  event = (int) rand() % DEFAULT;

  if(event < CMERGE){
    if(num_group == 1){
      fprintf(stderr, "  *\n");
      return DEFAULT;
    }
    else{
      if(str_generate_merge(&(*init_list), list, ctx) == CMERGE){
        return CMERGE;
      }
      else{
        return DEFAULT;
      }
    }
  }
  else if(event < CPARTITION){
    if(list->num == 1){
      fprintf(stderr, "  *\n");
      return DEFAULT;
    }
    else{
      if(str_generate_partition(list, ctx) == CPARTITION){
        return CPARTITION;
      }
      else{
        return DEFAULT;
      }
    }
  }
  else {
    fprintf(stderr, "  *\n");
  }

  return DEFAULT;
}


/* generate_partition */
int str_generate_partition(STR_LIST *list, STR_CONTEXT *ctx[])
{
  STR_LIST *tmp_list1=NULL, *tmp_list2=NULL;
  int i, num, ret, k=0;
  STR_NAME *tmp_name[NUM_USERS+1];
  STR_TOKEN *tmp=NULL;

  if(list->num < 2){
    fprintf(stderr, "  *\n");
    return DEFAULT;
  }

  if(list->token_list != NULL){
    list->token_list = remove_all_token(list->token_list);
  }
  tmp_list1 = list;
  while(tmp_list1->next != NULL){
    tmp_list1 = tmp_list1->next;
  }

  tmp_list2 = (STR_LIST *) calloc(sizeof(STR_LIST), 1);
  tmp_list1->next = tmp_list2;

  for(i=0; i<NUM_USERS+1; i++){
    tmp_name[i] = list->list[i];
    list->list[i] = NULL;
  }
  
  num = list->num;
  list->num = 1;
  list->list[0] = tmp_name[0];
  tmp_list2->num = 1;
  tmp_list2->list[0] = tmp_name[1];
  
  for(i=2; i<num; i++){
    if((int)rand() %2){
      tmp_list2->list[tmp_list2->num] = tmp_name[i];
      tmp_list2->num++;
    }
    else{
      list->list[list->num] = tmp_name[i];
      list->num++;
    }
  }

  k=0;
  fprintf(stderr, "++Partition happened %d:%d\n", list->num, tmp_list2->num);
  for(i=0; i<list->num; i++){
    ret = str_cascade(&ctx[atoi(list->list[i])], GROUP_NAME,
                       tmp_list2->list, NULL, &tmp);
    printf("\t::::str_cascade of %s returns %d with output %p\n",
           list->list[i],ret, tmp); 
    if(ret <= 0) exit(ret);
    if(tmp != NULL){
      k++;
      list->token_list = add_token(list->token_list, tmp);
      tmp = NULL;
    }
    tmp=NULL;
  }
  if(k>1){
    fprintf(stderr, "%d ", k);
    fprintf(stderr, "Strange!!!");
  }

  k=0;
  for(i=0; i<tmp_list2->num; i++){
    ret = str_cascade(&ctx[atoi(tmp_list2->list[i])], GROUP_NAME,
                       list->list, NULL, &tmp);
    printf("\t::::str_cascade of %s returns %d with output %p\n",
           tmp_list2->list[i],ret,tmp); 
    if(ret <= 0) exit(ret);
    if(tmp != NULL){
      k++;
      tmp_list2->token_list = add_token(tmp_list2->token_list, tmp);
      tmp = NULL;
    }
  }
  if(k>1){
    fprintf(stderr, "Strange!!!");
  }

  return CPARTITION;
}

/* generate_merge */
int str_generate_merge(STR_LIST **init_list, STR_LIST *list,
                       STR_CONTEXT *ctx[]) 
{
  STR_LIST *tmp_list1=NULL, *tmp_list2=NULL;
  int i=0, num=0, ret=0, k=0;
  int num_group=0;
  STR_TOKEN *tmp=NULL;
  TOKEN_LIST *tmp_token_list=NULL;

  if((*init_list) == list){
    fprintf(stderr, "  *\n");
    return DEFAULT;
  }

  tmp_list1 = (*init_list);
  while(tmp_list1 != NULL){
    num_group++;
    tmp_list1 = tmp_list1->next;
  }

  num = (int)(rand()) % num_group;

  tmp_list1 = (*init_list);

  for(i=0; i<num; i++){
    tmp_list1 = tmp_list1->next;
  }
  if(tmp_list1 == list){
    fprintf(stderr, "  *\n");
    return DEFAULT;
  }
  
  tmp_list1 = (*init_list);

  if(num == 0){
    tmp_list2 = (*init_list);
    (*init_list) = (*init_list)->next;
  }
  else{
    for(i=0; i<num-1; i++){
      tmp_list1 = tmp_list1->next;
    }
    tmp_list2 = tmp_list1->next;
    if(tmp_list2->next != NULL){
      tmp_list1->next = tmp_list2->next;
    }
    else{
      tmp_list1->next = NULL;
    }
  }
  
  for(i=0; i<tmp_list2->num; i++){
    list->list[i+list->num] = tmp_list2->list[i];
  }
  list->num += tmp_list2->num;
  tmp_list2->next = NULL;

  fprintf(stderr, "++Merge happened %d\n", list->num);

  str_destroy_list(&tmp_list2);
  list->token_list = remove_all_token(list->token_list); 

  for(i=0; i<list->num; i++){
    ret=str_merge_req(ctx[atoi(list->list[i])], list->list[i],
                       GROUP_NAME, &tmp); 
    printf ("\t::str_merge_req of %s returns %d with output %p\n",
            list->list[i],ret,tmp);
    if (ret!=1) {
      exit(0);
    }
    if(tmp != NULL){
      list->token_list = add_token(list->token_list, tmp);
    }
    tmp=NULL;
  }
  if(list->token_list == NULL) {
    exit(0);
  }

  k=0;
  while(list->token_list != NULL){
    for(i=0; i<list->num; i++){
      ret = str_cascade(&ctx[atoi(list->list[i])], GROUP_NAME, NULL,
                         list->token_list->token, &tmp);
      printf("\t::::str_cascade of %s returns %d with output %p\n",
             list->list[i],ret, tmp); 
      if(ret <= 0){
        exit(0);
      }
      if(tmp != NULL){
        k++;
        tmp_token_list = add_token(tmp_token_list, tmp);
      }
      tmp=NULL;
    }
    list->token_list = remove_token(&(list->token_list));
  }
  list->token_list = tmp_token_list;
  if(k>1){
    fprintf(stderr, "Strange!!!");
  }

  return CMERGE;
}


/* destroy_list */
void str_destroy_list(STR_LIST **list)
{
  STR_LIST *tmp_list=NULL;

  tmp_list = (*list)->next;
  while((*list) != NULL){
    if((*list)->token_list != NULL){
      (*list)->token_list = remove_all_token((*list)->token_list);
    }
    free(*list);
    (*list) = tmp_list;
    if((*list) == NULL){
      break;
    }
    else{
      tmp_list = (*list)->next;
    }
  }

  return;
}

void str_check_list_secret (STR_CONTEXT *ctx[], STR_NAME *list[], int num) {
  int i;
  int same=TRUE;
  
  for (i=1; i < num; i++) {
    if (ctx[atoi(list[i])]->group_secret !=NULL) {
      if (BN_cmp(ctx[atoi(list[0])]->group_secret, ctx[atoi(list[i])]->group_secret)){ 
        same=FALSE;
      }
    }
    else {
      same = FALSE;
    }
  }
  
  if (same){
#ifdef DEBUG_ALL
    printf ("Group secret is the same in the entire group :)\n");
#endif
  }
  else{
    printf ("Group secret is NOT the same :(\n");
    exit(0);
  }
  
}

#ifdef TIMING

double str_gettimeofday(void) {
  struct timeval used;
  
  gettimeofday(&used, 0);
  /*    printf (":%ld %ld:\n", used.tv_sec, used.tv_usec); */
  return (used.tv_sec + (double)((used.tv_usec) / 1e6));
}


#endif
