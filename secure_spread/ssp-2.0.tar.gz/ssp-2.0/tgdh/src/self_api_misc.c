/* CLIQUES Non-Commercial License (covers BD, CLQ, STR and TGDH
libraries).  Copyright (c) 1998-2002 by the University of California,
Irvine.  All rights reserved.

Permission to use, copy, modify, and distribute this software and its
documentation in source and binary forms for lawful non-commercial
purposes and without fee is hereby granted, provided that the above
copyright notice appear in all copies and that both the copyright
notice and this permission notice appear in supporting documentation,
and that any documentation, advertising materials, and other materials
related to such distribution and use acknowledge that the software was
developed by the University of California, Irvine, Information and
Computer Science Department. The name of University of California,
Irvine may not be used to endorse or promote products derived from
this software without specific prior written permission.

THE UNIVERSITY OF CALIFORNIA, IRVINE MAKES NO REPRESENTATIONS ABOUT
THE SUITABILITY OF THIS SOFTWARE FOR ANY PURPOSE.  THIS SOFTWARE IS
PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND
NON-INFRINGEMENT.

IN NO EVENT SHALL UNIVERSITY OF CALIFORNIA, IRVINE OR ANY OTHER
CONTRIBUTOR BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
DAMAGES, WHETHER IN CONTRACT, TORT, OR OTHER FORM OF ACTION, ARISING
OUT OF OR IN CONNECTION WITH, THE USE OR PERFORMANCE OF THIS SOFTWARE.

All questions concerning this software should be directed to
cliques@ics.uci.edu. */



/*********************************************************************
 * self_api_misc.c                                                   * 
 * TREE api miscellaneous source file.                               * 
 * Date      Tue Nov 21 22:08:07 PST 2000                            *
 * Wrote by:                                                         * 
 * Yongdae Kim                                                       *
 *                                                                   *
 * CLIQUES Project                                                   *
 * Information Sciences Institute                                    *
 * University of Southern California                                 *
 *********************************************************************/

#include <stdio.h>
/* The next three are needed for creat() in self_gen_params */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <string.h>
#include <unistd.h>
#include <malloc.h>

#ifdef TIMING
/* Needed by getrusgae */
#include <sys/time.h>
#include <sys/resource.h>
#include <unistd.h>

int print=1;

#endif

/* SSL include files */
#include "bio.h"
#include "dsa.h"
#include "bn.h"
#include "rand.h"
#include "md5.h"

/* SELF_API include files */
#include "self_api.h"
#include "self_api_misc.h"

/* dmalloc CNR.  */
#ifdef USE_DMALLOC
#include <dmalloc.h>
#endif


#ifdef MEMCHECK
int number_malloc[length_memcheck];
int number_free[length_memcheck];
#endif

int self_print_dsa(DSA *dsa) {
  char *tmp;
  
  if (dsa == NULL) { 
    fprintf(ERR_STRM,"Invalid DSA structure.\n"); 
    return 0;
  }

  fprintf(ERR_STRM,"\n--- begin DSA structure ---\n");
  fprintf(ERR_STRM,"Size: %d\n\n",dsa->p==NULL ? 0: BN_num_bits(dsa->p));
  tmp=BN_bn2hex(dsa->p);
  fprintf(ERR_STRM,"p = %s\n", tmp==NULL ? "n.d.": tmp);
  free(tmp); tmp=BN_bn2hex(dsa->q);
  fprintf(ERR_STRM,"q = %s\n", tmp==NULL ? "n.d.": tmp);
  free(tmp); tmp=BN_bn2hex(dsa->g);
  fprintf(ERR_STRM,"g = %s\n\n", tmp==NULL ? "n.d.": tmp);
  free(tmp); tmp=BN_bn2hex(dsa->priv_key);
  fprintf(ERR_STRM,"secr = %s\n", tmp==NULL ? "n.d.": tmp);
  free(tmp); tmp=BN_bn2hex(dsa->pub_key);
  fprintf(ERR_STRM,"pub  = %s\n", tmp==NULL ? "n.d.": tmp);
  free (tmp);
  fprintf(ERR_STRM,"\n--- end DSA structure ---\n");

  return 1;
}

void self_print_ctx(char *name, SELF_CONTEXT *ctx){

  fprintf(ERR_STRM,"\n--- %s ---\n\t", name);
  if(ctx == NULL) {
    fprintf(ERR_STRM,"CTX for %s is null\t", name);
    return;
  }
  if(ctx->member_name != NULL)
    fprintf(ERR_STRM,"name     = %s\t", ctx->member_name);
  else fprintf(ERR_STRM,"name     = NULL\t");
  if(ctx->group_name != NULL)
    fprintf(ERR_STRM,"group    = %s\t", ctx->group_name);
  else fprintf(ERR_STRM,"group    = NULL\t");
  if(ctx->group_secret != NULL){
    fprintf(ERR_STRM,"grpsecret= ");
    BN_print_fp(ERR_STRM, ctx->group_secret);
    fprintf(ERR_STRM,"\n");
  }
  else fprintf(ERR_STRM,"grpsecret= NULL\n");
  if(ctx->epoch != (int)NULL){
    fprintf(ERR_STRM,"epoch= %d\n", ctx->epoch);
  }
  else fprintf(ERR_STRM,"epoch= NULL\n");

  self_print_all(name, ctx->root);

  return;
}

void self_simple_ctx_print(SELF_CONTEXT *ctx){
  if(ctx == NULL) fprintf(ERR_STRM, "\n\nTREE is NULL\n");
  else{
    fprintf(stderr, "\n\n========TREE for member %s ========\n",
            ctx->member_name);  
    self_simple_node_print(ctx->root);
  }
}

void self_simple_node_print(KEY_TREE *tree){
  KEY_TREE *tmp_tree=NULL;
    int power2[16]={0x1, 0x2, 0x4, 0x8, 0x10, 0x20, 0x40, 0x80, 0x100,
                    0x200, 0x400, 0x800, 0x1000, 0x2000, 0x4000, 0x8000};

  int i=0, k=0;

  /*
    for(i=2; i<(int)pow(2, tree->self_nv->height+2); i += 2){
    for(j=0; j<8; j++){
    if(i == power2[j]) {
    fprintf(stderr, "\n");
    for(k=0; k<(int)(pow(2, tree->self_nv->height+2)/i) - 2; k++)
    fprintf(stderr, " ");
    }
    }
    
    tmp_tree = self_search_index(tree, i);
    if(tmp_tree == NULL) fprintf(ERR_STRM,"   ");
    else{
    if(tmp_tree->self_nv->key != NULL) fprintf(ERR_STRM, "+ ");
    else fprintf(ERR_STRM, "- ");
    if(tmp_tree->self_nv->bkey != NULL) fprintf(ERR_STRM, "+");
    else fprintf(ERR_STRM, "-");
    }
    for(k=0; k<(int)(pow(2, tree->self_nv->height+3 - 
    (int)(log(i)/log(2)))) - 3; k++)
    fprintf(stderr, " ");
    }
  */
                              
  for(i=1; i<(int)pow(2, tree->self_nv->height); i++){
    if(log(i)/log(2) - log2(i) < 0.0001) {
      fprintf(stderr, "\n");
      for(k=0; k<power2[tree->self_nv->height-log2(i)-1]-1; k++)
        fprintf(stderr, " ");
    }
    else{
      for(k=0; k<power2[tree->self_nv->height-log2(i-1)]-1; k++)
        fprintf(stderr, " ");
    }

    tmp_tree = self_search_number(tree, i);
    if(i==1) fprintf(ERR_STRM,"1");
    else if(tmp_tree == NULL) fprintf(ERR_STRM," ");
    else if(tmp_tree->self_nv->index) fprintf(ERR_STRM,"%d",tmp_tree->self_nv->index);
    else fprintf(ERR_STRM," ");
    
  }
  
}

/* self_search_number: Returns the node having the index
 */
KEY_TREE *self_search_number(KEY_TREE *tree, int index)
{
  int height=0;
  int i;
  KEY_TREE *tmp_tree;
  
  height = log2(index);
  
  tmp_tree = tree;
  
  for(i=1; i<=height; i++){
    if((index >> (height-i)) & 0x1){
      if(tmp_tree->right == NULL) return NULL;
      else tmp_tree = tmp_tree->right;
    }
    else{
      if(tmp_tree->left == NULL) return NULL;
      else tmp_tree = tmp_tree->left;
    }
  }
  
  return tmp_tree;
}

void self_print_node(char *name, KEY_TREE *tree) {
  fprintf(ERR_STRM,"\n\t---tree print %s ---\n\t", name);
  if(tree->self_nv != NULL){
    fprintf(ERR_STRM,"index     = %d\t", tree->self_nv->index);
    if(tree->self_nv->joinQ == TRUE)
      fprintf(ERR_STRM,"joinQ     = %d\t", tree->self_nv->joinQ);
    else fprintf(ERR_STRM,"joinQ     = FALSE\t");
    if(tree->self_nv->potential > -2) 
      fprintf(ERR_STRM,"potential = %d\t", tree->self_nv->potential);
    else fprintf(ERR_STRM,"potential = NULL\t");
    if(tree->self_nv->height > -2)
      fprintf(ERR_STRM,"height    = %d\t", tree->self_nv->height);
    else fprintf(ERR_STRM,"height    = NULL\t");
    if(tree->self_nv->num_node > -2)
      fprintf(ERR_STRM,"num_node  = %d\n\t", tree->self_nv->num_node);
    else fprintf(ERR_STRM,"num_node  = NULL\n\t");
    if(tree->self_nv->key != NULL){
      fprintf(ERR_STRM,"key  = ");
      BN_print_fp(ERR_STRM, tree->self_nv->key);
    }
    else fprintf(ERR_STRM,"key  = NULL");
    if(tree->self_nv->bkey != NULL){
      fprintf(ERR_STRM,"\n\tbkey = ");
      BN_print_fp(ERR_STRM, tree->self_nv->bkey);
    }
    else fprintf(ERR_STRM,"\n\tbkey = NULL");
    fprintf(ERR_STRM,"\n\tmypt      = %x\t", (int)tree);
    if(tree->self_nv->member != NULL){
      if(tree->self_nv->member->member_name != NULL)
        fprintf(ERR_STRM,"name      = %s\n\t", tree->self_nv->member->member_name);
      else fprintf(ERR_STRM, "name     = NULL\n\t");  
      if(tree->self_nv->member->cert != NULL)
        fprintf(ERR_STRM,"cert      = %x\n\t", (int)tree->self_nv->member->cert);
      else fprintf(ERR_STRM, "cert     = NULL\n\t");  
    }
    if(tree->parent != NULL)
      fprintf(ERR_STRM,"prntpt    = %x\t", (int)tree->parent);
    if(tree->left != NULL)
      fprintf(ERR_STRM,"leftpt    = %x\t", (int)tree->left);
    if(tree->right != NULL)
      fprintf(ERR_STRM,"rightpt   = %x\t", (int)tree->right);
    if(tree->prev != NULL)
      fprintf(ERR_STRM,"prevpt    = %x\t", (int)tree->prev);
    if(tree->next != NULL)
      fprintf(ERR_STRM,"nextpt    = %x\t", (int)tree->next);
  }
  
  return;
}

void self_print_all(SELF_NAME *name, KEY_TREE *tree) {
  if(tree == NULL) return;
  self_print_node(name,tree);
  self_print_all(name, tree->left);
  self_print_all(name, tree->right);
}

void self_print_simple(SELF_NAME *name, KEY_TREE *tree) {
  if(tree == NULL) return;
  self_print_bkey(name,tree);
  self_print_simple(name, tree->left);
  self_print_simple(name, tree->right);
}

void self_print_bkey(char *name, KEY_TREE *tree) {
  fprintf(ERR_STRM,"%s ", name);
  if(tree->self_nv != NULL){
    fprintf(ERR_STRM,"ind = %02d ", tree->self_nv->index);
    if(tree->self_nv->member != NULL){
      if(tree->self_nv->member->member_name != NULL)
        fprintf(ERR_STRM,"name = %s ", tree->self_nv->member->member_name);
      else fprintf(ERR_STRM, "name = NUL ");  
    }
    else fprintf(ERR_STRM, "name = NUL ");  
    if(tree->self_nv->bkey != NULL){
      fprintf(ERR_STRM,"bkey = %lu", *(tree->self_nv->bkey->d));
    }
    else fprintf(ERR_STRM,"bkey = NUL       ");
    if(tree->self_nv->key != NULL){
      fprintf(ERR_STRM," key = %lu", *(tree->self_nv->key->d));
    }
    else fprintf(ERR_STRM," key = NUL");
    fprintf(ERR_STRM,"\n");
  }
  
  return;
}

int compare_key(SELF_CONTEXT *ctx[], int num) {
  int i=0;
  BIGNUM *tmp_key=0;

  for(i=0; i<num; i++)
    if(ctx[i])
      if(ctx[i]->root->self_nv->key)
        tmp_key=ctx[i]->root->self_nv->key;
    
  for(i=0; i<num; i++){
    if(ctx[i] != NULL){
      if(BN_cmp(tmp_key, ctx[i]->root->self_nv->key) != 0){
        fprintf(stderr, "()()())(()()()()()()()()()\n");
        return -1;
      }
    }
    else{
      printf("***************Some context is empty\n");
    }
  }
  
#ifdef DEBUG_ALL    
  fprintf(stderr, "\n\n\nAll right... All keys are same!!!\n");
  fprintf(stderr, "All right... All keys are same!!!\n");
  fprintf(stderr, "All right... All keys are same!!!\n");
#endif
  
  return 1;
}

#ifdef TIMING

#define strm stderr

void self_print_times(char *str, double time) {

  if (print) {
    fprintf (strm, "<- %s\n",str);
    fprintf (strm, " Total Time: %f sec\n", time);
    fprintf (strm, "   %s ->\n",str);
  }
}

/* Old version of self_print_times that was used in conjunction with
   gettimeof day 6/3/99 Dmn.- */
/*
void self_print_times(char *str,struct timeval t_initial, struct timeval
		     t_final) {

  if (print) {
  fprintf (strm, "<- %s\n",str);
  fprintf (strm," Total Secs: %ld uSecs: %ld\n",    
	   t_final.tv_usec > t_initial.tv_usec ?
	   t_final.tv_sec-t_initial.tv_sec :
	   t_final.tv_sec-1-t_initial.tv_sec,  
	   t_final.tv_usec > t_initial.tv_usec ?
	   (t_final.tv_usec-t_initial.tv_usec) :
	   (t_final.tv_usec+1000000-t_initial.tv_usec)); 
  fprintf (strm, "   %s ->\n",str);
  }
}
*/

double self_get_time(void) {
  struct rusage used;
  
  getrusage(RUSAGE_SELF, &used);
  /*
  printf (":%ld %ld %ld %ld:\n", used.ru_utime.tv_sec, used.ru_utime.tv_usec,
	  used.ru_stime.tv_sec, used.ru_stime.tv_usec);
	  */
  return (used.ru_utime.tv_sec + used.ru_stime.tv_sec +
	  (used.ru_utime.tv_usec + used.ru_stime.tv_usec) / 1e6);
}


#endif

/* self_get_secret: Returns in a static variable with
 * ctx->group_secret_hash 
 */ 
tgdh_uchar *self_get_secret(SELF_CONTEXT *ctx) {
  static tgdh_uchar tmp[MD5_DIGEST_LENGTH];

  memcpy (tmp,ctx->group_secret_hash,MD5_DIGEST_LENGTH);

  return tmp;
}

void self_print_group_secret(SELF_CONTEXT *ctx) {
  int i;

  fprintf(ERR_STRM,"Group Secret (MD5): ");
  if (ctx->group_secret_hash == NULL) fprintf (ERR_STRM,"EMPTY");
  else {
    for (i=0; i < MD5_DIGEST_LENGTH; i++) 
      fprintf(ERR_STRM, "%02X",ctx->group_secret_hash[i]);
  }

  fprintf(ERR_STRM,"\n");
}

/* cmp_str: Returns 1 if input1 is greater,
 *          Returns -1 if input2 is greater,
 *          0 otherwise 
 */
int cmp_str(char *input1, char *input2)
{
  int i=0, j=0;
  
  while((int)input1[i] != 0){
    if((int)input2[i] == 0){
      break;
    }
    i++;
  }
  if(((int)input2[i] == 0) && ((int)input1[i] != 0)){
    return 1;
  }
  if((int)input2[i] != 0){
    return -1;
  }
  for(j=i-1; j>-1; j--){
    if((int)input1[j] > (int)input2[j]){
      return 1;
    }
    if((int)input1[j] < (int)input2[j]){
      return -1;
    }
  }

  return 0;
}

#ifdef MEMCHECK
/* increment counter */
void add_alloc(int which)
{
  number_malloc[which]++;
}
void add_free(int which)
{
  number_free[which]++;
}
void print_count()
{
  int i=0;
  
  for(i=0; i<length_memcheck; i++)
    printf("malloc%d - free%d = %d - %d = %d\n", i, i,
           number_malloc[i], number_free[i],
           number_malloc[i]-number_free[i]); 
}

#endif
