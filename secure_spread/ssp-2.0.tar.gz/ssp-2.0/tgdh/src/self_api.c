/* CLIQUES Non-Commercial License (covers BD, CLQ, STR and TGDH
libraries).  Copyright (c) 1998-2002 by the University of California,
Irvine.  All rights reserved.

Permission to use, copy, modify, and distribute this software and its
documentation in source and binary forms for lawful non-commercial
purposes and without fee is hereby granted, provided that the above
copyright notice appear in all copies and that both the copyright
notice and this permission notice appear in supporting documentation,
and that any documentation, advertising materials, and other materials
related to such distribution and use acknowledge that the software was
developed by the University of California, Irvine, Information and
Computer Science Department. The name of University of California,
Irvine may not be used to endorse or promote products derived from
this software without specific prior written permission.

THE UNIVERSITY OF CALIFORNIA, IRVINE MAKES NO REPRESENTATIONS ABOUT
THE SUITABILITY OF THIS SOFTWARE FOR ANY PURPOSE.  THIS SOFTWARE IS
PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND
NON-INFRINGEMENT.

IN NO EVENT SHALL UNIVERSITY OF CALIFORNIA, IRVINE OR ANY OTHER
CONTRIBUTOR BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
DAMAGES, WHETHER IN CONTRACT, TORT, OR OTHER FORM OF ACTION, ARISING
OUT OF OR IN CONNECTION WITH, THE USE OR PERFORMANCE OF THIS SOFTWARE.

All questions concerning this software should be directed to
cliques@ics.uci.edu. */


/*********************************************************************
 * self_api.c                                                        * 
 * Broadcast based Group Key Ageement Scheme                         * 
 * Date      Tue Nov 21 22:08:07 PST 2000                            *
 * Wrote by:                                                         * 
 * Yongdae Kim                                                       *
 *                                                                   *
 * CLIQUES Project                                                   *
 * Information Sciences Institute                                    *
 * University of Southern California                                 *
 *********************************************************************/

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <strings.h>
#include <malloc.h>
#include <math.h>

#include <netinet/in.h> /* Needed by htonl and ntohl */

/* SSL include files */
#include "openssl/bn.h"
#include "openssl/bio.h"
#include "openssl/md5.h"
#include "openssl/err.h"
#include "openssl/dsa.h"

/* SELF_API include files */
#include "self_api.h"
#include "self_error.h"
#include "self_cert.h" /* self_get_cert is here */

#include "self_sig.h"
#include "self_test_misc.h" /* self_get_time is defined here */

#include "self_api_misc.h" /* self_get_time is defined here */


/* dmalloc CNR.  */
#ifdef USE_DMALLOC
#include <dmalloc.h>
#endif

/* self_new_member is called by the new member in order to create its
 *   own context. Main functionality of this function is to generate
 *   session random for the member
 */
int self_new_member(SELF_CONTEXT **ctx, SELF_NAME *member_name,
                    SELF_NAME *group_name)
{
  int ret=OK;

  if(member_name == NULL) return INVALID_MEMBER_NAME;
  if ((strlen(member_name) == 0) ||
      (strlen(member_name) > MAX_LGT_NAME)) return INVALID_LGT_NAME;
  if (group_name == NULL) return INVALID_GROUP_NAME;
  if ((strlen(group_name) == 0) ||
      (strlen(group_name) > MAX_LGT_NAME)) return INVALID_LGT_NAME;
  
  if ((ret=self_create_ctx(ctx)) != OK) {goto error;}
  
  (*ctx)->member_name=(SELF_NAME *) calloc(sizeof(SELF_NAME)*MAX_LGT_NAME,1);
  if (((*ctx)->member_name) == NULL) { ret=MALLOC_ERROR; goto error; }
  strncpy((*ctx)->member_name,member_name,MAX_LGT_NAME);
  (*ctx)->group_name=(SELF_NAME *) calloc(sizeof(SELF_NAME)*MAX_LGT_NAME,1);
  if (((*ctx)->group_name) == NULL) { ret=MALLOC_ERROR; goto error; }
  strncpy((*ctx)->group_name,group_name,MAX_LGT_NAME);
  /* Get DSA parameters */
  (*ctx)->params=self_read_dsa(NULL,SELF_PARAMS);
  if ((*ctx)->params == (DSA *)NULL) { ret=INVALID_DSA_PARAMS; goto error; }
  /* Get user private and public keys */
  (*ctx)->pkey=self_get_pkey(member_name);
  if (((*ctx)->pkey) == (EVP_PKEY*) NULL) { ret=INVALID_PRIV_KEY; goto error; }
  
  (*ctx)->root->self_nv=(SELF_NV *) calloc(sizeof(SELF_NV),1);
  (*ctx)->root->self_nv->member = (SELF_GM *) calloc(sizeof(SELF_GM),1);
  (*ctx)->root->self_nv->member->member_name=(SELF_NAME *)
    calloc(sizeof(SELF_NAME)*MAX_LGT_NAME,1); 
  strncpy ((*ctx)->root->self_nv->member->member_name,
           (*ctx)->member_name,MAX_LGT_NAME);
  (*ctx)->root->self_nv->member->cert = NULL;
  
  (*ctx)->root->self_nv->index=1;
  (*ctx)->root->self_nv->num_node=1;
  (*ctx)->root->self_nv->height=0;
  (*ctx)->root->self_nv->potential=-1;
  (*ctx)->root->self_nv->joinQ=FALSE;
  
  /* I'm only member in my group... So key is same as my session random */
  (*ctx)->root->self_nv->key=self_rand((*ctx)->params);
  if (BN_is_zero((*ctx)->root->self_nv->key) ||
      (*ctx)->root->self_nv->key==NULL){
    ret=MALLOC_ERROR;
    goto error;
  }
  /* group_secret is same as key */
  if((*ctx)->group_secret == NULL){
    (*ctx)->group_secret=BN_dup((*ctx)->root->self_nv->key);
    if ((*ctx)->group_secret == (BIGNUM *) NULL) {
      ret=MALLOC_ERROR;
      goto error;
    }
  }
  else{
    BN_copy((*ctx)->group_secret,(*ctx)->root->self_nv->key);
  }
  
  ret=self_compute_secret_hash ((*ctx));
  if (ret!=OK) goto error;
  (*ctx)->root->self_nv->member->cert=NULL;
  
  /* Compute blinded Key */
  (*ctx)->root->self_nv->bkey=
    self_compute_bkey((*ctx)->root->self_nv->key, (*ctx)->params);
  if((*ctx)->root->self_nv->bkey== NULL){
    ret=MALLOC_ERROR;
    goto error;
  }
  (*ctx)->tmp_key = (*ctx)->tmp_bkey = NULL;
  (*ctx)->status = OK;

error:
  /* OK... Let's free the memory */
  if (ret!=OK) self_destroy_ctx(&(*ctx),1);
  
  return ret;
}

/* self_merge_req is called by every members in both groups and only
 * the sponsors will return a output token
 *   o When any addtive event happens this function will be called.
 *   o In other words, if merge and leave happen, we need to call this
 *     function also.
 *   o If only addtive event happens, users_leaving should be NULL.
 *   ctx: context of the caller
 *   member_name: name of the caller
 *   users_leaving: name of the leaving members
 *   group_name: target group name
 *   output: output token(input token of self_merge)
 */
int self_merge_req (SELF_CONTEXT *ctx, SELF_NAME *member_name, 
                    SELF_NAME *group_name, SELF_NAME *users_leaving[],
                    SELF_TOKEN **output)
{
  int ret=OK;
  SELF_TOKEN_INFO *info=NULL;
  KEY_TREE *tmp_tree=NULL, *tmp1_tree=NULL;

  KEY_TREE *the_sponsor=NULL;
  int sponsor = 0;
  BN_CTX *bn_ctx=BN_CTX_new();
  
  if (ctx == NULL) return CTX_ERROR;
  if (member_name == NULL) return INVALID_MEMBER_NAME;
  if ((strlen(member_name) == 0) ||
      (strlen(member_name) > MAX_LGT_NAME)) return INVALID_LGT_NAME;
  if (group_name == NULL) return INVALID_GROUP_NAME;
  if ((strlen(group_name) == 0) ||
      (strlen(group_name) > MAX_LGT_NAME)) return INVALID_LGT_NAME;

  /* If there was any cache, we need to remove it, since we have
   * cascaded event
   */
  if(ctx->cache != NULL){
    self_free_tree(&ctx->cache);
  }

  if(users_leaving != NULL){
    if(ctx->cache != NULL){
      self_free_tree(&(ctx->cache));
    }
    ret = remove_member(ctx, users_leaving, &the_sponsor);
    if(ret == 4){
      ret = OK;
      goto error;
    }
    else{
      if(ret < 0){
        goto error;
      }
    }
  }

  /* If we want change key and if I am not the root node */
  tmp_tree = self_search_member(ctx->root, 4, ctx->member_name);
  
  if((the_sponsor == NULL) && (tmp_tree != ctx->root) ){
    the_sponsor = self_search_member(ctx->root, 3, NULL);
    if(the_sponsor == NULL){
      fprintf(stderr, "The sponsor is NULL!\n");
      ret = SELF_STRUCTURE_ERROR;
      goto error;
    }
    else{
#ifdef DEBUG_YD
      fprintf(stderr, "The sponsor is %s\n",
              the_sponsor->self_nv->member->member_name);
#endif
    }
  }

  if (the_sponsor == NULL){
    /*
     * This means that I am the only member in my tree. So we don't
     * need to change key... We just need to broadcast, since I am the
     * sponsor
     */
    sponsor = 1;
    ret = OK;
    goto error;
  }

  /* Remove keys and bkeys related with the sponsor */
  tmp_tree = the_sponsor;
  while(tmp_tree != NULL){
    if(tmp_tree->self_nv->bkey != NULL){
      BN_clear_free(tmp_tree->self_nv->bkey);
      tmp_tree->self_nv->bkey = NULL;
    }
    if(tmp_tree->self_nv->key != NULL){
      BN_clear_free(tmp_tree->self_nv->key);
      tmp_tree->self_nv->key = NULL;
    }
    tmp_tree = tmp_tree->parent;
  }

  /* If I am not the sponsor, quietly go out */
  if(strcmp(the_sponsor->self_nv->member->member_name,
            ctx->member_name)!=0){ 
    ret = OK;
    goto error;
  }

  /* Now, I am the sponsor */

  /* Every change on key value needs to be done on the cache */
  ctx->cache = self_dup_tree(ctx->root);

  /* Generate new key and bkeys for the sponsor */
  the_sponsor->self_nv->key=self_rand(ctx->params);
  if(ctx->tmp_key != NULL){
    BN_clear_free(ctx->tmp_key);
  }
  ctx->tmp_key = BN_dup(the_sponsor->self_nv->key);
  the_sponsor->self_nv->bkey=
    self_compute_bkey(the_sponsor->self_nv->key, ctx->params);
  if(ctx->tmp_bkey != NULL){
    BN_clear_free(ctx->tmp_bkey);
  }
  ctx->tmp_bkey = BN_dup(the_sponsor->self_nv->bkey);
  sponsor = 1;
  
  /* Now compute every key and bkey */
  tmp_tree = the_sponsor;

  if(tmp_tree->parent->self_nv->key != NULL){
    fprintf(stderr, "Parent key is not null 1!\n");
    ret = SELF_STRUCTURE_ERROR;
    goto error;
  }
  if(tmp_tree->self_nv->index % 2){
    tmp1_tree = tmp_tree->parent->left;
  }
  else{
    tmp1_tree = tmp_tree->parent->right;
  }
  while(tmp1_tree->self_nv->bkey != NULL){
    /* Compute intermediate keys until I can */
    if(tmp_tree->parent->self_nv->key != NULL){
      fprintf(stderr, "Parent key is not null 2!\n");
      ret=SELF_STRUCTURE_ERROR;
      goto error;
    }
    tmp_tree->parent->self_nv->key = BN_new();
    sponsor = 1;
    if(tmp_tree->parent->left->self_nv->key != NULL){
      ret = BN_mod(tmp_tree->parent->left->self_nv->key,
                   tmp_tree->parent->left->self_nv->key,   
                   ctx->params->q, bn_ctx);
      if(ret != OK) goto error;
      
      ret=BN_mod_exp(tmp_tree->parent->self_nv->key, 
                     tmp_tree->parent->right->self_nv->bkey,
                     tmp_tree->parent->left->self_nv->key,
                     ctx->params->p,bn_ctx);
    }
    else{
      ret = BN_mod(tmp_tree->parent->right->self_nv->key,
                   tmp_tree->parent->right->self_nv->key,   
                   ctx->params->q, bn_ctx);
      if(ret != OK) goto error;
      ret=BN_mod_exp(tmp_tree->parent->self_nv->key,
                     tmp_tree->parent->left->self_nv->bkey,
                     tmp_tree->parent->right->self_nv->key,
                     ctx->params->p,bn_ctx);
    }
    if(ret != OK) {
      fprintf(stderr, "mod exp problem\n");
      goto error;
    }
    
    /* Compute bkeys */
    if(tmp_tree->parent->self_nv->bkey != NULL){
      BN_clear_free(tmp_tree->parent->self_nv->bkey);
      tmp_tree->parent->self_nv->bkey=NULL;
    }
    tmp_tree->parent->self_nv->bkey
      =self_compute_bkey(tmp_tree->parent->self_nv->key, ctx->params);
    
    if(tmp_tree->parent->parent == NULL) {
      break;
    }
    else{
      tmp_tree = tmp_tree->parent;
    }
    if(tmp_tree->self_nv->index % 2){
      tmp1_tree = tmp_tree->parent->left;
    }
    else{
      tmp1_tree = tmp_tree->parent->right;
    }
  }
  

error:
  if(sponsor==1){
    /* Creating token info */
    ret=self_create_token_info(&info,ctx->group_name,TGDH_KEY_MERGE_UPDATE, 
                               time(0),ctx->member_name); 
    /* Encoding */
    if(ret == 1){
      ret=self_encode(ctx,output,info);
    }
    /* sign_message */
    if(ret == 1){
      ret=self_sign_message (ctx, *output);
    }
  }
  
  /* OK... Let's free the memory */
  if (ret!=OK) self_destroy_ctx(&ctx, 1);
  if (info != (SELF_TOKEN_INFO*)NULL) self_destroy_token_info(&info);
  if (ctx->cache != NULL){
    swap((void *)&(ctx->cache), (void *)&(ctx->root));
  }
  if (bn_ctx != NULL) BN_CTX_free (bn_ctx);
  
  return ret;
}

/* self_cascade is called by every member several times until every
 * member can compute the new group key when any network events occur.
 * o this function handles every membership event, e.g. join, leave,
 *   merge, and partition.
 * o this function handles any cascaded events.
 * o this funciton is self-stabilizing.
 * o sponsors are decided uniquely for every membership event, and
 *   only the sponsors return an output
 *   - ctx: context of the caller
 *   - member_name: name of the caller
 *   - users_leaving: list of the leaving members, used only for
 *       subtractive events
 *   - input: Input token(previous output token of
 *       self_cascade or join or merge request) 
 *   - output: output token(will be used as next input token of
 *       self_cascade) 
 */
int self_cascade(SELF_CONTEXT **ctx, SELF_NAME *group_name,
                 SELF_NAME *users_leaving[], 
                 TOKEN_LIST *list, SELF_TOKEN **output){
  SELF_TOKEN_INFO *info=NULL;
  SELF_SIGN *sign=NULL;
  int ret=CONTINUE;
  KEY_TREE *tmp_node=NULL, *tmp1_node=NULL;
  
  int i=0;
  int new_information=0;
  int result=OK;
  int new_status=0;
  int new_key_comp=0;
  int need_swap=0;
  BN_CTX *bn_ctx=BN_CTX_new();
  SELF_NAME *sponsor_list[NUM_USERS+1]={NULL};
  KEY_TREE *the_sponsor=NULL;
  int sponsor=0, sender=0;
  int leaveormerge=0;
  int message_type=-1;
  TOKEN_LIST *tmp_list=NULL;
  TREE_LIST *new_tree_list=NULL, *tmp_tree_list=NULL;
  SELF_CONTEXT *new_ctx=NULL;
  
  for(i=0; i<NUM_USERS+1; i++){
    sponsor_list[i]=NULL;
  }
  
  /* Doing some error checkings */
  if ((*ctx) == NULL) return CTX_ERROR;
  if (group_name == NULL) return INVALID_GROUP_NAME;
  if ((strlen(group_name) == 0) ||
      (strlen(group_name) > MAX_LGT_NAME)) return INVALID_LGT_NAME;

  if(users_leaving != NULL){
    leaveormerge = 1;
    if((*ctx)->cache != NULL){
      self_free_tree(&((*ctx)->cache));
    }
    
    result = remove_member(*ctx, users_leaving, &the_sponsor);
    if(result == 4){
      result = (*ctx)->status;
      goto error;
    }
    else{
      if(result < 0){
        goto error;
      }
    }
    
    (*ctx)->cache = self_dup_tree((*ctx)->root);
    need_swap = 1;

    if(strcmp(the_sponsor->self_nv->member->member_name,
              (*ctx)->member_name)== 0){
      new_information = 1;
      new_key_comp = 1;
      the_sponsor->self_nv->key=self_rand((*ctx)->params);
      if((*ctx)->tmp_key != NULL){
        BN_clear_free((*ctx)->tmp_key);
      }
      (*ctx)->tmp_key = BN_dup(the_sponsor->self_nv->key);
      the_sponsor->self_nv->bkey=
        self_compute_bkey(the_sponsor->self_nv->key, (*ctx)->params);
      if((*ctx)->tmp_bkey != NULL){
        BN_clear_free((*ctx)->tmp_bkey);
      }
      (*ctx)->tmp_bkey = BN_dup(the_sponsor->self_nv->bkey);
      sponsor = 1;
    }
  }
  else{ /* This is not leave */
    if(list == NULL) {
      result = INVALID_INPUT_TOKEN;
      printf("This is weird 2\n\n");
        
      goto error;
    }

    tmp_list = list;
    while (tmp_list != NULL){
      result=self_remove_sign(tmp_list->token,&sign);
      if (result != OK) goto error;
        
      /* Decoding the token & creating new_ctx */
      result=self_decode(&new_ctx, tmp_list->token, &info);
      if (result!=OK){
        goto error;
      }
    
      (*ctx)->epoch = MAX((*ctx)->epoch, new_ctx->epoch);
      new_status = new_ctx->status;
      if (strcmp(info->group_name,group_name)){
        result=GROUP_NAME_MISMATCH;
        goto error;
      }
      /* Before merging the tree, we need to verify signature */
      result=self_vrfy_sign ((*ctx), new_ctx, tmp_list->token,
                             info->sender_name, sign);  
      if(result!=OK) goto error;
        
      if(tmp_list->token != NULL){
        result=self_restore_sign(tmp_list->token,&sign);
      }

      tmp_node = self_search_member(new_ctx->root, 4, (*ctx)->member_name);
      if(tmp_node != NULL){  
        /* If I receive my token and if I have cache, I'll install my */
        /* cache information to the original tree */
        if((strcmp(info->sender_name, (*ctx)->member_name)==0) &&
           ((*ctx)->cache!= NULL)){  
          swap((void *)&((*ctx)->cache), (void *)&((*ctx)->root));
          self_free_tree(&((*ctx)->cache));
          if((*ctx)->tmp_key != NULL){
            BN_clear_free((*ctx)->tmp_key);
            (*ctx)->tmp_key = NULL;
          }
          if((*ctx)->tmp_bkey != NULL){
            BN_clear_free((*ctx)->tmp_bkey);
            (*ctx)->tmp_bkey = NULL;
          }
          sender = 1;
        }
        else if(self_check_useful(new_ctx->root, (*ctx)->root)==1){
          /* Copy new information(if any) to my context;           */
          /* Tree should be same to process the following function */
          self_swap_bkey(new_ctx->root, (*ctx)->root);

        }
        self_free_tree(&(new_ctx->root));
        new_ctx->root = (*ctx)->root;
      }
      
      /* Add new_ctx, info to new_tree_list */
      new_tree_list = add_tree_list(new_tree_list, new_ctx->root);
      tmp_list = tmp_list->next;
      message_type = info->message_type;
      
      self_destroy_ctx(&new_ctx, 0);
      self_destroy_token_info(&info);
    }
    
    switch (message_type) { /* There is no leave or join event */

      /*****************/
      /*               */
      /* JOIN or MERGE */
      /*               */
      /*****************/
      case TGDH_KEY_MERGE_UPDATE:
      {

        (*ctx)->status = CONTINUE;
        leaveormerge = 1;

        (*ctx)->root = new_tree_list->tree;
        tmp_tree_list = new_tree_list->next;
        while(tmp_tree_list != NULL){
          (*ctx)->root = self_merge((*ctx)->root, tmp_tree_list->tree);
          tmp_tree_list = tmp_tree_list->next;
        }
        
        self_free_tree(&((*ctx)->cache));
        (*ctx)->cache = self_dup_tree((*ctx)->root);
        need_swap = 1;
        
        break;
      }
      /********************/
      /*                  */
      /* MEMBERSHIP EVENT */
      /*                  */
      /********************/
      case PROCESS_EVENT:
      {
        /* This includes second call of partition, update_ctx of */
        /* join and merge operation                              */
        if(new_status == KEY_COMPUTED){ 
          (*ctx)->status = OK; 
          ret = OK;
          new_information = 1;
        } 
    
        if(sender==1){
          goto error;
        }

        /*
         * I'll check if I am the sponsor... If I am the sponsor,
         * I'll try to computed some value
         */
        tmp1_node = self_search_member((*ctx)->root, 4, (*ctx)->member_name);
        if(tmp1_node == NULL){
          fprintf(stderr, "I cannot find my name!\n");
          result = SELF_STRUCTURE_ERROR;
          goto error;
        }
        if(tmp1_node != (*ctx)->root){
          while(tmp1_node->parent != NULL){
            if(tmp1_node->parent->self_nv->key == NULL){
              break;
            }
            tmp1_node = tmp1_node->parent;
          }
        }
        
        /* Only rightmost member is the sponsor */
        if(tmp1_node != (*ctx)->root){
          tmp1_node = self_search_member(tmp1_node->parent, 3, NULL);
          if(strcmp(tmp1_node->self_nv->member->member_name, 
                    (*ctx)->member_name)==0){
            new_information = 1;
          }
        }
        
        if(new_information == 0){
          goto error;
        }
        /* If I don't have cache, then I generated a cache... If I 
           don't broadcast token, I'll remove cache... */
        if((*ctx)->cache == NULL){
          (*ctx)->cache = self_dup_tree((*ctx)->root);
        }
        /*  If I have cache, I'll add new information to the cache also... */
        else{
          self_copy_bkey((*ctx)->root, (*ctx)->cache);
        }
        /* Now every computation will be processed on the cache... */
        swap((void *)&((*ctx)->cache), (void *)&((*ctx)->root));
        need_swap = 1;
        break;
      }

      /* No more cases */
      default:
      {
        result=INVALID_MESSAGE_TYPE;
        goto error;
      }
    }
  }
  
  tmp1_node = self_search_member((*ctx)->root, 4, (*ctx)->member_name);
  if(tmp1_node == NULL){
    fprintf(stderr, "I cannot find me 222\n");
    result = SELF_STRUCTURE_ERROR;
    goto error;
  }

  if((tmp1_node->self_nv->key == NULL) && (leaveormerge== 1)){
    if(((*ctx)->tmp_key != NULL) && ((*ctx)->tmp_bkey != NULL)){
      new_information = 1;
      new_key_comp = 1;
      tmp1_node->self_nv->key = BN_dup((*ctx)->tmp_key);
      if(tmp1_node->self_nv->bkey == NULL){
        tmp1_node->self_nv->bkey = BN_dup((*ctx)->tmp_bkey);
      }
    }
  }

  if(tmp1_node != (*ctx)->root){
    while(tmp1_node->parent != NULL){
      if(tmp1_node->parent->self_nv->key == NULL){
        break;
      }
      tmp1_node = tmp1_node->parent;
    }
  }

  /* Only rightmost member is the sponsor */
  if(tmp1_node != (*ctx)->root){
    tmp1_node = self_search_member(tmp1_node->parent, 3, NULL);
    if(strcmp(tmp1_node->self_nv->member->member_name, 
              (*ctx)->member_name)==0){
      new_information = 1;
    }
  }

  /* If not needed, only sponsor computes the key... */
  if(new_information || new_status == KEY_COMPUTED){
    tmp1_node = self_search_member((*ctx)->root, 4, (*ctx)->member_name);
    if(tmp1_node == NULL){
      fprintf(stderr, "I cannot find me 3\n");
      result = SELF_STRUCTURE_ERROR;
      goto error;
    }
    if(tmp1_node != (*ctx)->root){
      while(tmp1_node->parent != NULL){
        if(tmp1_node->parent->self_nv->key == NULL){
          break;
        }
        tmp1_node = tmp1_node->parent;
      }
    }

/*      self_print_simple("Bef comput", (*ctx)->root); */
    if(tmp1_node != (*ctx)->root){
      if(tmp1_node->parent->self_nv->key != NULL){
        fprintf(stderr, "PArent not null 2\n");
        result = SELF_STRUCTURE_ERROR;
        goto error;
      }
      if(tmp1_node->self_nv->index % 2){
        tmp_node = tmp1_node->parent->left;
      }
      else{
        tmp_node = tmp1_node->parent->right;
      }
      while(tmp_node->self_nv->bkey != NULL){
        /* Compute intermediate keys until I can */
        if(tmp1_node->parent->self_nv->key != NULL){
          fprintf(stderr, "PArent not null 2\n");
          result=SELF_STRUCTURE_ERROR;
          goto error;
        }
        tmp1_node->parent->self_nv->key = BN_new();
        new_key_comp = 1;
        if(tmp1_node->parent->left->self_nv->key != NULL){
          result = BN_mod(tmp1_node->parent->left->self_nv->key,
                          tmp1_node->parent->left->self_nv->key,   
                          (*ctx)->params->q, bn_ctx);
          if(result != OK) goto error;
          result=BN_mod_exp(tmp1_node->parent->self_nv->key, 
                            tmp1_node->parent->right->self_nv->bkey,
                            tmp1_node->parent->left->self_nv->key,
                            (*ctx)->params->p,bn_ctx);
        }
        else{
          result = BN_mod(tmp1_node->parent->right->self_nv->key,
                          tmp1_node->parent->right->self_nv->key,   
                          (*ctx)->params->q, bn_ctx);
          if(result != OK) goto error;
          result=BN_mod_exp(tmp1_node->parent->self_nv->key,
                            tmp1_node->parent->left->self_nv->bkey,
                            tmp1_node->parent->right->self_nv->key,
                            (*ctx)->params->p,bn_ctx);
        }
        if(result != OK) goto error;
        
        /* Compute bkeys */
        if(tmp1_node->parent->self_nv->bkey != NULL){
          BN_clear_free(tmp1_node->parent->self_nv->bkey);
          tmp1_node->parent->self_nv->bkey=NULL;
        }
        tmp1_node->parent->self_nv->bkey
          =self_compute_bkey(tmp1_node->parent->self_nv->key, (*ctx)->params);
        
        if(tmp1_node->parent->parent == NULL) {
          break;
        }
        else{
          tmp1_node = tmp1_node->parent;
        }
        if(tmp1_node->self_nv->index % 2){
          tmp_node = tmp1_node->parent->left;
        }
        else{
          tmp_node = tmp1_node->parent->right;
        }
      }
    }
  }
  
  
  if((*ctx)->root->self_nv->key != NULL){
    if((*ctx)->status == CONTINUE){
      ret = KEY_COMPUTED;
      (*ctx)->status = KEY_COMPUTED;
    }
    if((*ctx)->root->self_nv->member != NULL){
      if(strcmp((*ctx)->root->self_nv->member->member_name,
                (*ctx)->member_name)==0){
        ret = OK;
        (*ctx)->status = OK;
      }
    }
  }

  if((new_information == 1) && (new_key_comp == 1) && ((*ctx)->status != OK)){
    /* Creating token info */
    result=self_create_token_info(&info, (*ctx)->group_name,
                                  PROCESS_EVENT, time(0),
                                  (*ctx)->member_name);  
    if (result!=OK) goto error;
    
    result=self_encode((*ctx),output,info);
    if (result!=OK) goto error;

    /* Sign output token; */
    result=self_sign_message ((*ctx), *output);
  }

error:
  if((new_information == 1) && (new_key_comp == 1) && ((*ctx)->status != OK)){
    /* Since I have useful information, I'll save the useful
       information until I receive my token */
    if(need_swap == 1){
      swap((void *)&((*ctx)->cache), (void *)&((*ctx)->root));
    }
  }
  else{
    /* I don't have any useful information */
    if((need_swap == 1) && ((*ctx)->status != OK)){
      swap((void *)&((*ctx)->cache), (void *)&((*ctx)->root));
    }
  }

  if(new_tree_list != NULL){
    remove_tree_list(&new_tree_list);
  }

  if(ret == OK){
    if((*ctx)->root->self_nv->key == NULL){
      fprintf(stderr, "Key is NULL, but return is OK\n\n");
    }
    if((*ctx)->cache != NULL){ 
      self_free_tree(&(*ctx)->cache);
    }
    BN_copy((*ctx)->group_secret,(*ctx)->root->self_nv->key);
    result=self_compute_secret_hash ((*ctx));
    (*ctx)->epoch++; /* Used inside self_encode */
  }
        
  if (result <= 0){
    ret = result;
    if (ctx != NULL) self_destroy_ctx(ctx,1);
  }
  if (info != NULL) self_destroy_token_info(&info);
  if (bn_ctx != NULL) BN_CTX_free (bn_ctx);
  

  return ret;
}

/* self_create_ctx creates the self context.
 * Preconditions: *ctx has to be NULL.
 */
int self_create_ctx(SELF_CONTEXT **ctx) 
{
  int ret=CTX_ERROR;

  if (*ctx != (SELF_CONTEXT *)NULL) return CTX_ERROR;
  /* Creating ctx */
  (*ctx) = (SELF_CONTEXT *) calloc(sizeof(SELF_CONTEXT), 1);
  if ((*ctx) == NULL) goto error;
  (*ctx)->member_name=NULL;
  (*ctx)->group_name=NULL;
  (*ctx)->root=(KEY_TREE *) calloc(sizeof(KEY_TREE),1);
  if ((*ctx)->root == (KEY_TREE *) NULL) goto error;
  (*ctx)->group_secret_hash=(tgdh_uchar*) calloc (MD5_DIGEST_LENGTH,1);
  if ((*ctx)->group_secret_hash==NULL){
    goto error;
  }
  
  (*ctx)->root->parent=(*ctx)->root->left=(*ctx)->root->right=NULL;
  (*ctx)->root->prev=(*ctx)->root->next=(*ctx)->root->bfs=NULL;
  (*ctx)->params=NULL; 
  (*ctx)->pkey=NULL;
  (*ctx)->epoch=0;
  
  ret=OK;
error:
  if (ret!=OK) self_destroy_ctx (ctx,1);
  
  return ret;
}

/* self_read_dsa: Reads a DSA structure from disk depending on
 * SELF_KEY_TYPE (SELF_PARAMS, SELF_PRV, SELF_PUB)
 *
 * Parameters:
 *  member_name
 *   User name requesting key. 
 *   If type is SELF_PARAMS then this parameter is not used. 
 *  type
 *   Type of key required.
 *
 * Return: A pointer to a DSA structure with the requested key if
 * succeed, otherwise NULL is returned. 
 *
 * Note: This function can be replaced for one provided by the
 * program using the API. Hence, the keys can be obtained form
 * another media if necessary. The only only condition required is
 * that the function returns a pointer to a DSA structure.
 *
 */
#ifndef USE_SELF_READ_DSA
DSA *self_read_dsa(SELF_NAME *member_name, 
                   enum SELF_KEY_TYPE type) 
{ 
  return (DSA*)self_get_dsa_key (member_name,type);
}
#else
DSA *self_read_dsa(SELF_NAME *member_name, 
                   enum SELF_KEY_TYPE type) 
{ 
  BIO *in=NULL;
  int ok=0;  
  char infile[50];
  DSA *dsa=NULL;
  
  switch (type) {
    case SELF_PRV:
      sprintf (infile, "%s_%s.%s",PRV_FMT, member_name,
               FILE_EXT);  
      break;
    case SELF_PUB:
      sprintf (infile, "%s_%s.%s",PUB_FMT, member_name,
               FILE_EXT);  
      break;
    case SELF_PARAMS:
      sprintf (infile, TGDH_COMMON_FILE);
      break;
  }
  
  if(strlen(infile)==0) goto error;
  
  in=BIO_new(BIO_s_file());
  if (in == NULL) { 
    /* ERR_print_errors(bio_err); */
    goto error;
  }
  
  if (BIO_read_filename(in,infile) <= 0) { 
    perror(infile); 
    goto error;
  }
#ifdef DEBUG
  fprintf(ERR_STRM,"Reading file %s.\n", infile);
  fprintf(ERR_STRM,"\tReading DSA ");
#endif
  
  if (type == SELF_PARAMS) {
#ifdef DEBUG
    fprintf(ERR_STRM,"parameters\n");
#endif
    d2i_DSAparams_bio(in,&dsa);
  }
  else if(type == SELF_PUB) {
#ifdef DEBUG
    fprintf(ERR_STRM,"public key\n");
#endif
    d2i_DSAPublicKey_bio(in,&dsa);
  }
  else if(type == SELF_PRV) {
#ifdef DEBUG
    fprintf(ERR_STRM,"private key\n");
#endif
    d2i_DSAPrivateKey_bio(in,&dsa);
  }
  
  if (dsa == NULL) {
#ifdef DEBUG
    fprintf(ERR_STRM,"ERROR: Unable to load DSA structure.\n");
#endif
    /* ERR_print_errors(bio_err); */
    goto error;
  }
  
  ok =1;
  
error:
  
  if (in != NULL) BIO_free(in);
  
  return dsa;
} /* self_read_dsa */
#endif

/* self_compute_bkey: Computes and returns bkey */
BIGNUM *self_compute_bkey (BIGNUM *key, DSA *params)
{
  int ret=OK;
  BIGNUM *new_bkey = BN_new();
  BN_CTX *bn_ctx=BN_CTX_new();  
  
  if (bn_ctx == (BN_CTX *) NULL) {ret=MALLOC_ERROR; goto error;}
  if (new_bkey == NULL) {ret=MALLOC_ERROR; goto error;}
  if (key == NULL) {ret=SELF_STRUCTURE_ERROR; goto error;}
  
  ret = BN_mod(key,key,params->q,bn_ctx);
  if(ret != OK) goto error;
  ret=BN_mod_exp(new_bkey,params->g,key,params->p,bn_ctx); 
  
error:
  if (bn_ctx != NULL) BN_CTX_free (bn_ctx);
  if (ret!=OK) 
    if (new_bkey != NULL) {
      BN_clear_free(new_bkey);
      new_bkey=NULL;
    }
  
  return new_bkey;
}

/* self_rand: Generates a new random number of "params->q" bits, using
 *   the default parameters.
 * Returns: A pointer to a dsa structure where the random value
 *          resides. 
 *          NULL if an error occurs.
 */
BIGNUM *self_rand (DSA *params) 
{
  /* DSA *Random=NULL; */
  int ret=OK;
  BIGNUM *random=NULL;
  int i=0;
  
  random=BN_new();
  if (random == NULL) { ret=MALLOC_ERROR; goto error;}
  
  /* The following idea was obtained from dsa_key.c (openssl) */
  i=BN_num_bits(params->q);
  for (;;) {
    ret = BN_rand(random,i,1,0);
    if (BN_cmp(random,params->q) >= 0)
      BN_sub(random,random,params->q);
    if (!BN_is_zero(random)) break;
  }
  
error:
  
  if (ret!=OK) 
    if (random != NULL) {
      BN_clear_free(random);
      random=NULL;
    }

  return random;
}

/* self_compute_secret_hash: It computes the hash of the group_secret.
 * Preconditions: ctx->group_secret has to be valid.
 */
int self_compute_secret_hash (SELF_CONTEXT *ctx) 
{
  char *tmp_str=NULL;
  
  tmp_str=BN_bn2hex(ctx->group_secret);
  if (tmp_str==NULL) return CTX_ERROR;
  
  MD5((tgdh_uchar *)tmp_str, (unsigned long)strlen(tmp_str), 
      ctx->group_secret_hash);
  
  free(tmp_str);
  
  if (ctx->group_secret_hash == (tgdh_uchar *) NULL) return CTX_ERROR; 
  
  return OK;
}

/* self_destroy_ctx frees the space occupied by the current context.
 * Including the group_members_list.
 *   if flag == 1, delete all context
 *   if flag == 0, delete all except the tree(used for merge)
 */

void self_destroy_ctx (SELF_CONTEXT **ctx, int flag) 
{
  
  if ((*ctx) == NULL) return;
  if (((*ctx)->member_name) != NULL) { 
    free((*ctx)->member_name);
    (*ctx)->member_name=NULL;
  }
  if (((*ctx)->group_name) != NULL) { 
    free((*ctx)->group_name);
    (*ctx)->group_name=NULL;
  }
  if (((*ctx)->group_secret) != NULL) {
    BN_clear_free((*ctx)->group_secret);
    (*ctx)->group_secret=NULL;
  }
  if (((*ctx)->tmp_key) != NULL) {
    BN_clear_free((*ctx)->tmp_key);
    (*ctx)->tmp_key=NULL;
  }
  if (((*ctx)->tmp_bkey) != NULL) {
    BN_clear_free((*ctx)->tmp_bkey);
    (*ctx)->tmp_bkey=NULL;
  }
  if (((*ctx)->group_secret_hash) != NULL) {
    free((*ctx)->group_secret_hash);
    (*ctx)->group_secret_hash=NULL;
  }

  if(flag == 1){
    self_free_tree(&((*ctx)->root));
    (*ctx)->root=NULL;
  }
  self_free_tree(&((*ctx)->cache));
  
  if (((*ctx)->params) != NULL) {
    DSA_free((*ctx)->params);
    (*ctx)->params=NULL;
  }
  if (((*ctx)->pkey) != NULL) {
    EVP_PKEY_free((*ctx)->pkey);
    (*ctx)->pkey=NULL;
  }
  if (((*ctx)->epoch) != (int)NULL) {
    (*ctx)->epoch = (int)NULL;
  }
  free((*ctx));
  (*ctx)=NULL;
  
  return;
}

/***********************/
/*TREE private functions*/
/***********************/

/* self_encode using information from the current context and from
 * token info generates the output token.
 * include_last_partial: If TRUE includes all last_partial_keys,
 * otherwise it includes the partial key of the (controller) first
 * user in ckd. Hence it should be TRUE if called within cliques and
 * FALSE if called from ckd_gnrt_gml.
 *
 * Note: output is created here.
 * Preconditions: *output should be empty (otherwise it will be
 * freed).  
 */
int self_encode(SELF_CONTEXT *ctx, SELF_TOKEN **output,
		SELF_TOKEN_INFO *info) 
{ 
  uint pos=0;
  tgdh_uchar *data;
  
  /* Freeing the output token if necessary */
  if((*output) != NULL) self_destroy_token(output);
  
  /* Do some error checkings HERE !! */
  if (ctx == (SELF_CONTEXT *) NULL) return CTX_ERROR;
  /* The token has to match the current group name */
  if (strcmp(info->group_name,ctx->group_name)) return GROUP_NAME_MISMATCH;
  /* Done with error checkings */
  
  data=(tgdh_uchar *) calloc (sizeof(tgdh_uchar)*TGDH_MSG_SIZE,1);
  if (data==(tgdh_uchar *) NULL) return MALLOC_ERROR;
  
  tgdh_string_encode(data,&pos,info->group_name);
  tgdh_int_encode(data,&pos,info->message_type);
  tgdh_int_encode(data,&pos,info->time_stamp);
  /* Note: info->sender_name is not used here. The name is retreived
   * from ctx.
   */
  tgdh_string_encode(data,&pos,ctx->member_name);
  tgdh_int_encode(data,&pos,ctx->epoch);
  tgdh_int_encode(data,&pos,ctx->status);
  
  self_map_encode(data, &pos, ctx->root);
  
  *output=(SELF_TOKEN *) calloc(sizeof(SELF_TOKEN),1);
  if (*output == (SELF_TOKEN *) NULL) return MALLOC_ERROR;
  (*output)->length=pos;
  (*output)->t_data=data;
  
  return OK;
}

/* Converts tree structure to unsigned character string */
void self_map_encode(tgdh_uchar *stream, uint *pos, KEY_TREE *root)
{
  KEY_TREE *head, *tail;
  int map = 0;        /* If map is 3, index, bkey, member_name
                       * If map is 2, index, member_name
                       * If map is 1, index, bkey
                       * If map is 0, only index
                       */

  head = self_search_member(root, 2, NULL);
  
  while(head != NULL){ 
    if(head->bfs != NULL) head->bfs = NULL;
    head = head->next; 
  } 

  tgdh_int_encode(stream, pos, (uint)root->self_nv->height);
  tgdh_int_encode(stream, pos, root->self_nv->num_node);
  head = tail = root;
  
  while(head != NULL){
    if(head->self_nv->member == NULL){
      if(head->self_nv->bkey == NULL){
        map = 0;
      }
      else map = 1;
    }
    else{
      if(head->self_nv->bkey == NULL){
        map = 2;
      }
      else map = 3;
    }
    
    /* Real encoding */
    tgdh_int_encode(stream, pos, map);
    tgdh_int_encode(stream, pos, head->self_nv->index);
    tgdh_int_encode(stream, pos, (uint)head->self_nv->potential);
    tgdh_int_encode(stream, pos, head->self_nv->joinQ);
    if(head->self_nv->bkey != NULL) 
      tgdh_bn_encode(stream, pos, head->self_nv->bkey);
    if(head->self_nv->member != NULL) 
      tgdh_string_encode(stream, pos, head->self_nv->member->member_name);
    
    /* Queue handling */
    if(head->left){
      tail->bfs = head->left;
      tail = tail->bfs;
    }
    if(head->right){
      tail->bfs = head->right;
      tail = tail->bfs;
    }
    head = head->bfs;
  }
  
  tail = head = NULL;
}

/* self_decode using information from the input token, it creates
 * ctx. info is also created here. It contains data recovered from
 * input such as message_type, sender, etc. (See structure for more
 * details) in readable format. 
 * Preconditions: *ctx has to be NULL.
 * Postconditions: ctx is created. The only valid data in it is
 * group_members_list (first & last), and epoch. All the other
 * variables are NULL. (self_create_ctx behavior)
 */
int self_decode(SELF_CONTEXT **ctx, SELF_TOKEN *input,
                SELF_TOKEN_INFO **info)
{
  uint pos=0;
  int ret=CTX_ERROR;
  
  if (input == NULL){
        printf("This is weird 3\n\n");
        
    return INVALID_INPUT_TOKEN;
  }
  if (input->t_data == NULL){
        printf("This is weird 4\n\n");
        
    return INVALID_INPUT_TOKEN;
  }
  if (input->length <= 0){
        printf("This is weird 5\n\n");
        
    return INVALID_INPUT_TOKEN;
  }
  
  /* Creating token info */
  ret=self_create_token_info(info,"",TGDH_INVALID,0L,"");
  if (ret!=OK) goto error;
  
  if (ret!=self_create_ctx(ctx)) goto error;
  
  ret=INVALID_INPUT_TOKEN;
  if (!tgdh_string_decode(input,&pos,(*info)->group_name)) 
    goto error;
  if (!tgdh_int_decode(input,&pos,(uint*)&(*info)->message_type)) 
    goto error;
  if (!tgdh_int_decode(input,&pos,(uint *)&(*info)->time_stamp)) 
    goto error;
  if (!tgdh_string_decode(input,&pos,(*info)->sender_name)) 
    goto error;
  /*  (*ctx)->member_name = (SELF_NAME *)malloc(sizeof(SELF_NAME)*MAX_LGT_NAME);
  strncpy((*ctx)->member_name, (*info)->sender_name, MAX_LGT_NAME);
  */
  if (!tgdh_int_decode(input,&pos,&(*ctx)->epoch)) 
    goto error;
  if (!tgdh_int_decode(input,&pos,&(*ctx)->status)) 
    goto error;
  
  if ((ret=self_map_decode(input,&pos,ctx)) != OK)
    goto error; 
  
  /* Checking after decoding */
  if ((((*info)->sender_name) == NULL) ||
      (((*info)->group_name) == NULL) ||
      ((*ctx)->epoch < 0)){
        printf("This is weird 6\n\n");
        
    ret=INVALID_INPUT_TOKEN;
  }
  
  else
    ret=OK;
  
error:
  
  if (ret != OK) {
        printf("This is weird 7\n\n");
        
    if (info != NULL) self_destroy_token_info(info);
    if (ctx != NULL) self_destroy_ctx(ctx,1);
  }
  
  return ret;
}

/* self_map_decode decode input token to generate tree for the new
 *   tree
 * *tree should be pointer to the root node
 */
int self_map_decode(const SELF_TOKEN *input, uint *pos, 
                    SELF_CONTEXT **ctx)
{
  int i;
  uint map=0;
  uint tmp_index;
  KEY_TREE *tmp_tree=NULL, *tmp1_tree=NULL;
  int ret=OK;
  
  (*ctx)->root->self_nv = (SELF_NV *)calloc(sizeof(SELF_NV),1);
  if ((*ctx)->root->self_nv == NULL) 
  {ret=MALLOC_ERROR; goto error;}
  if(!tgdh_int_decode(input, pos, (uint *)&((*ctx)->root->self_nv->height))) 
    return 0;
  if(!tgdh_int_decode(input, pos, (uint *)&((*ctx)->root->self_nv->num_node))) 
    return 0;
  
  (*ctx)->root->parent = NULL;
  (*ctx)->root->self_nv->member = NULL;
  
  if(!tgdh_int_decode(input, pos, &map)) return 0;
  if(!tgdh_int_decode(input, pos, &tmp_index)) return 0;
  
  (*ctx)->root->self_nv->index = tmp_index;
  if(!tgdh_int_decode(input, pos, (uint *)&((*ctx)->root->self_nv->potential))) 
    return 0;
  if(!tgdh_int_decode(input, pos, &((*ctx)->root->self_nv->joinQ))) 
    return 0;
  
  (*ctx)->root->self_nv->key = (*ctx)->root->self_nv->bkey = NULL;
  if(map & 0x1){
    (*ctx)->root->self_nv->bkey = BN_new();
    if(!tgdh_bn_decode(input, pos, (*ctx)->root->self_nv->bkey)) return 0;
  }
  if((map >> 1) & 0x1){
    (*ctx)->root->self_nv->member 
      = (SELF_GM *)calloc(sizeof(SELF_GM),1);
    if((*ctx)->root->self_nv->member == NULL)
    {ret=MALLOC_ERROR; goto error;}
    
    (*ctx)->root->self_nv->member->cert = NULL;
    (*ctx)->root->self_nv->member->member_name = 
      (SELF_NAME *)calloc(sizeof(SELF_NAME)*MAX_LGT_NAME,1);
    if((*ctx)->root->self_nv->member->member_name == NULL)
    {ret=MALLOC_ERROR; goto error;}
    if(!tgdh_string_decode(input, pos,
                      (*ctx)->root->self_nv->member->member_name))
      return 0; 
  }
  
  for(i=0; i<(*ctx)->root->self_nv->num_node-1; i++){
    if(!tgdh_int_decode(input, pos, &map)) return 0;
    if(!tgdh_int_decode(input, pos, &tmp_index)) return 0;
    tmp_tree=self_search_index((*ctx)->root, tmp_index);
    if(tmp_tree == NULL) return 0;
    tmp_tree->self_nv->member = NULL;
    tmp1_tree = (KEY_TREE *)calloc(sizeof(KEY_TREE),1);
    
    tmp1_tree->parent = tmp_tree;
    if(tmp_index % 2)
      tmp_tree->right = tmp1_tree;
    else tmp_tree->left = tmp1_tree;
    tmp1_tree->self_nv = (SELF_NV *)calloc(sizeof(SELF_NV),1);
    tmp1_tree->self_nv->member = NULL;
    tmp1_tree->self_nv->key = tmp1_tree->self_nv->bkey = NULL;
    tmp1_tree->self_nv->index = tmp_index;
    tmp1_tree->self_nv->height = tmp1_tree->self_nv->num_node=-1;
    tmp1_tree->left=tmp1_tree->right=NULL;
    tmp1_tree->prev=tmp1_tree->next=tmp1_tree->bfs=NULL;
    if(!tgdh_int_decode(input, pos, (uint *)&(tmp1_tree->self_nv->potential))) 
      return 0;
    if(!tgdh_int_decode(input, pos, &(tmp1_tree->self_nv->joinQ))) 
      return 0;
    if(map & 0x1){
      tmp1_tree->self_nv->bkey = BN_new();
      if(!tgdh_bn_decode(input, pos, tmp1_tree->self_nv->bkey)) return 0;
    }
    if((map >> 1) & 0x1){
      tmp1_tree->self_nv->member=(SELF_GM *)calloc(sizeof(SELF_GM),1);
      tmp1_tree->self_nv->member->member_name = 
        (SELF_NAME *)calloc(sizeof(SELF_NAME)*MAX_LGT_NAME,1); 
      tmp1_tree->self_nv->member->cert=NULL;
      
      if(!tgdh_string_decode(input, pos, tmp1_tree->self_nv->member->member_name))
        return 0; 
      tmp_tree = self_search_member(tmp1_tree, 0, NULL);
      tmp1_tree->prev = tmp_tree;
      if(tmp_tree != NULL) tmp_tree->next = tmp1_tree;
      tmp_tree = self_search_member(tmp1_tree, 1, NULL);
      tmp1_tree->next = tmp_tree;
      if(tmp_tree != NULL) tmp_tree->prev = tmp1_tree;
      tmp1_tree->bfs = NULL;
    }
  }
  
  error:
  if(ret != OK){
    if((*ctx)->root->self_nv->member != NULL){
      if((*ctx)->root->self_nv->member->member_name != NULL) 
        free((*ctx)->root->self_nv->member->member_name);
      free((*ctx)->root->self_nv->member);
    }
    if((*ctx)->root->self_nv != NULL) free((*ctx)->root->self_nv);
  }
  
  return ret;
}

/* int_encode: It puts an integer number in stream. Note that the size
 * of the integer number is added to the stream as well.
 */
void tgdh_int_encode(tgdh_uchar *stream, uint *pos, uint data) 
{
  int int_size=htonl(INT_SIZE);
  
  data=htonl(data);
  if(LENGTH_SIZE+*pos > TGDH_MSG_SIZE) { 
    fprintf(stderr, "Problems in int_encode\n"); 
    exit(1); 
  } 
  
  bcopy (&int_size,stream+*pos,LENGTH_SIZE);
  *pos+=LENGTH_SIZE;
  if(INT_SIZE+*pos > TGDH_MSG_SIZE) { 
    fprintf(stderr, "Problems in int_encode\n"); 
    exit(1); 
  } 
  bcopy (&data,stream+*pos,INT_SIZE);
  *pos+=INT_SIZE;
}

/* int_decode: It gets an integer number from input->t_data. Note that
 * the size of the integer number is decoded first, and then the
 * actual number is decoded.
 * Returns: 1 succeed.
 *          0 Fails.
 */
int tgdh_int_decode(const SELF_TOKEN *input,uint *pos, uint *data) 
{
  int int_size;

  if (input->length  < LENGTH_SIZE+*pos) return 0;
  bcopy (input->t_data+*pos,&int_size,LENGTH_SIZE);
  int_size=ntohl(int_size);
  *pos+=LENGTH_SIZE;
  if(int_size+*pos > TGDH_MSG_SIZE) return 0;
  if (input->length  < int_size+*pos) return 0;
  bcopy (input->t_data+*pos,data,int_size);
  *pos+=int_size;
  *data=ntohl(*data);

  return 1;
}

/* string_encode: It puts the valid 'c' string into stream. It first
 * stores the message length (including \0) and the the actual
 * message.
 */
void tgdh_string_encode (tgdh_uchar *stream, uint *pos, char *data) 
{
  int str_len=1;
  
  /* Note: we are copying the '/0' also */
  str_len+=strlen(data); 
  tgdh_int_encode(stream,pos,str_len);
  if(str_len+*pos > TGDH_MSG_SIZE) {
    fprintf(stderr, "Problems in str_encode\n");
    exit(1);
  }

  bcopy (data,stream+*pos,str_len);
  *pos+=str_len;
}

/* string_decode: It restores a valid 'c' string from
 * input->t_data. First the string length is decode (this one should
 * have \0 already), and the actual string.
 * Returns: 1 succeed.
 *          0 Fails.
 */
int tgdh_string_decode (const SELF_TOKEN *input, uint *pos, char *data) 
{
  uint str_len;

  if (!tgdh_int_decode(input,pos,&str_len)) return 0;
  if(str_len+*pos > TGDH_MSG_SIZE) return 0; 
  if (input->length  < str_len+*pos) return 0;
  bcopy(input->t_data+*pos,data,str_len);
  *pos+=str_len;

  return 1;
}

/* bn_encode: BIGNUM encoding. */
void tgdh_bn_encode (tgdh_uchar *stream, uint *pos, BIGNUM *num) 
{
  uint size;

  size=BN_num_bytes(num);
  assert (size > 0);
  tgdh_int_encode(stream,pos,size);
  BN_bn2bin(num,stream+*pos);
  *pos+=size;
}

/* bn_decode: BIGNUM decoding.
 * Preconditions: num has to be different from NULL.
 * Returns: 1 succeed.
 *          0 Fails.
 */
int tgdh_bn_decode (const SELF_TOKEN *input, uint *pos, BIGNUM *num) 
{
  uint size=0;

  if (num == (BIGNUM *) NULL) return 0;
  if (!tgdh_int_decode(input,pos,&size)) return 0;
  if (size <= 0) return 0;
  if (input->length < size+*pos) return 0;
  BN_bin2bn(input->t_data+*pos,size,num);
  *pos+=size;

  return 1;
}

/* self_create_token_info: It creates the info token. */
int self_create_token_info (SELF_TOKEN_INFO **info, SELF_NAME *group, 
                            enum TGDH_MSG_TYPE msg_type, time_t time,
                            SELF_NAME *sender/*, uint epoch*/) 
{ 
  int ret=MALLOC_ERROR;
  
  /* Creating token information */
  (*info)=(SELF_TOKEN_INFO *) calloc (sizeof(SELF_TOKEN_INFO),1);
  if ((*info) == NULL) goto error;
  if (group != NULL) {
    (*info)->group_name
      =(SELF_NAME *) calloc(sizeof(SELF_NAME)*MAX_LGT_NAME,1);
    if (((*info)->group_name) == NULL) goto error;
    strncpy ((*info)->group_name,group,MAX_LGT_NAME);
  } else (*info)->group_name=NULL;
  (*info)->message_type=msg_type;
  (*info)->time_stamp=time;
  if (sender != NULL) {
    (*info)->sender_name=(SELF_NAME *)
      calloc(sizeof(SELF_NAME)*MAX_LGT_NAME,1);
    if (((*info)->sender_name) == NULL) goto error;
    strncpy ((*info)->sender_name,sender,MAX_LGT_NAME);
  }
  else (*info)->sender_name=NULL;
  /*  (*info)->epoch=epoch; */
  
  ret=OK;
error:
  if (ret != OK) self_destroy_token_info(info);

  return ret;
}

/* self_destroy_token: It frees the memory of the token. */
void self_destroy_token (SELF_TOKEN **token) {
  if (*token !=(SELF_TOKEN *) NULL) {
    if ((*token)->t_data != NULL) {
      free ((*token)->t_data);
      (*token)->t_data=NULL;
    }
    free(*token);
    *token=NULL;
  }
}

/* self_destroy_token_info: It frees the memory of the token. */
void self_destroy_token_info (SELF_TOKEN_INFO **info) 
{
  
  if (info == NULL) return;
  if ((*info) == NULL) return;
  if ((*info)->group_name != NULL) {
    free ((*info)->group_name);
    (*info)->group_name =NULL;
  }
  if ((*info)->sender_name != NULL) {
    free ((*info)->sender_name);
    (*info)->sender_name=NULL;
  }
  free ((*info));
  *info = NULL;
  
}

/* self_merge_tree returns root of a new tree which is the result of
 *   merge of two trees
 */
KEY_TREE *self_merge_tree(KEY_TREE *joiner, KEY_TREE *joinee)
{
  KEY_TREE *tmp_tree=NULL, *tmp_root=NULL;
  KEY_TREE *last=NULL, *last1=NULL, *first=NULL;
  int height=-1;
  
  if(joiner->parent != NULL) return NULL;
  
  tmp_tree = (KEY_TREE *)calloc(sizeof(KEY_TREE),1);
  if(tmp_tree == NULL) return NULL;
  
  /* setting up pointers for the new node */
  tmp_tree->parent = joinee->parent;
  tmp_tree->left = joinee;
  tmp_tree->right = joiner;
  tmp_tree->prev=tmp_tree->next=tmp_tree->bfs=NULL;
  
  /* setting up pointer for the parent of the joinee */
  if(joinee->parent != NULL){
    if(joinee->self_nv->index % 2)
      joinee->parent->right = tmp_tree;
    else joinee->parent->left = tmp_tree;
  }
  
  /* setting up pointers for the joinee and joiner */
  joiner->parent = tmp_tree;
  joinee->parent = tmp_tree;
  
  /* setting up the pointers for the leaf nodes */
  last = self_search_member(joinee, 3, NULL);
  first = self_search_member(joiner, 2, NULL);
  last1 = self_search_member(joiner, 3, NULL);
  if(last->next != NULL){
    last1->next = last->next;
    last->next->prev = last1;
  }
  last->next = first;
  first->prev = last;
  
  /* Now, real values for the tmp_tree */
  tmp_tree->self_nv=(SELF_NV *)calloc(sizeof(SELF_NV),1);
  tmp_tree->self_nv->index = tmp_tree->left->self_nv->index;
  tmp_tree->self_nv->key = tmp_tree->self_nv->bkey = NULL; 
  
  /* I decide to change everything -_-''
   * It looks simple, but inefficient...
   * But correct in every cases
   */
  /* Firstly, I'm just updating index... And then I'll update
   * potential using brute-force way
   */
  self_update_index(tmp_tree->right, 1, tmp_tree->self_nv->index);  
  self_update_index(tmp_tree->left, 0, tmp_tree->self_nv->index);

  tmp_tree->self_nv->member = NULL;

  /* Potential will be updated here */
  tmp_root = tmp_tree;
  while(tmp_root->parent != NULL)
    tmp_root = tmp_root->parent;
  
  first = self_search_member(tmp_root, 2, NULL);
  while(first != NULL){
    height = MAX(height, log2(first->self_nv->index));
    first = first->next;
  }
  
  tmp_root->self_nv->height = height; /* update height */
  first = self_search_member(tmp_root, 2, NULL);
  while(first != NULL){ /* Update potential for leaf users */
    first->self_nv->potential
      = height - log2(first->self_nv->index) - 1;
    if(first->self_nv->potential == -1)
      first->self_nv->joinQ = FALSE;
    else first->self_nv->joinQ = TRUE;
    first = first ->next;
  }
  self_update_potential(tmp_root);
  
  /* Now update some values upto the root */
  self_update_key_path(&tmp_root);

  last=last1=first=NULL;
  
  return tmp_root;
}


/* self_search_member: returns the pointer of the previous or the next
 *   member or the first or the last member
 *   if option is 0, this will return the pointer to the previous member
 *   if option is 1, this will return the pointer to the next member
 *     in the above two cases, tree is the starting leaf node in this
 *     searching 
 *   if option is 2, this will return the pointer to the left-most
 *      leaf member 
 *   if option is 3, this will return the pointer to the right-most
 *      leaf member 
 *   if option is 4 and member_name is not null, this will return the
 *     pointer to the node with that name
 *   if option is 5, this will return the pointer to the root
 *   if option is 6, this will return the shallowest leaf node
 */
KEY_TREE *self_search_member(KEY_TREE *tree, int option, 
                             SELF_NAME *member_name )
{
  KEY_TREE *tmp_tree;
  int min_node=100000;
  SELF_NAME *the_name=NULL;
  
  tmp_tree = tree;
  
  if(member_name == NULL){
    switch (option) {
      case 0: 
        if(tree->self_nv->member == NULL) return NULL;
        if(tree->self_nv->member->member_name == NULL) return NULL;
        if(tmp_tree->parent == NULL) return NULL;
        if(tmp_tree->parent->left == NULL) return NULL;
        while(tmp_tree->parent->left == tmp_tree){
          tmp_tree = tmp_tree->parent;
          if(tmp_tree->parent == NULL) return NULL;
        }
        tmp_tree = tmp_tree->parent->left;
        while(tmp_tree->self_nv->member == NULL){
          if(tmp_tree->right == NULL) return NULL;
          tmp_tree = tmp_tree->right; 
        }
        if(tmp_tree->self_nv->member->member_name == NULL) return NULL;
        return tmp_tree;
      case 1:
        if(tree->self_nv->member == NULL) return NULL;
        if(tree->self_nv->member->member_name == NULL) return NULL;
        if(tmp_tree->parent == NULL) return NULL;
        if(tmp_tree->parent->right == NULL) return NULL;
        while(tmp_tree->parent->right == tmp_tree){
          tmp_tree = tmp_tree->parent;
          if(tmp_tree->parent == NULL) return NULL;
        }
        tmp_tree = tmp_tree->parent->right;
        while(tmp_tree->self_nv->member == NULL){
          if(tmp_tree->left == NULL) return NULL;
          tmp_tree = tmp_tree->left;
        }
        if(tmp_tree->self_nv->member->member_name == NULL) return NULL;
        return tmp_tree;
      case 2:
        if(tmp_tree->left == NULL) return tmp_tree;
        while(tmp_tree->left != NULL) tmp_tree=tmp_tree->left;
        return tmp_tree;
      case 3:
        if(tmp_tree->right == NULL) return tmp_tree;
        while(tmp_tree->right != NULL) tmp_tree=tmp_tree->right;
        return tmp_tree;
      case 5:
        if(tmp_tree->parent == NULL) return tmp_tree;
        while(tmp_tree->parent != NULL) tmp_tree=tmp_tree->parent;
        return tmp_tree;
      case 6:
        tmp_tree = self_search_member(tmp_tree, 2, NULL);
        while(tmp_tree->next != NULL){
          if(tmp_tree->self_nv->index < min_node){
            min_node = tmp_tree->self_nv->index;
            the_name = tmp_tree->self_nv->member->member_name;
          }
          tmp_tree = tmp_tree->next;
        }
        tmp_tree = self_search_member(tmp_tree, 5, NULL);
        tmp_tree = self_search_member(tmp_tree, 4, the_name);
        if(tmp_tree == NULL){
          fprintf(stderr, "What happened???????\n");
        }
        return tmp_tree;
      default:
        return NULL;
    }
  }
  else{
    if(option==4){
      tmp_tree = self_search_member(tree, 2, NULL);
      if(tmp_tree == NULL) return NULL;
      
      while(strcmp(tmp_tree->self_nv->member->member_name,
                   member_name)!=0 ){
        if(tmp_tree->next == NULL) return NULL;
        tmp_tree = tmp_tree->next;
      }
      return tmp_tree;
    }
  }
  return NULL;
}

/* self_search_node: Returns the first fit or worst fit node
 *   if option is 0, search policy is the first fit
 *   if option is 1, search policy is the best fit
 * height of the joiner should be always smaller or equal to that of
 *   the joinee
 */
KEY_TREE *self_search_node(KEY_TREE *joiner, KEY_TREE *joinee,
			   int option)
{
  KEY_TREE *tmp_tree;
  
  if(joiner->self_nv->height > joinee->self_nv->potential) return joinee;
  
  tmp_tree = joinee;
  
  if(option==0){
    while(tmp_tree->self_nv->joinQ == FALSE){
      if(tmp_tree->right->self_nv->potential >= 
         tmp_tree->left->self_nv->potential){
        tmp_tree = tmp_tree->right;
      }
      else tmp_tree = tmp_tree->left;
    }
    return tmp_tree;
  }
  return NULL;
}

/* self_search_index: Returns the node having the index as a child 
 *   index should be greater than 1
 */
KEY_TREE *self_search_index(KEY_TREE *tree, int index)
{
  int height=0;
  int i;
  KEY_TREE *tmp_tree;
  
  height = log2(index);
  
  tmp_tree = tree;
  
  if(index==1) return NULL;
  
  for(i=1; i<height; i++){
    if((index >> (height-i)) & 0x1){
      if(tmp_tree->right == NULL) return NULL;
      else tmp_tree = tmp_tree->right;
    }
    else{
      if(tmp_tree->left == NULL) return NULL;
      else tmp_tree = tmp_tree->left;
    }
  }
  
  return tmp_tree;
}

/* self_update_index: update index of the input tree by 1
 * index 0 is for the left node
 * index 1 is for the right node
 * if option is -1, potential and joinQ need not be recomputed
 * if option is >=0, potential and joinQ should be recomputed
 * if option is > 0, the value means potential for the left sibling
 * height is only meaningful, when right tree need to be modified
 */
void self_update_index(KEY_TREE *tree, int index, int root_index) 
{
  if(tree == NULL) return;
  
  tree->self_nv->index = root_index * 2 + index;

  self_update_index(tree->left, 0, tree->self_nv->index);
  self_update_index(tree->right, 1, tree->self_nv->index);
}

/* Updates potential and joinQ except the leaf node */
void self_update_potential(KEY_TREE *tree)
{
  if(tree == NULL) return;
  
  self_update_potential(tree->left);
  self_update_potential(tree->right);
  
  if(tree->left != NULL){
    if((tree->left->self_nv->joinQ == TRUE) && 
       (tree->right->self_nv->joinQ == TRUE)){
      tree->self_nv->potential = 
        tree->left->self_nv->potential + 1;
      tree->self_nv->joinQ = TRUE;
    }
    else{
      tree->self_nv->potential = 
        MAX(tree->left->self_nv->potential,
            tree->right->self_nv->potential);
      tree->self_nv->joinQ = FALSE;
    }
  }
}

/* self_update_key_path: update joinQ, potential of key_path
 */
void self_update_key_path(KEY_TREE **tree)
{
  if((*tree) != NULL){
    while((*tree)->parent != NULL){
      (*tree) = (*tree)->parent;
      if(((*tree)->left->self_nv->joinQ == 0) ||
         ((*tree)->right->self_nv->joinQ == 0))
        (*tree)->self_nv->joinQ = FALSE;
      else (*tree)->self_nv->joinQ = TRUE;
      (*tree)->self_nv->potential = 
        MAX((*tree)->left->self_nv->potential,
            (*tree)->right->self_nv->potential);
      if(((*tree)->left->self_nv->potential >= 0) && 
         ((*tree)->right->self_nv->potential >= 0) &&
         ((*tree)->left->self_nv->joinQ ==TRUE) &&
         ((*tree)->right->self_nv->joinQ ==TRUE))
        (*tree)->self_nv->potential++;
      if((*tree)->self_nv->member != NULL)
        (*tree)->self_nv->member = NULL;
    }
  }
}

/* leaderQ: true if I am the node(first or worst fit)
   false otherwise
   */
int leaderQ(KEY_TREE *tree, SELF_NAME *my_name)
{
  KEY_TREE *tmp_tree;
  
  tmp_tree = tree;
  
  while(tmp_tree->right != NULL) tmp_tree = tmp_tree->right;
  if(strcmp(tmp_tree->self_nv->member->member_name, my_name) == 0)
    return TRUE;
  else return FALSE;
}

/* Frees a SELF_TREE structure */
void self_free_tree(KEY_TREE **tree) {
  
  if(tree == NULL) return;
  if((*tree) == NULL) return;

  if((*tree)->left != NULL)
    self_free_tree(&((*tree)->left));
  if((*tree)->right != NULL)
    self_free_tree(&((*tree)->right));
  
  self_free_node(&(*tree));
}

/* Frees a NODE structure */
void self_free_node(KEY_TREE **tree) {

  if(tree == NULL) return;
  if((*tree) == NULL) return;
  
  if((*tree)->self_nv != NULL){
    self_free_nv(&((*tree)->self_nv));
    (*tree)->self_nv = NULL;
  }
  
  free((*tree));
  
  (*tree)=NULL;
}

/* Frees a SELF_NV structure */
void self_free_nv(SELF_NV **nv) {
  if (nv == NULL) return;
  if ((*nv) == NULL) return;
  if((*nv)->member != NULL){
    self_free_gm(&((*nv)->member));
    (*nv)->member=NULL;
  }
  
  if ((*nv)->key != NULL){
    BN_clear_free((*nv)->key);
  }
  
  if ((*nv)->bkey != NULL){
    BN_clear_free((*nv)->bkey);
  }
  
  free((*nv));
  (*nv)=NULL;
}

/* Frees a SELF_GM structure */
void self_free_gm(SELF_GM **gm) {
  if((*gm) == NULL) return;
  if (((*gm)->member_name) != NULL) {
    free ((*gm)->member_name);
    (*gm)->member_name=NULL;
  }
  if (((*gm)->cert) != NULL) {
    X509_free ((*gm)->cert);
    (*gm)->cert=NULL;
  }
  free((*gm));
  (*gm)=NULL;
}

/* return log_2 a */
int log2(int a)
{
  int tmp = a;
  int i=-1;
  
  while(tmp > 0){
    i++;
    tmp >>= 1;
  }
  
  return i;
}

/* swap pointer a and b */
void swap(void **a, void **b)
{
  void *tmp;

  tmp = *a;
  *a = *b;
  *b = tmp;
}

/* self_copy tree structure, but to finish the real copy, we need to
   call self_dup_tree, which finishes prev and next pointer */  
KEY_TREE *self_copy_tree(KEY_TREE *src)
{
  KEY_TREE *dst=NULL;
  
  if(src != NULL){
    dst = (KEY_TREE *) calloc(sizeof(KEY_TREE), 1);
    if(src->self_nv != NULL){
      dst->self_nv = (SELF_NV *) calloc(sizeof(SELF_NV), 1);
      dst->self_nv->index = src->self_nv->index;
      dst->self_nv->joinQ=src->self_nv->joinQ;
      dst->self_nv->potential=src->self_nv->potential;
      dst->self_nv->height=src->self_nv->height;
      dst->self_nv->num_node=src->self_nv->num_node;
      if(src->self_nv->key != NULL){
        dst->self_nv->key = BN_dup(src->self_nv->key);
      }
      if(src->self_nv->bkey != NULL){
        dst->self_nv->bkey = BN_dup(src->self_nv->bkey);
      }
      if(src->self_nv->member != NULL){
        dst->self_nv->member = (SELF_GM *) calloc(sizeof(SELF_GM),1);
        if(src->self_nv->member->member_name != NULL){
          dst->self_nv->member->member_name=(SELF_NAME *)
            calloc(sizeof(SELF_NAME)*MAX_LGT_NAME,1);
          strncpy (dst->self_nv->member->member_name,
                   src->self_nv->member->member_name,MAX_LGT_NAME);
        }
        if(src->self_nv->member->cert != NULL){
          dst->self_nv->member->cert = X509_dup(src->self_nv->member->cert);
        }
      }
    }
    dst->left = self_copy_tree(src->left);
    dst->right = self_copy_tree(src->right);
    if(dst->left) {
      dst->left->parent = dst;
    }
    if(dst->right) {
      dst->right->parent = dst;
    }
  }

  return dst;
}

/* self_dup_tree finishes the copy process of one tree to
   another... Mainly, it just handles prev and next pointer */
KEY_TREE *self_dup_tree(KEY_TREE *src)
{
  KEY_TREE *dst=NULL;
  KEY_TREE *tmp1_src=NULL, *tmp1_dst=NULL;
  KEY_TREE *tmp2_src=NULL, *tmp2_dst=NULL;

  dst = self_copy_tree(src);
  if(src != NULL){
    tmp1_src = self_search_member(src, 2, NULL);
    tmp2_src = tmp1_src->next;
    tmp1_dst = self_search_member(dst, 4,
                                  tmp1_src->self_nv->member->member_name);
    while(tmp2_src != NULL){
      tmp2_dst = self_search_member(tmp1_dst, 1, NULL);
      tmp1_dst->next = tmp2_dst;
      tmp2_dst->prev = tmp1_dst;
      tmp2_src = tmp2_src->next;
      tmp1_src = tmp1_src->next;
      tmp1_dst = tmp2_dst;
    }
  }

  return dst;
}


/* self_copy_node copies or changes self_nv values of src node to dst
   node */  
void self_copy_node(KEY_TREE *src, KEY_TREE *dst)
{
  if(src->self_nv != NULL){
    dst->self_nv->index = src->self_nv->index;
    dst->self_nv->joinQ=src->self_nv->joinQ;
    dst->self_nv->potential=src->self_nv->potential;
    dst->self_nv->height=src->self_nv->height;
    dst->self_nv->num_node=src->self_nv->num_node;
    if(src->self_nv->key != NULL){
      swap((void *)&(src->self_nv->key),(void *)&(dst->self_nv->key));
    }
    if(src->self_nv->bkey != NULL){
      swap((void *)&(src->self_nv->bkey),(void *)&(dst->self_nv->bkey));
    }
    if(src->self_nv->member != NULL){
      swap((void *)&(src->self_nv->member), (void *)&(dst->self_nv->member));
    }
  }
}

/* self_swap_bkey swap my null bkey with meaningful bkey from new token */
void self_swap_bkey(KEY_TREE *src, KEY_TREE *dst) 
{
  if(src->left != NULL){
    self_swap_bkey(src->left, dst->left);
    self_swap_bkey(src->right, dst->right);
  }
  if(src != NULL){
    if((src->self_nv->bkey != NULL) && (dst->self_nv->bkey == NULL)){
      swap((void *)&(src->self_nv->bkey),(void *)&(dst->self_nv->bkey));
    }
  }
}

/* self_copy_bkey copies meaningful bkey from new token to my null
   token, used for cache update */
void self_copy_bkey(KEY_TREE *src, KEY_TREE *dst) 
{
  if(src->left != NULL){
    self_copy_bkey(src->left, dst->left);
    self_copy_bkey(src->right, dst->right);
  }
  if(src != NULL){
    if(src->self_nv->bkey != NULL){
      if(dst->self_nv->bkey == NULL){
        dst->self_nv->bkey = BN_dup(src->self_nv->bkey);
      }
    }
  }
}

/* self_check_useful checks whether new_ctx has useful information
 * If it has, return 1,
 * else, return 0
 */
int self_check_useful(KEY_TREE *newtree, KEY_TREE *mytree) 
{
  KEY_TREE *head_new=NULL, *tail_new=NULL;
  KEY_TREE *head_my=NULL, *tail_my=NULL;

  head_new=tail_new=newtree;
  head_my=tail_my=mytree;

  self_init_bfs(newtree);
  self_init_bfs(mytree); 
  
  while(head_new != NULL){
    if(head_new->self_nv->bkey!=NULL){
      if(head_my->self_nv->bkey==NULL){
        return 1;
      }
      else{
        if(BN_cmp(head_new->self_nv->bkey, head_my->self_nv->bkey) != 0){
          return 1;
        }
      }
    }
    /* Queue handling */
    if(head_new->left){
      tail_new->bfs = head_new->left;
      tail_new = tail_new->bfs;
      tail_my->bfs = head_my->left;
      tail_my = tail_my->bfs;
    }
    if(head_new->right){
      tail_new->bfs = head_new->right;
      tail_new = tail_new->bfs;
      tail_my->bfs = head_my->right;
      tail_my = tail_my->bfs;
    }
    head_new = head_new->bfs;
    head_my = head_my->bfs;
    
  }
  self_init_bfs(newtree);
  self_init_bfs(mytree); 

  return 0;
}

/* self_init_bfs initializes(nullfies) bfs pointers for each node */
void self_init_bfs(KEY_TREE *tree)
{
  if(tree != NULL){
    if(tree->left){
      self_init_bfs(tree->left);
      self_init_bfs(tree->right);
    }
    if(tree != NULL){
      tree->bfs = NULL;
    }
  }
}

/* remove_sponsor: remove the sponsor from the sponsor list */
int remove_sponsor(SELF_NAME *sponsor_list[], SELF_NAME *sponsor)
{
  int i=0, j=0;

  if(sponsor_list[0] == NULL) {
    return -1;
  }
  
  for(i=0; i<NUM_USERS+1; i++){
    if(sponsor_list[i] != NULL){
      if(strcmp(sponsor_list[i], sponsor)==0){
        break;
      }
    }
  }
/*   if(sponsor_list[i] == NULL){ */
/*     return -1; */
/*   } */
  for(j=i; j<NUM_USERS-1; j++){
    if(sponsor_list[j] != NULL){
      sponsor_list[j] = sponsor_list[j+1];
    }
  }
  
  return 1;
}

/* remove_member removes leaving members from the current tree.
 * o Reason for this function: It was leave part of self_cascade
 *    function, but I decided to make a function since we need to add
 *    this functionality to self_merge_req too...
 * o What is it doing?
 *   - This function will only remove the leaving members...
 *   - No key update happens...
 */
int remove_member(SELF_CONTEXT *ctx, SELF_NAME *users_leaving[],
                  KEY_TREE **the_sponsor)
{
  SELF_NAME *sponsor_list[NUM_USERS+1]={NULL};
  int list_counter = 0, i=0;
  KEY_TREE *leave_node=NULL, *first=NULL;
  KEY_TREE *tmp_node=NULL, *tmp1_node=NULL;
  int min_index=100000;
  int height=0;
  
  while(users_leaving[i] != NULL){
    /* If I have cache and if I receive another membership, remove
       cache */
    if(remove_sponsor(sponsor_list, users_leaving[i])>0){
      list_counter--;
    }
    ctx->status = CONTINUE;
    
    /* If my name is in the users_leaving list, then I just exit
     * partition with OK... I will call again to partition out other
     * members
     */
    if(strcmp(users_leaving[i], ctx->member_name)==0){
      return 4;
    }
    
    /* Delete every bkey and key which is related with the leaving
     * members;
     */ 
    tmp1_node=leave_node=self_search_member(ctx->root, 4,
                                            users_leaving[i]);
    if(tmp1_node == NULL) {
      return MEMBER_NOT_IN_GROUP;
    }
    while(tmp1_node != NULL){
      if(tmp1_node->self_nv->bkey != NULL){
        BN_clear_free(tmp1_node->self_nv->bkey);
        tmp1_node->self_nv->bkey = NULL;
      }
      if(tmp1_node->self_nv->key != NULL){
        BN_clear_free(tmp1_node->self_nv->key);
        tmp1_node->self_nv->key = NULL;
      }
      tmp1_node = tmp1_node->parent;
    }
    
    /* Delete the leaving members from the current tree;
     * Pointer handling
     */
    if(leave_node->parent->parent == NULL){ /* If my index is 2 or 3 */
      if(leave_node->self_nv->index % 2 == 0){ /* If my index is 2 */
        if(leave_node->parent != ctx->root){
          fprintf(stderr, "Parent of leave node is not root 1\n");
          return SELF_STRUCTURE_ERROR;
        }
        self_copy_node(leave_node->parent, leave_node->parent->right);
        tmp_node=ctx->root = leave_node->parent->right;
        leave_node->parent->right->parent = NULL;
      }
      else{ /* If my index is 3 */
        if(leave_node->parent != ctx->root){
          fprintf(stderr, "Parent of leave node is not root 1\n");
          return SELF_STRUCTURE_ERROR;
        }
        self_copy_node(leave_node->parent, leave_node->parent->left);
        tmp_node=ctx->root = leave_node->parent->left;
        leave_node->parent->left->parent = NULL;
      }
    }
    else{
      if(leave_node->parent->self_nv->index % 2 == 0){
        if(leave_node->self_nv->index % 2 == 0){
          self_copy_node(leave_node->parent, leave_node->parent->right);
          leave_node->parent->parent->left = leave_node->parent->right;
          leave_node->parent->right->parent = leave_node->parent->parent;
          tmp_node = leave_node->parent->right;
        }
        else{
          self_copy_node(leave_node->parent, leave_node->parent->left);
          leave_node->parent->parent->left = leave_node->parent->left;
          leave_node->parent->left->parent = leave_node->parent->parent;
          tmp_node = leave_node->parent->left;
        }
      }
      else{
        if(leave_node->self_nv->index % 2 == 0){
          self_copy_node(leave_node->parent, leave_node->parent->right);
          leave_node->parent->parent->right = leave_node->parent->right;
          leave_node->parent->right->parent = leave_node->parent->parent;
          tmp_node = leave_node->parent->right;
        }
        else{
          self_copy_node(leave_node->parent, leave_node->parent->left);
          leave_node->parent->parent->right = leave_node->parent->left;
          leave_node->parent->left->parent = leave_node->parent->parent;
          tmp_node = leave_node->parent->left;
        }
      }
    }
    if(users_leaving[0] != NULL){
      (*the_sponsor) = self_search_member(tmp_node, 2, NULL);
      sponsor_list[list_counter] = (*the_sponsor)->self_nv->member->member_name;
      list_counter++;
    }
    if(tmp_node->left){
      self_update_index(tmp_node->right, 1, 
                        tmp_node->self_nv->index);
      self_update_index(tmp_node->left, 0,
                        tmp_node->self_nv->index);
    }
    
    if(leave_node->prev != NULL) 
      leave_node->prev->next = leave_node->next;
    if(leave_node->next != NULL) 
      leave_node->next->prev = leave_node->prev;
    self_free_node(&leave_node->parent);
    self_free_node(&leave_node);
    
    ctx->root->self_nv->num_node -= 2;
    first = self_search_member(ctx->root, 2, NULL);
    if(first == NULL) {
      return SELF_STRUCTURE_ERROR;
    }
    height=0;
    while(first != NULL){
      height = MAX(log2(first->self_nv->index), height);
      first = first->next;
    }
    
    ctx->root->self_nv->height = height;
    first = self_search_member(ctx->root, 2, NULL);
    if(first == NULL) {
      return SELF_STRUCTURE_ERROR;
    }
    while(first != NULL){
      first->self_nv->potential =
        height - log2(first->self_nv->index) -1;
      if(first->self_nv->potential > -1) first->self_nv->joinQ = TRUE;
      else first->self_nv->joinQ = FALSE;
      first = first->next;
    }
    
    self_update_potential(ctx->root);
    
    i++;
  }
  
  /*      self_print_simple("Bef spo ch", ctx->root); */
  if(sponsor_list[0] != NULL){
    for(i=0; i<list_counter; i++){
      tmp1_node = self_search_member(ctx->root, 4, sponsor_list[i]);
      if(tmp1_node->self_nv->index < min_index){
        *the_sponsor = tmp1_node;
        min_index = tmp1_node->self_nv->index;
      }
    }
    
    tmp1_node = *the_sponsor;
    if(tmp1_node->self_nv->bkey != NULL){
      BN_clear_free(tmp1_node->self_nv->bkey);
      tmp1_node->self_nv->bkey = NULL;
    }
    if(tmp1_node->self_nv->key != NULL){
      BN_clear_free(tmp1_node->self_nv->key);
      tmp1_node->self_nv->key = NULL;
    }
    tmp1_node = tmp1_node->parent;
    while(tmp1_node != NULL){
      if(tmp1_node->self_nv->bkey != NULL){
        BN_clear_free(tmp1_node->self_nv->bkey);
        tmp1_node->self_nv->bkey = NULL;
      }
      if(tmp1_node->self_nv->key != NULL){
        BN_clear_free(tmp1_node->self_nv->key);
        tmp1_node->self_nv->key = NULL;
      }
      tmp1_node = tmp1_node->parent;
    }
  }

  return 1;
}

/* Make a tree list for merge */
TREE_LIST *add_tree_list(TREE_LIST *list, KEY_TREE *tree) 
{
  TREE_LIST *tmp_list=NULL, *tmp1_list=NULL, *tmp2_list=NULL;
  TREE_LIST *head=NULL; 
  KEY_TREE *tmp_tree=NULL, *tmp1_tree=NULL;

  head = list;
  tmp_tree = self_search_member(tree, 3, NULL);

  if(tree == NULL) return NULL;
  
  if(list == NULL){
    list = (TREE_LIST *) calloc(sizeof(TREE_LIST), 1);
    if(list == NULL){
      return NULL;
    }
    list->tree = tree;
    list->end = list;
    list->next = NULL;
    return list;
  }
  else{
    if(list->end != list){
      if(list->next == NULL){
        return NULL;
      }
    }
    else{
      if(list->end->next != NULL){
        return NULL;
      }
    }
    tmp_list = (TREE_LIST *) calloc(sizeof(TREE_LIST), 1);
    tmp_list->tree = tree;

    tmp1_list = head;
    while(tmp1_list != NULL){
      tmp1_tree = self_search_member(tmp1_list->tree, 3, NULL);
      if(tmp1_list->tree->self_nv->height <
         tmp_list->tree->self_nv->height){
        break;
      }
      else if((tmp1_list->tree->self_nv->height ==
               tmp_list->tree->self_nv->height) &&
              (strcmp(tmp1_tree->self_nv->member->member_name,
                      tmp_tree->self_nv->member->member_name) < 0)){
        break;
      }
      else{
        tmp2_list = tmp1_list;
        tmp1_list = tmp1_list->next;
      }
    }

    if(tmp2_list == NULL){
      tmp_list->next = tmp1_list;
      tmp_list->end = tmp1_list->end;
      tmp1_list->end = NULL;
      return tmp_list;
    }
    
    if(tmp1_list == NULL){
      tmp2_list->next = tmp_list;
      head->end = tmp_list;
      if(tmp2_list != head){
        tmp2_list->end = NULL;
      }
      return head;
    }

    tmp2_list->next = tmp_list;
    tmp_list->next = tmp1_list;
    
  }

  return head;
}

/* self_merge merges two tree using self_merge_tree */
KEY_TREE *self_merge(KEY_TREE *big_tree, KEY_TREE *small_tree)
{
  KEY_TREE *tmp1_node=NULL, *tmp_node=NULL;
  KEY_TREE *joiner=NULL, *joinee=NULL;
  int tmp_height=0, tmp_num=0;
  
  /* Now, we can merge two trees to generate a new tree   */
  if(big_tree->self_nv->height == small_tree->self_nv->height){
    tmp1_node = self_search_member(big_tree, 2, NULL);
    tmp_node = self_search_member(small_tree, 2, NULL);
    if(strcmp(tmp1_node->self_nv->member->member_name,
              tmp_node->self_nv->member->member_name)>0){  
      joiner = small_tree;
      joinee = big_tree;
    }
    else if(strcmp(tmp1_node->self_nv->member->member_name,
                   tmp_node->self_nv->member->member_name)<0){  
      joiner = big_tree;
      joinee = small_tree;
    }
    else{
      fprintf(stderr,"strange... two of them are same???\n");
      return NULL;
    }
  }
  else if(big_tree->self_nv->height > small_tree->self_nv->height){ 
    joiner = small_tree;
    joinee = big_tree;
  }
  else{
    joiner = big_tree;
    joinee = small_tree;
  }
  
  if(joiner->self_nv->height <= joinee->self_nv->potential){
    tmp_height = joinee->self_nv->height;
  }
  else{
    tmp_height = joinee->self_nv->height+1;
  }
  tmp_num=joiner->self_nv->num_node+joinee->self_nv->num_node+1;
  tmp1_node = tmp_node = self_search_node(joiner, joinee, 0);
  tmp_node = self_merge_tree(joiner, tmp_node);
  if(tmp_node == NULL) {
    return NULL;
  }
  if(tmp_node->parent != NULL){
    return NULL;
  }
  
  tmp1_node = joiner->parent;
  while(tmp1_node != NULL){
    if(tmp1_node->self_nv->key != NULL){
      BN_clear_free(tmp1_node->self_nv->key);
      tmp1_node->self_nv->key = NULL;
    }
    if(tmp1_node->self_nv->bkey != NULL){
      BN_clear_free(tmp1_node->self_nv->bkey);
      tmp1_node->self_nv->bkey = NULL;
    }
    tmp1_node = tmp1_node->parent;
  }
  
  big_tree = tmp_node;
  
  big_tree->self_nv->height = tmp_height;
  big_tree->self_nv->num_node = tmp_num;
  if(joinee != tmp_node){
    joinee->self_nv->height=joinee->self_nv->num_node=-1;
  }
  if(joiner != tmp_node){
    joiner->self_nv->height=joiner->self_nv->num_node=-1;
  }

  
  return big_tree;
}

/* Remove all tree list */
void remove_tree_list(TREE_LIST **list)
{
  TREE_LIST *tmp_list=NULL;

  tmp_list = (*list)->next;
  while((*list) != NULL){
    free(*list);
    (*list) = tmp_list;
    if((*list) == NULL){
      break;
    }
    else{
      tmp_list = (*list)->next;
    }
  }

  return;
}

  
