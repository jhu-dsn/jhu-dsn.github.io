/* CLIQUES Non-Commercial License (covers BD, CLQ, STR and TGDH
libraries).  Copyright (c) 1998-2002 by the University of California,
Irvine.  All rights reserved.

Permission to use, copy, modify, and distribute this software and its
documentation in source and binary forms for lawful non-commercial
purposes and without fee is hereby granted, provided that the above
copyright notice appear in all copies and that both the copyright
notice and this permission notice appear in supporting documentation,
and that any documentation, advertising materials, and other materials
related to such distribution and use acknowledge that the software was
developed by the University of California, Irvine, Information and
Computer Science Department. The name of University of California,
Irvine may not be used to endorse or promote products derived from
this software without specific prior written permission.

THE UNIVERSITY OF CALIFORNIA, IRVINE MAKES NO REPRESENTATIONS ABOUT
THE SUITABILITY OF THIS SOFTWARE FOR ANY PURPOSE.  THIS SOFTWARE IS
PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND
NON-INFRINGEMENT.

IN NO EVENT SHALL UNIVERSITY OF CALIFORNIA, IRVINE OR ANY OTHER
CONTRIBUTOR BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
DAMAGES, WHETHER IN CONTRACT, TORT, OR OTHER FORM OF ACTION, ARISING
OUT OF OR IN CONNECTION WITH, THE USE OR PERFORMANCE OF THIS SOFTWARE.

All questions concerning this software should be directed to
cliques@ics.uci.edu. */


/*********************************************************************
 * self_test_all.c                                                    * 
 * SELF test source file.                                            * 
 * Date      Tue Nov 21 22:08:07 PST 2000                            *
 * Modified by:                                                      *
 *   Yongdae Kim                                                     *
 *                                                                   *
 * CLIQUES Project                                                   *
 * Information Sciences Institute                                    *
 * University of Southern California                                 *
 *********************************************************************/


#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <strings.h>

#include <sys/types.h>
#include <time.h>
#include <sys/resource.h>

#include "bn.h"
#include "self_api.h"
#include "self_api_misc.h"
#include "self_error.h"

#include "self_test_misc.h"
#include "self_test.h"
#include "self_test_all.h"

/* dmalloc CNR.  */
#ifdef USE_DMALLOC
#include <dmalloc.h>
#endif


#define CMERGE 2
#define CPARTITION 3
#define DEFAULT 10

int main(int argc, char **argv) {
  TEST_USER *users[NUM_USERS]={NULL};
  SELF_NAME *global_list[NUM_USERS+1]={NULL};
  SELF_NAME *delegates[NUM_USERS+1]={NULL};
  SELF_NAME *leaving_list[NUM_USERS+1]={NULL};
  SELF_NAME *merge_list=NULL;
  
  int num_users=0, num_round=0;
  int ret = OK;
  int round=0, max_part=0;
  int i=0, j=0, k=0, l=0;
  int index=0;
  int finish=0;
  int new_round=1;

#ifdef TIMING
  print=1;
#endif
#if defined(PROFILE) | defined(TIMING)
  r=0; /* To avoid a warning during compilation */
#endif
  if (!parse_args(argc,argv,&num_users,&num_round)) goto error;
  /*********************************/
  
  if(!initialize_all(users, global_list, delegates, leaving_list,
                     num_users)){ 
    goto error;
  }

  if(!join_all(users, num_users, global_list)){
    goto error;
  }

  /* To generate a random event, we need some number of
   * groups... Hence, I'm partition whole group into 2 ~ 4 small
   * groups
   */
  if((max_part=generate_one_random_partition(users, users[0]->user[0]))<1){
    goto error;
  }

  self_print_all("root",users[0]->ctx->root);
  
  for(j=0; j<max_part; j++){
    for(i=0; i<num_users; i++){
      if(users[i]->which_partition==j){
        delegates[j] = users[i]->ctx->member_name;
      }
    }
  }

  for(j=0; j<max_part; j++){
    finish = -1;
    index = atoi(delegates[j]);
    while(finish!=1){
      finish = one_cascade(users, users[index]->user);
    }
  }

  for(i=0; i<NUM_USERS+1; i++){
    delegates[i]=NULL;
  }
  max_part=0;

  clear_token(users);
  
  fprintf(stderr, "\n\nSTARTING EVERYTING!!!\n\n");

  round=0;
  j=0;
  finish=0;
  
  while(round<num_round){
    if(new_round){
      fprintf(stderr, "%d-th round started\n", round);
      ret=generate_one_random_event(users, global_list, delegates, 
                                    &merge_list, leaving_list, num_users,
                                    &max_part, &j, 1); 
      j=0;
      finish=0;
      new_round=0;
    }
    else{
      if((ret=generate_one_random_event(users, global_list, delegates, 
                                        &merge_list, leaving_list, num_users,
                                        &max_part, &j, 0))>0){   
        finish=0;
      }
    }
    
    if(delegates[0] != NULL){
      if(ret == 0){
        index = atoi(delegates[0]);
        finish = one_cascade(users, users[index]->user);
      }
      if(ret == 1){
        finish = one_cascade(users, users[atoi(merge_list)]->user);
        finish = one_cascade(users, users[atoi(merge_list)]->user);
      }
      if(ret == 2){
        for(k=0; leaving_list[k] != NULL; k++){
          index = atoi(leaving_list[k]);
          finish = one_cascade(users, users[index]->user);
          if(finish == 1){
            if(remove_delegates(delegates, leaving_list[k], &max_part)==-1){
              goto error;
            }
          }
        }
        finish = 100;
      }
      ret=0;
    }
    if(finish == OK){
      for(i=0; users[index]->user[i] != NULL; i++){
        remove_delegates(delegates,
                         users[index]->user[i],
                         &max_part);
        if(delegates[0] == NULL){
          break;
        }
      }
      
      if(delegates[0] == NULL){
        fprintf(stderr, "End of round %d\n\n", round);
        clear_token(users);
        round++;
        new_round=1;
        j=0;
        for(i=0; i<NUM_USERS; i++){ 
          delegates[i]=NULL; 
        }
      }
    }
  }
  
error:
  destroy_all(users, global_list, num_users);

  return 0;
}

int generate_one_random_event(TEST_USER *test_user[],
                              SELF_NAME *global_list[],
                              SELF_NAME *delegates[],
                              SELF_NAME **merge_list,
                              SELF_NAME *leaving_list[], int num_users,
                              int *max_part, int *curr_delegate,
                              int cases)
{
  struct rusage used;
  int mem1=0, mem2=0;
  int search=0;
  int event=0;
  int i=0, j=0, k=0, l=0;
  SELF_NAME *current_list[NUM_USERS+1]={NULL};
  int ret=OK;
  int max_part1=0;
  int num_delegates=0;
  int sub=0;
  int count=0;
  int start_leaving=0;
  int choose_from_current=0;

  for(num_delegates=0; delegates[num_delegates] != NULL;
      num_delegates++);
  
  getrusage(RUSAGE_SELF, &used);
  srand(used.ru_utime.tv_usec+31267831);
  if(cases==1){
    if(num_delegates == 1){
      event = CPARTITION-1;
    }
    else{
      event = (int)rand() % CPARTITION;
    }
    for(i=0; test_user[0]->user[i] != NULL; i++);
    if(i == num_users){
      event = CPARTITION-1;
    }
  }
  else{
    if(num_delegates == 1){
      event = (int)rand() % (DEFAULT-CMERGE);
      event += CMERGE;
    }
    else{
      event = (int)rand() % DEFAULT;
    }
  }

  if((event >= 0) && (event < CMERGE)){ /* Event is merge */
    (*merge_list) = NULL;
    if(num_delegates > 1){
      choose_from_current = 1;
      getrusage(RUSAGE_SELF, &used);
      srand(used.ru_utime.tv_usec+l);

      mem1 = *curr_delegate;
      search = -1;
      count = 0;
      
      while(search != 1){
        if((count++) == 60){
          fprintf(stderr, "Nothing happened...\n");
          return 0;
        }
        getrusage(RUSAGE_SELF, &used);
        srand(used.ru_utime.tv_usec+l);
        mem2 = (int)rand() % num_users;
        search = 1;
      
        for(j=0; test_user[atoi(delegates[*curr_delegate])]->user[j] != NULL; j++){ 
          if(atoi(test_user[atoi(delegates[*curr_delegate])]->user[j]) == mem2){ 
            search = -1; 
            break; 
          } 
        } 
      }
      mem1 = atoi(delegates[mem1]);
    }
    else{
      getrusage(RUSAGE_SELF, &used);
      srand(used.ru_utime.tv_usec+l);
      mem1 = (int)rand() % num_users;

      search = -1;
      count = 0;
      while(search != 1){
        if((count++) == 60){
          fprintf(stderr, "Nothing happened...\n");
          return 0;
        }
        getrusage(RUSAGE_SELF, &used);
        srand(used.ru_utime.tv_usec+mem2);
        mem2 = (int)rand() % num_users;
        search = 1;
        for(i=0; test_user[mem1]->user[i] != NULL; i++){
          if(atoi(test_user[mem1]->user[i]) == mem2){
            search=-1;
            break;
          }
        }
      }
    }
    
    (*merge_list) = global_list[mem1];
#ifdef DEBUG_ALL
    fprintf(stderr, "Cascaded merge happens\n");
#endif
    for(i=0; test_user[mem1]->user[i] != NULL; i++){
      if(test_user[mem1]->user[i] != NULL){
        test_user[atoi(test_user[mem1]->user[i])]->input =
          remove_all_token(test_user[atoi(test_user[mem1]->user[i])]->input); 
      }
    }
    for(i=0; test_user[mem2]->user[i] != NULL; i++){
      if(test_user[mem2]->user[i] != NULL){
        test_user[atoi(test_user[mem2]->user[i])]->input =
          remove_all_token(test_user[atoi(test_user[mem2]->user[i])]->input); 
      }
    }
    ret = one_merge_req(test_user, global_list[mem1], global_list[mem2]);
    if(ret != 1){
      fprintf(stderr, "Merge request failed\n");
      return -1;
    }
    ret = one_merge_req(test_user, global_list[mem2], global_list[mem1]);
    if(ret != 1){
      fprintf(stderr, "Merge request failed\n");
      return -1;
    }
    update_member_list(test_user, global_list[mem1],
                       global_list[mem2], NULL); 
    if(delegates[0]==NULL){
      *max_part=1;
      delegates[0]=global_list[mem1];
    }
    else{
      for(j=0; j<NUM_USERS; j++){
        if(delegates[j] != NULL){
          if(strcmp(delegates[j], global_list[mem2])==0){
            remove_delegates(delegates, global_list[mem2], max_part);
            break;
          }
        }
      }
      (*max_part)--;
    }
    ret=CMERGE-1;
  }
  else if((event >= CMERGE) && (event < CPARTITION)){ /* Event is
                                                         partition */
    for(i=0; i<NUM_USERS; i++){
      leaving_list[i]=NULL;
    }
    if(num_delegates > 0){
      mem1 = atoi(delegates[*curr_delegate]);
      start_leaving = 1;
      if(test_user[mem1]->ctx->root->self_nv->num_node < 2){
        fprintf(stderr, "Nothing happened...\n");
        return 0;
      }
      if(test_user[mem1]->leaving_list[0] != NULL){
        fprintf(stderr, "Nothing happened...\n");
        return 0;
      }
    }
    else{
      getrusage(RUSAGE_SELF, &used);
      srand(used.ru_utime.tv_usec+event);
      mem1 = (int)rand() % num_users;
      count=0;
      while(test_user[mem1]->ctx->root->self_nv->num_node < 2){
        if((count++) == 60){
          fprintf(stderr, "Nothing happened...\n");
          return 0;
        }
        getrusage(RUSAGE_SELF, &used);
        srand(used.ru_utime.tv_usec+l);
        mem1 = (int)rand() % num_users;
      }
    }
    for(i=0; i<NUM_USERS; i++){
      current_list[i]=test_user[mem1]->user[i];
    }
    
    for(i=0; current_list[i] != NULL; i++){
      if(test_user[atoi(current_list[i])] != NULL){
        test_user[atoi(current_list[i])]->input =
          remove_all_token(test_user[atoi(current_list[i])]->input); 
      }
    }
    for(i=0; i<NUM_USERS; i++){
      if(test_user[i]){
        test_user[i]->which_partition = -1;
      }
    }

    if(test_user[atoi(global_list[mem1])]->user[1] == NULL){
      fprintf(stderr, "Nothing happened...\n");
      return 0;
    }
    
    max_part1 = generate_one_random_partition(test_user, global_list[mem1]);
#ifdef DEBUG_ALL
    if(max_part1>0){
      fprintf(stderr, "Cascaded partition happens\n");
    }
#endif
    for(k=0; delegates[k] != NULL; k++);
    for(j=0; j<max_part1; j++){
      for(i=0; current_list[i] != NULL; i++){
        if(test_user[atoi(current_list[i])]->which_partition == j){
          leaving_list[j]=current_list[i];
          search = -1;
          for(l=0; l<k; l++){
            if(strcmp(current_list[i], delegates[l])==0){ 
              start_leaving--;
              search = 1;
              break;
            }
          }
          if(search == -1){
            delegates[j+k-sub] = current_list[i];
/*              leaving_list[j+start_leaving] = current_list[i]; */
          }
          else{
            sub++;
          }
          break;
        }
      }
    }
    if(*max_part == 0){
      *max_part = max_part1;
    }
    else{
      *max_part = max_part1 + *max_part - 1 - sub;
    }
    
    ret = CPARTITION-1;
  }
  else{
    fprintf(stderr, "Nothing happened...\n");
    ret=0;
  }
  
  return ret;
}
     
int generate_one_random_partition(TEST_USER *test_user[],
                                  SELF_NAME *initiator)
{
  int index=0;
  int j1=0, j2=0, i=0, l=0, j=0, k1=-1, k2=-1;
  int num_users=0;
  struct rusage used;
  SELF_NAME *current_list[NUM_USERS+1];

  index = atoi(initiator);
  for(num_users=0; test_user[index]->user[num_users] != NULL;
      num_users++){ 
  }
  getrusage(RUSAGE_SELF, &used);
  srand(used.ru_utime.tv_usec+l);
  /* This depends on the network topology... However, let's say 4 */
  /* l=((int) rand()) % (num_user/2); */
  if(num_users<4){
    l=2;
  }
  else{
    l=((int) rand()) % 2;
    l += 2;
  }

    
#ifdef DEBUG_ALL
  fprintf(stderr, "num_users = %d, num_partition = %d\n",
          num_users,l);
#endif

  for(i=0; i<NUM_USERS; i++){
    if(test_user[i]){
      test_user[i]->which_partition = -1;
    }
  }

  for(k1=0; k1<l; k1++){
    test_user[atoi(test_user[index]->user[k1])]->which_partition = k1;
    fprintf(stderr, "%d:%d ", atoi(test_user[index]->user[k1]),
            test_user[atoi(test_user[index]->user[k1])]->which_partition); 
  }
  for(i=l; test_user[index]->user[i] != NULL; i++){
    j = atoi(test_user[index]->user[i]);
    getrusage(RUSAGE_SELF, &used);
    srand(used.ru_utime.tv_usec+rand());
    test_user[j]->which_partition=((int) rand()) % l;
    fprintf(stderr, "%d:%d ", j, test_user[j]->which_partition);
  }
#ifdef DEBUG_ALL
  fprintf(stderr, "\n");
#endif
  
  for(i=0; i<NUM_USERS; i++){
    current_list[i] = test_user[index]->user[i];
  }
  
  for(i=0; current_list[i] != NULL; i++){
    j1 = atoi(current_list[i]);
    k1=k2=0;
    for(j=0; j<NUM_USERS; j++){
      test_user[j1]->remaining_list[j]=NULL;
      test_user[j1]->leaving_list[j]=NULL;
    }
    
    for(j=0; current_list[j] != NULL; j++){
      j2 = atoi(current_list[j]);
      if(test_user[j1]->which_partition==test_user[j2]->which_partition){
        test_user[j1]->remaining_list[k1] =
          test_user[j2]->ctx->member_name;
        k1++;
      }
      else{
        test_user[j1]->leaving_list[k2] =
          test_user[j2]->ctx->member_name;
        k2++;
      }
    }
    for(j=0; j<NUM_USERS; j++){
      test_user[j1]->user[j]=test_user[j1]->remaining_list[j];
      test_user[j1]->remaining_list[j]=NULL;
    }
  }
  

  return l;
}

int join_all(TEST_USER *test_user[], int num_users,
             SELF_NAME *global_list[]) 
{
  int ret=-1;
  int i=0, j=0;

  for(i=0; i<num_users-1; i++){
    ret = one_merge_req(test_user, global_list[i+1], global_list[i]);
    if(ret != 1){
      fprintf(stderr, "Merge request failed\n");
      return -1;
    }
    ret = one_merge_req(test_user, global_list[i], global_list[i+1]);
    if(ret != 1){
      fprintf(stderr, "Merge request failed\n");
      return -1;
    }
    j = atoi(global_list[i]);
    update_member_list(test_user, global_list[i], global_list[i+1],
                       NULL); 
  
    ret=-1;
    while(ret != 1){
      ret = one_cascade(test_user, test_user[i]->user);
    }
    clear_token(test_user);
  }

  return ret;
}

int one_cascade(TEST_USER *test_user[], SELF_NAME *current_members[])
{
  int Ret=OK;
  int ret=OK;
  int i=0, j=0, k=0, l=0;
  SELF_TOKEN *output[NUM_USERS]={NULL}, *tmp=NULL;

  for(i=0; i<NUM_USERS; i++){
    output[i]=NULL;
  }

  i=0;
  while(current_members[i] != NULL){
    j = atoi(current_members[i]);
    if(test_user[j]->leaving_list[0]){
      ret = self_cascade(&(test_user[j]->ctx), GROUP_NAME,
                         test_user[j]->leaving_list,
                         NULL, &tmp);
      for(l=0; test_user[j]->leaving_list[l] != NULL; l++){
        test_user[j]->leaving_list[l] = NULL;
      }
    }
    else{
      ret = self_cascade(&(test_user[j]->ctx), GROUP_NAME,
                         test_user[j]->leaving_list,
                         test_user[j]->input->token, &tmp);
    }
    
#ifdef DEBUG_ALL
    printf("\t::::self_cascade of %s returns %d\n",
           test_user[j]->ctx->member_name,ret); 
#endif
    if(ret <= 0){
      return ret;
    }
    Ret = MAX(Ret, ret);

    if(tmp != NULL){
      if(output[k] != NULL){
        self_destroy_token(&output[k]);
      }
      output[k] = tmp;
      k++;
    }
    tmp=NULL;
    i++;
  }

  remove_token_sub(test_user, current_members);

  for(j=0; j<k; j++){
    ret = add_token_sub(test_user, current_members, output[j]);
    self_destroy_token(&output[j]);
    output[j] = NULL;
  }
  
  return Ret;
}

int one_merge_req(TEST_USER *test_user[], SELF_NAME *joiner,
                  SELF_NAME *joinee)  
{
  int j=0;
  int ret=OK;
  KEY_TREE *sponsor=NULL;
  SELF_TOKEN *tmp_token=NULL;

#ifdef DEBUG_ALL
  printf("\n\n++++++++++ merge happens\n");
#endif
  /* One member sends merge request */
  j = atoi(joiner);

  /* To find the sponsor */
  sponsor = self_search_member(test_user[j]->ctx->root, 3, NULL);
  j = atoi(sponsor->self_nv->member->member_name);

  ret=self_merge_req(test_user[j]->ctx,
                     test_user[j]->ctx->member_name, GROUP_NAME, 
                     &tmp_token);
#ifdef DEBUG_ALL
  printf ("\t::self_merge_req of %s returns %d\n",
          test_user[j]->ctx->member_name,ret); 
#endif  
  if (ret!=1) {
    return ret;
  }

  /* Add token means that token is broadcasted and each member in both
   * groups receives the token
   */
  j = atoi(joiner);
  ret = add_token_sub(test_user, test_user[j]->user, tmp_token);
  if(ret != 1) {
    return ret;
  }
  j = atoi(joinee);
  ret = add_token_sub(test_user, test_user[j]->user, tmp_token);
  if(ret != 1) {
    return ret;
  }
  
  self_destroy_token(&tmp_token);
  
  return ret;
}

int initialize_all(TEST_USER *test_user[], SELF_NAME *global_list[],
                   SELF_NAME *delegates[], SELF_NAME *leaving_list[],
                   int num_users)
{
  int i=0;
  int ret=OK;
  
  if(num_users < 1){
    fprintf(stderr, "I cannot initialize less than 1 users\n");
    return -1;
  }
  for(i=0; i<num_users; i++){
    global_list[i]=
      (SELF_NAME *)malloc(sizeof(SELF_NAME)*MAX_LGT_NAME);
    sprintf(global_list[i], "%03d", i);
    delegates[i]=leaving_list[i]=NULL;
    ret = initialize_user(&test_user[i], global_list[i]);
    if(ret != 1){
      fprintf(stderr, "Initialization failed!!!\n");
      goto error;
    }
  }
  
error:
  if(ret != OK){
    destroy_all(test_user, global_list, num_users);
  }
  
  return ret;
}
  
int initialize_user(TEST_USER **test_user, SELF_NAME *user_name)
{
  int ret=OK;
  int i=0;
  
  if((*test_user) != NULL){
    fprintf(stderr,"User is not null!!!");
    return -1;
  }
  else{
    (*test_user) = (TEST_USER *)calloc(sizeof(TEST_USER), 1);
    if((*test_user) == NULL){
      fprintf(stderr, "MALLLOC error at initialize_user\n");
      return MALLOC_ERROR;
    }
    ret = self_new_member(&((*test_user)->ctx),user_name,GROUP_NAME);
    if(ret != 1){
      fprintf(stderr, "self_new_member error at initialize_user\n");
      return ret;
    }

    for(i=0; i<NUM_USERS; i++){
      (*test_user)->user[i]=NULL;
      (*test_user)->leaving_list[i]=NULL;
      (*test_user)->remaining_list[i]=NULL;
    }
    (*test_user)->user[0] = user_name;
    (*test_user)->which_partition = -1;
  }
  return ret;
}

void destroy_all(TEST_USER *test_user[], SELF_NAME *global_list[],
                 int num_users)  
{
  int i=0;
  
  for(i=0; i<num_users; i++){
    if(global_list[i] != NULL) {
      free(global_list[i]);
      global_list[i] = NULL;
    }
    if(test_user[i] != NULL){
      destroy_user(&test_user[i]);
    }
  }
}

void destroy_user(TEST_USER **test_user)
{
  int i=0;
  
  if((*test_user)->ctx != NULL){
    self_destroy_ctx(&((*test_user)->ctx),1);
  }
  for(i=0; i<NUM_USERS; i++){
    (*test_user)->user[i]=NULL;
    (*test_user)->leaving_list[i]=NULL;
    (*test_user)->remaining_list[i]=NULL;
  }

  (*test_user)->input = remove_all_token((*test_user)->input);
  (*test_user)->input = NULL;
  
  free((*test_user));
  (*test_user) = NULL;
}

int clear_token(TEST_USER *test_user[])
{
  int i=0;

  for(i=0; i<NUM_USERS; i++){
    if(test_user[i] != NULL){
      test_user[i]->input = remove_all_token(test_user[i]->input);
    }
  }
  return OK;
}

      
int add_token_sub(TEST_USER *test_user[], SELF_NAME *current_user[],
                  SELF_TOKEN *new_token)
{
  int i=0;
  int ret=OK;
  int index=0;

  while(current_user[i] != NULL){
    index = atoi(current_user[i]);
    ret = token_dup(test_user[index], new_token);
    if(ret != 1){
      return -1;
    }
    i++;
  }

  return OK;
}

int remove_token_sub(TEST_USER *test_user[], SELF_NAME *current_user[])
{
  int i=0;
  int index=0;

  while(current_user[i] != NULL){
    index = atoi(current_user[i]);
    test_user[index]->input = remove_token(&(test_user[index]->input));
    i++;
  }
  return OK;
}

int token_dup(TEST_USER *test_user, SELF_TOKEN *new_token)
{
  TOKEN_LIST *tmp_list=NULL;

  if(new_token == NULL) return -1;

  if(test_user->input == NULL){
    test_user->input = (TOKEN_LIST *) calloc(sizeof(TOKEN_LIST), 1);
    if(test_user->input == NULL){
      return -1;
    }
    test_user->input->token
      = (SELF_TOKEN *)malloc(sizeof(SELF_TOKEN));
    if(test_user->input->token == NULL){
      return -1;
    }
    test_user->input->token->length = new_token->length;
    test_user->input->token->t_data
      =(tgdh_uchar *)malloc(sizeof(tgdh_uchar)*test_user->input->token->length);
    if(test_user->input->token->t_data == NULL){
      return -1;
    }
    bcopy(new_token->t_data, test_user->input->token->t_data,
          test_user->input->token->length);
        
    test_user->input->end = test_user->input;
    test_user->input->next = NULL;
  }
  else{
    tmp_list = (TOKEN_LIST *) calloc(sizeof(TOKEN_LIST), 1);
    if(tmp_list == NULL){
      return -1;
    }
    tmp_list->token
      = (SELF_TOKEN *)malloc(sizeof(SELF_TOKEN));
    if(tmp_list->token == NULL){
      return -1;
    }
    tmp_list->token->length = new_token->length;
    tmp_list->token->t_data
      =(tgdh_uchar *)malloc(sizeof(tgdh_uchar)*tmp_list->token->length);
    if(tmp_list->token->t_data == NULL){
      return -1;
    }
    bcopy(new_token->t_data, tmp_list->token->t_data,
          tmp_list->token->length);
    test_user->input->end->next = tmp_list;
    test_user->input->end = tmp_list;
    tmp_list->next = NULL;
    tmp_list->end = NULL;
  }

  return OK;

}

int update_member_list(TEST_USER *test_user[], SELF_NAME *sponsor1,
                       SELF_NAME *sponsor2, SELF_NAME *leaving_members[])
{
  int ret=OK;
  int index1=0, index2=0;
  int i=0, j=0, num=0;
  SELF_NAME *tmp_list[NUM_USERS+1]={NULL};

  if(leaving_members == NULL){
    if((sponsor1 == NULL)||(sponsor2 == NULL)){
      return -1;
    }
    for(i=0; i<NUM_USERS; i++){
      tmp_list[i]=NULL;
    }
  
    index1 = atoi(sponsor1);
    index2 = atoi(sponsor2);
    i = 0;
    j = 0;
    while(test_user[index1]->user[i] != NULL){
      tmp_list[i] = test_user[index1]->user[i];
      i++;
    }
    while(test_user[index2]->user[j] != NULL){
      tmp_list[i] = test_user[index2]->user[j];
      i++;
      j++;
    }
    num = i;

    for(i=0; i<num; i++){
      index1 = atoi(tmp_list[i]);
      for(j=0; j<num; j++){
        test_user[index1]->user[j] = tmp_list[j];
      }
    }
  }
  return ret;
}

int remove_delegates(SELF_NAME *delegates[], SELF_NAME *which, int *max_part)
{
  int i=0, j=0;

  if(delegates[0] == NULL) {
    return -1;
  }
  
  for(i=0; i<NUM_USERS+1; i++){
    if(delegates[i] != NULL){
      if(strcmp(delegates[i], which)==0){
        break;
      }
    }
  }
  if(delegates[i] == NULL){
    return -1;
  }
  for(j=i; j<NUM_USERS-1; j++){
    if(delegates[j] != NULL){
      delegates[j] = delegates[j+1];
    }
  }
  *max_part--;
  
  return 1;
}
