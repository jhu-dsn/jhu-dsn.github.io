/* CLIQUES Non-Commercial License (covers BD, CLQ, STR and TGDH
libraries).  Copyright (c) 1998-2002 by the University of California,
Irvine.  All rights reserved.

Permission to use, copy, modify, and distribute this software and its
documentation in source and binary forms for lawful non-commercial
purposes and without fee is hereby granted, provided that the above
copyright notice appear in all copies and that both the copyright
notice and this permission notice appear in supporting documentation,
and that any documentation, advertising materials, and other materials
related to such distribution and use acknowledge that the software was
developed by the University of California, Irvine, Information and
Computer Science Department. The name of University of California,
Irvine may not be used to endorse or promote products derived from
this software without specific prior written permission.

THE UNIVERSITY OF CALIFORNIA, IRVINE MAKES NO REPRESENTATIONS ABOUT
THE SUITABILITY OF THIS SOFTWARE FOR ANY PURPOSE.  THIS SOFTWARE IS
PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND
NON-INFRINGEMENT.

IN NO EVENT SHALL UNIVERSITY OF CALIFORNIA, IRVINE OR ANY OTHER
CONTRIBUTOR BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
DAMAGES, WHETHER IN CONTRACT, TORT, OR OTHER FORM OF ACTION, ARISING
OUT OF OR IN CONNECTION WITH, THE USE OR PERFORMANCE OF THIS SOFTWARE.

All questions concerning this software should be directed to
cliques@ics.uci.edu. */

/*********************************************************************
 * self_error.h                                                      * 
 * TREE error codes                                                  * 
 * Wrote by:                                                         * 
 *  Yongdae Kim                                                      *
 *                                                                   *
 * CLIQUES Project                                                   *
 * Information Sciences Institute                                    *
 * University of Southern California                                 *
 *********************************************************************/
#ifndef CLQ_ERROR_H
#define CLQ_ERROR_H

/* Error codes */
#define OK                          1
#define CONTINUE                    2
#define KEY_COMPUTED                3

#define CTX_ERROR                  -1
#define INVALID_INPUT_TOKEN       -10
#define INVALID_MEMBER_NAME       -12
#define INVALID_MESSAGE_TYPE      -11
#define INVALID_GROUP_NAME        -13
#define GROUP_NAME_MISMATCH       -14
#define INVALID_LGT_NAME          -15
#define SELF_STRUCTURE_ERROR      -16
#define MEMBER_NOT_IN_GROUP       -17

#define SELF_MERGE_FAILURE        -21
#define ERROR_INT_DECODE          -22

#define INVALID_DSA_PARAMS        -40
#define INVALID_PRIV_KEY          -42

#define MALLOC_ERROR              -50

/* clq_cert errors */
#define INVALID_DSA_TYPE         -100 
#define INVALID_CA_FILE          -101
#define INVALID_CERT_FILE        -102
#define INVALID_PKEY             -103

#define INVALID_SIGNATURE_SCHEME -300
#define SIGNATURE_ERROR          -301
#define SIGNATURE_DIFER          -302
#define INVALID_SIGNATURE        -303

#endif






