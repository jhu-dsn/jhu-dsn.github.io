/* CLIQUES Non-Commercial License (covers BD, CLQ, STR and TGDH
libraries).  Copyright (c) 1998-2002 by the University of California,
Irvine.  All rights reserved.

Permission to use, copy, modify, and distribute this software and its
documentation in source and binary forms for lawful non-commercial
purposes and without fee is hereby granted, provided that the above
copyright notice appear in all copies and that both the copyright
notice and this permission notice appear in supporting documentation,
and that any documentation, advertising materials, and other materials
related to such distribution and use acknowledge that the software was
developed by the University of California, Irvine, Information and
Computer Science Department. The name of University of California,
Irvine may not be used to endorse or promote products derived from
this software without specific prior written permission.

THE UNIVERSITY OF CALIFORNIA, IRVINE MAKES NO REPRESENTATIONS ABOUT
THE SUITABILITY OF THIS SOFTWARE FOR ANY PURPOSE.  THIS SOFTWARE IS
PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND
NON-INFRINGEMENT.

IN NO EVENT SHALL UNIVERSITY OF CALIFORNIA, IRVINE OR ANY OTHER
CONTRIBUTOR BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
DAMAGES, WHETHER IN CONTRACT, TORT, OR OTHER FORM OF ACTION, ARISING
OUT OF OR IN CONNECTION WITH, THE USE OR PERFORMANCE OF THIS SOFTWARE.

All questions concerning this software should be directed to
cliques@ics.uci.edu. */

/*********************************************************************
 * Copyright (c) 1998-2000 by the University of Southern California.
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and
 *
 * its documentation in source and binary forms for lawful
 * non-commercial purposes and without fee is hereby granted, provided
 * that the above copyright notice appear in all copies and that both
 * the copyright notice and this permission notice appear in supporting
 * documentation, and that any documentation, advertising materials, and
 * other materials related to such distribution and use acknowledge that
 * the software was developed by the University of Southern California,
 * Information Sciences Institute. The name of USC may not be used to
 * endorse or promote products derived from this software without
 * specific prior written permission.
 *
 * THE UNIVERSITY OF SOUTHERN CALIFORNIA MAKES NO REPRESENTATIONS
 * ABOUT THE SUITABILITY OF THIS SOFTWARE FOR ANY PURPOSE.  THIS
 * SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND
 * NON-INFRINGEMENT.
 *
 * IN NO EVENT SHALL USC OR ANY OTHER CONTRIBUTOR BE LIABLE FOR ANY
 * SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES, WHETHER IN CONTRACT,
 * TORT, OR OTHER FORM OF ACTION, ARISING OUT OF OR IN CONNECTION
 * WITH, THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * All questions concerning this software should be directed to
 * cliques@isi.edu.
 *********************************************************************/

/*********************************************************************
 * clq_api.c                                                         * 
 * CLQ api source file.                                              * 
 * Date      Tue Nov 21 22:08:07 PST 2000                            *
 * Wrote by:                                                         * 
 * Damian Hasse                                                      *
 *                                                                   *
 * CLIQUES Project                                                   *
 * Information Sciences Institute                                    *
 * University of Southern California                                 *
 *********************************************************************/
#include <stdio.h>
#include <time.h>
#include <sys/time.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <strings.h>
#include <malloc.h>

#include <netinet/in.h> /* Needed by htonl and ntohl */

/* SSL include files */
#include "openssl/bn.h"
#include "openssl/bio.h"
#include "openssl/md5.h"
#include "openssl/err.h"
#include "openssl/dsa.h"

/* CLQ_API include files */
#include "clq_api.h"
#include "clq_error.h"
#include "clq_cert.h" /* clq_get_cert is here */

#ifndef SIGNATURES
#include "clq_mac.h"
#else
#include "clq_sig.h"
#endif
#ifdef TIMING
#include "clq_api_misc.h" /* clq_get_time is defined here */
#endif

/*
 * clq_join is called by a new group member who has received a
 * NEW_MEMBER message from the current controller.
 * Parameters:
 *  ctx
 *   Group context (created).
 *   Preconditions: *ctx should be empty
 *  member_name
 *   Current user member name.
 *   It has to be a valid c-string.
 *  group_name
 *    Name of the group that has been joined. This
 *    name has to match the one that is included in input.
 *    It has to be a valid c-string.  
 *  input
 *    Message received from the controller containing the
 *    communication token (i.e. the header and the group member list
 *    without the long-term shared key). This message is generated by
 *    the controller using clq_proc_join. 
 *  output
 *    New key updated message generated to be broadcasted to the group.
 *    It will be set to NULL if an error occurs during computation.
 *
 * Return: 
 *   OK succeed.
 *   CTX_ERROR when ctx is null.
 *   INVALID_MEMBER_NAME when member_name is invalid (i.e NULL).
 *
 *
 */
/*
  LIKE -> receive_last_bcst(AGDH *agdh, char *mess);
 */
int clq_join (CLQ_CONTEXT **ctx, CLQ_NAME *member_name, 
              CLQ_NAME *group_name, CLQ_TOKEN *input, 
              CLQ_TOKEN **output) {
  CLQ_GML *group;
  CLQ_TOKEN_INFO *info;
  int not_fnd = 1;
  int ret=OK;
#ifndef SIGNATURES
  uchar *hmc=NULL;
  clq_uint num_mac=0;
#else
  CLQ_SIGN *sign=NULL;
#endif
#ifdef TIMING
  double Time=0.0;

  Time=clq_get_time();
#endif
  
  /* Doing some error checkings */
  if (*ctx != (CLQ_CONTEXT *) NULL) return CTX_ERROR;
  if (member_name == NULL) return INVALID_MEMBER_NAME;
  if ((strlen(member_name) == 0) ||
      (strlen(member_name) > MAX_LGT_NAME)) return INVALID_LGT_NAME;
  if (group_name == NULL) return INVALID_GROUP_NAME;
  if ((strlen(group_name) == 0) ||
      (strlen(group_name) > MAX_LGT_NAME)) return INVALID_LGT_NAME;
  
#ifndef SIGNATURES
  /* Added by Yongdaek for MAC */
  hmc = (uchar *)malloc(sizeof(uchar) * MD5_DIGEST_LENGTH);
  if(hmc == (uchar *) NULL)  {ret = MALLOC_ERROR; goto error;}
  ret=remove_hmac(input, hmc, &num_mac);
  /* end of adding by Yongdaek */
#else
  ret=clq_remove_sign(input,&sign);
#endif
  if (ret != OK) goto error;
  
  /* Decoding the token & creating ctx */
  if ((ret=clq_decode(ctx, input, &info))!=OK) goto error;
  
  if (info->message_type != NEW_MEMBER) 
  { ret=INVALID_MESSAGE_TYPE; goto error; }
  if (strcmp(info->group_name,group_name))
  { ret=GROUP_NAME_MISMATCH; goto error; }
  (*ctx)->group_name=info->group_name;
  
  /* Looking for myself in ctx, and setting the pointers last &
   * me.
   */
  group = (*ctx)->first;
  while (group != (CLQ_GML*)NULL) {
    if (!strcmp(group->member->member_name,member_name)) {
      not_fnd = !not_fnd; /* Found myself */
      (*ctx)->me=group;
      break;
    }
    group = group->next;
  }
  
  /* Since there cannot be anybody else after myself let's check it*/
  if (not_fnd) { ret=INVALID_INPUT_TOKEN; goto error; }
  (*ctx)->last=(*ctx)->me; /* Since I am the last member, me & last point
                              to the same location */
  (*ctx)->member_name=(CLQ_NAME *) malloc(sizeof(CLQ_NAME)*MAX_LGT_NAME);
  if ((*ctx)->member_name == (CLQ_NAME *) NULL) 
  { ret=MALLOC_ERROR; goto error; }
  strcpy ((*ctx)->member_name,member_name);
  
  /* Checking if the user previous to me is on the list */
  if (group->prev == (CLQ_GML *) NULL) { ret=CTX_ERROR; goto error; }
  if (strcmp(group->prev->member->member_name,info->sender_name))
  { ret=MEMBER_NAME_MISMATCH; goto error; }
  /* Error checkings done */
  
  /* Get DSA parameters */
  (*ctx)->params=clq_read_dsa(NULL,CLQ_PARAMS);
  if ((*ctx)->params == (DSA *)NULL) { ret=INVALID_DSA_PARAMS; goto error; }
#ifndef SIGNATURES
  /* Get user private and public keys */
  (*ctx)->private=clq_read_dsa(member_name,CLQ_PRV);
  if ((*ctx)->private == (DSA *)NULL) { ret=INVALID_PRIV_KEY; goto error; }
#else
  (*ctx)->pkey=clq_get_pkey(member_name);
  if (((*ctx)->pkey) == (EVP_PKEY*) NULL) { ret=INVALID_PRIV_KEY; goto error; }
#endif
  
#ifndef SIGNATURES
  /*Added by Yongdaek for MAC */
  ret=check_hmac(*ctx, input, hmc,
                 (*ctx)->me->prev->member->member_name, num_mac);
#else
  ret=clq_vrfy_sign (*ctx, input,
                     (*ctx)->me->prev->member->member_name, sign); 
#endif
  
  if(ret!=OK) goto error;
  
  if ((ret=clq_sanity_check(*ctx))==OK) {
#ifdef DEBUG
    fprintf(ERR_STRM,"I (%s) am the new"
            " controller.\n", (*ctx)->member_name);
#endif
    /* Creating new key */
    (*ctx)->key_share = clq_grt_rnd_val((*ctx)->params);
    if ((*ctx)->key_share == (BIGNUM *) NULL) 
    { ret=MALLOC_ERROR; goto error;}
    if ((ret=clq_creat_new_key(*ctx,TRUE))!=OK) goto error;
    
    /* Updating the token information & generating token */
    info->message_type=KEY_UPDATE_MESSAGE;
    info->time_stamp=time(0);
    strcpy (info->sender_name,member_name);
    (*ctx)->epoch++; /* Used inside clq_encode */
    ret=clq_encode((*ctx),output,info);
    if (ret!=OK) goto error;
    
#ifndef SIGNATURES
    ret=add_hmac((*ctx), (CLQ_NAME *)NULL, output);
#else
    /* sign_message */
    ret=clq_sign_message ((*ctx), *output);
#endif
    
    info->group_name=NULL; /* This memory location is now used by
                              ctx->group_name, so do NOT free it. */
    (*ctx)->epoch--; /* I am undoing it so every member will do it at the
                      * same time.
                      */
    
#ifdef DEBUG
    fprintf(ERR_STRM,"Broadcasting Update: %s\n",(*ctx)->member_name);
#endif
  }
  
  error:
#ifndef SIGNATURES
  restore_hmac (input,num_mac);
  if(hmc != (uchar *)NULL) free(hmc);
#else
  if (ret==OK) ret=clq_restore_sign(input,&sign);
#endif
  
  if (ret!= OK) 
    if (*ctx != (CLQ_CONTEXT *) NULL) clq_destroy_ctx(ctx);
  
  if (info != (CLQ_TOKEN_INFO*)NULL) clq_destroy_token_info(&info);
  
#ifdef TIMING
  Time=clq_get_time()-Time;
  clq_print_times("clq_join",Time); 
#endif
  
  return ret;
} /* clq_join */

/* clq_proc_join (clq process join) is called by the current
 * controller to hand over the group context to a new member (who will
 * become the next controller). 
 * If a regular user calls the function, NOT_CONTROLLER will be returned.
 * Postconditions: If controller then, ctx is modified.
 *
 * Parameters:
 *  ctx
 *   Group context. If user is the controller then ctx will be
 *   modified.  
 *  member_name
 *   Current user member name.
 *   It has to be a valid c-string.
 *  output
 *   New key updated message generated to be broadcasted to the group.
 *   It should be empty (otherwise it will be freed). 
 *   It is generated using clq_context.group_members_list (without
 *   long_term_key). This token should be used as the input token
 *   of clq_join.
 *   It will be set to NULL if an error occurs during computation.
 *
 * Return:
 *  OK succeed.
 *   CTX_ERROR when ctx is null.
 *   INVALID_MEMBER_NAME when member_name is invalid (i.e NULL).
 *
 */
int clq_proc_join (CLQ_CONTEXT *ctx, CLQ_NAME *member_name, 
                   CLQ_TOKEN **output) {
  int ret=OK;
  CLQ_TOKEN_INFO *info=NULL;
#ifdef TIMING
  double Time=0.0;
  
  Time=clq_get_time();
#endif
  
  /* Doing some error checkings */
  if (ctx == (CLQ_CONTEXT *) NULL) return CTX_ERROR;
  if (member_name == NULL) return INVALID_MEMBER_NAME;
  if ((strlen(member_name) == 0) ||
      (strlen(member_name) > MAX_LGT_NAME)) return INVALID_LGT_NAME;
  if (ctx->me != ctx->last) return NOT_CONTROLLER;
  
  /* Was the user already in the group? */
  if (clq_search_gml(ctx->group_members_list,member_name)!=(CLQ_GML *)NULL)
    return MEMBER_IS_IN_GROUP;
  /* Error checkings done */
  
  /* Updating last_partial_keys between this user and everybody else's
     before sending it. */
  ret=clq_join_update_key(ctx,member_name);
  
  if (ret!=OK) goto error;
  
  /* Creating token info */
  ret=clq_create_token_info(&info,ctx->group_name,NEW_MEMBER, 
                            time(0),ctx->member_name); 
  
  if (ret!=OK) goto error;
  
  /* Generating output token */
  ret=clq_encode(ctx,output,info);
  if (ret!=OK) goto error;
  
#ifndef SIGNATURES
  /* Added by Yongdaek for MAC */
  ret=add_hmac(ctx, ctx->last->member->member_name, output);
#else
  /* sign_message */
  ret=clq_sign_message (ctx, *output);
#endif
  
  error:  
  
  if (info != (CLQ_TOKEN_INFO*)NULL) clq_destroy_token_info(&info);
  
#ifdef TIMING
  Time=clq_get_time()-Time;
  clq_print_times("clq_proc_join",Time); 
#endif

  return ret;
} /* clq_proc_join */


/* clq_update_ctx is called by a member upon reception of a
 * KEY_UPDATE_MESSAGE or KEY_MERGE_UPDATE from the current group
 * controller. This function will update the group_secret.
 *
 * Parameters:
 * ctx
 *  Group context (modified).
 * input
 *  Message received by new member, or by current controller. This
 *  last one can happen when an update of the key is required
 *  (i.e. a user left, or the key has been compromised.) 
 *
 * Return:
 *   OK succeed.
 *   CTX_ERROR when ctx is null.
 */
/*
  LIKE -> receive_broadcast(agdh,mess,sender)
 */
int clq_update_ctx (CLQ_CONTEXT *ctx, CLQ_TOKEN *input) 
{
  BN_CTX *bn_ctx=BN_CTX_new();  
  BIGNUM *tmp_key=BN_new();
  CLQ_CONTEXT *new_ctx=NULL;
  CLQ_TOKEN_INFO *info=NULL;
  int ret=OK;
  int controller=FALSE;
#ifndef SIGNATURES
  uchar *hmc=NULL;
  clq_uint num_mac=0;
#else
  CLQ_SIGN *sign=NULL;
#endif
#ifdef TIMING
  double Time=0.0;

  Time=clq_get_time();
#endif

  if ((bn_ctx == (BN_CTX *) NULL) || (tmp_key == (BIGNUM *) NULL)) 
    return MALLOC_ERROR;

  if (ctx == (CLQ_CONTEXT *) NULL) { ret=CTX_ERROR; goto error; }


#ifndef SIGNATURES
  /*Added by Yongdaek for MAC */
  hmc = (uchar *)malloc(sizeof(uchar) * MD5_DIGEST_LENGTH * MAX_LIST);
  if(hmc == (uchar *) NULL)  {ret = MALLOC_ERROR; goto error;}
  ret=remove_hmac(input, hmc, &num_mac);
  /* end of adding by Yongdaek */
#else
  ret=clq_remove_sign(input,&sign);
#endif
  if (ret != OK) goto error;

  /* Doing some error checking and setting the new group member list
   * if it is valid. 
   */
  if ((ret=clq_decode(&new_ctx, input, &info))!=OK)
    goto error;

  if (strcmp (info->group_name,ctx->group_name)) 
    { ret=GROUP_NAME_MISMATCH; goto error; }

  if (new_ctx->epoch != (ctx->epoch+1)) { ret=UNSYNC_EPOCH; goto error; }

  if ((info->message_type != KEY_UPDATE_MESSAGE) &&
      (info->message_type != KEY_MERGE_UPDATE))
      { ret=INVALID_MESSAGE_TYPE; goto error; }
  /* Last member (i.e. controller) should be the one sending the
   * message.
   */
  if (strcmp(new_ctx->last->member->member_name,info->sender_name))
    { ret=SENDER_NOT_CONTROLLER; goto error; }

  controller = !strcmp (new_ctx->last->member->member_name,ctx->member_name);

  ret=clq_gml_update (ctx,new_ctx,info->message_type);
  if (ret != OK) goto error;

#ifndef SIGNATURES
  /*Added by Yongdaek for MAC */
  if (ctx->me != ctx->last) {
    ret=check_hmac(ctx, input, hmc,
		   ctx->last->member->member_name, num_mac);
  }
#else
  /* if ctx->me == ctx->last then I am just veriyfing my own message */
  ret=clq_vrfy_sign (ctx, input, ctx->last->member->member_name, sign); 
#endif

  if(ret!=OK) goto error;
  else {

    ctx->epoch++;
    
#ifdef SLOW
    /* This is done above optimized */
    /* Updating long term keys. 
       This can be optimize !!!
       i.e. clq_update_lt_key does NOT have to be called, becuase we
       already have the long_term_key in the old group. But since it
       is not straight forward when several members left, then I will
       optimize this once the rest is working :) (Note: when a new member
       is added we need to compute this new long term key, but when
       member left we have this information but in a different order) */
    ret=clq_update_lt_key (ctx);
    if (ret!=OK) goto error;
#endif
    /* Done with error checkings & updates */
    
#ifdef DEBUG
    fprintf(ERR_STRM,"Received partial key broadcast.\n"); 
#endif
    
#ifndef SIGNATURES
    /* If I am the controller then I don't need to compute
     * K-inverse.
     */
    if (!controller) { 
      BIGNUM *inv_long_term_key=NULL;

      /* Computing long_term_key with user if need it */
      if (ctx->last->member->long_term_key == (BIGNUM*) NULL) {
        ret=clq_compute_one_lt_key(ctx,ctx->last->member);
        if (ret!=OK) goto error;
      }

      inv_long_term_key = BN_mod_inverse(inv_long_term_key,
                                         ctx->last->member->long_term_key,
                                         ctx->params->q,bn_ctx); 
      if (inv_long_term_key == NULL) { ret=CTX_ERROR; goto error; }
      BN_mod_mul (tmp_key, inv_long_term_key,
                  ctx->key_share,
                  ctx->params->q, bn_ctx ); 
      
      BN_clear_free (inv_long_term_key);
      inv_long_term_key=NULL;
    }
    else
#endif
      BN_copy (tmp_key, ctx->key_share); /* BN_copy needs tmp_key to
					    be initialized (BN_new). */

    BN_mod_exp(ctx->group_secret,ctx->me->member->last_partial_key,
	       tmp_key, ctx->params->p,bn_ctx); 


#ifdef PRINT_BN
    printf ("BN_mod_exp\n");
#endif

    ret=clq_compute_secret_hash (ctx);
    if (ret!=OK) goto error;

  } /* if (clq_gml_update(...) */

error:
#ifndef SIGNATURES
  restore_hmac(input,num_mac);
  if(hmc != (uchar *)NULL) free(hmc);
#else
  if (ret==OK) ret=clq_restore_sign(input,&sign);
#endif

  clq_destroy_ctx(&new_ctx);
  clq_destroy_token_info(&info);
  if (bn_ctx != NULL) BN_CTX_free (bn_ctx);
  if (tmp_key != NULL) BN_clear_free(tmp_key);

#ifdef TIMING
  Time=clq_get_time()-Time;
  clq_print_times("clq_update_ctx",Time);
#endif

  return ret;
} /* clq_update_ctx */



/* clq_gml_update: It is used by clq_update_ctx and clq_factor_out to
 * update the group member list with the new one provided in the
 * new_ctx. 
 */
int clq_gml_update (CLQ_CONTEXT *ctx, CLQ_CONTEXT *new_ctx, 
		    enum MSG_TYPE m_type) {
  CLQ_GML *group;
  CLQ_GML *new_group;
  int ret=OK;
  int not_fnd=TRUE;

  new_group=new_ctx->group_members_list;
  if (new_group == (CLQ_GML*) NULL) {ret=CTX_ERROR; goto error; }
  group=ctx->group_members_list;

  while ((new_group != (CLQ_GML *) NULL) && (group != NULL)) {
    /* If the names are equal, then set found */
    if (!strcmp(ctx->member_name,new_group->member->member_name)){
      if (not_fnd) {
        new_ctx->me=new_group;
        not_fnd=!not_fnd;
      }
      else { 
        ret=MEMBER_REPEATED; /* I am at least twice in the new_group */
        goto error;
      }
    }
    /* Found the first difference among group and new_group */
    if (strcmp(new_group->member->member_name,group->member->member_name)) 
      break;

#ifndef SIGNATURES
    /* Copying long_term_keys to new_group */
    if (group->member->long_term_key != NULL) {
      new_group->member->long_term_key=group->member->long_term_key;
      group->member->long_term_key=NULL;
    }
#else
    /* Copying certificates to new_group */
    if (group->member->cert != NULL) {
      new_group->member->cert=group->member->cert;
      group->member->cert=NULL;
    }
#endif

    new_group=new_group->next;
    group=group->next;
  }

  /* If not_fnd is true, then a difference between group and new_group
   * was found before I found myself in the group (or new_group does
   * not contain myself). This is an error
   * because if a member was deleted before me then I should have been
   * the group controller at some point in time. Thus, I should have
   * updated my ctx (ctx->group_members_list). So group and new_group
   * should not differ.
   */
  if (not_fnd) { ret=MEMBER_NOT_IN_GROUP; goto error; }

  if (m_type != MERGE_BROADCAST) { /* called by clq_update_ctx */ 
    if ((new_group != (CLQ_GML *)NULL) && (group == NULL) && 
	(m_type != KEY_MERGE_UPDATE) && 
	(new_group->next != (CLQ_GML *) NULL))
      { ret = SEVERAL_JOINS; goto error; }
    
    /* params (p  and q) are required for the sanity check. I am saving
     * memory and time dealing with p & q this way.
     */
    new_ctx->params=ctx->params;
    ret=clq_sanity_check(new_ctx);
    new_ctx->params=NULL;
  }

  if (ret==OK) {
    /* Setting the new group */
    clq_free_gml(ctx->group_members_list);
    ctx->group_members_list=new_ctx->group_members_list;
    ctx->first=new_ctx->group_members_list;
    ctx->last=new_ctx->last;
    ctx->me=new_ctx->me;
    new_ctx->last=new_ctx->me=new_ctx->first=new_ctx->group_members_list=NULL;
  }

error:

  return ret;
}


/* clq_leave is called by every group member right after a member
 * leaves the group or a partition occurs (i.e. several members
 * left). This function will remove all the valid members in
 * member_list from the group_members_list. It does not depend on the
 * type of the user. 
 * Once all the deletion has been achieved, then if the user is the
 * controller (i.e. ctx->last == ctx->me) an output token will be
 * generated. Otherwise output token will be NULL.
 *
 * Only the members that are found in the group_members_list will be
 * deleted. Any invalid member in member_list will be ignored.
 *
 * If current user belongs to the members_list (i.e. ctx->me is
 * NULL after the deletion), then ctx will be destroyed.  
 *
 * Preconditions: member_list has to be NULL terminated. 
 *                The size of member_list should be less than MAX_LIST
 * Parameters:
 *  ctx
 *   Group context (modified).
 *  member_list
 *   List of names of users leaving the group.
 *  output
 *   New key updated message generated to be broadcasted to the group.
 *  flag
 *   if it is 1, then compute the real values... Otherwise, just remove members
 *
 * Return:
 *   OK succeed.
 *   CTX_ERROR when ctx is null.
 */

/*
  LIKE -> received_leave(agdh,target_groups,vs_members,num_groups);
*/
int clq_leave (CLQ_CONTEXT **ctx, CLQ_NAME *member_list[], 
               CLQ_TOKEN **output, int flag) {
  int i;
  CLQ_GML *gml;
  CLQ_GML *tmp_member;
  CLQ_NAME *old_controller;
  BIGNUM *old_long_term_key_inv=NULL; /* long term key if old
                                         controller */
  BN_CTX *bn_ctx=BN_CTX_new();
  int ret=OK;

#ifdef TIMING
  double Time=0.0;

  Time=clq_get_time(); 
#endif

  if (bn_ctx == (BN_CTX *) NULL) return MALLOC_ERROR;

  if (*ctx ==(CLQ_CONTEXT *) NULL) return CTX_ERROR;

  if ((*ctx)->group_members_list == (CLQ_GML *) NULL) return CTX_ERROR;

  if (member_list == NULL) return LIST_EMPTY;

  /* Getting name of old controller */
  old_controller=(CLQ_NAME *) malloc(sizeof(CLQ_NAME)*MAX_LGT_NAME);
  strcpy (old_controller,(*ctx)->last->member->member_name);
#ifndef SIGNATURES
  /* Kij with myself is not kept */
  if ((*ctx)->last->member->long_term_key != NULL) {
    old_long_term_key_inv=BN_mod_inverse(old_long_term_key_inv,
					 (*ctx)->last->member->long_term_key,
					 (*ctx)->params->q,bn_ctx);  
    if (old_long_term_key_inv==NULL) { ret=CTX_ERROR; goto error; }
  }
#endif
  
  /* Removing the members */
  i=0;
  while ((member_list[i] != NULL) && (i < MAX_LIST)) {
    gml=(*ctx)->group_members_list;
    while (gml != NULL) { /* Note if there is a match then it will
                             stop also, see the break below */
      if (!strcmp(gml->member->member_name,member_list[i])) { 
        /* Member found -> remove it */
        tmp_member=gml;
        if (gml->prev == (CLQ_GML *)NULL) { /* First user */
          if (gml->next != (CLQ_GML *)NULL) /* There is more than one user */
            gml->next->prev=NULL;
        }
        else  
          if (gml->next == (CLQ_GML *)NULL) { /* Last user */
            gml->prev->next=NULL;
            (*ctx)->last=gml->prev;
          }
          else { /* A regular user */
            gml->prev->next=gml->next;
            gml->next->prev=gml->prev;
          }
#ifdef DEBUG
        fprintf (ERR_STRM,"Deleting member : %s.\n",
                 tmp_member->member->member_name);
#endif
        if (tmp_member==(*ctx)->group_members_list) 
          (*ctx)->group_members_list=(*ctx)->first=gml->next;
        
        clq_free_gm(tmp_member->member);
        tmp_member->member=NULL;
        tmp_member->prev=NULL;
        tmp_member->next=NULL;
        if (tmp_member == (*ctx)->me) (*ctx)->me=NULL;
        free(tmp_member);
        break;
      }
      gml=gml->next;
    }
    i++;
  }

  /* If I removed myself or the group_members_list is empty then ctx is
     destroyed */
  if ((*ctx)->group_members_list==(CLQ_GML*) NULL || ((*ctx)->me)==NULL) {
    clq_destroy_ctx(ctx);
    ret=OK;
    goto error;
  }

  /* Am I the controller ? */
  if ((*ctx)->me == (*ctx)->last) {
    CLQ_TOKEN_INFO *info;

    if(flag == 1){
      if ((ret=clq_creat_new_key_rm(*ctx,FALSE,TRUE))!=OK) {
        goto error;
      }
    }
    
    /* Controller will create output token */
    /* Creating token info */
    ret=clq_create_token_info(&info,(*ctx)->group_name,KEY_UPDATE_MESSAGE, 
                              time(0),(*ctx)->member_name); 
    
    if (ret!=OK) goto error;
    
    /* Generating output token */
    (*ctx)->epoch++;
    ret=clq_encode(*ctx,output,info);
    if (ret!=OK) goto error;

#ifndef SIGNATURES
    /* Added by Yongdaek for MAC */
    ret=add_hmac((*ctx), (CLQ_NAME *)NULL, output);
    /* End of Adding */
#else
    /* sign_message */
    ret=clq_sign_message ((*ctx), *output);
#endif
    if (ret!=OK) goto error;

    (*ctx)->epoch--; /* I am undoing it so every member will do it at the
		   * same time.
		   */
    
    clq_destroy_token_info(&info);
  }
#ifndef SIGNATURES
  else 
    /* Controller died and I am not the controller (i.e. I am a
     * regular user)
     */
    if (strcmp(old_controller,(*ctx)->last->member->member_name))
      /* Each user will recalculate it's user key, as follows:
       * key_share=key_share*old_long_term_key_inv
       * Note: The new controller is doing this in a different manner
       * (see above, last_partial_key=last_partial_key^old_long_term_key_inv
       */
      BN_mod_mul ((*ctx)->key_share, (*ctx)->key_share,
		  old_long_term_key_inv, (*ctx)->params->q, bn_ctx);
#endif


error:

  if (old_controller != NULL) free (old_controller);
  if (old_long_term_key_inv!=NULL)
    BN_clear_free(old_long_term_key_inv);
  BN_CTX_free(bn_ctx);

#ifdef TIMING
  Time=clq_get_time()-Time;
  clq_print_times("clq_leave",Time);
#endif

  return ret;
} /* clq_leave */

/* clq_refresh_key is called by the controller only, when
 * group_secret needs to be updated.
 *
 * Parameters:
 *  ctx
 *   Group context (modified if called by current controller).
 *  output
 *   New key updated message generated to be broadcasted to the group.
 *   It should be empty (otherwise it will be freed). CLQ_TOKEN **
 *   It will be set to NULL if an error occurs during computation.
 * Return:
 *   (Same as clq_leave)
 *   OK succeed.
 *   CTX_ERROR when ctx is null.
 */
int clq_refresh_key (CLQ_CONTEXT **ctx, CLQ_TOKEN **output) {
  int ret=OK;
  CLQ_NAME *user_leaving[]={NULL};
  
  ret=clq_leave(ctx,user_leaving,output,1);

  return ret;
}
			 
/* clq_destroy_ctx frees the space occupied by the current context.
 * Including the group_members_list.
 *
 */
void clq_destroy_ctx (CLQ_CONTEXT **Ctx) {
  CLQ_CONTEXT *ctx=*Ctx;

  if (ctx == NULL) return;
  if ((ctx->member_name) != NULL) { 
    free(ctx->member_name);
    ctx->member_name=NULL;
  }
  if ((ctx->group_name) != NULL) { 
    free(ctx->group_name);
    ctx->group_name=NULL;
  }
  if ((ctx->key_share) != NULL) {
    BN_clear_free(ctx->key_share);
    ctx->key_share=NULL;
  }
  if ((ctx->group_secret) != NULL) {
    BN_clear_free(ctx->group_secret);
    ctx->group_secret=NULL;
  }
  if ((ctx->group_secret_hash) != NULL) {
    free(ctx->group_secret_hash);
    ctx->group_secret_hash=NULL;
  }
  clq_free_gml(ctx->group_members_list);
  ctx->group_members_list=ctx->me=ctx->first=ctx->last=NULL;
  clq_free_gml(ctx->gml_cache);
  ctx->gml_cache=NULL;
  if ((ctx->params) != NULL) {
    DSA_free(ctx->params);
    ctx->params=NULL;
  }
#ifndef SIGNATURES
  if ((ctx->private) != NULL) {
    DSA_free(ctx->private);
    ctx->private=NULL;
  }
#else
  if ((ctx->pkey) != NULL) {
    EVP_PKEY_free(ctx->pkey);
    ctx->pkey=NULL;
  }
#endif
  free(ctx);
  ctx=*Ctx=NULL;

}

/* clq_new_user: Called by the first user in the group only or by new
 * users in a merge operation!.
 *
 * Parameters:
 *  ctx
 *   Group context (created).
 *   *ctx should be empty
 *  member_name
 *   Current user member name.
 *   It has to be a valid c-string.
 *  group_name
 *   Name of the group that has been joined. 
 *   It has to be a valid c-string.  
 *  set_gml
 *   In a join operation it should be TRUE.
 *   In a merge operation it should be FALSE.
 *   The main purpose is to set (or not) the group_members_list.
 *
 * Returns:
 *   OK succeed.
 *   CTX_ERROR when ctx is null.
 *   INVALID_MEMBER_NAME when member_name is invalid (i.e NULL).
 */
int clq_new_user(CLQ_CONTEXT **Ctx,CLQ_NAME *member_name, CLQ_NAME
		   *group_name, int set_gml) {
  CLQ_CONTEXT *ctx;
  int ret=OK;

  if (member_name == NULL) return INVALID_MEMBER_NAME;
  if ((strlen(member_name) == 0) ||
      (strlen(member_name) > MAX_LGT_NAME)) return INVALID_LGT_NAME;
  if (group_name == NULL) return INVALID_GROUP_NAME;
  if ((strlen(group_name) == 0) ||
      (strlen(group_name) > MAX_LGT_NAME)) return INVALID_LGT_NAME;

  if ((ret=clq_create_ctx(Ctx)) != OK) return ret;

  ctx=*Ctx;

  ctx->me=ctx->group_members_list;
  ctx->member_name=(CLQ_NAME *) malloc(sizeof(CLQ_NAME)*MAX_LGT_NAME);
  if ((ctx->member_name) == NULL) { ret=MALLOC_ERROR; goto error; }
  strcpy(ctx->member_name,member_name);
  ctx->group_name=(CLQ_NAME *) malloc(sizeof(CLQ_NAME)*MAX_LGT_NAME);
  if ((ctx->group_name) == NULL) { ret=MALLOC_ERROR; goto error; }
  strcpy(ctx->group_name,group_name);
  /* Get DSA parameters */
  ctx->params=clq_read_dsa(NULL,CLQ_PARAMS);
  if (ctx->params == (DSA *)NULL) { ret=INVALID_DSA_PARAMS; goto error; }
  /* Get user private and public keys */
#ifndef SIGNATURES
  ctx->private=clq_read_dsa(member_name,CLQ_PRV);
  if ((ctx->private) == (DSA*) NULL) { ret=INVALID_PRIV_KEY; goto error; }
#else
  ctx->pkey=clq_get_pkey(member_name);
  if ((ctx->pkey) == (EVP_PKEY*) NULL) { ret=INVALID_PRIV_KEY; goto error; }
#endif
  if (set_gml) {
    /* Since it is the first member, there is no point to generate a
     * random number. The random number will be generated upon the join
     * of a new member.
     */
    ctx->key_share=BN_dup(BN_value_one());
    ctx->me->member=(CLQ_GM *) malloc(sizeof(CLQ_GM));
    ctx->me->member->member_name=(CLQ_NAME *)
      malloc(sizeof(CLQ_NAME)*MAX_LGT_NAME); 
    strcpy (ctx->me->member->member_name,ctx->member_name);
    ctx->me->member->last_partial_key=BN_dup(ctx->params->g);
#ifndef SIGNATURES
    ctx->me->member->long_term_key=NULL;
#else
    ctx->me->member->cert=NULL;
#endif
    ctx->me->prev=NULL;
    ctx->me->next=NULL;
    ctx->controller=ctx->me;
  }
  else {
    free(ctx->group_members_list);
    ctx->me=ctx->last=ctx->first=ctx->group_members_list=NULL;
  }

error:

  if (ret!=OK) clq_destroy_ctx(Ctx);

  return ret;
} /* clq_new_user */

/* clq_read_dsa: Reads a DSA structure from disk depending on
 * CLQ_KEY_TYPE (CLQ_PARAMS, CLQ_PRV, CLQ_PUB)
 *
 * Parameters:
 *  member_name
 *   User name requesting key. 
 *   If type is CLQ_PARAMS then this parameter is not used. 
 *  type
 *   Type of key required.
 *
 * Return: A pointer to a DSA structure with the requested key if
 * succeed, otherwise NULL is returned. 
 *
 * Note: This function can be replaced for one provided by the
 * program using the API. Hence, the keys can be obtained form
 * another media if necessary. The only only condition required is
 * that the function returns a pointer to a DSA structure.
 *
 */
#ifndef USE_CLQ_READ_DSA
DSA *clq_read_dsa(CLQ_NAME *member_name, 
		  enum CLQ_KEY_TYPE type) { 
  return (DSA*)clq_get_dsa_key (member_name,type);
}
#else
DSA *clq_read_dsa(CLQ_NAME *member_name, 
		  enum CLQ_KEY_TYPE type) { 
  BIO *in=NULL;
  int ok=0;  
  char infile[50];
  DSA *dsa=NULL;

#ifdef TIMING
  double Time=0.0;

  Time=clq_get_time();
#endif

  switch (type) {
  case CLQ_PRV:
    sprintf (infile, "%s_%s.%s",PRV_FMT, member_name,
	     FILE_EXT);  
    break;
  case CLQ_PUB:
    sprintf (infile, "%s_%s.%s",PUB_FMT, member_name,
	     FILE_EXT);  
    break;
  case CLQ_PARAMS:
    sprintf (infile, COMMON_FILE);
    break;
  }

  if(strlen(infile)==0) goto error;

  in=BIO_new(BIO_s_file());
  if (in == NULL) { 
    /* ERR_print_errors(bio_err); */
    goto error;
  }

  if (BIO_read_filename(in,infile) <= 0) { 
    perror(infile); 
    goto error;
  }
#ifdef DEBUG
  fprintf(ERR_STRM,"Reading file %s.\n", infile);
  fprintf(ERR_STRM,"\tReading DSA ");
#endif

  if (type == CLQ_PARAMS) {
#ifdef DEBUG
    fprintf(ERR_STRM,"parameters\n");
#endif
    d2i_DSAparams_bio(in,&dsa);
  }
  else if(type == CLQ_PUB) {
#ifdef DEBUG
    fprintf(ERR_STRM,"public key\n");
#endif
    d2i_DSAPublicKey_bio(in,&dsa);
  }
  else if(type == CLQ_PRV) {
#ifdef DEBUG
    fprintf(ERR_STRM,"private key\n");
#endif
    d2i_DSAPrivateKey_bio(in,&dsa);
  }

  if (dsa == NULL) {
#ifdef DEBUG
    fprintf(ERR_STRM,"ERROR: Unable to load DSA structure.\n");
#endif
    /* ERR_print_errors(bio_err); */
    goto error;
  }
  
  ok =1;

error:

  if (in != NULL) BIO_free(in);

#ifdef TIMING
  Time=clq_get_time()-Time;
  clq_print_times("clq_read_dsa",Time);
#endif

  return dsa;
} /* clq_read_dsa */
#endif

/***********************/
/*CLQ private functions*/
/***********************/

/* clq_grl_encode using information from the current context and from
 * token info generates the output token.
 * include_last_partial: If TRUE includes all last_partial_keys,
 * otherwise it includes the partial key of the (controller) first
 * user in ckd. Hence it should be TRUE if called within cliques and
 * FALSE if called from ckd_gnrt_gml.
 *
 * Note: output is created here.
 * Preconditions: *output should be empty (otherwise it will be
 * freed).  
 */
int clq_grl_encode(CLQ_CONTEXT *ctx, CLQ_TOKEN **output,
		   CLQ_TOKEN_INFO *info, int include_last_partial) { 
  clq_uint pos=0;
  uchar *data;
  CLQ_GML *grp=ctx->first;

#ifdef TIMING
  double Time=0.0;

  Time=clq_get_time();
#endif
  /* Freeing the output token if necessary */
  clq_destroy_token(output);

  /* Do some error checkings HERE !! */
  if (ctx == (CLQ_CONTEXT *) NULL) return CTX_ERROR;
  /* The token has to match the current group name */
  if (strcmp(info->group_name,ctx->group_name)) return GROUP_NAME_MISMATCH;
  /* Done with error checkings */

  data=(uchar *) malloc (sizeof(uchar)*MSG_SIZE);
  if (data==(uchar *) NULL) return MALLOC_ERROR;

  string_encode(data,&pos,info->group_name);
  int_encode(data,&pos,info->message_type);
  int_encode(data,&pos,info->time_stamp);
  /* Note: info->sender_name is not used here. The name is retreived
   * from ctx.
   */
  string_encode(data,&pos,ctx->member_name);
  int_encode(data,&pos,ctx->epoch);

  /* Encoding the member list WITHOUT the long-term key information */
  if ((grp != NULL) && (!include_last_partial)) {
    string_encode(data,&pos,grp->member->member_name);
    bn_encode(data,&pos,grp->member->last_partial_key);
    grp=grp->next;
  }
  
  while (grp != NULL) {
    string_encode(data,&pos,grp->member->member_name);
    if (include_last_partial) 
      bn_encode(data,&pos,grp->member->last_partial_key);
    else
      bn_encode(data,&pos,BN_value_one());
    grp=grp->next;
  }

  *output=(CLQ_TOKEN *) malloc(sizeof(CLQ_TOKEN));
  if (*output == (CLQ_TOKEN *) NULL) return MALLOC_ERROR;
  (*output)->length=pos;
  (*output)->t_data=data;

#ifdef TIMING
  Time=clq_get_time()-Time;
  clq_print_times("clq_encode",Time);
#endif

  return OK;
}

/* clq_decode using information from the input token, it creates
 * ctx. info is also created here. It contains data recovered from
 * input such as message_type, sender, etc. (See structure for more
 * details) in readable format. 
 * Preconditions: *ctx has to be NULL.
 * Postconditions: ctx is created. The only valid data in it is
 * group_members_list (first & last), and epoch. All the other
 * variables are NULL. (clq_create_ctx behavior)
 */
int clq_decode(CLQ_CONTEXT **ctx, CLQ_TOKEN *input, CLQ_TOKEN_INFO **info) {
  clq_uint pos=0;
  int ret=CTX_ERROR;
  CLQ_GML *tmp=NULL;
  CLQ_GML *gml=NULL;
  CLQ_GML *curr=NULL;

#ifdef TIMING
  double Time=0.0;

  Time=clq_get_time();
#endif

  if (input == NULL) return INVALID_INPUT_TOKEN;
  if (input->t_data == NULL) return INVALID_INPUT_TOKEN;
  if (input->length <= 0) return INVALID_INPUT_TOKEN;

  /* Creating token info */
  ret=clq_create_token_info(info,"",INVALID,0L,"");

  if (ret!=OK) goto error;

  if (ret!=clq_create_ctx(ctx)) goto error;
  curr=(*ctx)->group_members_list;
  gml=(*ctx)->group_members_list;
  gml->member=(CLQ_GM *) malloc(sizeof(CLQ_GM));
  if (gml->member == (CLQ_GM *) NULL) {ret=MALLOC_ERROR; goto error;}
  gml->prev=NULL;
  gml->next=NULL;
  gml->member->member_name=(CLQ_NAME *)
    malloc(sizeof(CLQ_NAME)*MAX_LGT_NAME);
  if ((gml->member->member_name) == NULL) { ret=MALLOC_ERROR; goto error;}
  gml->member->last_partial_key=BN_new();
#ifndef SIGNATURES
  gml->member->long_term_key=NULL;
#else
  gml->member->cert=NULL;
#endif

  ret=INVALID_INPUT_TOKEN;
  if (!string_decode(input,&pos,(*info)->group_name)) goto error;
  if (!int_decode(input,&pos,(clq_uint*)&(*info)->message_type)) goto error;
  if (!int_decode(input,&pos,(clq_uint *)&(*info)->time_stamp)) goto error;
  if (!string_decode(input,&pos,(*info)->sender_name)) goto error;
  if (!int_decode(input,&pos,&(*ctx)->epoch)) goto error;
 
  /* Decoding the member list */
  do {
    if (!string_decode(input,&pos,curr->member->member_name)) goto error;
#ifndef SIGNATURES
    curr->member->long_term_key=NULL; 
#else
    curr->member->cert=NULL;
#endif
    if (!bn_decode(input,&pos,curr->member->last_partial_key)) goto error;
    if (pos < input->length) {
      tmp=(CLQ_GML *) malloc(sizeof(CLQ_GML));
      tmp->member=(CLQ_GM *) malloc(sizeof(CLQ_GM));
      tmp->member->member_name=(CLQ_NAME *)
        malloc(sizeof(CLQ_NAME)*MAX_LGT_NAME);
      tmp->member->last_partial_key=BN_new();
      tmp->prev=curr;
      tmp->next=NULL;
      curr->next=tmp;
      curr=curr->next;
    }
  } while (pos < input->length);

  (*ctx)->last=curr;

  /* Checking after decoding */
  if ((((*info)->sender_name) == NULL) ||
      (((*info)->group_name) == NULL) ||
      (((*ctx)->group_members_list) == NULL) ||
      ((*ctx)->epoch < 0)) ret=INVALID_INPUT_TOKEN;
  else
    ret=OK;

error:

  if (ret != OK) {
    if (info != NULL) clq_destroy_token_info(info);
    if (ctx != NULL) clq_destroy_ctx(ctx);
  }

#ifdef TIMING
  Time=clq_get_time()-Time;
  clq_print_times("clq_decode",Time);
#endif

  return ret;
}

/* int_encode: It puts an integer number in stream. Note that the size
 * of the integer number is added to the stream as well.
 */
void int_encode(uchar *stream, clq_uint *pos, clq_uint data) {
  int int_size=htonl(INT_SIZE);

  data=htonl(data);
  bcopy (&int_size,stream+*pos,LENGTH_SIZE);
  *pos+=LENGTH_SIZE;
  bcopy (&data,stream+*pos,INT_SIZE);
  *pos+=INT_SIZE;
}

/* int_decode: It gets an integer number from input->t_data. Note that
 * the size of the integer number is decoded first, and then the
 * actual number is decoded.
 * Returns: 1 succeed.
 *          0 Fails.
 */
int int_decode(const CLQ_TOKEN *input,clq_uint *pos, clq_uint *data) {
  int int_size;

  if (input->length  < LENGTH_SIZE+*pos) return 0;
  bcopy (input->t_data+*pos,&int_size,LENGTH_SIZE);
  int_size=ntohl(int_size);
  *pos+=LENGTH_SIZE;
  if (input->length  < int_size+*pos) return 0;
  bcopy (input->t_data+*pos,data,int_size);
  *pos+=int_size;
  *data=ntohl(*data);

  return 1;
}

/* string_encode: It puts the valid 'c' string into stream. It first
 * stores the message length (including \0) and the the actual
 * message.
 */
void string_encode (uchar *stream, clq_uint *pos, char *data) {
  int str_len=1;

  /* Note: we are copying the '/0' also */
  str_len+=strlen(data); 
  int_encode(stream,pos,str_len);
  bcopy (data,stream+*pos,str_len);
  *pos+=str_len;
}

/* string_decode: It restores a valid 'c' string from
 * input->t_data. First the string length is decode (this one should
 * have \0 already), and the actual string.
 * Returns: 1 succeed.
 *          0 Fails.
 */
int string_decode (const CLQ_TOKEN *input, clq_uint *pos, char *data) {
  clq_uint str_len;

  if (!int_decode(input,pos,&str_len)) return 0;
  if (input->length  < str_len+*pos) return 0;
  bcopy(input->t_data+*pos,data,str_len);
  *pos+=str_len;

  return 1;
}

/* bn_encode: BIGNUM encoding. */
void bn_encode (uchar *stream, clq_uint *pos, BIGNUM *num) {
  clq_uint size;

  size=BN_num_bytes(num);
  assert (size > 0);
  int_encode(stream,pos,size);
  BN_bn2bin(num,stream+*pos);
  *pos+=size;
}

/* bn_decode: BIGNUM decoding.
 * Preconditions: num has to be different from NULL.
 * Returns: 1 succeed.
 *          0 Fails.
 */
int bn_decode (const CLQ_TOKEN *input, clq_uint *pos, BIGNUM *num) {
  clq_uint size=0;

  if (num == (BIGNUM *) NULL) return 0;
  if (!int_decode(input,pos,&size)) return 0;
  if (size <= 0) return 0;
  if (input->length < size+*pos) return 0;
  BN_bin2bn(input->t_data+*pos,size,num);
  *pos+=size;

  return 1;
}

/* clq_create_ctx creates the clq context.
 * Preconditions: *ctx has to be NULL.
 */
int clq_create_ctx(CLQ_CONTEXT **ctx) {
  CLQ_CONTEXT *Ctx;
  int ret=CTX_ERROR;

  if (*ctx != (CLQ_CONTEXT *)NULL) return CTX_ERROR;
  /* Creating ctx */
  Ctx = (CLQ_CONTEXT *) malloc(sizeof(CLQ_CONTEXT));
  if (Ctx == NULL) goto error;
  Ctx->member_name=NULL;
  Ctx->group_name=NULL;
  Ctx->key_share=NULL; 
  Ctx->group_secret=BN_new();
  Ctx->group_secret_hash=(uchar*) malloc (MD5_DIGEST_LENGTH);
  if ((Ctx->group_secret==NULL) || (Ctx->group_secret_hash==NULL)) goto error;
  Ctx->group_members_list=(CLQ_GML *) malloc(sizeof(CLQ_GML));
  if (Ctx->group_members_list == (CLQ_GML *) NULL) goto error;
  Ctx->group_members_list->member=NULL;
  Ctx->group_members_list->prev=NULL;
  Ctx->group_members_list->next=NULL;
  Ctx->first=Ctx->group_members_list;
  Ctx->last=Ctx->group_members_list;
  Ctx->controller=NULL;
  Ctx->me=NULL;
  Ctx->gml_cache=NULL;
  Ctx->params=NULL; 
#ifndef SIGNATURES
  Ctx->private=NULL; 
#else
  Ctx->pkey=NULL;
#endif
  Ctx->epoch=0;

  ret=OK;
  *ctx=Ctx;
error:
  if (ret!=OK) 
    clq_destroy_ctx (&Ctx);

  return ret;
}
  
/* clq_create_token_info: It creates the info token.
 */
int clq_create_token_info (CLQ_TOKEN_INFO **info, CLQ_NAME *group, 
		      enum MSG_TYPE msg_type, time_t time, CLQ_NAME
		      *sender/*, clq_uint epoch*/) { 
  CLQ_TOKEN_INFO *temp;
  int ret=MALLOC_ERROR;
  
  /* Creating token information */
  temp=(CLQ_TOKEN_INFO *) malloc (sizeof(CLQ_TOKEN_INFO));
  if (temp == NULL) goto error;
  if (group != NULL) {
    temp->group_name=(CLQ_NAME *)
      malloc(sizeof(CLQ_NAME)*MAX_LGT_NAME);
    if ((temp->group_name) == NULL) goto error;
    strcpy (temp->group_name,group);
  } else temp->group_name=NULL;
  temp->message_type=msg_type;
  temp->time_stamp=time;
  if (sender != NULL) {
    temp->sender_name=(CLQ_NAME *)
      malloc(sizeof(CLQ_NAME)*MAX_LGT_NAME);
    if ((temp->sender_name) == NULL) goto error;
    strcpy (temp->sender_name,sender);
  }
  else temp->sender_name=NULL;
  /*  temp->epoch=epoch; */

  *info=temp;
  
  ret=OK;
error:
  if (ret != OK) clq_destroy_token_info(&temp);

  return ret;
}

/* clq_destroy_token_info: It frees the memory of the token. */
void clq_destroy_token_info (CLQ_TOKEN_INFO **info) {
  CLQ_TOKEN_INFO *tmp=*info;

  if (tmp == NULL) return;
  if ((tmp->group_name) != NULL) {
    free (tmp->group_name);
    tmp->group_name=NULL;
  }
  if ((tmp->sender_name) != NULL) {
    free (tmp->sender_name);
    tmp->sender_name=NULL;
  }
  free (tmp);
  tmp=*info=NULL;
}

/* clq_destroy_token: It frees the memory of the token. */
void clq_destroy_token (CLQ_TOKEN **token) {
  if (*token !=(CLQ_TOKEN *) NULL) {
    if ((*token)->t_data != NULL) {
      free ((*token)->t_data);
      (*token)->t_data=NULL;
    }
    free(*token);
    *token=NULL;
  }
}



/* clq_sanity_check: It does a sanity check on each member
 * last_partial_key.
 * Returns: OK succeed 
 *          GML_EMPTY: Group member list is empty.
 *          ONE_RCVD: One has been received.
 *          ZERO_RCVD: Zero has been received.
 *          NUM_NOT_IN_GROUP: Number received is not valid (invalid modulus)
 */
int clq_sanity_check(CLQ_CONTEXT *ctx) {
  CLQ_GML *grp=ctx->group_members_list;
  BIGNUM *num=NULL;
  BN_CTX *bn_ctx=NULL;
  int ret=OK;

#ifdef NO_SANITY_CHECK
  return OK;
#endif
  num=BN_new();
  bn_ctx=BN_CTX_new();
  
  if ((num == (BIGNUM *) NULL) || (bn_ctx == (BN_CTX*) NULL)) 
    return MALLOC_ERROR;
  if (grp == NULL) ret = GML_EMPTY;
 
  while ((grp != NULL) && ret) {
    if (BN_is_one(grp->member->last_partial_key)) {
#ifdef DEBUG
      fprintf(ERR_STRM,"Error: The number one has been received in the "\
	      "message.\n");
#endif
      ret=ONE_RCVD;
      break;
    }
    if (ret && BN_is_zero(grp->member->last_partial_key)) {
#ifdef DEBUG
      fprintf(ERR_STRM,"Error: The number zero has been received in the "\
	      "message.\n");
#endif
      ret=ZERO_RCVD;
      break;
    }
    BN_mod_exp (num,grp->member->last_partial_key,ctx->params->q,
		ctx->params->p,bn_ctx);
#ifdef PRINT_BN
    printf ("BN_mod_exp\n");
#endif
    if (!BN_is_one(num)) {
#ifdef DEBUG
      fprintf(ERR_STRM,"Error: Value received doesn't belong to group.\n");
#endif
      ret=NUM_NOT_IN_GROUP;
      break;
    }
    grp=grp->next;
  }
  
  if (bn_ctx != NULL) BN_CTX_free (bn_ctx);
  if (num != NULL) BN_clear_free (num);

  return ret;
}

/* clq_rand: Generates a new random number of "num" bits, using the
 * default parameters.
 * Returns: A pointer to a dsa structure where the random value
 *          resides. 
 *          NULL if an error occurs.
 */
BIGNUM *clq_rand (DSA *params,BIGNUM *num) {
  /* DSA *Random=NULL; */
  int ret=OK;
  BIGNUM *random=NULL;
  int i;

#ifdef TIMING
  double Time=0.0;

  Time=clq_get_time();
#endif
  
  if ((random=BN_new()) == NULL) { ret=MALLOC_ERROR; goto error;}

  /* The following idea was obtained from dsa_key.c (openssl) */
  i=BN_num_bits(num);
  for (;;) {
    BN_rand(random,i,1,0);
    if (BN_cmp(random,num) >= 0)
      BN_sub(random,random,num);
    if (!BN_is_zero(random)) break;
  }

#ifdef TIMING
  Time=clq_get_time()-Time;
  clq_print_times("clq_grt_rnd_val",Time);
#endif
 error:

  if (ret!=OK) 
    if (random != NULL) { BN_free(random); random=NULL; }

  return random;
}

/* clq_update_lt_key: Updates the long_term_key between this member
 * and each other member.
 * UNUSED FUNCTION :) 7/30/99 Dmn.-
 */
#ifdef SLOW 
int clq_update_lt_key(CLQ_CONTEXT *ctx) {
  CLQ_GML *group;
  int ret=OK;  

#ifdef TIMING
  double Time=0.0;

  Time=clq_get_time();
#endif

  group = ctx->group_members_list;
  while (group != (CLQ_GML *) NULL) {
    if (group != ctx->me) { /* I don't need my long term key with myself */
      ret=clq_compute_one_lt_key (ctx,group->member);
      if (ret!=OK) goto error;
    }
    group=group->next;
  }
error:

#ifdef TIMING
  Time=clq_get_time()-Time;
  clq_print_times("clq_update_lt_key",Time);
#endif
 
  return ret;
} /* clq_update_lt_key */
#endif 

#ifndef SIGNATURES
/* clq_compute_one_lt_key: It computes one long term key between myself
 * and member->member_name.
 * Preconditions:
 *   member->long_term_key should be NULL.
 *   ctx->private should be valid.
 *   ctx->params should be valid.
 */
int clq_compute_one_lt_key (CLQ_CONTEXT *ctx, CLQ_GM* member) {
  int ret=OK;
  DSA *other_pub=NULL;
  BN_CTX *bn_ctx=NULL;
  CLQ_GML *cached=NULL;

  if ((ctx->private == (DSA *)NULL) || (ctx->params == (DSA *)NULL)) 
    { ret=CTX_ERROR; goto error; }

  if (member->long_term_key!=NULL) {ret=CTX_ERROR; goto error; }
  member->long_term_key=BN_new();
  if (member->long_term_key == (BIGNUM *)NULL) 
    { ret=MALLOC_ERROR; goto error; }

  cached=clq_search_gml (ctx->gml_cache,member->member_name);

  /* Using the cached version */
  if ((cached != (CLQ_GML*) NULL) && 
      (cached->member->long_term_key != NULL)) {
#ifdef DEBUG
    printf ("Using the cached key between %s and %s.\n",
	    ctx->member_name, member->member_name);
#endif
    if (BN_copy (member->long_term_key,cached->member->long_term_key) == NULL)
      { ret=MALLOC_ERROR; goto error; }
  }
  else {

    bn_ctx=BN_CTX_new(); /* Temporary storage used by BN functions. */

    if (bn_ctx == (BN_CTX *) NULL) { ret=MALLOC_ERROR; goto error; }

    other_pub=clq_read_dsa(member->member_name,CLQ_PUB); 
    
    if (other_pub==NULL) { ret=INVALID_PUB_KEY; goto error; }

    BN_mod_exp(member->long_term_key,other_pub->pub_key,
	       ctx->private->priv_key,ctx->params->p,bn_ctx);
#ifdef PRINT_BN
    printf ("BN_mod_exp\n");
#endif
    /* Adding this long_term_key to the cache */
    clq_gml_cache_add (ctx, member);
    
    DSA_free(other_pub);
  }

 error:

  if (bn_ctx != NULL) BN_CTX_free (bn_ctx);
  if (ret!=OK) 
    if (member->long_term_key != NULL) 
      BN_clear_free (member->long_term_key);
  
  return ret;
}      
#endif /* ifndef SIGNATURES */

/* clq_creat_new_key: Creates new key for the group members using
 * his/her new random key (key_share). The long_term_key (K) is added
 * as well to the new key.
 * If AddK is true then Kij and the key_share is added,
 * otherwise just the key_share is added.
 */
int clq_creat_new_key_rm(CLQ_CONTEXT *ctx, int AddK, int calc_inv) {
  BIGNUM *tmp_bn=BN_new();
  BIGNUM *mult=BN_new();
  BN_CTX *bn_ctx=BN_CTX_new(); /* Temporary storage used by BN functions. */
  CLQ_GML *group;
  int ret=OK;

#ifdef TIMING
  double Time=0.0;

  Time=clq_get_time();
#endif

  if ((tmp_bn == (BIGNUM *) NULL) || (bn_ctx == (BN_CTX*) NULL))
    return MALLOC_ERROR;

  if (mult == NULL) return MALLOC_ERROR;
  
  if (calc_inv) {
    /* Removing my old key */
    mult = BN_mod_inverse(mult,ctx->key_share, ctx->params->q, bn_ctx);

    /* Updating my key */
    if ((ctx->key_share) == (BIGNUM *) NULL) {ret=CTX_ERROR; goto error;}
    BN_clear_free(ctx->key_share);

    /* Creating new random key */
    ctx->key_share = clq_grt_rnd_val(ctx->params);
    
    if (ctx->key_share == NULL) { ret=MALLOC_ERROR; goto error; }
  }


  /* Adding the long_term_key (K) to the new last_partial_key, before
   * sending the data.
   */
  group = ctx->group_members_list;
  while ((group != NULL) && ret) {
    if (group != ctx->me) { /* I don't need the long term in my number */
#ifndef SIGNATURES
      if (AddK) {
        /* Computing long_term_key with user if need it */
        if (group->member->long_term_key == (BIGNUM*) NULL) {
          ret=clq_compute_one_lt_key(ctx,group->member);
          if (ret!=OK) break;
        }
        /* Calculates K between each user and the controller */
        
        ret=BN_mod_mul(tmp_bn,ctx->key_share,group->member->long_term_key,
                       ctx->params->q, bn_ctx);
      }
      else 
#endif
        ret=(int)BN_copy(tmp_bn,ctx->key_share);
      if ((group->next != NULL) && calc_inv)
        if (ret) BN_mod_mul (tmp_bn,tmp_bn,mult,ctx->params->q,bn_ctx);
      if (ret) {
        ret=BN_mod_exp(group->member->last_partial_key, 
                       group->member->last_partial_key,
                       tmp_bn,ctx->params->p, bn_ctx);
      }
      
#ifdef PRINT_BN
      printf ("BN_mod_exp\n");
#endif
    }
    group=group->next;
  }

 error:
  if (mult != (BIGNUM *) NULL) BN_clear_free (mult);
  if (tmp_bn != (BIGNUM *) NULL) BN_clear_free (tmp_bn);
  if (bn_ctx != (BN_CTX *) NULL) BN_CTX_free (bn_ctx);

#ifdef TIMING
  Time=clq_get_time()-Time;
  clq_print_times("clq_creat_new_key",Time);
#endif
  
  return ret;

}

/* clq_join_update_key: It update the last_partial keys of the entire
 * group. This is necessary when a new member has joined the group. It
 * removes Kij's between the current user and everybody else's, while
 * adding a new key_share for the user. Then a new node is created
 * where the last_partial_key data for the new user is dropped.
 * Preconditions: It is assumed that the member calling this function
 * is the current controller.
 */
int clq_join_update_key(CLQ_CONTEXT *ctx,CLQ_NAME *new_user) {
  BIGNUM *Random=NULL;
  BIGNUM *mult=BN_new();
  BIGNUM *inv_key_share=NULL;
#ifndef SIGNATURES
  BIGNUM *inv_long_term_key=NULL;
#endif
  BIGNUM *new_exp=BN_new();
  BN_CTX *bn_ctx=BN_CTX_new();
  CLQ_GML *group=NULL;
  int ret=OK;

  if ((bn_ctx == (BN_CTX *)NULL) || (mult == (BIGNUM *)NULL) ||
      (new_exp == (BIGNUM *) NULL))
    { ret=MALLOC_ERROR; goto error; } 

  /* Since I am the controller, then I should be the last member */
  if (ctx->me != ctx->last) { ret=CTX_ERROR; goto error; }

  /* Removing my old random key */
  inv_key_share = BN_mod_inverse(inv_key_share,ctx->key_share, 
				 ctx->params->q, bn_ctx);
  /* Creating new random key */
  Random = clq_grt_rnd_val(ctx->params);

  if (Random == (BIGNUM *)NULL) { ret=MALLOC_ERROR; goto error; }
 
  /* NOTE: mult has to be different from Random and from inv_key_share, see
     bn.doc for more info. */
  /* BN_mod_mul is slower than BN_mul */
  BN_mul(mult, Random, inv_key_share, bn_ctx); 

  /* Updating my key */
  if (ctx->key_share == (BIGNUM *)NULL) { ret=CTX_ERROR; goto error; }
  BN_clear_free (ctx->key_share);
  ctx->key_share = Random;
  
  /* Removing old Kij's from broadcast, except from my last_partial_key. */
  group = ctx->group_members_list;
  while (group->next != (CLQ_GML *)NULL) { 

#ifndef SIGNATURES
    /* Computing long_term_key with user if need it */
    if (group->member->long_term_key == (BIGNUM*) NULL) {
      ret=clq_compute_one_lt_key(ctx,group->member);
      if (ret!=OK) goto error;
    }

    inv_long_term_key = BN_mod_inverse(inv_long_term_key,
				       group->member->long_term_key,
				       ctx->params->q,bn_ctx); 
    if (inv_long_term_key==NULL) { ret=CTX_ERROR; goto error; }
    
    BN_mod_mul (new_exp, mult, inv_long_term_key, ctx->params->q, bn_ctx);

    BN_mod_exp (group->member->last_partial_key,
		group->member->last_partial_key, new_exp, 
		ctx->params->p, bn_ctx); 

    BN_clear_free (inv_long_term_key);
    inv_long_term_key=NULL;
#else
    BN_mod_exp (group->member->last_partial_key,
		group->member->last_partial_key, mult, 
		ctx->params->p, bn_ctx); 
#endif
#ifdef PRINT_BN
    printf ("BN_mod_exp\n");
#endif
    group = group->next;
  }

  /* Adding new node and last_partial_key for new user */
  group->next=(CLQ_GML *) malloc(sizeof(CLQ_GML));
  group->next->prev=group;
  group=group->next;
  group->member=(CLQ_GM *) malloc(sizeof(CLQ_GM));
  group->member->member_name=(CLQ_NAME *)
    malloc(sizeof(CLQ_NAME)*MAX_LGT_NAME); 
  group->member->last_partial_key=BN_new();
#ifndef SIGNATURES
  group->member->long_term_key=NULL;
#else
  group->member->cert=NULL;
#endif
  group->next=NULL;

  strcpy (group->member->member_name,new_user);
  BN_mod_exp (group->member->last_partial_key,
	      ctx->me->member->last_partial_key,
	      ctx->key_share, ctx->params->p, bn_ctx);
#ifdef PRINT_BN
  printf ("BN_mod_exp\n");
#endif
  ctx->last=group;

error:

  if (bn_ctx != (BN_CTX *)NULL)  BN_CTX_free (bn_ctx);
  if (mult != (BIGNUM *)NULL) BN_clear_free (mult);
  if (inv_key_share != (BIGNUM *) NULL) BN_clear_free (inv_key_share);
  if (new_exp != (BIGNUM *)NULL) BN_clear_free(new_exp);

  return ret;
}

/* Frees a CLQ_GML structure */
void clq_free_gml(CLQ_GML *gml) {
  CLQ_GML *next;
  while (gml != (CLQ_GML*) NULL) {
    clq_free_gm(gml->member);
    gml->member=(CLQ_GM*) NULL;
    next=gml->next;
    free(gml);
    gml=next;
  }
}

/* Frees a CLQ_GM structure */
void clq_free_gm(CLQ_GM *gm) {
  if (gm == (CLQ_GM *)NULL) return;
  if ((gm->member_name) != NULL) {
    free (gm->member_name);
    gm->member_name=NULL;
  }
#ifndef SIGNATURES
  if ((gm->long_term_key) != NULL) {
    BN_clear_free (gm->long_term_key);
    gm->long_term_key=NULL;
  }
#else
  if ((gm->cert) != NULL) {
    X509_free (gm->cert);
    gm->cert=NULL;
  }
#endif
  if ((gm->last_partial_key) != NULL) {
    BN_clear_free (gm->last_partial_key);
    gm->last_partial_key=NULL;
  }
  free (gm);
}


/* clq_search_gml search a member in group member list. */
CLQ_GML *clq_search_gml (CLQ_GML *gml, CLQ_NAME *member_name) {
  while (gml != (CLQ_GML*) NULL) {
    if (! strcmp(gml->member->member_name, member_name))
      return gml; 
    gml= gml->next;
  }
  return NULL;
}

/* clq_create_gml creates a CLQ_GML node. The only valid value is
 * member_name (if the parameter is different from NULL).
 */
CLQ_GML *clq_create_gml (CLQ_NAME *member_name) {
  int ret=OK;
  CLQ_GML *gml;

  gml=(CLQ_GML*) malloc (sizeof(CLQ_GML));
  if (gml == (CLQ_GML*) NULL) return NULL;
  
  gml->member=(CLQ_GM *) malloc(sizeof(CLQ_GM));
  if (gml->member==(CLQ_GM *) NULL)
    { ret=MALLOC_ERROR; goto error;}
  if (member_name != (CLQ_NAME *) NULL) {
    gml->member->member_name=(CLQ_NAME *)
      malloc(sizeof(CLQ_NAME)*MAX_LGT_NAME);
    if (gml->member->member_name==(CLQ_NAME *) NULL)
      { ret=MALLOC_ERROR; goto error;}
    strcpy (gml->member->member_name,member_name);
  }
  gml->member->last_partial_key=NULL;
#ifndef SIGNATURES
  gml->member->long_term_key=NULL;
#else
  gml->member->cert=NULL;
#endif
  gml->next=NULL;
  gml->prev=NULL;

 error:
  
  if (ret!=OK) {
    clq_free_gml(gml);
    gml=NULL;
  }

  return gml;
}

/* clq_create_name_list: Creates a list of members in static_gml using
 * ctx->group_members_list. Every member is included.
 * Also setting last_partial_key of users in ctx to zero if zero_key
 * is TRUE (but not of the controller)
 */
int clq_create_name_list(CLQ_CONTEXT *ctx, CLQ_GML **static_gml, 
			 int zero_key) {
  int ret=OK;
  CLQ_GML *tmp_gml=NULL;
  CLQ_GML *gml=NULL;  
  
  tmp_gml=ctx->first;
  if (tmp_gml == (CLQ_GML*) NULL) return CTX_ERROR;
  if (tmp_gml->member == (CLQ_GM*)NULL) return CTX_ERROR;
  
  /* Creating a temporary (static_gml) list of members to keep track of
   * the token processed (received). 
   */
  *static_gml=(CLQ_GML *) malloc(sizeof(CLQ_GML));
  if (*static_gml == (CLQ_GML *) NULL) { ret=MALLOC_ERROR; goto error;}
  (*static_gml)->member=tmp_gml->member;
  if ((zero_key) && (tmp_gml != ctx->controller))
    BN_zero(tmp_gml->member->last_partial_key);
  (*static_gml)->prev=NULL;
  gml=*static_gml;
  while (tmp_gml->next != NULL) {
    gml->next=(CLQ_GML *) malloc(sizeof(CLQ_GML));
    if (gml->next == (CLQ_GML *) NULL) { ret=MALLOC_ERROR; goto error;}
    gml->next->prev=gml;
    gml=gml->next;
    tmp_gml=tmp_gml->next;
    gml->member=tmp_gml->member;
    if ((zero_key) && (tmp_gml != ctx->controller))
      BN_zero(tmp_gml->member->last_partial_key);
  }
  gml->next=NULL;
  
  /* Am I the only member in the group ? */
  if ((*static_gml)->next == (CLQ_GML *) NULL) { ret=CTX_ERROR; goto error;}
  
 error:

  return ret;
}

/* clq_compute_secret_hash: It computes the hash of the group_secret.
 * Preconditions: ctx->group_secret has to be valid.
 */
int clq_compute_secret_hash (CLQ_CONTEXT *ctx) {
  char *tmp_str=NULL;

  tmp_str=BN_bn2hex(ctx->group_secret);
  if (tmp_str==NULL) return CTX_ERROR;

  MD5(tmp_str, strlen(tmp_str), ctx->group_secret_hash);

  free(tmp_str);

  if (ctx->group_secret_hash == (uchar *) NULL) return CTX_ERROR; 

  return OK;
}

int clq_gml_cache_add (CLQ_CONTEXT *ctx, CLQ_GM* member) {
  int ret=OK;
  CLQ_GML *gml=NULL;

  gml=clq_search_gml (ctx->gml_cache,member->member_name);

  if (gml==(CLQ_GML*) NULL) {
    gml=(CLQ_GML *) malloc(sizeof(CLQ_GML));
    if (gml == (CLQ_GML *) NULL) 
      { ret=MALLOC_ERROR; goto error;}
    gml->prev=gml->next=NULL;
    gml->member=(CLQ_GM *) malloc(sizeof(CLQ_GM));
    if (gml->member==NULL) { ret=MALLOC_ERROR; goto error;}
    gml->member->member_name=(CLQ_NAME *) malloc(sizeof(CLQ_NAME)*
						 MAX_LGT_NAME);
    if (gml->member->member_name == (CLQ_NAME *) NULL) 
      { ret=MALLOC_ERROR; goto error; }
    strcpy (gml->member->member_name,member->member_name);
#ifndef SIGNATURES
    gml->member->long_term_key=BN_dup(member->long_term_key);
    if (gml->member->long_term_key == NULL)
      { ret=MALLOC_ERROR; goto error; }
#else
    gml->member->cert=X509_dup(member->cert);
    if (gml->member->cert == NULL)
      { ret=MALLOC_ERROR; goto error; }
#endif
    gml->member->last_partial_key=NULL;
    if (ctx->gml_cache != NULL) {
      gml->next=ctx->gml_cache;
      ctx->gml_cache->prev=gml;
    }
    ctx->gml_cache=gml;
  }
  else {
#ifndef SIGNATURES
    if (gml->member->long_term_key == (BIGNUM *)NULL) {
      gml->member->long_term_key=BN_new();
      if (gml->member->long_term_key == (BIGNUM *)NULL)
	{ ret=MALLOC_ERROR; goto error; }
    }
    BN_copy(gml->member->long_term_key,member->long_term_key);
#else
    if (gml->member->cert != (X509 *)NULL)
      X509_free(gml->member->cert);
    gml->member->cert=X509_dup(member->cert);
#endif
  }
  
 error:
  if (ret!=OK)
    clq_free_gml(gml);

  return ret;
}
