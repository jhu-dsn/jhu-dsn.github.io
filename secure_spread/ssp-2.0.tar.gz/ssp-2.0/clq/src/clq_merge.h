/* CLIQUES Non-Commercial License (covers BD, CLQ, STR and TGDH
libraries).  Copyright (c) 1998-2002 by the University of California,
Irvine.  All rights reserved.

Permission to use, copy, modify, and distribute this software and its
documentation in source and binary forms for lawful non-commercial
purposes and without fee is hereby granted, provided that the above
copyright notice appear in all copies and that both the copyright
notice and this permission notice appear in supporting documentation,
and that any documentation, advertising materials, and other materials
related to such distribution and use acknowledge that the software was
developed by the University of California, Irvine, Information and
Computer Science Department. The name of University of California,
Irvine may not be used to endorse or promote products derived from
this software without specific prior written permission.

THE UNIVERSITY OF CALIFORNIA, IRVINE MAKES NO REPRESENTATIONS ABOUT
THE SUITABILITY OF THIS SOFTWARE FOR ANY PURPOSE.  THIS SOFTWARE IS
PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND
NON-INFRINGEMENT.

IN NO EVENT SHALL UNIVERSITY OF CALIFORNIA, IRVINE OR ANY OTHER
CONTRIBUTOR BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
DAMAGES, WHETHER IN CONTRACT, TORT, OR OTHER FORM OF ACTION, ARISING
OUT OF OR IN CONNECTION WITH, THE USE OR PERFORMANCE OF THIS SOFTWARE.

All questions concerning this software should be directed to
cliques@ics.uci.edu. */

/*********************************************************************
 * clq_merge.h                                                       * 
 * Date      Mon Jul 19 17:09:28 PDT 1999                            *
 * Wrote by:                                                         *
 *  Olivier Chevassut                                                *
 *  Damian Hasse                                                     *
 *                                                                   *
 * Module: Merge (include file)                                      *
 *                                                                   *
 * Function: Functions to handle the merge operation.                *
 *                                                                   *
 * CLIQUES Project                                                   *
 * Information Sciences Institute                                    *
 * University of Southern California                                 *
 *********************************************************************/

#ifndef CLQ_MERGE_H
#define CLQ_MERGE_H

#include "clq_api.h"

enum CLQ_OPER { CLQ_MERGE,
		CKD_GENERATE_KEY };

/* clq_update_key is called by every new user (who are part of the
 * merge operation) and the group controller. If the group controller
 * is the one calling this function then member_list will be
 * valid. Otherwise, for every other user input token will be valid (and
 * member_list will be NULL.
 * The last new member calling this function will not add his/her
 * key_share.
 * member_list has to be NULL terminated.
 * last_partial_keys of old members in the group remain in the context
 * of the current controller, but they will not be encoded in the
 * token.
 */
int clq_update_key (CLQ_CONTEXT *ctx, CLQ_NAME *member_list[], 
		    CLQ_TOKEN *input, CLQ_TOKEN **output);

/* clq_factor_out is called by every member in the group except by the
 * last new member upon recepction of a MERGE_BROADCAST
 * message. Although the last new member doesn't have to called this
 * function because he/she is the one that generates that message, if
 * he/she does then the function will return (no side effects will
 * occur).
 * During this operation ctx is not modified (but ctx->epoch is).
 */
int clq_factor_out (CLQ_CONTEXT *ctx, CLQ_TOKEN *input, 
		    CLQ_TOKEN **output_token);
/* clq_last_step: The last step of the merge operation or of an ckd
 * event. The controller upon reception of the indiviual
 * (FACTOR_OUT or CKD_SHORT_TERM_KEY) messages should call this 
 * function. After he/she receives all the messages, an output token
 * will be generated. This token should be broadcasted to the entire
 * group.
 */
int clq_last_step (CLQ_CONTEXT *ctx, CLQ_NAME *sender_name, 
		   CLQ_TOKEN *input, CLQ_TOKEN **output, 
		   enum CLQ_OPER oper);

#define clq_merge(ctx,sender_name,input,output) \
        clq_last_step(ctx,sender_name,input,output,CLQ_MERGE)


CLQ_NAME *clq_get_next_username(CLQ_CONTEXT *ctx);

CLQ_NAME *clq_get_controller_name(CLQ_CONTEXT *ctx);


#endif
