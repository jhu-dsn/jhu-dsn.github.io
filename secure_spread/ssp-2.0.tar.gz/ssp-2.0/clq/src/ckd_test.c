/* CLIQUES Non-Commercial License (covers BD, CLQ, STR and TGDH
libraries).  Copyright (c) 1998-2002 by the University of California,
Irvine.  All rights reserved.

Permission to use, copy, modify, and distribute this software and its
documentation in source and binary forms for lawful non-commercial
purposes and without fee is hereby granted, provided that the above
copyright notice appear in all copies and that both the copyright
notice and this permission notice appear in supporting documentation,
and that any documentation, advertising materials, and other materials
related to such distribution and use acknowledge that the software was
developed by the University of California, Irvine, Information and
Computer Science Department. The name of University of California,
Irvine may not be used to endorse or promote products derived from
this software without specific prior written permission.

THE UNIVERSITY OF CALIFORNIA, IRVINE MAKES NO REPRESENTATIONS ABOUT
THE SUITABILITY OF THIS SOFTWARE FOR ANY PURPOSE.  THIS SOFTWARE IS
PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND
NON-INFRINGEMENT.

IN NO EVENT SHALL UNIVERSITY OF CALIFORNIA, IRVINE OR ANY OTHER
CONTRIBUTOR BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
DAMAGES, WHETHER IN CONTRACT, TORT, OR OTHER FORM OF ACTION, ARISING
OUT OF OR IN CONNECTION WITH, THE USE OR PERFORMANCE OF THIS SOFTWARE.

All questions concerning this software should be directed to
cliques@ics.uci.edu. */



/*********************************************************************
 * ckd_test.c                                                        * 
 * CKD test source file.                                             * 
 * Date      Tue Nov 21 22:08:07 PST 2000                            *
 * Wrote by:                                                         * 
 * Damian Hasse                                                      *
 *                                                                   *
 * CLIQUES Project                                                   *
 * Information Sciences Institute                                    *
 * University of Southern California                                 *
 *********************************************************************/

#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include <sys/types.h>
#include <time.h>
#include <sys/time.h>

#include "bn.h"
#include "clq_api.h"
#include "clq_api_misc.h"
#include "clq_merge.h"
#include "clq_error.h"
#include "clq_test_misc.h"

#include "ckd_api.h"
/* #include "ckd_test.h" */

#ifdef TIMING
extern int print;
#endif


int main(int argc, char **argv) {
  CLQ_NAME user[NUM_USERS][NAME_LENGTH];
  CLQ_NAME *users_leaving[NUM_USERS+1]={NULL};
  CLQ_CONTEXT *ctx[NUM_USERS];
  CLQ_TOKEN *out=NULL;
  CLQ_TOKEN *in=NULL;
  CLQ_TOKEN *tmp_in=NULL;
  CLQ_TOKEN *new_in=NULL;
  enum MSG_TYPE msg_type=INVALID;
  int ret=OK;
  int i=0;
  int j=0;
  int r=0;
  int num_users=NUM_USERS;
  int ctr=-1;

#ifdef TIMING
  print=0;
#endif
#if defined(PROFILE) | defined(TIMING)
  r=0; /* To avoid a warning during compilation */
#endif
  for (i=0; i < NUM_USERS; i++) {
    ctx[i]=NULL; 
    sprintf (user[i],"%03d",i);
  }

  if (!parse_args(argc,argv,&num_users,user)) goto error;
  /*********************************/

  /* All the members will joing the group */
  /* First user joining group */
  ret=clq_first_user(&ctx[0],user[0],GROUP_NAME);
  printf ("clq_first_user returns %d \n",ret);
  if (ret!=OK) goto error;

  /* All the other users joining group */
  for (i=1; i < num_users; i++) {
#ifdef TIMING
    print=0;
    /* Print stuff times for the last user only */
    /* if (i==num_users-1) print=1; */
    if ((i%5)==0) 
    { print=1; fprintf (stderr,"\n--\nNum users: %d\n--\n",i); }
#endif
    ret=clq_new_user(&ctx[i],user[i],GROUP_NAME,FALSE);
    printf ("clq_new_user returns %d \n",ret);
    if (ret!=OK) goto error;
    
    /* Every member already in the group is processing the event */
    for (j=0; j < i; j++) {
      ret=ckd_proc_event(&ctx[j],user[i],CKD_JOIN,&msg_type,&out);
      printf ("ckd_proc_event returns %d \n",ret);
      if (ret!=OK) goto error;
      if (out != NULL){
        if (in == NULL) { in=out; out=NULL; }
        else { 
          printf ("Error in ckd_proc_event two output returns.\n");
          goto error;
        }
      }
    }
    
    tmp_in=in; in=NULL;
    for (j=0; j <= i; j++) {
      ret=ckd_comp_new_share(ctx[j],tmp_in,&out);
      printf ("ckd_comp_new_share returns %d \n",ret);
      if (ret!=OK) goto error;
      
      if (out!=NULL) {
        in=out; out=NULL;
        /* ctx[0] is the controller */
        ret=ckd_generates_key(ctx[0], user[j],in,&out);
        printf ("ckd_generates_key returns %d \n",ret);
        if (ret!=OK) goto error;
        
        clq_destroy_token(&in);
        if (out!=NULL){
          if (new_in==NULL) { new_in=out; out=NULL; }
          else {
            printf ("Error in ckd_generates_key two output returns.\n");
            goto error;
          }
        }
      }
    }

    if(tmp_in != NULL) {
      clq_destroy_token(&tmp_in);
    }
    
    for (j=0; j <= i; j++) {
      ret=ckd_get_session_key (ctx[j],new_in);
      printf ("ckd_get_session_key returns %d \n",ret);
      if (ret!=OK) goto error;
    }
    
    check_group_secret(ctx, i+1);
    
    clq_destroy_token(&out);
    clq_destroy_token(&in);
    clq_destroy_token(&tmp_in);
    clq_destroy_token(&new_in);
  }
  /*********************************/

  /*
  for (i=0; ctx[i] != NULL; i++)
    clq_print_ctx(ctx[i]);
  */

  /* Some random users will leave the group */
  /* To make it a little more interesting :) */
  srand(time(0));
  r=((int) rand()%(num_users-1))+1;
  printf (" %d users leaving group.\n",r);
  r = 1;
  /* 'r' users will leave the group */
  usr_lst(users_leaving,r,num_users); 
  /* r=1; */
  
  msg_type=INVALID;

  for (j=0; j < r; j++) {
    /* Skipping user that leaves more than once (to avoid error) */
    if (ctx[atoi(users_leaving[j])] == NULL) continue;
    for (i=0; i < num_users; i++) {
      if (ctx[i] != NULL) {
        ret=ckd_proc_event (&ctx[i],users_leaving[j],CKD_LEAVE,&msg_type,&out);
        printf ("ckd_proc_event returns %d \n",ret);
        if (ret!=OK) goto error;
        
        if (out!=NULL){
          /* Setting ctr to save time */
          if (new_in==NULL) { new_in=out; out=NULL; ctr=i;} 
          else {
            printf ("Error in ckd_proc_event two output returns.\n");
            goto error;
          }
        }
      }
    }

    if (msg_type==CKD_NEW_KEY_SHARE) {
      for (i=0; i < num_users; i++) {
        if (ctx[i] != NULL) {
          ret=ckd_comp_new_share(ctx[i],new_in,&out);
          printf ("ckd_comp_new_share returns %d \n",ret);
          if (ret!=OK) goto error;
          if (i==ctr) continue;
          
          if (out==NULL) { ret=-999; goto error; }
          
          in=out; out=NULL;
          /* ctx[ctr] is the controller (use ckd_get_controller_name) */
          ret=ckd_generates_key(ctx[ctr], user[i],in,&out);
          printf ("ckd_generates_key returns %d \n",ret);
          if (ret!=OK) goto error;
          
          clq_destroy_token(&in);
          if (out!=NULL){
            if (tmp_in==NULL) { tmp_in=out; out=NULL; }
            else {
              printf ("Error in ckd_generates_key two output returns.\n");
              goto error;
            }
          }
        }
      }
      if(new_in != NULL) {
        clq_destroy_token(&new_in);
      }
      new_in=tmp_in; tmp_in=NULL;
    }
    
    for (i=0; i < num_users; i++){
      if (ctx[i] != NULL) {
        ret=ckd_get_session_key (ctx[i],new_in);
        printf ("ckd_get_session_key returns %d \n",ret);
        if (ret!=OK) goto error;
      }
    }
    
    clq_destroy_token (&new_in);
  }
  
  for (i=0; i < num_users; i++)
    if (ctx[i]!=NULL)
      clq_print_ctx(ctx[i]);
  
  printf ("Users that left : ");
  for (i=0; users_leaving[i]!=NULL ; i++) printf ("%s ",users_leaving[i]);
  printf("\n");
  /* Checking if group_secrets are the same between users */
  check_group_secret(ctx, num_users);
  
error:
  
  for (i=0; i < num_users; i++) {
    clq_destroy_ctx(&ctx[i]);
  }
  
  i=0;
  while (users_leaving[i] != NULL) free(users_leaving[i++]);
  
  clq_destroy_token(&out);
  clq_destroy_token(&in);
  
  return 1;
}
