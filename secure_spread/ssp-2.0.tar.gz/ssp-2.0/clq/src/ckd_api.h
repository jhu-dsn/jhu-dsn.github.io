/* CLIQUES Non-Commercial License (covers BD, CLQ, STR and TGDH
libraries).  Copyright (c) 1998-2002 by the University of California,
Irvine.  All rights reserved.

Permission to use, copy, modify, and distribute this software and its
documentation in source and binary forms for lawful non-commercial
purposes and without fee is hereby granted, provided that the above
copyright notice appear in all copies and that both the copyright
notice and this permission notice appear in supporting documentation,
and that any documentation, advertising materials, and other materials
related to such distribution and use acknowledge that the software was
developed by the University of California, Irvine, Information and
Computer Science Department. The name of University of California,
Irvine may not be used to endorse or promote products derived from
this software without specific prior written permission.

THE UNIVERSITY OF CALIFORNIA, IRVINE MAKES NO REPRESENTATIONS ABOUT
THE SUITABILITY OF THIS SOFTWARE FOR ANY PURPOSE.  THIS SOFTWARE IS
PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND
NON-INFRINGEMENT.

IN NO EVENT SHALL UNIVERSITY OF CALIFORNIA, IRVINE OR ANY OTHER
CONTRIBUTOR BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
DAMAGES, WHETHER IN CONTRACT, TORT, OR OTHER FORM OF ACTION, ARISING
OUT OF OR IN CONNECTION WITH, THE USE OR PERFORMANCE OF THIS SOFTWARE.

All questions concerning this software should be directed to
cliques@ics.uci.edu. */

/*********************************************************************
 * ckd_api.h                                                         * 
 * Centralized Key Distribution  api include file.                   * 
 * Date      Fri Jul 23 16:22:10 PDT 1999                            *
 * Wrote by:                                                         * 
 *  Damian Hasse                                                     *
 *                                                                   *
 * CLIQUES Project                                                   *
 * Information Sciences Institute                                    *
 * University of Southern California                                 *
 *********************************************************************/
#ifndef CKD_API_H
#define CKD_API_H

/* SSL include files */
#include "bn.h"

/* CLQ_API include files */
#include "clq_api.h"
#include "clq_merge.h"

typedef CLQ_CONTEXT CKD_CONTEXT;

/* CKD Event definitions */
enum CKD_EVENT { CKD_JOIN, 
		 CKD_LEAVE,
		 CKD_REFRESH_KEY};

int ckd_proc_event (CKD_CONTEXT **Ctx, CLQ_NAME *username, enum CKD_EVENT
		    event, enum MSG_TYPE *msg_type, CLQ_TOKEN **output);

int ckd_comp_new_share (CKD_CONTEXT *ctx, CLQ_TOKEN *input, 
			CLQ_TOKEN **output);

#define ckd_generates_key(ctx,sender_name,input,output) \
	clq_last_step(ctx,sender_name,input,output,CKD_GENERATE_KEY)

int ckd_get_session_key (CKD_CONTEXT *ctx, CLQ_TOKEN *input);

/* ckd_compute_session_key : Computes new session key and encrypts
 * it for each user.
 */
int ckd_compute_session_key (CLQ_CONTEXT *ctx,CLQ_TOKEN **output);

/* ckd_gnrt_single: Used inside ckd_comp_new_share to generate the
 * individual (single) token of this user, which will be send to the
 * controller. 
 */
int ckd_gnrt_single (CKD_CONTEXT *ctx, CLQ_TOKEN **output);

/* ckd_compute_user_key: Removing Kij with user.
 */ 
int ckd_compute_user_key (CLQ_CONTEXT *ctx,CLQ_GML *gml);

/* ckd_create_share: Creates a new key_share and computes my
   last_partial_key using the key_share */
int ckd_create_share (CLQ_CONTEXT *ctx);

/* ckd_cmp_gmls: Compare two gmls. */
int ckd_cmp_gmls (CLQ_GML *gml, CLQ_GML *tmp_gml);

/* Preconditions: ctx->controller has to be valid (i.e. not NULL) */
CLQ_NAME *ckd_get_controller_name (CLQ_CONTEXT *ctx);




#endif
