/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */

/***********************************************************************************************/
/* timing.c                                                                                    */
/*                                                                                             */
/* John Schultz                                                                                */
/* Created: June 23, 1999                                                                      */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/


#ifdef TIMING

#include <stdio.h>
#include <sys/resource.h>
#include <sys/time.h>
#include <unistd.h>
#include <sp.h>
#include "timing.h"

double times[MAX_MEMBERSHIPS][NUM_TIMING_SLOTS];
double rtimes[MAX_MEMBERSHIPS][NUM_TIMING_SLOTS];
service stype[MAX_MEMBERSHIPS];
int time_index = 0;

void print_time_info(int index) {
  printf("memb %d\n"
	 "tod:  fl_req -> %f -> fl_memb -> %f -> ssp_memb\n"
	 "rusg: fl_req -> %f -> fl_memb -> %f -> ssp_memb\n", index,
	 times[index][FL_MEMB_TIME] - times[index][REQ_TIME],
	 times[index][SSP_MEMB_TIME] - times[index][FL_MEMB_TIME],
	 rtimes[index][FL_MEMB_TIME] - rtimes[index][REQ_TIME],
	 rtimes[index][SSP_MEMB_TIME] - rtimes[index][FL_MEMB_TIME]);
}

double get_time_rusage(void) {  
  struct rusage used;
  
  getrusage(RUSAGE_SELF, &used);
  
 
  return ((used.ru_utime.tv_sec + used.ru_stime.tv_sec)*1000 +
          (used.ru_utime.tv_usec + used.ru_stime.tv_usec)/1000 );
}

double get_time_timeofday(void) {  
  struct timeval used;
  
  gettimeofday(&used, 0);
  
  return used.tv_sec*1000 + used.tv_usec/1000;
}

void mark_time(double *t, double *r) {
  *t = get_time_timeofday();
  *r = get_time_rusage();
}


#endif

