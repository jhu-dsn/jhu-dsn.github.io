/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */

/***********************************************************************************************/
/* tgdh_alg.h                                                                                  */
/* Implements TGDH protocol                                                                    */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: Feb 15, 2001                                                                       */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#ifndef _TGDH_ALG_H_
#define _TGDH_ALG_H_

#include <stdutil/stddefines.h>
#include <stdutil/stderror.h>
#include <stdutil/stddll.h>
#include <stdutil/stdarr.h>

#include "ssp_info.h"
#include "self_api.h"

/* TGDH ALGORITHM  -----------------------------------------------------------------------------
--------------------------------------------------------------------------------------------- */
#define SSP_TGDH_ALG 2

typedef enum {
  TGDH_SECURE,
  TGDH_WAIT_FOR_SELF_JOIN,
  TGDH_WAIT_FOR_MEMBERSHIP,
  TGDH_WAIT_FOR_OLD_TREE,
  TGDH_WAIT_FOR_NEW_TREE,
} TGDH_Alg_State;

typedef enum {
  TGDH_NONE,
  TGDH_ADD,
  TGDH_SUBTRACT,
  TGDH_BOTH
} TGDH_Grp_Op;


typedef struct dummy_TGDH_Alg {
  TGDH_Alg_State state;               /* state machine */
  stddll        msg_deque;            /* msgs deque */
  SELF_CONTEXT  *ctx;                 /* key agreement context specific */
  SSP_Bool      ts_delivered_to_app;  /* marks that a ts was delivered to the app */
  SSP_Bool      vs_ts_received;       /* marks that a vs ts was received while doing key agreemet */
  int           num_vs_membs;         /* counter for intermediary vs, if no cascaded is 1  */
  int           num_old_tree_msgs;    /* counter for the old tree messages, idealy needs to be 2*/
  SSP_Bool      wait_for_sec_fl_ok;   /* marks that I delivered Fl_Req to the app, wait for Fl_Ok */
  SSP_Msg       *curr_memb_msg;       /* the memb that we try to install  */
  TGDH_Grp_Op   curr_grp_op;          /* the type of the operation upon the group */ 
  SELF_TOKEN    *tk;                  /* copy for the first token in merge case */
} TGDH_Alg;


TGDH_Alg *TGDH_Alg_create();
void TGDH_Alg_free(TGDH_Alg **clq);


/* spread message types used by TGDH algorithm */
#define TGDH_OLD_TREE               ((int16) -32743)
#define TGDH_NEW_TREE               ((int16) -32742)

#define Is_old_tree_msg(type)       (type == TGDH_OLD_TREE)
#define Is_new_tree_msg(type)       (type == TGDH_NEW_TREE)
 
#define TGDH_OLD_TREE_TYPE           AGREED_MESS
#define TGDH_NEW_TREE_TYPE           AGREED_MESS   

/* wrapper fcn that implements the "generic" key_alg interface */
int  TGDH_handles_msg(SSP_Msg *msg, SSP_Grp *grp);
int  TGDH_handle_recv(SSP_Con *conn, SSP_Grp *grp, SSP_Msg *msg);
int  TGDH_handle_fl_ok(SSP_Con *conn, SSP_Grp *grp);
int  TGDH_handle_send(SSP_Con *con, SSP_Grp *grp);


#endif /* _TGDH_ALG_H_*/



















