/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */

/***********************************************************************************************/
/* clq_alg.c                                                                                   */
/* Implements the GDH and CKD key agreement algorithms.                                        */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: July 9, 1999                                                                       */
/* Modified: Jun 30, 2000 by Cristina Nita-Rotaru                                              */
/* Modified: Nov 3, 2000 by Cristina Nita-Rotaru - alg robust                                  */
/* Modified: Feb. 15, 2001 by CNR - CKD implem.                                                */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "clq_alg.h"
#include "ssp_info.h"
#include "scatter.h"
#include "scatter_cryptor.h"
#include "ssp.h"
#include "utility.h"
#include "ssp_dbg.h"
#include "ssp_p.h"
#include "ssp_error.h"

#include <stdutil/stdhash.h>

#include "clq_merge.h"
#include "clq_api_misc.h"
#include "ckd_api.h"
#include "clq_error.h"

#include "fl.h"

#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif

extern FILE *f_dbg;

/* ============================  cliques algorithm specific  ================================= */

/* CLQ_Alg_init  -------------------------------------------------------------------------------
   It initializes a CLQ_Alg data structure
---------------------------------------------------------------------------------------------- */
static void CLQ_Alg_init(CLQ_Alg *clq) {
  clq->ctx = 0;
  stddll_construct(&(clq->msg_deque), sizeof(SSP_Msg*));
  clq->first_trans = SSP_TRUE; 
  clq->vs_trans = SSP_FALSE;
  clq->wait_for_sec_fl_ok = SSP_FALSE;
  clq->kl_got_fl_req = SSP_FALSE;
  clq->first_cascaded_memb = SSP_TRUE;
  clq->vs_set = 0;
  stdhash_construct(&clq->vs_set_hash, sizeof(char*), 0, grp_name_ptr_eq, grp_name_ptr_hashcode);
  clq->curr_memb_msg = 0;
  clq->state = CLQ_WAIT_FOR_SELF_JOIN; 
}

/* CLQ_Alg_destroy -----------------------------------------------------------------------------
   It frees any memory used by CLQ_Alg.
---------------------------------------------------------------------------------------------- */
static void CLQ_Alg_destroy(CLQ_Alg *clq) {
  stddll_it lit;
  SSP_Msg *msg = 0;
  
  for(stddll_begin(&(clq->msg_deque), &lit); !stddll_it_is_end(&lit); stddll_it_next(&lit)) {
    msg = *(SSP_Msg**) stddll_it_val(&lit);
    SSP_Msg_free(&msg);
  }
  stddll_destruct(&(clq->msg_deque));

  clq_destroy_ctx(&clq->ctx);

  if(clq->vs_set) {
    free(clq->vs_set);
    clq->vs_set = NULL;
  }
  stdhash_destruct(&clq->vs_set_hash);  
}

/* CLQ_Alg_create  ------------------------------------------------------------------------------
   It allocates and initializes a CLQ_Alg data structure.
---------------------------------------------------------------------------------------------- */
CLQ_Alg * CLQ_Alg_create() {
  CLQ_Alg * clq = (CLQ_Alg*) malloc(sizeof(CLQ_Alg));
    
  if(!clq) {
    ssp_err_quit("CLQ_Alg_create: malloc failed \n");
  }
  CLQ_Alg_init(clq);

  return clq;
}

/* CLQ_Alg_free ---------------------------------------------------------------------------------
   It frees a CLQ_Alg data structure.
---------------------------------------------------------------------------------------------- */
void CLQ_Alg_free(CLQ_Alg **clq) {
  if (*clq) {
    CLQ_Alg_destroy(*clq);
    free(*clq);
    *clq = NULL;
  } 
}

/* ============================  helper functions  =========================================== */

/* copy_key  ------------------------------------------------------------------------------------
   Helper function that copies the key from the cliques context in the encryption info.
-----------------------------------------------------------------------------------------------*/
static int copy_key(SSP_Grp *grp) {
  CLQ_Alg *clq = (CLQ_Alg*)(grp->ka->info);
  
  memcpy(grp->enc->key, clq->ctx->group_secret_hash, grp->enc->key_len);
  
  ON_DEBUG (
    { 
      int i;
      printf("The key is: 0x");
      for (i = 0; i < grp->enc->key_len; i++){
        printf("%02X", ((unsigned char*)(grp->enc->key))[i]);
      }
      printf("\n");
    }
  )

  return 0;
}

/* msg_2_tk  -----------------------------------------------------------------------------------
   This function copies a spread message into a cliques token. For a partial token or
   final token it attaches the service in the beginning.
---------------------------------------------------------------------------------------------- */
static void msg_2_tk(SSP_Msg *msg, CLQ_TOKEN *tk, service *serv) {
  int err;
  int length = 0;
  int offset = 0;

  if(Is_partial_token_msg(msg->msg_type) || Is_final_token_msg(msg->msg_type)) {
    length = msg->msg_len - sizeof(service);
    offset = sizeof(service);

    err = scat_get2((char*)serv, msg->scat, -1, 0, 0, sizeof(service));
    if(err != sizeof(service)) {
      ssp_err_quit("msg_2_tk: scat_get2 failed\n");
    }
  }
  else if(Is_fact_out_msg(msg->msg_type) || Is_key_list_msg(msg->msg_type)) {
    length = msg->msg_len; 
    offset = 0;
  }
  else {
    ssp_err_quit("msg_2_tk: Unknown token type\n");
  }

  tk->length = length; 
  tk->t_data = (unsigned char*) malloc(tk->length * sizeof(unsigned char));
  if(!tk->t_data) {
    ssp_err_quit("msg_2_tk: malloc failed\n");  
  }

  err = scat_get2((char*)tk->t_data, msg->scat, -1, 0, offset, tk->length);
  if(err != tk->length) {
    ssp_err_quit("msg_2_tk: scat_get2 failed\n");
  }
}


/* tk_2_msg  -----------------------------------------------------------------------------------
   This function returns the length of the message, it allocates a buffer if necessary
   and puts the data that will be multicasted in it or, in the case when the data sent is
   just the token is sets the buffer pointer to point to the right data.
   Alloc specifies if the function allocated or not new memory and set the buf pointer:
   alloc   1, then memory was allocated and the caller needs to free it
   alloc   0, then memory was not allocated, the fuction just set the pointer.
---------------------------------------------------------------------------------------------- */
static int tk_2_msg(char **buf, CLQ_TOKEN *tk, int16 msg_type, service serv_type, int *alloc) {
  int msg_len;

  if(Is_partial_token_msg(msg_type) || Is_final_token_msg(msg_type)) {
    *buf = (unsigned char*) malloc(tk->length * sizeof(unsigned char) + sizeof(service));
    if(!(*buf)) {
      ssp_err_quit("tk_2_msg: malloc failed\n");  
    }
    *alloc = 1;
    memcpy(*buf, &serv_type, sizeof(service));
    memcpy(*buf + sizeof(service), tk->t_data, tk->length);
    msg_len = tk->length + sizeof(service);
  }
  else if(Is_fact_out_msg(msg_type) || Is_key_list_msg(msg_type)) {
    msg_len = tk->length;
    *buf = tk->t_data;
    *alloc = 0;
  }
  else {
    ssp_err_quit("tk_2_msg: Unknown token type\n");
  }

  return msg_len;
}


/* move_msg_con_deque  --------------------------------------------------------------------------
   This function is called when a secure memb. will be installed. It moves all the messages 
   from the ka queue in the connection delivery queue.
---------------------------------------------------------------------------------------------- */
static void move_msg_con_deque(SSP_Con *con, SSP_Grp *grp) {
  CLQ_Alg     *clq = (CLQ_Alg *)grp->ka->info;	
  SSP_Msg     *msg_tmp;
  stddll_it   lit;
  
  DEBUG_enter(f_dbg, "move_msg_con_deque");

  for(stddll_begin(&(clq->msg_deque), &lit); !stddll_it_is_end(&lit); stddll_it_next(&lit)) {
    msg_tmp = *(SSP_Msg**) stddll_it_val(&lit);
    if(Is_encrypt_mess_type(msg_tmp->msg_type)) {   
      if(Dec_Scat(msg_tmp->scat, grp->enc->dec_fcn, grp->enc->block_size, grp->enc->info, 
		  (unsigned int) msg_tmp->msg_len, &msg_tmp->msg_type, msg_tmp->endian_mism) < 0) {
	ssp_err_quit("move_msg_con_deque: Dec_Scat failed!\n");
      }
    } 
    if(Is_reg_memb_mess(msg_tmp->serv_type)) {
      ssp_err_quit("move_msg_con_deque: membership message in the ka queue\n ");
    }
    stddll_push_back(&con->deliv_deque, &msg_tmp);
  }
  stddll_clear(&(clq->msg_deque));

  DEBUG_leave(f_dbg, "move_msg_con_deque", 0);
}


/* ============================  state machine functions for cliques  ======================== */

/* first_user -----------------------------------------------------------------------------------
   This function handles the key agreement when the group contains only one user. 
   It returns void, it fails if cliques fails.
---------------------------------------------------------------------------------------------- */
static void first_user(SSP_Con *con, SSP_Grp *grp) {
  int       err;
  CLQ_Alg   *clq = (CLQ_Alg *)grp->ka->info;	
  char      *joiner = (char*)grp->curr_membs; 

  DEBUG_enter(f_dbg, "first_user");

  clq_destroy_ctx(&clq->ctx);
  if((err = clq_first_user(&clq->ctx, joiner, grp->name)) < 0){
    ssp_err_quit("first_user: clq_first_user failed  %d\n", err);
  }

  copy_key(grp);
  stddll_push_back(&con->deliv_deque, &clq->curr_memb_msg);
  clq->state = CLQ_SECURE;
  grp->ka->key_state = ESTABLISH;
  clq->first_cascaded_memb = SSP_TRUE;
  clq->first_trans = SSP_TRUE; 
  (*grp->enc->chg_key_fcn)(grp->enc->key, grp->enc->key_len, grp->enc->info);    
  
  DEBUG_leave(f_dbg, "first_user", 0);
}


/* start_alg -----------------------------------------------------------------------------------
   This function is invoked when a cascading membership happens and the group contains more 
   than one member. It returs nothing and it exists if either cliques call or FL_unicast fails.
--------------------------------------------------------------------------------------------- */
static void start_alg(SSP_Con *con, SSP_Grp *grp) {
  int        err;
  CLQ_Alg    *clq = (CLQ_Alg *)grp->ka->info;	
  char       *chosen_name=0, *tmp = 0;
  stdarr     merge_set;
  stdhash    *curr = &grp->curr_membs_hash;
  stdhash_it hit;	
  stdarr_it  ait;
  char       **merge_set_ptr=0;
  CLQ_TOKEN  *tk_out = NULL;
  int        msg_len;
  char       *msg_buf = 0;
  int        alloc = 0;

  DEBUG_enter(f_dbg, "start_alg");

  stdarr_construct(&merge_set, sizeof(char*));
  clq_destroy_ctx(&clq->ctx);
  choose(&chosen_name, grp);
  if(strcmp(chosen_name, con->priv_name) == 0) {
    if((err = clq_first_user(&clq->ctx, con->priv_name, grp->name)) < 0){
      ssp_err_quit("start_alg: clq_first_user failed  %d\n", err);
    }  

    for(stdhash_begin(curr, &hit); !stdhash_it_is_end(&hit); stdhash_it_next(&hit)) {
      char *name = *(char**)stdhash_it_key(&hit);
      if(strcmp(name, con->priv_name) != 0) {
	stdarr_push_back(&merge_set, stdhash_it_key(&hit));
      }
    }
    stdarr_push_back(&merge_set, &tmp);        /* NULL terminate for CLQs */

    merge_set_ptr = (char**)stdarr_it_val(stdarr_begin(&merge_set, &ait));
    if(((err = clq_update_key(clq->ctx, merge_set_ptr, NULL, &tk_out)) < 0) || !tk_out) {
      ssp_err_quit("start_alg: clq_update_key failed %d\n", err);
    }   

    msg_len = tk_2_msg(&msg_buf, tk_out, CLQ_PARTIAL_TOKEN, clq->curr_memb_msg->serv_type, &alloc);
    if((err = FL_unicast(con->mbox, CLQ_SERVICE_TYPE, grp->name, clq_get_next_username(clq->ctx), 
			 CLQ_PARTIAL_TOKEN, msg_len, msg_buf)) < 0) {
      SSP_disconnect(con->mbox);
      goto end;
    }

    clq->state = CLQ_WAIT_FOR_FINAL_TOKEN;
    
    ON_DEBUG(
      printf("------>  %s I am chosen\n", con->priv_name);
      printf("This is the merge list:\n");
      for (stdarr_begin(&merge_set, &ait); !stdarr_it_is_end(&ait); stdarr_it_next(&ait)) { 
	printf("%s\n", *(char**) stdarr_it_val(&ait));
      }
      printf("partial token sent to %s, move to CLQ_WAIT_FOR_FINAL_TOKEN state\n", 
	     clq_get_next_username(clq->ctx));
    )
  }
  else {
    if((err = clq_new_user(&clq->ctx, con->priv_name, grp->name, FALSE)) < 0) {
      ssp_err_quit("start_alg: clq_new_user failed %d\n", err);  	
    }
    clq->state = CLQ_WAIT_FOR_PARTIAL_TOKEN;

    ON_DEBUG(
      printf("--------------------> %s I am not chosen\n", con->priv_name);
      printf("erase clq ctx, move to CLQ_WAIT_FOR_PARTIAL_TOKEN state\n");
    )
  }
  
 end:
  if(alloc && msg_buf) {
    free(msg_buf);
  }
  clq_destroy_token(&tk_out);
  stdarr_destruct(&merge_set);


  DEBUG_leave(f_dbg, "start_alg", 0);
}



/* handle_leave_or_partition -------------------------------------------------------------------
   This function handles a leave or a partition (the fast way clq_leave + broadcast)
   It returs nothing and it exists if either cliques call or FL_unicast fails.

   Note: all the members can call clq_leave, only for the controller the function will
   return a valid token.
--------------------------------------------------------------------------------------------- */
static void handle_leave_or_partition(SSP_Con *con, SSP_Grp *grp, stdarr *leave_set) {
  int        err;
  CLQ_Alg    *clq = (CLQ_Alg *)grp->ka->info;	
  char       **leave_set_ptr;
  CLQ_TOKEN  *tk_out = 0;
  stdarr_it  ait;
  int        msg_len;
  char*      msg_buf=0;
  int        alloc = 0;

  DEBUG_enter(f_dbg, "handle_leave_or_partition");
  
  leave_set_ptr = (char**)stdarr_it_val(stdarr_begin(leave_set, &ait));
  if((err = clq_leave(&clq->ctx, leave_set_ptr, &tk_out, 1)) < 0 && err != NOT_CONTROLLER) {
    ssp_err_quit("handle_leave_or_partition: clq_leave failed %d\n", err);
  }

  if(tk_out) {
    msg_len = tk_2_msg(&msg_buf, tk_out, CLQ_KEY_LIST, clq->curr_memb_msg->serv_type, &alloc);
    if ((err = FL_multicast(con->mbox, CLQ_KL_TYPE, grp->name, CLQ_KEY_LIST, msg_len, msg_buf)) < 0) {
      SSP_disconnect(con->mbox);
      goto end;
    }
  }
  clq->state = CLQ_WAIT_FOR_KEY_LIST;
  
 end:
  if(alloc && msg_buf) {
    free(msg_buf);
  }
  clq_destroy_token(&tk_out);

  DEBUG_leave(f_dbg, "handle_leave_or_partition", 0);
}


/* handle_merge_and_partition -----------------------------------------------------------------
   This function handles a combined event, parition + merge
   It returs nothing and it exists if cliques call fail.
--------------------------------------------------------------------------------------------- */
static void handle_merge_and_partition(SSP_Con *con, SSP_Grp *grp, stdarr *merge_set, 
				      stdarr *leave_set) {
  int        err;
  CLQ_Alg    *clq = (CLQ_Alg *)grp->ka->info;	
  char       **leave_set_ptr = 0;
  char       **merge_set_ptr = 0; 
  CLQ_TOKEN  *tk_out = 0;
  stdarr_it  ait;
  int        msg_len;
  char       *msg_buf=0;
  int        alloc = 0;

  DEBUG_enter(f_dbg, "handle_merge_and_partition");
  
  if(is_old_member(grp)) {
    ON_DEBUG(printf(" ------------- OLD member ----------- \n");)
    /* first remove the leave list  */
    leave_set_ptr = (char**)stdarr_it_val(stdarr_begin(leave_set, &ait));
    if((err = clq_leave(&clq->ctx, leave_set_ptr, &tk_out, 0)) < 0 && err != NOT_CONTROLLER) {
      ssp_err_quit("handle_leave_or_partition: clq_leave failed %d\n", err);
    }
    
    /* now start the merge  */
    if(tk_out) {
      clq_destroy_token(&tk_out);
      
      merge_set_ptr = (char**)stdarr_it_val(stdarr_begin(merge_set, &ait));
      if((err = clq_update_key(clq->ctx, merge_set_ptr, NULL, &tk_out)) < 0 && err != NOT_CONTROLLER ) {  
	ssp_err_quit("handle_merge_and_partition: clq_update_key failed %d\n", err);
      }  
      
      if(tk_out) {
	msg_len = tk_2_msg(&msg_buf, tk_out, CLQ_PARTIAL_TOKEN, clq->curr_memb_msg->serv_type, &alloc);
	if((err = FL_unicast(con->mbox, CLQ_SERVICE_TYPE, grp->name, clq_get_next_username(clq->ctx), 
			     CLQ_PARTIAL_TOKEN, msg_len, msg_buf)) < 0) {
	  SSP_disconnect(con->mbox);
	  goto end;
	}

      }
    }
    clq->state = CLQ_WAIT_FOR_FINAL_TOKEN;
  }
  else {
    ON_DEBUG(printf(" ------------- NEW member ----------- \n");)
    clq_destroy_ctx(&clq->ctx);
    if((err = clq_new_user(&clq->ctx, con->priv_name, grp->name, FALSE)) < 0) {
      ssp_err_quit("handle_merge_and_partition: clq_new_user failed %d\n", err);  	
    }
    clq->state = CLQ_WAIT_FOR_PARTIAL_TOKEN;	
  }

 end:
  if(alloc && msg_buf) {
    free(msg_buf);
  }
  clq_destroy_token(&tk_out);

  DEBUG_leave(f_dbg, "handle_leave_or_partition", 0);
}


/* start_merge -------------------------------------------------------------------------------
   This function starts a merge algorithm. It is called when the member executing the 
   algorithm is the controller. Join is handled as a particular case of merge.
   
   It returns nothing, it fails if either cliques or flush calls failed.
--------------------------------------------------------------------------------------------- */
static void start_merge(SSP_Con *con, SSP_Grp *grp, stdarr *merge_set) {
  int        err;
  CLQ_Alg    *clq = (CLQ_Alg *)grp->ka->info;	
  char       **merge_set_ptr;
  CLQ_TOKEN  *tk_out = 0;
  stdarr_it  ait;
  int        msg_len;
  char       *msg_buf = 0;
  int        alloc = 0;

  DEBUG_enter(f_dbg, "start_merge");
  
  merge_set_ptr = (char**)stdarr_it_val(stdarr_begin(merge_set, &ait));

  if((err = clq_update_key(clq->ctx, merge_set_ptr, NULL, &tk_out)) < 0 && err != NOT_CONTROLLER ) {  
    ssp_err_quit("start_alg: clq_update_key failed %d\n", err);
  }   

  if(tk_out) {
    msg_len = tk_2_msg(&msg_buf, tk_out, CLQ_PARTIAL_TOKEN, clq->curr_memb_msg->serv_type, &alloc);
    if((err = FL_unicast(con->mbox, CLQ_SERVICE_TYPE, grp->name, clq_get_next_username(clq->ctx), 
			 CLQ_PARTIAL_TOKEN, msg_len, msg_buf)) < 0) {
      SSP_disconnect(con->mbox);
      goto end;
    }
    ON_DEBUG(printf("partial token sent to %s  \n", clq_get_next_username(clq->ctx));)
  }
  clq->state = CLQ_WAIT_FOR_FINAL_TOKEN;
  ON_DEBUG(printf("move to WAIT_FOR_FINAL_TOKEN state\n");)
  
 end:
  if(alloc && msg_buf) {
    free(msg_buf);
  }
  clq_destroy_token(&tk_out);
  
  DEBUG_leave(f_dbg, "start_merge", 0);
}


/* handle_merge -------------------------------------------------------------------------------
   This function starts a merge algorithm. It is called when the member executing the 
   algorithm is the controller. Join is handled as a particular case of merge.
   
   It returns nothing, it fails if either cliques or flush calls failed.
--------------------------------------------------------------------------------------------- */
static void handle_merge(SSP_Con *con, SSP_Grp *grp, stdarr *merge_set) {
 int        err;
  CLQ_Alg    *clq = (CLQ_Alg *)grp->ka->info;  

  DEBUG_enter(f_dbg, "handle_merge");
  
  if(is_old_member(grp)) {
    ON_DEBUG(printf(" ------------- OLD member ----------- \n");)
    start_merge(con, grp, merge_set);
  }
  else {
    ON_DEBUG(printf(" ------------- NEW member ----------- \n");)
    clq_destroy_ctx(&clq->ctx);
    if((err = clq_new_user(&clq->ctx, con->priv_name, grp->name, FALSE)) < 0) {
      ssp_err_quit("handle_merge: clq_new_user failed %d\n", err);  	
    }
    clq->state = CLQ_WAIT_FOR_PARTIAL_TOKEN;	
  } 
  
  DEBUG_leave(f_dbg, "handle_merge", 0);
}



/* handle_data_msg ------------------------------------------------------------------------------ 
   This function specifies the actions taken by the state machine if the message received was
   a data message (message received from the flush layer).
-----------------------------------------------------------------------------------------------*/
static int handle_data_msg(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CLQ_Alg *clq) {
  int ret = DONT_DELIV_MSG;
  
  DEBUG_enter(f_dbg, "handle_data_msg");

  switch(clq->state) {
  case CLQ_SECURE:
    ssp_err_quit("handle_data_msg: this message should not be here");
    break;
    
  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
  case CLQ_WAIT_FOR_FINAL_TOKEN:
  case CLQ_COLLECT_FACT_OUTS:
  case CLQ_WAIT_FOR_SELF_JOIN:
    ssp_err_quit("handle_data_msg: no message should be received in this state");
    break;

  case CLQ_WAIT_FOR_KEY_LIST:
    stddll_push_back(&clq->msg_deque, &msg);
    break;

  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
  case CLQ_WAIT_FOR_MEMBERSHIP:
    ret = DELIV_MSG;
    break;

  }

  DEBUG_leave(f_dbg, "handle_data_msg", ret);
  return ret;
}


/* handle_trans ---------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a transitional message.
---------------------------------------------------------------------------------------------- */
static int handle_trans(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CLQ_Alg *clq) {
  int ret = DONT_DELIV_MSG;

  DEBUG_enter(f_dbg, "handle_trans");

  switch(clq->state) {
  case CLQ_SECURE:
    clq->first_trans = SSP_FALSE;
    clq->vs_trans = SSP_TRUE;
    ret = DELIV_MSG;
    break;

  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
  case CLQ_WAIT_FOR_FINAL_TOKEN:
  case CLQ_COLLECT_FACT_OUTS:
  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
  case CLQ_WAIT_FOR_MEMBERSHIP:
    if(clq->first_trans == SSP_TRUE) {
      clq->first_trans = SSP_FALSE;
      ret = DELIV_MSG;
    }
    clq->vs_trans = SSP_TRUE;
    break;
  
  case CLQ_WAIT_FOR_KEY_LIST:
    if(clq->first_trans == SSP_TRUE) {
      clq->first_trans = SSP_FALSE;
      ret = DELIV_MSG;
    }
    clq->state = CLQ_WAIT_FOR_CASCADING_MEMBERSHIP;
    clq->vs_trans = SSP_TRUE;
    break; 

  case CLQ_WAIT_FOR_SELF_JOIN:
    ssp_err_quit("handle_trans: trans received in wrong state, %d!\n", clq->state);
    break;
  }
  
  DEBUG_leave(f_dbg, "handle_trans", ret);
  return ret;
}


/* handle_memb ----------------------------------------------------------------------------------
  This function specifies the actions taken by the state machine if the message received was
  a group membership.

  Some comments:
      a member in the WAIT_FOR_SELF_JOIN can receive 2 events: a membership due to its own join
      (a join event) or a membership due to a network event (in this case the joinee is on the
      list of new added members. Flush delivers this special network in some cases:
      -  a partiton happen after the join and before the new membership is delivered
      -  the join happened while a previous partition was processed, so the two events are
         combined in one
      -  somebody left immediately after my join. Since flush membership deliveries are based
         on gathering flush_oks from old members, if the guy that left did not send his 
         flush_ok, the two events will be combined. Note that if he managed to send his
         flush_ok, then the join will be delivered first, then the leave.
---------------------------------------------------------------------------------------------- */
static int handle_memb(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CLQ_Alg *clq) {
  int    ret = DONT_DELIV_MSG;
  int    was_leave = 0;
  int    err = 0;
  stdarr join_set;
  stdarr leave_set;

  DEBUG_enter(f_dbg, "handle_memb");
  
  stdarr_construct(&leave_set, sizeof(char*));
  stdarr_construct(&join_set, sizeof(char*));

  switch(clq->state) {
  case CLQ_SECURE:
  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
  case CLQ_WAIT_FOR_FINAL_TOKEN:
  case CLQ_COLLECT_FACT_OUTS:
  case CLQ_WAIT_FOR_KEY_LIST: 
    ssp_err_quit("handle_memb: memb received in wrong state, %d!\n", clq->state);
    break;

  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
    if(clq->first_cascaded_memb == SSP_TRUE) {
      clq->first_cascaded_memb = SSP_FALSE;
      init_vs_set(grp); 
    }
    was_leave = upd_vs_set_and_get_join_leave_set(grp, msg->serv_type, &join_set, &leave_set);
    if (was_leave  && (clq->first_trans == SSP_TRUE)) {
      clq->first_trans = SSP_FALSE;
      gen_and_push_msg(con, grp, TRANSITION_MESS);
    }

    if(clq->curr_memb_msg != NULL) { /* free prev. memb that we were trying to install  */
      SSP_Msg_free(&(clq->curr_memb_msg));
    }
    clq->curr_memb_msg = msg; /* delay delivery of memb  */

    /* cascaded occured, so memberships will be collapsed, deliver a NETWORK */
    clq->curr_memb_msg->serv_type = REG_MEMB_MESS | CAUSED_BY_NETWORK;

    grp->ka->key_state = NOT_ESTABLISH;
    if(stdhash_size(&grp->curr_membs_hash) > 1) {
      start_alg(con, grp);
    }
    else {
      first_user(con, grp);
    }
    ret = DONT_DELIV_MSG;
    clq->vs_trans = SSP_FALSE;
    break;

  case CLQ_WAIT_FOR_SELF_JOIN:
    grp->ka->key_state = NOT_ESTABLISH;
    
    init_vs_set(grp); 
    was_leave = upd_vs_set_and_get_join_leave_set(grp, msg->serv_type, &join_set, &leave_set);
    clq->first_cascaded_memb = SSP_FALSE;
    
    clq->curr_memb_msg = msg;  /* delay delivery of memb  */

    if(stdhash_size(&grp->curr_membs_hash) > 1) {
      if(Is_reg_memb_mess(msg->serv_type)) {
	if(Is_caused_join_mess(msg->serv_type)) {
	  if((err = clq_new_user(&clq->ctx, con->priv_name, grp->name, FALSE)) < 0) {
	    ssp_err_quit("handle_memb: clq_new_user failed %d\n", err);  	
	  }
	  clq->state = CLQ_WAIT_FOR_PARTIAL_TOKEN;	
	}	      
	else if(Is_caused_leave_mess(msg->serv_type) || Is_caused_disconnect_mess(msg->serv_type)) {
	  ssp_err_quit("handle_memb: leave or disconnect in the wrong state %d\n", clq->state);
	}
	else if(Is_caused_network_mess(msg->serv_type)) {
	  char *chosen_name = NULL;
	  choose(&chosen_name, grp);
	  
	  if(!strcmp(chosen_name, con->priv_name)) {
	    /* need to add only new members, since I just joined I don't need to remove anybody  */
	    if((err = clq_first_user(&clq->ctx, con->priv_name, grp->name)) < 0){
	      ssp_err_quit("handle_memb: clq_first_user failed  %d\n", err);
	    }
	    start_merge(con, grp, &join_set);
	  }
	   else {
	     if((err = clq_new_user(&clq->ctx, con->priv_name, grp->name, FALSE)) < 0) {
	       ssp_err_quit("handle_memb: clq_new_user failed %d\n", err);  	
	     }
	     clq->state = CLQ_WAIT_FOR_PARTIAL_TOKEN;
	   }
	}
      }
    }
    else {
      first_user(con, grp);
    }
    clq->vs_trans = SSP_FALSE;
    break;
    
  case CLQ_WAIT_FOR_MEMBERSHIP:
    grp->ka->key_state = NOT_ESTABLISH;
    clq->first_cascaded_memb = SSP_FALSE;
    
    init_vs_set(grp); 
    was_leave = upd_vs_set_and_get_join_leave_set(grp, msg->serv_type, &join_set, &leave_set);
    
    clq->curr_memb_msg = msg; /* delay delivery of memb  */
    
    if(stdhash_size(&grp->curr_membs_hash) > 1) {
      if(stdarr_size(&leave_set) > 1) { /* count the NULL too */
	if(stdarr_size(&join_set) <= 1) {  /* only partition or leave, count the NULL too  */
	  handle_leave_or_partition(con, grp, &leave_set);
	}
	else {
	  handle_merge_and_partition(con, grp, &join_set, &leave_set);
	}
      }
      else { /*  merge &  join */
	if(Is_caused_join_mess(msg->serv_type)) { /* if I am here I am an old member */
	  start_merge(con, grp, &join_set);
	}
	else {
	  handle_merge(con, grp, &join_set);
	}
      }
    }  
    else { /* alone  */
      first_user(con, grp);
    }
    clq->vs_trans = SSP_FALSE;
    break;
  }

  stdarr_destruct(&leave_set);  
  stdarr_destruct(&join_set);      

  DEBUG_leave(f_dbg, "handle_memb", ret);
  return ret;
}


/* handle_partial_token -------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a partial token message.
   IMPORTANT: all members need to call update_key. The controller passes a merge_list and an
   output token and the others are passing a input and an output token. This needs to be passed
   from the controller to each of the new members. The last member (which in the current cliques
   implementation becomes the new group controller) needs also to call clq_update_keu BEFORE
   checking if he is the last member or not. That is beacuse clq_update_key also sets the list
   of memebrs of the group.
---------------------------------------------------------------------------------------------- */
static int handle_partial_token(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CLQ_Alg *clq) {
  int        ret = DONT_DELIV_AND_FREE_MSG;
  CLQ_TOKEN  *tk_out = 0;
  CLQ_TOKEN  tk_in = {0};  
  int        err;
  int        msg_len;
  char       *msg_buf = 0;
  int        alloc = 0;
  service    serv;

  DEBUG_enter(f_dbg, "handle_partial_token");
  
  switch(clq->state) {
  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
    msg_2_tk(msg, &tk_in, &serv);
 
    /* update the service type for the current membership handled */
    if(Is_caused_network_mess(serv) && Is_caused_join_mess(clq->curr_memb_msg->serv_type)) {
      clq->curr_memb_msg->serv_type = serv;
    }

    if(((err = clq_update_key(clq->ctx, NULL, &tk_in, &tk_out)) < 0 && err != NOT_CONTROLLER) || !tk_out) {
      ssp_err_quit("clq_update_key failed %d  %p\n", err, tk_out); 
    }

    ON_TEST_CASCADING (sleep(TIMEOUT_CASCADING);)

    if(clq->ctx->me->next != NULL) { /* I am not the new controller, pass the token to next */
      msg_len = tk_2_msg(&msg_buf, tk_out, CLQ_PARTIAL_TOKEN, clq->curr_memb_msg->serv_type, &alloc);
      if((ret = FL_unicast(con->mbox, CLQ_SERVICE_TYPE, grp->name, clq_get_next_username(clq->ctx), 
			   CLQ_PARTIAL_TOKEN, msg_len, msg_buf))
	 == CONNECTION_CLOSED || ret == ILLEGAL_SESSION) {
	SSP_disconnect(con->mbox);
	goto end;
      }

      clq->state = CLQ_WAIT_FOR_FINAL_TOKEN;
      ON_DEBUG (printf("partial token sent to %s, move to WAIT_FOR_FINAL_TOKEN state\n",
		       clq_get_next_username(clq->ctx));)
    }
    else { /* I am the new controller, this is the final token, multicast it with SELF_DISCARD */
      msg_len = tk_2_msg(&msg_buf, tk_out, CLQ_FINAL_TOKEN, clq->curr_memb_msg->serv_type, &alloc);
      if((ret = FL_multicast(con->mbox, CLQ_SERVICE_TYPE | SELF_DISCARD, grp->name, CLQ_FINAL_TOKEN, 
			     msg_len, msg_buf)) == CONNECTION_CLOSED || ret == ILLEGAL_SESSION) {
	SSP_disconnect(con->mbox);
	goto end;
      }
      clq->state = CLQ_COLLECT_FACT_OUTS;

      if(ret > 0){ /* if the sending succeded, return DONT_DELIVER_MSG  */
	ret = DONT_DELIV_AND_FREE_MSG;
      }

      ON_DEBUG(printf("final token sent to group, move to COLLECT_FACT_OUTS state\n");)
    }
  
  end:
    if(alloc && msg_buf) {
      free(msg_buf);
    }

    if(tk_in.t_data) {
      free(tk_in.t_data);
      tk_in.t_data = NULL;
    }
    clq_destroy_token(&tk_out);

    break;

  case CLQ_SECURE:
  case CLQ_WAIT_FOR_FINAL_TOKEN:
  case CLQ_COLLECT_FACT_OUTS:
  case CLQ_WAIT_FOR_KEY_LIST:
    ssp_err_quit("handle_partial_token: partial token in wrong state!");
    break;

  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
    ret = DONT_DELIV_AND_FREE_MSG;
    break;

  case CLQ_WAIT_FOR_SELF_JOIN:
  case CLQ_WAIT_FOR_MEMBERSHIP:
    break;
  }

  DEBUG_leave(f_dbg, "handle_partial_token", ret);
  return ret;
}


/* handle_final_token --------------------------------------------------------------------------
  This function specifies the actions taken by the state machine if the message received was
  a final token message.
  IMPORTANT: the new controller must not call clq_factor_out function. 
---------------------------------------------------------------------------------------------- */
static int handle_final_token(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CLQ_Alg *clq) {
  int        ret = DONT_DELIV_AND_FREE_MSG, err;
  CLQ_TOKEN  *tk_out = 0;
  CLQ_TOKEN  tk_in = {0}; 
  int        msg_len;
  char       *msg_buf=0;
  int        alloc = 0;
  service    serv;

  DEBUG_enter(f_dbg, "handle_final_token");

  switch(clq->state) {
  case CLQ_WAIT_FOR_FINAL_TOKEN:
    if(clq->ctx->me->next != NULL) { /* I am not the new gc, call factor out */
      msg_2_tk(msg, &tk_in, &serv);

      /* update the service type for the current membership handled */
      if(Is_caused_network_mess(serv) && Is_caused_join_mess(clq->curr_memb_msg->serv_type)) {
	clq->curr_memb_msg->serv_type = serv;
      }

      if((err = clq_factor_out(clq->ctx, &tk_in, &tk_out)) < 0 || !tk_out) {
	ssp_err_quit("handle_final_token: clq_factor_out failed %d\n", err);
      }

      ON_TEST_CASCADING(sleep(TIMEOUT_CASCADING);)

      msg_len = tk_2_msg(&msg_buf, tk_out, CLQ_FACT_OUT, clq->curr_memb_msg->serv_type, &alloc);
      if ((ret = FL_unicast(con->mbox, CLQ_SERVICE_TYPE, grp->name, clq_get_controller_name(clq->ctx), 
			    CLQ_FACT_OUT, msg_len, msg_buf)) 
	  == CONNECTION_CLOSED || ret == ILLEGAL_SESSION) {
	SSP_disconnect(con->mbox);
	goto end;
      }
      clq->state = CLQ_WAIT_FOR_KEY_LIST;
      clq->kl_got_fl_req = SSP_FALSE;
      if(ret > 0) {
	ret = DONT_DELIV_AND_FREE_MSG;
      }

      ON_DEBUG (printf("factor out sent to gc %s, move to WAIT_FOR_KEY_LIST state\n", 
		       clq_get_controller_name(clq->ctx));)
	
    end:
      clq_destroy_token(&tk_out);

      if(tk_in.t_data) {
	free(tk_in.t_data);
	tk_in.t_data = NULL;
      } 
      
      if(alloc && msg_buf) {
	free(msg_buf);
      }
    }
    break;
    
  case CLQ_SECURE:
  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
  case CLQ_COLLECT_FACT_OUTS:
  case CLQ_WAIT_FOR_KEY_LIST:
    ssp_err_quit("handle_final_token: final token in wrong state!");
    break;

  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
    ret = DONT_DELIV_AND_FREE_MSG;
    break;

  case CLQ_WAIT_FOR_SELF_JOIN:
  case CLQ_WAIT_FOR_MEMBERSHIP:
    break;
  }  

  DEBUG_leave(f_dbg, "handle_final_token", ret);
  return ret;
}


/* handle_fact_out ------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a factor out message.
   IMPORTANT: only the new group controller should be in this state. clq_merge needs to be 
   for every factor out merge received. When the expected number of factor out messages was
   received, clq_merge outputs a valid token. 
---------------------------------------------------------------------------------------------- */
static int handle_fact_out(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CLQ_Alg *clq) {
  int        ret = DONT_DELIV_AND_FREE_MSG;
  CLQ_TOKEN  *tk_out = 0;
  CLQ_TOKEN  tk_in = {0}; 
  int        err;
  int        msg_len;
  char*      msg_buf = 0;
  int        alloc = 0;
  service    serv;

  DEBUG_enter(f_dbg, "handle_fact_out");
  
  switch(clq->state) {
  case CLQ_COLLECT_FACT_OUTS:
    if((strcmp(clq_get_controller_name(clq->ctx), con->priv_name) == 0) &&
        clq->vs_trans == SSP_FALSE) {
      msg_2_tk(msg, &tk_in, &serv);

      if((err = clq_merge(clq->ctx, msg->sender, &tk_in, &tk_out)) < 0) {
	ssp_err_quit("handle_fact_out: clq_merge failed %d\n", err);
      }    

      if(tk_out) { /* KEY_LIST ready  */
	ON_TEST_CASCADING(sleep(TIMEOUT_CASCADING);)

	msg_len = tk_2_msg(&msg_buf, tk_out, CLQ_KEY_LIST, clq->curr_memb_msg->serv_type, &alloc);
	if ((ret = FL_multicast(con->mbox, CLQ_KL_TYPE, grp->name, CLQ_KEY_LIST, msg_len, msg_buf)) 
	    == CONNECTION_CLOSED || ret == ILLEGAL_SESSION) {
	  SSP_disconnect(con->mbox);
	  goto end;
	}

	ON_DEBUG(printf("key list sent to groups, move to WAIT_FOR_KEY_LIST state\n");)
	clq->state = CLQ_WAIT_FOR_KEY_LIST;
	clq->kl_got_fl_req = SSP_FALSE;	
      }

      if(ret > 0) {
	ret = DONT_DELIV_AND_FREE_MSG;
      }

    end:
      if(tk_in.t_data) {
	free(tk_in.t_data);
	tk_in.t_data = NULL;
      }

      if(alloc && msg_buf) {
	free(msg_buf);
      }
      
      clq_destroy_token(&tk_out);      
    }

    break;
    
  case CLQ_SECURE:
  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
  case CLQ_WAIT_FOR_FINAL_TOKEN:
  case CLQ_WAIT_FOR_KEY_LIST:
    ssp_err_quit("handle_fact_out: fact_out received in wrong state!\n");
    break;

  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
    ret = DONT_DELIV_AND_FREE_MSG;
    break;

  case CLQ_WAIT_FOR_SELF_JOIN:
  case CLQ_WAIT_FOR_MEMBERSHIP:
    break;

  }

  DEBUG_leave(f_dbg, "handle_fact_out", ret);
  return ret;
}

/* handle_key_list -----------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a key list message.
---------------------------------------------------------------------------------------------- */
static int handle_key_list(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CLQ_Alg *clq) {
  int        ret = DONT_DELIV_AND_FREE_MSG;
  CLQ_TOKEN  tk_in = {0}; 
  int        err;  
  service    serv;

  DEBUG_enter(f_dbg, "handle_key_list");

  switch(clq->state) {
  case CLQ_WAIT_FOR_KEY_LIST:
    if(clq->vs_trans == SSP_FALSE) {
      msg_2_tk(msg, &tk_in, &serv);

      if((err = clq_update_ctx(clq->ctx, &tk_in)) < 0) {
	ssp_err_quit("handle_key_list: clq_update_ctx failed %d!\n", err);
      }      

      copy_key(grp);      
      grp->ka->key_state = ESTABLISH;      
      (*grp->enc->chg_key_fcn)(grp->enc->key, grp->enc->key_len, grp->enc->info);
     
      /* in case of a cascading due to a join, the joiner starts in WAIT_FOR_SELF_JOIN 
         and it never knows it it was a cascading or not so he deliveres JOIN while 
         all the other members of the group will deliver NETWORK. That's why each
         members that passes along the partial token attaches also its group event,
	 and if it was join is upgraded to network. With the final token broadcast
	 everybody agreed to deliver that group event type.
      */
      if(Is_caused_network_mess(clq->curr_memb_msg->serv_type)) {
	set_vs_set_memb_msg(clq->curr_memb_msg, grp); 
      }

      /* first put the new secure memb in the connection queue */
      stddll_push_back(&con->deliv_deque, &clq->curr_memb_msg);
      move_msg_con_deque(con, grp);

      clq->state = CLQ_SECURE;
      clq->first_trans = SSP_TRUE;
      clq->first_cascaded_memb = SSP_TRUE;

      if(clq->kl_got_fl_req == SSP_TRUE) {
	clq->wait_for_sec_fl_ok = SSP_TRUE;
	gen_and_push_msg(con, grp, FLUSH_REQ_MESS); /* push flush request in the application queue*/
      }
      if(tk_in.t_data) {
	free(tk_in.t_data);
	tk_in.t_data = NULL;
      } 
    }

    if(ret > 0) {
      ret = DONT_DELIV_AND_FREE_MSG;
    }
    break;
    
  case CLQ_SECURE:
  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
  case CLQ_WAIT_FOR_FINAL_TOKEN:
  case CLQ_COLLECT_FACT_OUTS:
    ssp_err_quit("handle_key_list: key list in wrong state!");
    break;

  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
    ret = DONT_DELIV_AND_FREE_MSG;
    break;

  case CLQ_WAIT_FOR_SELF_JOIN:
  case CLQ_WAIT_FOR_MEMBERSHIP:
    break;

  }
  
  DEBUG_leave(f_dbg, "handle_key_list", ret);
  return ret;
}

/* handle_fl_req -------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a flush request message.
---------------------------------------------------------------------------------------------- */
static int handle_fl_req(SSP_Con *con, SSP_Grp *grp, SSP_Msg *mess, CLQ_Alg *clq) {
  int ret = DONT_DELIV_AND_FREE_MSG;

  DEBUG_enter(f_dbg, "handle_fl_req");

  switch(clq->state) {
  case CLQ_SECURE:
    clq->wait_for_sec_fl_ok = SSP_TRUE;
    ret = DELIV_MSG; 
    break;

  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
  case CLQ_WAIT_FOR_FINAL_TOKEN:
  case CLQ_COLLECT_FACT_OUTS:
  case CLQ_WAIT_FOR_KEY_LIST:
    if ((ret = FL_flush(con->mbox, grp->name)) == CONNECTION_CLOSED || ret == ILLEGAL_SESSION) {
      SSP_disconnect(con->mbox); 
      goto end;
    }
    clq->state = CLQ_WAIT_FOR_CASCADING_MEMBERSHIP;
    ON_DEBUG(printf("Flush ok sent\n");)

    ret = DONT_DELIV_AND_FREE_MSG;
    break;
  
  case CLQ_WAIT_FOR_SELF_JOIN:
  case CLQ_WAIT_FOR_MEMBERSHIP:
  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
    ssp_err_quit("handle_fl_req: fl_req received in wrong state, not possible !");
    break;

  }

 end: 
  DEBUG_leave(f_dbg, "handle_fl_req", ret);
  return ret;
}

/* ============================  wrapper functions for cliques  ============================== */

/* CLQ_handles_mess ------------------------------------------------------------------------------
   This function specifies if a spread message is used or not by the key agreement algorithm.
   All the messages specified here will be redirected by spread to CLQ_Comp_Key_Wrapper;
   In this case, all the membership messages (including transitional messages) are sended,
   Also the regular messages used internal by the key agreement algorithm (OT... messages)
   and regular messages received between having a stable key, are sent here.
-----------------------------------------------------------------------------------------------*/
int CLQ_handles_msg(SSP_Msg *msg, SSP_Grp *grp) {
  service serv_type = msg->serv_type;
  int     msg_type  = msg->msg_type;
  
  return  !Is_regular_mess(serv_type) ||  
    grp->ka->key_state == NOT_ESTABLISH ||
    msg_type == CLQ_PARTIAL_TOKEN || msg_type == CLQ_FINAL_TOKEN  || 
    msg_type == CLQ_FACT_OUT || msg_type == CLQ_KEY_LIST;
}


/* CLQ_handle_recv ----------------------------------------------------------------------------
   This function is implementing the state machine for the key agreement algorithm. 
   It returns 1 if the message must be delivered by the SSP, 0 otherwise. The SSP can check if 
   the key agreement finished by looking and Key_State.
-----------------------------------------------------------------------------------------------*/
int CLQ_handle_recv(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg) {
  int  ret = DELIV_MSG;
  CLQ_Alg *clq = (CLQ_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "CLQ_handle_recv");
  
  if(Is_regular_mess(msg->serv_type)) {
    if(Is_partial_token_msg(msg->msg_type)) {
      ret = handle_partial_token(con, grp, msg, clq);
    }
    else if(Is_final_token_msg(msg->msg_type)) {
      ret = handle_final_token(con, grp, msg, clq);
    }
    else if(Is_fact_out_msg(msg->msg_type)) {
      ret = handle_fact_out(con, grp, msg, clq);
    }
    else if(Is_key_list_msg(msg->msg_type)) {
      ret = handle_key_list(con, grp, msg, clq);
    }
    else {
      ret = handle_data_msg(con, grp, msg, clq);
    }
  }
  else if(Is_flush_req_mess(msg->serv_type)) {
    ret = handle_fl_req(con, grp, msg, clq);
  }
  else if(Is_membership_mess(msg->serv_type)) {
    if(Is_self_leave_mess(msg->serv_type)) {
      ;
    }
    else if(Is_transition_mess(msg->serv_type)) {
      ret = handle_trans(con, grp, msg, clq);
    }
    else {
      ret = handle_memb(con, grp, msg, clq);
    }
  }

  DEBUG_leave(f_dbg, "CLQ_handle_recv", ret);
  return ret;  
}

/* CLQ_handle_fl_ok ----------------------------------------------------------------------------
   This function specifies the action taken by the key agreement state machine if a flush
   ok event happen. This is actually Secure_Flush_Ok, sent by the user using SSP_Flush, 
   which does not sent the flush okinvoking directlly FL_flush, but calls this function to 
   handle it.
--------------------------------------------------------------------------------------------- */
int CLQ_handle_fl_ok(SSP_Con *con, SSP_Grp *grp){
  int  ret = DELIV_MSG;
  CLQ_Alg *clq = (CLQ_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "CLQ_handle_fl_ok");
  
  switch(clq->state) {
  case CLQ_SECURE:
    if(clq->wait_for_sec_fl_ok == SSP_TRUE) {
      clq->wait_for_sec_fl_ok = SSP_FALSE;      
      if ((ret = FL_flush(con->mbox, grp->name)) == CONNECTION_CLOSED || ret == ILLEGAL_SESSION) {
	SSP_disconnect(con->mbox);
	goto end;
      }
      clq->state = CLQ_WAIT_FOR_MEMBERSHIP;
    }
    else {
      ret = FLUSH_OK_ALREADY_SENT;
    }
    break;
    
  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
  case CLQ_WAIT_FOR_FINAL_TOKEN:
  case CLQ_WAIT_FOR_KEY_LIST:
  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
  case CLQ_COLLECT_FACT_OUTS:
  case CLQ_WAIT_FOR_MEMBERSHIP:
  case CLQ_WAIT_FOR_SELF_JOIN:
    ret = FLUSH_OK_ALREADY_SENT;
    break;    
  }
  
 end:
  DEBUG_leave(f_dbg, "CLQ_handle_fl_ok", ret);
  return ret;
  
}

/* CLQ_handle_send ----------------------------------------------------------------------------
   This function specifies the actions taken by the key agreement state machine, if the event
   that happen is a 'user' message. The event is caused by a user calling SSP_scat_multicast
   or SSP_multicast. Right now this function is not handleing the sending, it just allows the
   sending of the message or not. As a general idea, the user is not allowed to send messages
   while the key agreement is performing.
-------------------------------------------------------------------------------------------- */
int CLQ_handle_send(SSP_Con *con, SSP_Grp *grp) {
  int  ret = DELIV_MSG;
  CLQ_Alg *clq = (CLQ_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "CLQ_handle_send");

  switch(clq->state) {
  case CLQ_SECURE:
    ret = SEND_MSG;
    break;

  case CLQ_WAIT_FOR_PARTIAL_TOKEN:
  case CLQ_WAIT_FOR_FINAL_TOKEN:
  case CLQ_WAIT_FOR_KEY_LIST:
  case CLQ_WAIT_FOR_CASCADING_MEMBERSHIP:
  case CLQ_COLLECT_FACT_OUTS:
  case CLQ_WAIT_FOR_SELF_JOIN:
  case CLQ_WAIT_FOR_MEMBERSHIP:
    ret = DONT_SEND_MSG;
    break;
  }

  DEBUG_leave(f_dbg, "CLQ_handle_send", ret);
  return ret;

}


/*******************************   CKD ALGORITHM ***********************************************/

/* CKD_Alg_init  -------------------------------------------------------------------------------
   It initializes a CKD_Alg data structure
---------------------------------------------------------------------------------------------- */
static void CKD_Alg_init(CKD_Alg *ckd) {
  ckd->ctx = 0;
  stddll_construct(&(ckd->msg_deque), sizeof(SSP_Msg*));
  ckd->first_trans = SSP_TRUE; 
  ckd->vs_trans = SSP_FALSE;
  ckd->wait_for_sec_fl_ok = SSP_FALSE;
  ckd->kl_got_fl_req = SSP_FALSE;
  ckd->first_cascaded_memb = SSP_TRUE;
  ckd->vs_set = 0;
  stdhash_construct(&ckd->vs_set_hash, sizeof(char*), 0,grp_name_ptr_eq, grp_name_ptr_hashcode);
  ckd->curr_memb_msg = 0;
  ckd->state = CKD_WAIT_FOR_SELF_JOIN;
}

/* CKD_Alg_destroy -----------------------------------------------------------------------------
   It frees any memory used by CKD_Alg.
---------------------------------------------------------------------------------------------- */
static void CKD_Alg_destroy(CKD_Alg *ckd) {
  stddll_it lit;
  SSP_Msg *msg = 0;
  
  for(stddll_begin(&(ckd->msg_deque), &lit); !stddll_it_is_end(&lit); stddll_it_next(&lit)) {
    msg = *(SSP_Msg**) stddll_it_val(&lit);
    SSP_Msg_free(&msg);
  }
  stddll_destruct(&(ckd->msg_deque));
  
  clq_destroy_ctx(&ckd->ctx);

  if(ckd->vs_set) {
    free(ckd->vs_set);
    ckd->vs_set = NULL;
  }
  stdhash_destruct(&ckd->vs_set_hash);
}

/* CKD_Alg_create  ------------------------------------------------------------------------------
   It allocates and initializes a CKD_Alg data structure.
---------------------------------------------------------------------------------------------- */
CKD_Alg * CKD_Alg_create() {
  CKD_Alg * ckd = (CKD_Alg*) malloc(sizeof(CKD_Alg));
    
  if(!ckd) {
    ssp_err_quit("CKD_Alg_create: malloc failed \n");
  }
  CKD_Alg_init(ckd);

  return ckd;
}

/* CKD_Alg_free -------------------------------------------------------------------------------
   It frees a CKD_Alg data structure.
---------------------------------------------------------------------------------------------- */
void CKD_Alg_free(CKD_Alg **clq) {
  if (*clq) {
    CKD_Alg_destroy(*clq);
    free(*clq);
    *clq = NULL;
  } 
}

/* ============================  helper functions  =========================================== */


/* ckd_copy_key  ------------------------------------------------------------------------------------
   Helper function that copies the key from the cliques context in the encryption info.
-----------------------------------------------------------------------------------------------*/
static int ckd_copy_key(SSP_Grp *grp) {
  CKD_Alg *ckd = (CKD_Alg*)(grp->ka->info);
  
  memcpy(grp->enc->key, ckd->ctx->group_secret_hash, grp->enc->key_len);

  ON_DEBUG (
    { 
      int i;
      printf("The key is: 0x");
      for (i = 0; i < grp->enc->key_len; i++){
        printf("%02X", ((unsigned char*)(grp->enc->key))[i]);
      }
      printf("\n");
    }
  )

  return 0;
}


/* ckd_msg_2_tk  -----------------------------------------------------------------------------------
   This function copies a spread message into a ckd token.
-----------------------------------------------------------------------------------------------*/
static void ckd_msg_2_tk(SSP_Msg *msg, CLQ_TOKEN *tk) {
  int err;

  if(Is_r_msg(msg->msg_type) || Is_new_share_msg(msg->msg_type) || Is_key_msg(msg->msg_type)) {
    tk->length = msg->msg_len;     
  }
  else {
    ssp_err_quit("ckd_msg_2_tk: Unknown token type\n");
  }

  if((tk->t_data = (unsigned char*) malloc(tk->length * sizeof(unsigned char))) == NULL) {
    ssp_err_quit("ckd_msg_2_tk: malloc failed\n");  
  }

  if((err = scat_get2((char*)tk->t_data, msg->scat, -1, 0, 0, tk->length)) != tk->length) {
    ssp_err_quit("ckd_msg_2_tk: scat_get2 failed\n");
  }
}


/* ckd_first_user -------------------------------------------------------------------------------
   This function handles the key agreement when the group contains only one user. 
   It returns void, it fails if cliques fails.
---------------------------------------------------------------------------------------------- */
static void ckd_first_user(SSP_Con *con, SSP_Grp *grp) {
  int       err;
  CKD_Alg   *ckd = (CKD_Alg *)grp->ka->info;	
  char       *joiner = (char*)grp->curr_membs; 

  DEBUG_enter(f_dbg, "ckd_first_user");

  clq_destroy_ctx(&ckd->ctx);
  if((err = clq_first_user(&ckd->ctx, joiner, grp->name)) < 0){
    ssp_err_quit("ckd_first_user: clq_first_user failed  %d\n", err);
  }

  ckd_copy_key(grp);
  stddll_push_back(&con->deliv_deque, &ckd->curr_memb_msg);
  ckd->state = CKD_SECURE;
  grp->ka->key_state = ESTABLISH;
  ckd->first_cascaded_memb = SSP_TRUE;
  ckd->first_trans = SSP_TRUE; 
  (*grp->enc->chg_key_fcn)(grp->enc->key, grp->enc->key_len, grp->enc->info);    
  
  DEBUG_leave(f_dbg, "ckd_first_user", 0);
}

/* ckd_start_alg -----------------------------------------------------------------------------------
   This function is invoked when a cascading membership happens and the group contains more 
   than one member. It returs nothing and it exists if either cliques call or FL_unicast fails.
--------------------------------------------------------------------------------------------- */
static void ckd_start_alg(SSP_Con *con, SSP_Grp *grp) {
  DEBUG_enter(f_dbg, "ckd_start_alg");
  DEBUG_leave(f_dbg, "ckd_start_alg", 0);
}

/* ckd_handle_leave ---------------------------------------------------------------------------
   This function handles a leave or a partition (the fast way clq_leave + broadcast)
   It returs nothing and it exists if either cliques call or FL_unicast fails.

   Note: all the members can call clq_leave, only for the controller the function will
   return a valid token.
--------------------------------------------------------------------------------------------- */
static void ckd_handle_leave(SSP_Con *con, SSP_Grp *grp, stdarr *leave_set) {
  CKD_Alg    *ckd = (CKD_Alg *)grp->ka->info;	
  CLQ_TOKEN  *tk_out = 0; 
  enum MSG_TYPE msg_type = INVALID;
  int        err;  
  int        type;
  char       *leave_ptr;
  stdarr_it  ait;
  
  DEBUG_enter(f_dbg, "ckd_handle_leave");

  if(strcmp(grp->leaver, ckd_get_controller_name(ckd->ctx))){
    ckd->state = CKD_WAIT_FOR_KEY;
    type = CKD_KEY;
  }
  else {
    ckd->state = CKD_WAIT_FOR_R;
    type = CKD_R;
  }

  leave_ptr = *(char**)stdarr_it_val(stdarr_begin(leave_set, &ait));
  if ((err = ckd_proc_event(&ckd->ctx, leave_ptr, CKD_LEAVE, &msg_type, &tk_out)) != OK) {
    ssp_err_quit("ckd_handle_leave: clq_proc_event failed %d\n", err);
  }
  
  if (tk_out != 0) {
    if ((err = FL_multicast(con->mbox, CLQ_SERVICE_TYPE, grp->name, type, tk_out->length, 
			    tk_out->t_data)) == CONNECTION_CLOSED || err == ILLEGAL_SESSION) {
      FL_disconnect(con->mbox);
    }
    else if (err == ILLEGAL_MESSAGE) {
      ssp_err_quit("ckd_handle_leave: FL_multicast failed\n");
    }
    clq_destroy_token(&tk_out);
  }

  DEBUG_leave(f_dbg, "ckd_handle_leave", 0);
}


/* ckd_handle_join ----------------------------------------------------------------------------
   This function handles a join.
   Note: all the members can call clq_leave, only for the controller the function will
   return a valid token.
--------------------------------------------------------------------------------------------- */
static void ckd_handle_join(SSP_Con *con, SSP_Grp *grp, stdarr *join_set) {
  int        err;
  CKD_Alg    *ckd = (CKD_Alg *)grp->ka->info;	
  char       *join_ptr;
  CLQ_TOKEN  *tk_out = 0;
  stdarr_it  ait;
  enum MSG_TYPE msg_type = INVALID;
  
  DEBUG_enter(f_dbg, "ckd_handle_join");
  
  join_ptr = *(char**)stdarr_it_val(stdarr_begin(join_set, &ait));
  if ((err = ckd_proc_event(&ckd->ctx, join_ptr, CKD_JOIN, &msg_type, &tk_out)) != OK) {
    ssp_err_quit("ckd_handle_join: clq_proc_event failed %d\n", err);
  }

  if (tk_out != 0) {
    if ((err = FL_multicast(con->mbox, CLQ_SERVICE_TYPE, grp->name, CKD_R, tk_out->length, 
			    tk_out->t_data)) == CONNECTION_CLOSED || err == ILLEGAL_SESSION) {
      FL_disconnect(con->mbox);
    }
    else if (err == ILLEGAL_MESSAGE) {
      ssp_err_quit("ckd_handle_join: FL_multicast failed\n");
    }
    clq_destroy_token(&tk_out);
  }
  ckd->state = CKD_WAIT_FOR_R;
  
  DEBUG_leave(f_dbg, "ckd_handle_join", 0);
}


/* ckd_handle_data_msg ----------------------------------------------------------------------------- 
   This function specifies the actions taken by the state machine if the message received was
   a data message (message received from the flush layer).
-----------------------------------------------------------------------------------------------*/
static int ckd_handle_data_msg(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CKD_Alg *ckd) {
  int ret = DONT_DELIV_MSG;
  
  DEBUG_enter(f_dbg, "ckd_handle_data_msg");

  switch(ckd->state) {
  case CKD_SECURE:
    ssp_err_quit("ckd_handle_data_msg: this message should not be here");
    break;
    
  case CKD_WAIT_FOR_R:
  case CKD_WAIT_FOR_NEW_SHARE:
  case CKD_WAIT_FOR_SELF_JOIN:
    ssp_err_quit("ckd_handle_data_msg: no message should be received in this state");
    break;

  case CKD_WAIT_FOR_KEY:
    stddll_push_back(&ckd->msg_deque, &msg);
    break;

  case CKD_WAIT_FOR_CASCADING_MEMBERSHIP:
  case CKD_WAIT_FOR_MEMBERSHIP:
    ret = DELIV_MSG;
    break;
  }

  DEBUG_leave(f_dbg, "ckd_handle_data_msg", ret);
  return ret;
}


/* ckd_handle_r --------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a 'R' message.
---------------------------------------------------------------------------------------------- */
static int ckd_handle_r(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CKD_Alg *ckd) {
  int        ret = DONT_DELIV_AND_FREE_MSG;
  CLQ_TOKEN  tk_in = {0};
  CLQ_TOKEN  *tk_out = 0; 
  int        err;  

  DEBUG_enter(f_dbg, "ckd_handle_r");

  switch(ckd->state) {
  case CKD_WAIT_FOR_R:
    ckd_msg_2_tk(msg, &tk_in);
    
    if ((err = ckd_comp_new_share(ckd->ctx, &tk_in, &tk_out)) != OK) {
      ssp_err_quit("ckd_handle_r: ckd_comp_new_share failed %d\n", err);
    }
    
    if (tk_out != 0) {
      if ((err = FL_unicast(con->mbox, CLQ_SERVICE_TYPE, grp->name, ckd_get_controller_name(ckd->ctx), 
			    CKD_NEW_SHARE, tk_out->length, tk_out->t_data))
	  == CONNECTION_CLOSED || err == ILLEGAL_SESSION) {
	FL_disconnect(con->mbox);
      }
      else if (err == ILLEGAL_MESSAGE) {
	ssp_err_quit("ckd_handle_r: FL_multicast failed\n");
      }
      clq_destroy_token(&tk_out);
    } 

    if (!strcmp(ckd_get_controller_name(ckd->ctx), con->priv_name)) {
      ckd->state = CKD_WAIT_FOR_NEW_SHARE;
    } 
    else {
      ckd->state = CKD_WAIT_FOR_KEY;
    }
    break;
    
  case CKD_SECURE:
  case CKD_WAIT_FOR_KEY:
  case CKD_WAIT_FOR_NEW_SHARE:
    ssp_err_quit("ckd_handle_r: key in wrong state!");
    break;

  case CKD_WAIT_FOR_CASCADING_MEMBERSHIP:
    ret = DONT_DELIV_AND_FREE_MSG;
    break;

  case CKD_WAIT_FOR_SELF_JOIN:
  case CKD_WAIT_FOR_MEMBERSHIP:
    break;
  }
  
  DEBUG_leave(f_dbg, "ckd_handle_r", ret);
  return ret;
}


/* ckd_handle_new_share ------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a 'new share' message.
---------------------------------------------------------------------------------------------- */
static int ckd_handle_new_share(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CKD_Alg *ckd) {
  int        ret = DONT_DELIV_AND_FREE_MSG;
  CLQ_TOKEN  tk_in = {0}; 
  CLQ_TOKEN  *tk_out = 0; 
  int        err;  
 
  DEBUG_enter(f_dbg, "ckd_handle_new_share");

  switch(ckd->state) {
  case CKD_WAIT_FOR_NEW_SHARE:
    ckd_msg_2_tk(msg, &tk_in);
   
    if ((err = ckd_generates_key(ckd->ctx, msg->sender, &tk_in, &tk_out)) != OK) {
      ssp_err_quit("ckd_handle_new_share: ckd_generates_key failed %d\n", err);
    }
    
    if (tk_out != 0) { /* multicast */
      if ((err = FL_multicast(con->mbox, CLQ_SERVICE_TYPE, grp->name, CKD_KEY, 
			      tk_out->length, tk_out->t_data)) < 0) {
	ssp_err_quit("ckd_handle_new_share: multicast failed %d\n", err);
      }
      
      ckd->state = CKD_WAIT_FOR_KEY;
      clq_destroy_token(&tk_out);
    } 
    break;
    
  case CKD_SECURE:
  case CKD_WAIT_FOR_KEY:
  case CKD_WAIT_FOR_R:
    ssp_err_quit("ckd_handle_new_share: key in wrong state!");
    break;

  case CKD_WAIT_FOR_CASCADING_MEMBERSHIP:
    ret = DONT_DELIV_AND_FREE_MSG;
    break;

  case CKD_WAIT_FOR_SELF_JOIN:
  case CKD_WAIT_FOR_MEMBERSHIP:
    break;

  }
  
  DEBUG_leave(f_dbg, "ckd_handle_new_share", ret);
  return ret;
}


/* ckd_handle_key ------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a key message.
---------------------------------------------------------------------------------------------- */
static int ckd_handle_key(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CKD_Alg *ckd) {
  int        ret = DONT_DELIV_AND_FREE_MSG;
  CLQ_TOKEN  tk_in = {0}; 
  int        err;  
  SSP_Msg    *msg_tmp;
  stddll_it  lit;

  DEBUG_enter(f_dbg, "ckd_handle_key");

  switch(ckd->state) {
  case CKD_WAIT_FOR_KEY:
    if(ckd->vs_trans == SSP_FALSE) {
      ckd_msg_2_tk(msg, &tk_in);

      if ((err = ckd_get_session_key(ckd->ctx, &tk_in)) != OK) {
	ssp_err_quit("ckd_handle_key: ckd_get_session_key failed %d\n", err);
      }	

      ckd_copy_key(grp);      
      grp->ka->key_state = ESTABLISH;      
      (*grp->enc->chg_key_fcn)(grp->enc->key, grp->enc->key_len, grp->enc->info);
     
      /* in case of a cascading due to a join, the joiner starts in WAIT_FOR_SELF_JOIN 
         and it never knows it it was a cascading or not so he deliveres JOIN while 
         all the other members of the group will deliver NETWORK. That's why each
         members that passes along the partial token attaches also its group event,
	 and if it was join is upgraded to network. With the final token broadcast
	 everybody agreed to deliver that group event type.
      */
      if(Is_caused_network_mess(ckd->curr_memb_msg->serv_type)) {
	set_vs_set_memb_msg(ckd->curr_memb_msg, grp); 
      }

      /* first put the new secure memb in the connection queue */
      stddll_push_back(&con->deliv_deque, &ckd->curr_memb_msg);

      for(stddll_begin(&(ckd->msg_deque), &lit); !stddll_it_is_end(&lit); 
	  stddll_it_next(&lit)) {
	msg_tmp = *(SSP_Msg**) stddll_it_val(&lit);
	if(Is_encrypt_mess_type(msg_tmp->msg_type)) {   
	  if(Dec_Scat(msg_tmp->scat, grp->enc->dec_fcn, grp->enc->block_size, grp->enc->info, 
		      (unsigned int) msg_tmp->msg_len, &msg->msg_type, msg->endian_mism) < 0) {
	    ssp_err_quit("ckd_handle_key: Dec_Scat failed!\n");
	  }
	} 
	if(Is_reg_memb_mess(msg_tmp->serv_type)) {
	  ssp_err_quit("ckd_handle_key: membeship message in the ka queue\n ");
	}
	stddll_push_back(&con->deliv_deque, &msg_tmp);
      }

      ckd->state = CLQ_SECURE;
      ckd->first_trans = SSP_TRUE;
      ckd->first_cascaded_memb = SSP_TRUE;
      stddll_clear(&(ckd->msg_deque));
      if(ckd->kl_got_fl_req == SSP_TRUE) {
	ckd->wait_for_sec_fl_ok = SSP_TRUE;
	gen_and_push_msg(con, grp, FLUSH_REQ_MESS); /* push flush request in the application queue*/
      }
      if(tk_in.t_data) {
	free(tk_in.t_data);
	tk_in.t_data = NULL;
      } 
    }

    if(ret > 0) {
      ret = DONT_DELIV_AND_FREE_MSG;
    }
    
    break;
    
  case CKD_SECURE:
  case CKD_WAIT_FOR_R:
  case CKD_WAIT_FOR_NEW_SHARE:
    ssp_err_quit("ckd_handle_key: key in wrong state!");
    break;

  case CKD_WAIT_FOR_CASCADING_MEMBERSHIP:
    ret = DONT_DELIV_AND_FREE_MSG;
    break;

  case CKD_WAIT_FOR_SELF_JOIN:
  case CKD_WAIT_FOR_MEMBERSHIP:
    break;
  }
  
  DEBUG_leave(f_dbg, "ckd_handle_key", ret);
  return ret;
}

/* ckd_handle_trans -----------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a transitional message.
---------------------------------------------------------------------------------------------- */
static int ckd_handle_trans(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CKD_Alg *ckd) {
  int ret = DONT_DELIV_MSG;

  DEBUG_enter(f_dbg, "ckd_handle_trans");

  switch(ckd->state) {
  case CKD_SECURE:
    ckd->first_trans = SSP_FALSE;
    ckd->vs_trans = SSP_TRUE;
    ret = DELIV_MSG;
    break;

  case CKD_WAIT_FOR_R:
  case CKD_WAIT_FOR_NEW_SHARE:
  case CKD_WAIT_FOR_CASCADING_MEMBERSHIP:
  case CKD_WAIT_FOR_MEMBERSHIP:
    if(ckd->first_trans == SSP_TRUE) {
      ckd->first_trans = SSP_FALSE;
      ret = DELIV_MSG;
    }
    ckd->vs_trans = SSP_TRUE;
    break;
  
  case CKD_WAIT_FOR_KEY:
    if(ckd->first_trans == SSP_TRUE) {
      ckd->first_trans = SSP_FALSE;
      ret = DELIV_MSG;
    }
    ckd->state = CKD_WAIT_FOR_CASCADING_MEMBERSHIP;
    ckd->vs_trans = SSP_TRUE;
    break; 

  case CKD_WAIT_FOR_SELF_JOIN:
    ssp_err_quit("ckd_handle_trans: trans received in wrong state, %d!\n", ckd->state);
    break;
  }
  
  DEBUG_leave(f_dbg, "ckd_handle_trans", ret);
  return ret;
}


/* ckd_handle_memb ------------------------------------------------------------------------------
  This function specifies the actions taken by the state machine if the message received was
  a group membership.

  Some comments:
      a member in the WAIT_FOR_SELF_JOIN can receive 2 events: a membership due to its own join
      (a join event) or a membership due to a network event (in this case the joinee is on the
      list of new added members. Flush delivers this special network in some cases:
      -  a partiton happen after the join and before the new membership is delivered
      -  the join happened while a previous partition was processed, so the two events are
         combined in one
      -  somebody left immediately after my join. Since flush membership deliveries are based
         on gathering flush_oks from old members, if the guy that left did not send his 
         flush_ok, the two events will be combined. Note that if he managed to send his
         flush_ok, then the join will be delivered first, then the leave.
---------------------------------------------------------------------------------------------- */
static int ckd_handle_memb(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, CKD_Alg *ckd) {
  int    ret = DONT_DELIV_MSG;
  int    was_leave = 0;
  int    err = 0;
  stdarr join_set;
  stdarr leave_set;


  DEBUG_enter(f_dbg, "ckd_handle_memb");
  
  stdarr_construct(&leave_set, sizeof(char*));
  stdarr_construct(&join_set, sizeof(char*));

  switch(ckd->state) {
  case CKD_SECURE:
  case CKD_WAIT_FOR_R:
  case CKD_WAIT_FOR_NEW_SHARE:
  case CKD_WAIT_FOR_KEY: 
    ssp_err_quit("ckd_handle_memb: memb received in wrong state, %d!\n", ckd->state);
    break;
    
  case CKD_WAIT_FOR_CASCADING_MEMBERSHIP:
    ssp_err_quit("Cascaded membership happend, not handled yet.\n");

    if(ckd->first_cascaded_memb == SSP_TRUE) {
      ckd->first_cascaded_memb = SSP_FALSE;
      init_vs_set(grp); 
    }
    was_leave = upd_vs_set_and_get_join_leave_set(grp, msg->serv_type, &join_set, &leave_set);
    if (was_leave  && (ckd->first_trans == SSP_TRUE)) {
      ckd->first_trans = SSP_FALSE;
      gen_and_push_msg(con, grp, TRANSITION_MESS);
    }

    ckd->curr_memb_msg = msg; /* delay delivery of memb  */
    ckd->curr_memb_msg->serv_type = REG_MEMB_MESS | CAUSED_BY_NETWORK; /* memb. collapsed  */

    grp->ka->key_state = NOT_ESTABLISH;
    if(stdhash_size(&grp->curr_membs_hash) > 1) {
      ckd_start_alg(con, grp);
    }
    else {
      ckd_first_user(con, grp);
    }
    ret = DONT_DELIV_MSG;
    ckd->vs_trans = SSP_FALSE;
    break;

  case CKD_WAIT_FOR_SELF_JOIN:
    grp->ka->key_state = NOT_ESTABLISH;
    
    init_vs_set(grp); 
    was_leave = upd_vs_set_and_get_join_leave_set(grp, msg->serv_type, &join_set, &leave_set);
    ckd->first_cascaded_memb = SSP_FALSE;
    
    ckd->curr_memb_msg = msg;  /* delay delivery of memb  */

    if(stdhash_size(&grp->curr_membs_hash) > 1) {
      if(Is_reg_memb_mess(msg->serv_type)) {
	if(Is_caused_join_mess(msg->serv_type)) {
	  if((err = clq_new_user(&ckd->ctx, con->priv_name, grp->name, FALSE)) < 0) {
	    ssp_err_quit("ckd_handle_memb: clq_new_user failed %d\n", err);  	
	  }
	  ckd->state = CKD_WAIT_FOR_R;	
	}	      
	else if(Is_caused_leave_mess(msg->serv_type) || Is_caused_disconnect_mess(msg->serv_type)) {
	  ssp_err_quit("ckd_handle_memb: leave or disconnect in the wrong state %d\n", 
		       ckd->state);
	}
	else if(Is_caused_network_mess(msg->serv_type)) {
	  ssp_err_quit("ckd_handle_memb: network in self join, not handled yet %d\n", err);  
	}
      }
    }
    else {
      ckd_first_user(con, grp);
    }
    ckd->vs_trans = SSP_FALSE;
    break;
    
  case CKD_WAIT_FOR_MEMBERSHIP:
    grp->ka->key_state = NOT_ESTABLISH;
    ckd->first_cascaded_memb = SSP_FALSE;
    
    init_vs_set(grp); 
    was_leave = upd_vs_set_and_get_join_leave_set(grp, msg->serv_type, &join_set, &leave_set);
    
    ckd->curr_memb_msg = msg; /* delay delivery of memb  */
    
    if(stdhash_size(&grp->curr_membs_hash) > 1) {
      if(stdarr_size(&leave_set) > 1) { /* count the NULL too */
	if(stdarr_size(&join_set) <= 1) {  /* only partition or leave, count the NULL too  */
	  if(Is_caused_leave_mess(msg->serv_type)) { /* if I am here I am an old member */
	    ckd_handle_leave(con, grp, &leave_set);
	  }
	  else {
	    ssp_err_quit("ckd_handle_memb: partition not handle yet\n");	  
	  }	 
	}
	else {
	  ssp_err_quit("ckd_handle_memb: combined leave and merge not handle yet\n");
	}
      }
      else { /*  merge &  join */
	if(Is_caused_join_mess(msg->serv_type)) { /* if I am here I am an old member */
	  ckd_handle_join(con, grp, &join_set);
	}
	else {
	  ssp_err_quit("ckd_handle_memb: merge not handle yet\n");	  
	}
      }
    }  
    else { /* alone  */
      ckd_first_user(con, grp);
    }
    ckd->vs_trans = SSP_FALSE;
    break;
  }

  stdarr_destruct(&leave_set);  
  stdarr_destruct(&join_set);      

  DEBUG_leave(f_dbg, "handle_memb", ret);
  return ret;
}
 

/* ckd_handle_fl_req -------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a flush request message.
---------------------------------------------------------------------------------------------- */
static int ckd_handle_fl_req(SSP_Con *con, SSP_Grp *grp, SSP_Msg *mess, CKD_Alg *ckd) {
  int ret = DONT_DELIV_AND_FREE_MSG;

  DEBUG_enter(f_dbg, "ckd_handle_fl_req");

  switch(ckd->state) {
  case CKD_SECURE:
    ckd->wait_for_sec_fl_ok = SSP_TRUE;
    ret = DELIV_MSG; 
    break;

  case CKD_WAIT_FOR_R:
  case CKD_WAIT_FOR_NEW_SHARE:
  case CKD_WAIT_FOR_KEY:
    ssp_err_quit("Cascading membership happend, not handled yet.");
    break;
  
  case CKD_WAIT_FOR_SELF_JOIN:
  case CKD_WAIT_FOR_MEMBERSHIP:
  case CKD_WAIT_FOR_CASCADING_MEMBERSHIP:
    ssp_err_quit("ckd_handle_fl_req: fl_req received in wrong state, not possible !");
    break;

  }

  DEBUG_leave(f_dbg, "ckd_handle_fl_req", ret);
  return ret;
}


/* ============================  wrapper functions for CKD  ==================================== */

/* CKD_handles_mess ------------------------------------------------------------------------------
   This function specifies if a spread message is used or not by the key agreement algorithm.
   All the messages specified here will be redirected by spread to CKD_Comp_Key_Wrapper;
   In this case, all the membership messages (including transitional messages) are sended,
   Also the regular messages used internal by the key agreement algorithm (OT... messages)
   and regular messages received between having a stable key, are sent here.
-----------------------------------------------------------------------------------------------*/
int CKD_handles_msg(SSP_Msg *msg, SSP_Grp *grp) {
  service serv_type = msg->serv_type;
  int     msg_type  = msg->msg_type;
  
  return  !Is_regular_mess(serv_type) ||  grp->ka->key_state == NOT_ESTABLISH ||
    msg_type == CKD_R || msg_type == CKD_NEW_SHARE  || msg_type == CKD_KEY;
}


/* CKD_handle_recv ----------------------------------------------------------------------------
   This function is implementing the state machine for the key agreement algorithm. 
   It returns 1 if the message must be delivered by the SSP, 0 otherwise. The SSP can check if 
   the key agreement finished by looking and Key_State.
-----------------------------------------------------------------------------------------------*/
int CKD_handle_recv(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg) {
  int  ret = DELIV_MSG;
  CKD_Alg *ckd = (CKD_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "CKD_handle_recv");
  
  if(Is_regular_mess(msg->serv_type)) {
    if(Is_r_msg(msg->msg_type)) {
      ret = ckd_handle_r(con, grp, msg, ckd);
    }
    else if(Is_new_share_msg(msg->msg_type)) {
      ret = ckd_handle_new_share(con, grp, msg, ckd);
    }
    else if(Is_key_msg(msg->msg_type)) {
      ret = ckd_handle_key(con, grp, msg, ckd);
    }
    else {
      ret = ckd_handle_data_msg(con, grp, msg, ckd);
    }
  }
  else if(Is_flush_req_mess(msg->serv_type)) {
    ret = ckd_handle_fl_req(con, grp, msg, ckd);
  }
  else if(Is_membership_mess(msg->serv_type)) {
    if(Is_self_leave_mess(msg->serv_type)) {
      ;
    }
    else if(Is_transition_mess(msg->serv_type)) {
      ret = ckd_handle_trans(con, grp, msg, ckd);
    }
    else {
      ret = ckd_handle_memb(con, grp, msg, ckd);
    }
  }

  DEBUG_leave(f_dbg, "CKD_handle_recv", ret);
  return ret;  
}

/* CKD_handle_fl_ok ----------------------------------------------------------------------------
   This function specifies the action taken by the key agreement state machine if a flush
   ok event happen. This is actually Secure_Flush_Ok, sent by the user using SSP_Flush, 
   which does not sent the flush okinvoking directlly FL_flush, but calls this function to 
   handle it.
-----------------------------------------------------------------------------------------------*/
int CKD_handle_fl_ok(SSP_Con *con, SSP_Grp *grp){
  int  ret = DELIV_MSG;
  CKD_Alg *ckd = (CKD_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "CKD_handle_fl_ok");
  
  switch(ckd->state) {
  case CKD_SECURE:
    if(ckd->wait_for_sec_fl_ok == SSP_TRUE) {
      ckd->wait_for_sec_fl_ok = SSP_FALSE;      
      if ((ret = FL_flush(con->mbox, grp->name)) == CONNECTION_CLOSED || ret == ILLEGAL_SESSION) {
	SSP_disconnect(con->mbox);
	goto end;
      }
      ckd->state = CKD_WAIT_FOR_MEMBERSHIP;
    }
    else {
      ret = FLUSH_OK_ALREADY_SENT;
    }
    break;
    
  case CKD_WAIT_FOR_R:
  case CKD_WAIT_FOR_NEW_SHARE:
  case CKD_WAIT_FOR_KEY:
  case CKD_WAIT_FOR_CASCADING_MEMBERSHIP:
  case CKD_WAIT_FOR_MEMBERSHIP:
  case CKD_WAIT_FOR_SELF_JOIN:
    ret = FLUSH_OK_ALREADY_SENT;
    break;    
  }
  
 end:
  DEBUG_leave(f_dbg, "CKD_handle_fl_ok", ret);
  return ret;
  
}

/* CKD_handle_send ----------------------------------------------------------------------------
   This function specifies the actions taken by the key agreement state machine, if the event
   that happen is a 'user' message. The event is caused by a user calling SSP_scat_multicast
   or SSP_multicast. Right now this function is not handleing the sending, it just allows the
   sending of the message or not. As a general idea, the user is not allowed to send messages
   while the key agreement is performing.
-----------------------------------------------------------------------------------------------*/
int CKD_handle_send(SSP_Con *con, SSP_Grp *grp) {
  int  ret = DELIV_MSG;
  CKD_Alg *ckd = (CKD_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "CKD_handle_send");

  switch(ckd->state) {
  case CKD_SECURE:
    ret = SEND_MSG;
    break;

  case CKD_WAIT_FOR_R:
  case CKD_WAIT_FOR_NEW_SHARE:
  case CKD_WAIT_FOR_KEY:
  case CKD_WAIT_FOR_CASCADING_MEMBERSHIP:
  case CKD_WAIT_FOR_MEMBERSHIP:
  case CKD_WAIT_FOR_SELF_JOIN:
    ret = DONT_SEND_MSG;
    break;
  }

  DEBUG_leave(f_dbg, "CKD_handle_send", ret);
  return ret;

}














