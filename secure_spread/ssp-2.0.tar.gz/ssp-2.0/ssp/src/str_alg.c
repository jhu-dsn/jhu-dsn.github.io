/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */

/***********************************************************************************************/
/* str_alg.c                                                                                   */
/* Implements STR protocol                                                                     */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: Feb 15, 2001                                                                       */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "str_alg.h"
#include "ssp_info.h"
#include "scatter.h"
#include "scatter_cryptor.h"
#include "fl.h"
#include "ssp.h"
#include "utility.h"
#include "ssp_dbg.h"
#include "ssp_p.h"
#include "ssp_error.h"

#include <stdutil/stddefines.h>
#include <stdutil/stderror.h>
#include <stdutil/stddll.h>
#include <stdutil/stdhash.h>
#include <stdutil/stdarr.h>

#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif

#include "str_error.h"
#include "str_api_misc.h"

extern FILE *f_dbg;

/* ==================================  STR  algorithm specific  ============================= */

/* STR_Alg_init  -------------------------------------------------------------------------------
   It initializes a STR_Alg data structure
---------------------------------------------------------------------------------------------- */
static void STR_Alg_init(STR_Alg *str) {
  str->ctx = 0;
  stddll_construct(&(str->msg_deque), sizeof(SSP_Msg*));
  str->ts_delivered_to_app = SSP_FALSE;
  str->vs_ts_received = SSP_FALSE;
  str->num_vs_membs = 0;
  str->wait_for_sec_fl_ok = SSP_FALSE;
  str->state = STR_WAIT_FOR_SELF_JOIN;
  str->num_old_tree_msgs = 0;
  str->curr_memb_msg = 0;
  str->curr_grp_op = STR_NONE;    
  str->tk = 0;
}

/* STR_Alg_destroy -----------------------------------------------------------------------------
   It frees any memory used by STR_Alg.
---------------------------------------------------------------------------------------------- */
static void STR_Alg_destroy(STR_Alg *str) {
  stddll_it lit;
  SSP_Msg *msg;
  
  for(stddll_begin(&(str->msg_deque), &lit); !stddll_it_is_end(&lit); stddll_it_next(&lit)) {
    msg = *(SSP_Msg**) stddll_it_val(&lit);
    SSP_Msg_free(&msg);
  }
  stddll_destruct(&(str->msg_deque));  
  str_destroy_ctx(&str->ctx, 1);
}

/* STR_Alg_create  ------------------------------------------------------------------------------
   It allocates and initializes a STR_Alg data structure.
---------------------------------------------------------------------------------------------- */
STR_Alg * STR_Alg_create() {
  STR_Alg * str = (STR_Alg*) malloc(sizeof(STR_Alg));
    
  if(!str) {
    ssp_err_quit("STR_Alg_create: malloc failed\n");
  }
  STR_Alg_init(str);

  return str;
}

/* STR_Alg_free -------------------------------------------------------------------------------
   It frees a STR_Alg data structure.
---------------------------------------------------------------------------------------------- */
void STR_Alg_free(STR_Alg **str) {
  if (*str) {
    STR_Alg_destroy(*str);
    free(*str);
    *str = NULL;
  } 
}

/* reset_vs_data  -------------------------------------------------------------------------------
   This function clears variables used to track the cascaded vs memebrships while trying to
   install a secure membership. It needs to be called everytime the algorithm moves to the
   SECURE state.
-----------------------------------------------------------------------------------------------*/
static void reset_vs_data(STR_Alg *str) {
  str->num_vs_membs = 0;
  str->ts_delivered_to_app = SSP_FALSE;
  str->vs_ts_received = SSP_FALSE;
}

/* copy_key  ------------------------------------------------------------------------------------
   Helper function that copies the key from the str context in the encryption info.
-----------------------------------------------------------------------------------------------*/
static int copy_key(SSP_Grp *grp) {
  STR_Alg *str = (STR_Alg*)(grp->ka->info);

  memcpy(grp->enc->key, str->ctx->group_secret_hash, grp->enc->key_len);

  ON_DEBUG (
    {
      int i;
      printf("The key is: 0x");
      for (i = 0; i < grp->enc->key_len; i++){
	printf("%02X", ((unsigned char*)(grp->enc->key))[i]);
      }
      printf("\n");
    }
  )

  return 0;
}

/* msg_2_tk  -----------------------------------------------------------------------------------
   This function copies a spread message into a str token. It also pack in there the service
   from the membership Flush message.
-----------------------------------------------------------------------------------------------*/
static void msg_2_tk(SSP_Msg *msg, STR_TOKEN *tk, service *serv) {
  int err;
  int length;
  int offset;

  if(Is_str_old_tree_msg(msg->msg_type) || Is_str_new_tree_msg(msg->msg_type)) {
    length = msg->msg_len - sizeof(service);
    offset = sizeof(service);

    if((err = scat_get2((char*)serv, msg->scat, -1, 0, 0, sizeof(service))) != sizeof(service)) {
      ssp_err_quit("msg_2_tk: scat_get2 failed\n");
    }
    
    tk->length = length; 
  
    if((tk->t_data = (unsigned char*) malloc(tk->length * sizeof(unsigned char))) == NULL) {
      ssp_err_quit("msg_2_tk: malloc failed\n");  
    }
    
    if((err = scat_get2((char*)tk->t_data, msg->scat, -1, 0, offset, tk->length)) != tk->length) {
      ssp_err_quit("msg_2_tk: scat_get2 failed\n");
    }
  }
  else {
    ssp_err_quit("msg_2_tk: Unknown token type\n");
  }
}


/* tk_2_msg  -----------------------------------------------------------------------------------
   This function returns the length of the message, it allocates a buffer if necessary
   and puts the data that will be multicasted in it or, in the case when the data sent is
   just the token is sets the buffer pointer to point to the right data.
-----------------------------------------------------------------------------------------------*/
static int tk_2_msg(char **buf, STR_TOKEN *tk, int16 msg_type, service serv_type) {
  int msg_len;

  if(Is_str_old_tree_msg(msg_type) || Is_str_new_tree_msg(msg_type)) {
    *buf = (unsigned char*) malloc(tk->length * sizeof(unsigned char) + sizeof(service));
    if(!(*buf)) {
      ssp_err_quit("tk_2_msg: malloc failed\n");  
    }
    memcpy(*buf, &serv_type, sizeof(service));
    memcpy(*buf + sizeof(service), tk->t_data, tk->length);
    msg_len = tk->length + sizeof(service);
  }
  else {
    ssp_err_quit("tk_2_msg: Unknown token type\n");
  }
  return msg_len;
}


/* move_msg_con_deque  -------------------------------------------------------------------------
   This function is called when a secure memb. will be installed. It moves all the messages 
   from the ka queue in the connection delivery queue.
--------------------------------------------------------------------------------------------- */
static void move_msg_con_deque(SSP_Con *con, SSP_Grp *grp) {
  STR_Alg     *str = (STR_Alg *)grp->ka->info;	
  SSP_Msg     *msg_tmp;
  stddll_it   lit;
  
  for(stddll_begin(&(str->msg_deque), &lit); !stddll_it_is_end(&lit); stddll_it_next(&lit)) {
    msg_tmp = *(SSP_Msg**) stddll_it_val(&lit);
    if(Is_encrypt_mess_type(msg_tmp->msg_type)) {   
      if(Dec_Scat(msg_tmp->scat, grp->enc->dec_fcn, grp->enc->block_size, grp->enc->info, 
		  (unsigned int) msg_tmp->msg_len, &msg_tmp->msg_type, msg_tmp->endian_mism) < 0) {
	ssp_err_quit("move_msg_con_deque: Dec_Scat failed!\n");
      }
    } 
    if(Is_reg_memb_mess(msg_tmp->serv_type)) {
      ssp_err_quit("move_msg_con_deque: membership message in the ka queue\n");
    }
    stddll_push_back(&con->deliv_deque, &msg_tmp);
  }
  stddll_clear(&(str->msg_deque));
}

/* first_user -----------------------------------------------------------------------------------
   This function handles the key agreement when the group contains only one user. 
   It returns void, it fails if str fails.
---------------------------------------------------------------------------------------------- */
static void first_user(SSP_Con *con, SSP_Grp *grp) {
  int        err;
  STR_Alg    *str = (STR_Alg *)grp->ka->info;	
  char       *joiner = (char*)grp->curr_membs; 

  DEBUG_enter(f_dbg, "first_user");

  str_destroy_ctx(&str->ctx, 1);
  if((err = str_new_member(&str->ctx, joiner, grp->name)) < 0) {
    ssp_err_quit("first_user: self_new_member failed  %d\n", err);
  }
  copy_key(grp);

  stddll_push_back(&con->deliv_deque, &str->curr_memb_msg);

  str->state = STR_SECURE;
  grp->ka->key_state = ESTABLISH;
  reset_vs_data(str);
  (*grp->enc->chg_key_fcn)(grp->enc->key, grp->enc->key_len, grp->enc->info);    
  
  DEBUG_leave(f_dbg, "first_user", 0);
}


/* handle_leave_or_partition -------------------------------------------------------------------
   This function handles a leave or a partition (self_cascade + broadcast)
   It returs nothing and it exists if either str call or FL_unicast fails.

   Note: all the members can call self_cascade, only the sponsor will return a token.
--------------------------------------------------------------------------------------------- */
static void handle_leave_or_partition(SSP_Con *con, SSP_Grp *grp, stdarr *leave_set) {
  int         err;
  STR_Alg     *str = (STR_Alg *)grp->ka->info;	
  char        **leave_set_ptr;
  STR_TOKEN   *tk_out = 0;
  stdarr_it   ait;
  int         msg_len;
  char*       msg_buf=0;

  DEBUG_enter(f_dbg, "handle_leave_or_partition");

  leave_set_ptr = (char**)stdarr_it_val(stdarr_begin(leave_set, &ait));

  if((err = str_cascade(&str->ctx, grp->name, leave_set_ptr, NULL, &tk_out)) < 0) {
    ssp_err_quit("handle_leave_or_partition: str_cascade failed %d\n", err);
  }

  if(tk_out) {
    msg_len = tk_2_msg(&msg_buf, tk_out, STR_NEW_TREE, str->curr_memb_msg->serv_type);
    if ((err = FL_multicast(con->mbox, STR_NEW_TREE_TYPE, grp->name, STR_NEW_TREE, 
			    msg_len, msg_buf)) < 0) {
      SSP_disconnect(con->mbox);
      goto end;
    }
  }
  str->state = STR_WAIT_FOR_NEW_TREE;  
 
 end:
  if(msg_buf) {
    free(msg_buf);
  }
  str_destroy_token(&tk_out);
  
  DEBUG_leave(f_dbg, "handle_leave_or_partition", 0);
}


/* handle_merge -------------------------------------------------------------------------------
   This function starts a merge algorithm. Join is handled as a particular case of merge.
   
   It returns nothing, it fails if either str or flush calls failed.
--------------------------------------------------------------------------------------------- */
static void handle_merge(SSP_Con *con, SSP_Grp *grp, stdarr *merge_set, int is_self_join) {
  int         err;
  STR_Alg    *str = (STR_Alg *)grp->ka->info;  
  STR_TOKEN  *tk_out = 0;
  int         msg_len;
  char        *msg_buf = 0;

  DEBUG_enter(f_dbg, "handle_merge");
  
  if(is_self_join) {
    if((err = str_new_member(&str->ctx, con->priv_name, grp->name)) < 0) {
      ssp_err_quit("first_user: str_new_member failed  %d\n", err);
    }
    ON_DEBUG(printf("Self_join, ctx created\n");)
  }

  if((err = str_merge_req(str->ctx, con->priv_name, grp->name, &tk_out)) < 0) {
    ssp_err_quit("handle_merge: str_merge_request failed %d\n", err);
  }

  if(tk_out) {
    msg_len = tk_2_msg(&msg_buf, tk_out, STR_OLD_TREE, str->curr_memb_msg->serv_type);
    if ((err = FL_multicast(con->mbox, STR_OLD_TREE_TYPE, grp->name, STR_OLD_TREE, 
			    msg_len, msg_buf)) < 0) {
      SSP_disconnect(con->mbox);
      goto end;
    }
    ON_DEBUG( printf("STR_OLD_TREE (%d bytes) multicasted\n", err);)
  }
  str->state = STR_WAIT_FOR_OLD_TREE;
  str->num_old_tree_msgs = 0;

 end:
  if(msg_buf) {
    free(msg_buf);
  }
  str_destroy_token(&tk_out);
  
  DEBUG_leave(f_dbg, "handle_merge", 0);
}

/* handle_data_msg ----------------------------------------------------------------------------- 
   This function specifies the actions taken by the state machine if the message received was
   a data message (message received from the flush layer).
-----------------------------------------------------------------------------------------------*/
static int handle_data_msg(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, STR_Alg *str) {
  int ret = DONT_DELIV_MSG;
  
  DEBUG_enter(f_dbg, "handle_data_msg");

  switch(str->state) {
  case STR_SECURE:
    ssp_err_quit("handle_data_msg: this message should not be here\n");
    break;

  case STR_WAIT_FOR_OLD_TREE:
  case STR_WAIT_FOR_SELF_JOIN:
    ssp_err_quit("handle_data_msg: no message should be received in this state");
    break;

  case STR_WAIT_FOR_NEW_TREE:
    stddll_push_back(&str->msg_deque, &msg);
    break;

  case STR_WAIT_FOR_MEMBERSHIP:
    ret = DELIV_MSG;
    break;
  }

  DEBUG_leave(f_dbg, "handle_data_msg", ret);
  return ret;
}


/* handle_trans ---------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a transitional message.
---------------------------------------------------------------------------------------------- */
static int handle_trans(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, STR_Alg *str) {
  int ret = DONT_DELIV_MSG;

  DEBUG_enter(f_dbg, "handle_trans");

  switch(str->state) {
  case STR_SECURE:
    if(str->ts_delivered_to_app == SSP_FALSE) {
      str->ts_delivered_to_app = SSP_TRUE;
      ret = DELIV_MSG;
    }
    break;

  case STR_WAIT_FOR_OLD_TREE:
  case STR_WAIT_FOR_NEW_TREE:
  case STR_WAIT_FOR_MEMBERSHIP:
    if(str->ts_delivered_to_app == SSP_FALSE) {
      str->ts_delivered_to_app = SSP_TRUE;
      ret = DELIV_MSG;
    }
    if(str->num_vs_membs > 0) {
      str->vs_ts_received = SSP_TRUE;
    }
   break;
  
  case STR_WAIT_FOR_SELF_JOIN:
    ssp_err_quit("handle_trans: trans received in wrong state, %d!\n", str->state);
    break;
  }
  
  DEBUG_leave(f_dbg, "handle_trans", ret);
  return ret;
}

/* handle_memb ----------------------------------------------------------------------------------
  This function specifies the actions taken by the state machine if the message received was
  a group membership.

  Some comments:
      a member in the WAIT_FOR_SELF_JOIN can receive 2 events: a membership due to its own join
      (a join event) or a membership due to a network event (in this case the joinee is on the
      list of new added members. Flush delivers this special network in some cases:
      -  a partiton happen after the join and before the new membership is delivered
      -  the join happened while a previous partition was processed, so the two events are
         combined in one
      -  somebody left immediately after my join. Since flush membership deliveries are based
         on gathering flush_oks from old members, if the guy that left did not send his 
         flush_ok, the two events will be combined. Note that if he managed to send his
         flush_ok, then the join will be delivered first, then the leave.
---------------------------------------------------------------------------------------------- */
static int handle_memb(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, STR_Alg *str) {
  int    ret = DONT_DELIV_MSG;
  int    was_leave = 0;
  stdarr join_set;
  stdarr leave_set;

  DEBUG_enter(f_dbg, "handle_memb");
  
  stdarr_construct(&leave_set, sizeof(char*));
  stdarr_construct(&join_set, sizeof(char*));

  switch(str->state) {
  case STR_SECURE:
  case STR_WAIT_FOR_NEW_TREE:
  case STR_WAIT_FOR_OLD_TREE:
    ssp_err_quit("handle_memb: memb received in wrong state, %d!\n", str->state);
    break;

  case STR_WAIT_FOR_SELF_JOIN:
    grp->ka->key_state = NOT_ESTABLISH;
    str->num_vs_membs++;    

    init_vs_set(grp); 
    was_leave = upd_vs_set_and_get_join_leave_set(grp, msg->serv_type, &join_set, &leave_set);

    if(str->curr_memb_msg != NULL) { /* free prev. memb that we were trying to install  */
      SSP_Msg_free(&(str->curr_memb_msg));
    }
    str->curr_memb_msg = msg;  /* delay delivery of memb  */
    str->curr_grp_op = STR_ADD;

    if(stdhash_size(&grp->curr_membs_hash) > 1) {
      if(Is_reg_memb_mess(msg->serv_type)) {
	if(Is_caused_join_mess(msg->serv_type)) {
	  handle_merge(con, grp, &join_set, 1); /* self_join */
	}	      
	else if(Is_caused_leave_mess(msg->serv_type) || Is_caused_disconnect_mess(msg->serv_type)) {
	  ssp_err_quit("handle_memb: leave or disconnect in the wrong state %d\n", str->state);
	  ;
	}
	else if(Is_caused_network_mess(msg->serv_type)) {
	  ssp_err_quit("handle_memb: network in self join, not supported yet %d\n", str->state);
	}
      }
    }
    else {
      first_user(con, grp);
    }
    break;
    
  case STR_WAIT_FOR_MEMBERSHIP:
    grp->ka->key_state = NOT_ESTABLISH;
    str->num_vs_membs++;       

    if(str->num_vs_membs == 1) { /* first vs memb from a possible cascaded vs membs */
      init_vs_set(grp); 
    }
    was_leave = upd_vs_set_and_get_join_leave_set(grp, msg->serv_type, &join_set, &leave_set);
   
    if(was_leave  && (str->ts_delivered_to_app == SSP_FALSE)) { 
      str->ts_delivered_to_app = SSP_TRUE;
      gen_and_push_msg(con, grp, TRANSITION_MESS);
    } 

    if((str->num_vs_membs > 1) && str->curr_memb_msg != NULL) { /* free prev. memb that we were trying to install  */
      SSP_Msg_free(&(str->curr_memb_msg));
    }
    str->curr_memb_msg = msg; /* delay delivery of memb  */
    

    if(stdhash_size(&grp->curr_membs_hash) > 1) {
      if(stdarr_size(&leave_set) > 1) { /* count the NULL too */
	if(stdarr_size(&join_set) <= 1) {  /* only partition or leave, count the NULL too  */
	  str->curr_grp_op = STR_SUBTRACT;
	  handle_leave_or_partition(con, grp, &leave_set);
	}
	else {
	  str->curr_grp_op = STR_BOTH;
	  ssp_err_quit("handle_memb: combined leave and merge not handle yet\n");
	}
      }
      else { /*  merge &  join */
	str->curr_grp_op = STR_ADD;
	handle_merge(con, grp, &join_set, 0); /* join or merge but nor self_join */
      }
    }  
    else { /* alone  */
      first_user(con, grp);
    }
    break;
  }

  stdarr_destruct(&leave_set);  
  stdarr_destruct(&join_set);      

  DEBUG_leave(f_dbg, "handle_memb", ret);
  return ret;
}


/* handle_old_tree -------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   an old tree message.
---------------------------------------------------------------------------------------------- */
static int handle_old_tree(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, STR_Alg *str) {
  int         ret = DONT_DELIV_AND_FREE_MSG;
  STR_TOKEN   *tk_out = 0;
  STR_TOKEN   *tk_in;  
  int         err;
  int         msg_len;
  char        *msg_buf = 0;
  service     serv;

  DEBUG_enter(f_dbg, "handle_old_tree");
  
  switch(str->state) {
  case STR_WAIT_FOR_OLD_TREE:
    if((tk_in = (STR_TOKEN*)malloc(sizeof(STR_TOKEN))) == NULL) {
      ssp_err_quit("handle_old_tree: malloc failed \n");
    }

    msg_2_tk(msg, tk_in, &serv);
    str->num_old_tree_msgs++;
    if(str->num_old_tree_msgs == 2) { /* got both */
      if(str->vs_ts_received == SSP_TRUE) { /* everybody abandons, wait for Fl_req to move to MEMB. */
	str_destroy_token(&str->tk);
	str->num_old_tree_msgs = 0;
	str_destroy_token(&tk_in);
      }
      else { /* can apply both messages */
	if((err = str_cascade(&str->ctx, grp->name, NULL, str->tk, &tk_out)) < 0) {
	  ssp_err_quit("handle_old_tree: str_cascade failed 1\n");
	}
	ON_DEBUG (printf("str_cascade returned:  %d   %p\n", err, tk_out);)
	  
	if(tk_out) {
	  msg_len = tk_2_msg(&msg_buf, tk_out, STR_NEW_TREE, str->curr_memb_msg->serv_type);
	  if ((err = FL_multicast(con->mbox, STR_NEW_TREE_TYPE, grp->name, STR_NEW_TREE, 
				  msg_len, msg_buf)) < 0) {
	    SSP_disconnect(con->mbox);
	    
	    str_destroy_token(&str->tk);
	    str_destroy_token(&tk_in);
	    str_destroy_token(&tk_out);
	    if(msg_buf) {
	      free(msg_buf);
	    }
	    
	    goto end;
	  }
	  
	  if(msg_buf) {
	    free(msg_buf);
	    msg_buf = 0;
	  }
	  str_destroy_token(&tk_out);
	  ON_DEBUG(printf("STR_NEW_TREE (%d bytes) multicasted\n", err);)
        }
	
	if((err = str_cascade(&str->ctx, grp->name, NULL, tk_in, &tk_out)) < 0) {
	  ssp_err_quit("handle_old_tree: self_cascade failed 2\n");
	}
	ON_DEBUG (printf("self_cascade returned:  %d   %p\n", err, tk_out);)
	  
        if(tk_out) {
	  msg_len = tk_2_msg(&msg_buf, tk_out, STR_NEW_TREE, str->curr_memb_msg->serv_type);
	  if ((err = FL_multicast(con->mbox, STR_NEW_TREE_TYPE, grp->name, STR_NEW_TREE, 
				  msg_len, msg_buf)) < 0) {
	    SSP_disconnect(con->mbox);
	    
	    str_destroy_token(&str->tk);
	    str_destroy_token(&tk_in);
	    str_destroy_token(&tk_out);
	    if(msg_buf) {
	      free(msg_buf);
	    }
	    goto end;
	  }
	  
	  if(msg_buf) {
	    free(msg_buf);
	    msg_buf = 0;
	  }
	  str_destroy_token(&tk_out);
          ON_DEBUG(printf("STR_NEW_TREE (%d bytes) multicasted\n", err);)
        }
	str_destroy_token(&str->tk);
	str_destroy_token(&tk_in);
	
	str->state = STR_WAIT_FOR_NEW_TREE;
      }
    }
    else if(str->num_old_tree_msgs == 1){ /* save the token, wait for the other one  */
      str->tk = tk_in;
    }
    else {
      ssp_err_quit("handle_old_tree: protocol in wrong state\n");
    }
   break;
 
  case STR_SECURE:
  case STR_WAIT_FOR_NEW_TREE:
    ON_DEBUG(printf("handle_old_tree:  DROPPING MESSAGE ========== \n ");)
    break;

  case STR_WAIT_FOR_SELF_JOIN:
    ssp_err_quit("handle_old_tree: old tree msg in wrong state\n");
    break;

  case STR_WAIT_FOR_MEMBERSHIP:
    if(str->curr_grp_op == STR_ADD) { /* current event was additive so I might get two old tree msgs here */
      tk_in = (STR_TOKEN*)malloc(sizeof(STR_TOKEN));
      if(!tk_in) {
	ssp_err_quit("handle_old_tree: malloc failed \n");
      }
      
      msg_2_tk(msg, tk_in, &serv);
      str->num_old_tree_msgs++;
      if(str->num_old_tree_msgs == 2) { /* got both */
	if(str->vs_ts_received == SSP_TRUE) { /* everybody abandons, wait for Fl_req to move to MEMB. */
	  str_destroy_token(&str->tk);
	  str->num_old_tree_msgs = 0;
	  str_destroy_token(&tk_in);
	}
	else { /* can apply both messages, but drop the tokens */
	  if((err = str_cascade(&str->ctx, grp->name, NULL, str->tk, &tk_out)) < 0) {
	    ssp_err_quit("handle_old_tree: self_cascade failed 1\n");
	  }
	  if(tk_out) {
	    str_destroy_token(&tk_out);
	  }	  
	  ON_DEBUG (printf("str_cascade returned:  %d\n", err);)
	    	
	  if((err = str_cascade(&str->ctx, grp->name, NULL, tk_in, &tk_out)) < 0) {
	    ssp_err_quit("handle_old_tree: str_cascade failed 2\n");
	  }
	  if(tk_out) {
	    str_destroy_token(&tk_out);
	  }
	  ON_DEBUG (printf("str_cascade returned:  %d\n", err);)
	}
	str_destroy_token(&str->tk);
	str_destroy_token(&tk_in);
      }
      else if(str->num_old_tree_msgs == 1){ /* save the token, wait for the other one  */
	str->tk = tk_in;
      }
      else {
	ssp_err_quit("handle_old_tree: protocol in wrong state\n");
      }  
    }
    else {
      ON_DEBUG( printf("Dropping old tree msg in WAIT_FOR_MEMBERSHIP\n") );
    }    
    break;
  }

 end:
  DEBUG_leave(f_dbg, "handle_old_tree", ret);
  return ret;
}


/* handle_new_tree --------------------------------------------------------------------------
  This function specifies the actions taken by the state machine if the message received was
  a new tree message.

  All the members call self_cascade either in the second step of join/merge/leave when one
  self_cascade call should be enough, or in the partition case when more than one round of
  self cascade and NEW_TREE messages might be needed. 

  NOTE: in case of a cascading due to a join, the joiner starts in WAIT_FOR_SELF_JOIN 
        and it never knows it it was a cascading or not so he deliveres JOIN while 
        all the other members of the group will deliver NETWORK. That's why each
        members that passes along the partial token attaches also its group event,
        and if it was join is upgraded to network. With the final token broadcast
        everybody agreed to deliver that group event type.
---------------------------------------------------------------------------------------------- */
static int handle_new_tree(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg, STR_Alg *str) {
  int         ret = DONT_DELIV_AND_FREE_MSG, err;
  STR_TOKEN   *tk_out = 0;
  STR_TOKEN   tk_in = {0}; 
  int         msg_len;
  char        *msg_buf=0;
  service     serv;

  DEBUG_enter(f_dbg, "handle_new_tree");

  switch(str->state) {
  case STR_WAIT_FOR_NEW_TREE:
    msg_2_tk(msg, &tk_in, &serv);
 
    if(str->vs_ts_received == SSP_TRUE) {
      ; /* everybody abandons, wait to get the Fl_req and then move to MEMB. */
    }
    else {
      /* update the service type for the current membership handled */
      if(Is_caused_network_mess(serv) && Is_caused_join_mess(str->curr_memb_msg->serv_type)) {
	str->curr_memb_msg->serv_type = serv;
      }

      if((err = str_cascade(&str->ctx, grp->name, NULL, &tk_in, &tk_out)) < 0) {
	ssp_err_quit("handle_new_tree: str_cascade failed %d\n", err);
      }
      ON_DEBUG(printf("str cascade returned %d \n", err);)
  
      if(err == OK) {
	if(tk_out) {	
	  msg_len = tk_2_msg(&msg_buf, tk_out, STR_NEW_TREE, str->curr_memb_msg->serv_type);
	  if ((ret = FL_multicast(con->mbox, STR_NEW_TREE_TYPE, grp->name, STR_NEW_TREE, 
				  msg_len, msg_buf)) 
	      == CONNECTION_CLOSED || ret == ILLEGAL_SESSION) {
	    SSP_disconnect(con->mbox);
	    goto end;
	  }
	}
	else { /* I'm done */
	  copy_key(grp);      
	  grp->ka->key_state = ESTABLISH;      
	  (*grp->enc->chg_key_fcn)(grp->enc->key, grp->enc->key_len, grp->enc->info);
	  
	  if(str->num_vs_membs > 1) { /* collapsed memb, deliv. NETWORK  */
	    str->curr_memb_msg->serv_type = REG_MEMB_MESS | CAUSED_BY_NETWORK;
	  }
	  
	  if(Is_caused_network_mess(str->curr_memb_msg->serv_type)) { /* update vs. */
	    set_vs_set_memb_msg(str->curr_memb_msg, grp); 
	  }
	  
	  /* first put the new secure memb in the connection queue */
	  stddll_push_back(&con->deliv_deque, &str->curr_memb_msg);
	  move_msg_con_deque(con, grp);
	  
	  str->state = STR_SECURE;
	  reset_vs_data(str);
	  
	  if(tk_in.t_data) {
	    free(tk_in.t_data);
	    tk_in.t_data = NULL;
	  } 
	}
      }
      else {
	ON_DEBUG(printf("not OK yet\n");)
      }
    }
    
    if(ret > 0) {
      ret = DONT_DELIV_AND_FREE_MSG;
    }   
    break;
    
  case STR_SECURE:
    ON_DEBUG (printf("handle_new_tree, dropping tree ========= x\n");)
    break;

  case STR_WAIT_FOR_OLD_TREE:
  case STR_WAIT_FOR_SELF_JOIN:
    ssp_err_quit("handle_new_tree: new tree in wrong state!\n");
    break;

  case STR_WAIT_FOR_MEMBERSHIP:
    ON_DEBUG( printf("Dropping new tree msg in WAIT_FOR_MEMBERSHIP\n") );
    break;
}  

 end:  
 if(msg_buf) {
    free(msg_buf);
  }
  
  if(tk_in.t_data) {
    free(tk_in.t_data);
    tk_in.t_data = NULL;
  } 
  str_destroy_token(&tk_out);

  DEBUG_leave(f_dbg, "handle_new_tree", ret);
  return ret;
}

/* handle_fl_req -------------------------------------------------------------------------------
   This function specifies the actions taken by the state machine if the message received was
   a flush request message.
   
   If a flush_req was answered and then the alg moves to STR_WAIT_FOR_MEMBERSHIP in any of the
   STR_WAIT_FOR_OLD_TREE or STR_WAIT_FOR_NEW_TREE states, then it means that a cascaded
   membership happen, and when the protocol finishes, a NETWORK will be delivered to the 
   application.
---------------------------------------------------------------------------------------------- */
static int handle_fl_req(SSP_Con *con, SSP_Grp *grp, SSP_Msg *mess, STR_Alg *str) {
  int ret = DONT_DELIV_AND_FREE_MSG;

  DEBUG_enter(f_dbg, "handle_fl_req");

  switch(str->state) {
  case STR_SECURE:
    str->wait_for_sec_fl_ok = SSP_TRUE;
    ret = DELIV_MSG; 
    break;

  case STR_WAIT_FOR_NEW_TREE:
  case STR_WAIT_FOR_OLD_TREE:
    if ((ret = FL_flush(con->mbox, grp->name)) == CONNECTION_CLOSED || ret == ILLEGAL_SESSION) {
      SSP_disconnect(con->mbox);
      goto end;
    }
    str->state = STR_WAIT_FOR_MEMBERSHIP;
    ret = DONT_DELIV_AND_FREE_MSG;
    break;

  case STR_WAIT_FOR_SELF_JOIN:
  case STR_WAIT_FOR_MEMBERSHIP:
    ssp_err_quit("handle_fl_req: fl_req received in wrong state, not possible !");
    break;
  }

 end: 
  DEBUG_leave(f_dbg, "handle_fl_req", ret);
  return ret;
}


/* ============================  wrapper functions for str  =================================== */

/* STR_handles_mess ------------------------------------------------------------------------------
   This function specifies if a spread message is used or not by the key agreement algorithm.
   All the messages specified here will be redirected by spread to STR_Comp_Key_Wrapper;
   In this case, all the membership messages (including transitional messages) are sended,
   Also the regular messages used internal by the key agreement algorithm (TREE... messages)
   and regular messages received between having a stable key, are sent here.
-----------------------------------------------------------------------------------------------*/
int STR_handles_msg(SSP_Msg *msg, SSP_Grp *grp) {
  service serv_type = msg->serv_type;
  int     msg_type  = msg->msg_type;
  
  return  !Is_regular_mess(serv_type) || grp->ka->key_state == NOT_ESTABLISH ||
    msg_type == STR_OLD_TREE || msg_type == STR_NEW_TREE;
}


/* STR_handle_recv ----------------------------------------------------------------------------
   This function is implementing the state machine for the key agreement algorithm. 
   It returns 1 if the message must be delivered by the SSP, 0 otherwise. The SSP can check if 
   the key agreement finished by checking the  Key_State variable.
-----------------------------------------------------------------------------------------------*/
int STR_handle_recv(SSP_Con *con, SSP_Grp *grp, SSP_Msg *msg) {
  int  ret = DELIV_MSG;
  STR_Alg *str = (STR_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "STR_handle_recv");
  
  if(Is_regular_mess(msg->serv_type)) {
    if(Is_str_old_tree_msg(msg->msg_type)) {
      ret = handle_old_tree(con, grp, msg, str);
    }
    else if(Is_str_new_tree_msg(msg->msg_type)) {
      ret = handle_new_tree(con, grp, msg, str);
    }
    else {
      ret = handle_data_msg(con, grp, msg, str);
    }
  }
  else if(Is_flush_req_mess(msg->serv_type)) {
    ret = handle_fl_req(con, grp, msg, str);
  }
  else if(Is_membership_mess(msg->serv_type)) {
    if(Is_self_leave_mess(msg->serv_type)) {
      ;
    }
    else if(Is_transition_mess(msg->serv_type)) {
      ret = handle_trans(con, grp, msg, str);
    }
    else {
      ret = handle_memb(con, grp, msg, str);
    }
  }

  DEBUG_leave(f_dbg, "STR_handle_recv", ret);
  return ret;  
}

/* STR_handle_fl_ok ----------------------------------------------------------------------------
   This function specifies the action taken by the key agreement state machine if a flush
   ok event happen. This is actually Secure_Flush_Ok, sent by the user using SSP_Flush, 
   which does not sent the flush okinvoking directlly FL_flush, but calls this function to 
   handle it.
-----------------------------------------------------------------------------------------------*/
int STR_handle_fl_ok(SSP_Con *con, SSP_Grp *grp){
  int  ret = DELIV_MSG;
  STR_Alg *str = (STR_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "STR_handle_fl_ok");
  
  switch(str->state) {
  case STR_SECURE:
    if(str->wait_for_sec_fl_ok == SSP_TRUE) {
      str->wait_for_sec_fl_ok = SSP_FALSE;      
      if ((ret = FL_flush(con->mbox, grp->name)) == CONNECTION_CLOSED || ret == ILLEGAL_SESSION) {
	SSP_disconnect(con->mbox);
	goto end;
      }
      str->state = STR_WAIT_FOR_MEMBERSHIP;
    }
    else {
      ret = FLUSH_OK_ALREADY_SENT;
    }
    break;
  
  case STR_WAIT_FOR_NEW_TREE:
  case STR_WAIT_FOR_OLD_TREE:  
  case STR_WAIT_FOR_SELF_JOIN:
  case STR_WAIT_FOR_MEMBERSHIP:
    ret = FLUSH_OK_ALREADY_SENT;
    break;    
  }
  
 end:
  DEBUG_leave(f_dbg, "STR_handle_fl_ok", ret);
  return ret;
  
}

/* STR_handle_send ----------------------------------------------------------------------------
   This function specifies the actions taken by the key agreement state machine, if the event
   that happen is a 'user' message. The event is caused by a user calling SSP_scat_multicast
   or SSP_multicast. Right now this function is not handleing the sending, it just allows the
   sending of the message or not. As a general idea, the user is not allowed to send messages
   while the key agreement is performing.
--------------------------------------------------------------------------------------------- */
int STR_handle_send(SSP_Con *con, SSP_Grp *grp) {
  int  ret = DELIV_MSG;
  STR_Alg *str = (STR_Alg*)grp->ka->info;
  
  DEBUG_enter(f_dbg, "STR_handle_send");

  switch(str->state) {
  case STR_SECURE:
    ret = SEND_MSG;
    break;

  case STR_WAIT_FOR_NEW_TREE:
  case STR_WAIT_FOR_OLD_TREE:
  case STR_WAIT_FOR_SELF_JOIN:
  case STR_WAIT_FOR_MEMBERSHIP:
    ret = DONT_SEND_MSG;
    break;
  }

  DEBUG_leave(f_dbg, "STR_handle_send", ret);
  return ret;
}




