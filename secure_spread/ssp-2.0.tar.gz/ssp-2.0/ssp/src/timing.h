/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */

/***********************************************************************************************/
/* timing.h                                                                                    */
/*                                                                                             */
/* John Schultz                                                                                */
/* Created: June 23, 1999                                                                      */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#ifndef _TIMING_H_ 
#define _TIMING_H_

#include <sp.h>

#define MAX_MEMBERSHIPS     1000
#define NUM_TIMING_SLOTS    20

#define REQ_TIME            0
#define FL_MEMB_TIME        1
#define SSP_MEMB_TIME       2
#define CLQ_UPD_CTX_BEF     3
#define CLQ_UPD_CTX_AFT     4
#define CLQ_LEAVE_BEF       5
#define CLQ_LEAVE_AFT       6
#define CLQ_UPD_KEY_BEF     7
#define CLQ_UPD_KEY_AFT     8
#define CLQ_FACT_OUT_BEF    9
#define CLQ_FACT_OUT_AFT    10
#define CLQ_MERGE_BEF       11
#define CLQ_MERGE_AFT       12
#define send_bef            13
#define send_aft            14
#define bef                 15
#define aft                 16
#define total_comp_r        17
#define total_comp          18

extern double times[MAX_MEMBERSHIPS][NUM_TIMING_SLOTS];
extern double rtimes[MAX_MEMBERSHIPS][NUM_TIMING_SLOTS];
extern service stype[MAX_MEMBERSHIPS];

extern int time_index;

void   print_time_info(int index);
double get_time_rusage(void);
double get_time_timeofday(void);

void mark_time(double *, double *);

#endif
