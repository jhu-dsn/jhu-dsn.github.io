/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 * This code is based on R. Stevens code from "Network programming"    
 */

/***********************************************************************************************/
/* ssp_error.h                                                                                 */
/* Error printing messages                                                                     */
/*                                                                                             */
/*                                                                                             */
/* Created: Aug 15, 2001                                                                       */
/* This code is based on R. Stevens code from "Network programming"                            */
/***********************************************************************************************/

#ifndef _SSP_ERROR_H_
#define _SSP_ERROR_H_

#ifdef __cplusplus
extern "C" {
#endif    

  void ssp_err_ret(const char *fmt, ...); /* Print nonfatal error related to a system call 
					     and return */
  void ssp_err_sys(const char *fmt, ...); /* Print fatal error related to a system call 
					     and terminate. */
  void ssp_err_dump(const char *fmt, ...);/* Print fatal error related to a system call, 
					     dump core and terminate. */
  void ssp_err_msg(const char *fmt, ...); /* Print nonfatal error unrelated to a system call 
					     and return. */
  void ssp_err_quit(const char *fmt, ...);/* Print fatal error unrelated to a system call 
					     and quit.*/

#ifdef __cplusplus
}
#endif

#endif /* _SSP_ERROR_H_ */


