/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */

/* ******************************************************************************************* */
/* init_encrypt.c                                                                              */
/* These functions create snd destroy  SSP_Encrypt, with the data particular to                */
/* an encrypting algorithm. It supports only BLOWFISH for now.                                 */
/*                                                                                             */
/* Cristina Nita-Rotaru and John Schultz                                                       */
/* Created: June 28, 1999                                                                      */
/* Modified: Jun 23 2000 by Cristina Nita-Rotaru                                               */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/* ******************************************************************************************* */

#include <stdlib.h>

#include "init_encrypt.h"
#include "utility.h" 
#include "encrypt.h"
#include "ssp_error.h"

#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif

/* SSP_Enc_create ------------------------------------------------------------------------------
   It returns a pointer to the SSP_Enc if the encryption algorithm is support, NULL otherwise.
-----------------------------------------------------------------------------------------------*/
SSP_Enc* SSP_Enc_create(unsigned int key_len, int alg) {
  unsigned char *key = NULL;
  SSP_Enc *enc = (SSP_Enc*) malloc(sizeof(SSP_Enc)); 
  
  if (!enc) {
    ssp_err_quit("SSP_Enc_create: malloc failed 1\n");   
  }

  if(alg == SSP_BLOWFISH_ALG) {
    BF_Alg *bf = BF_Alg_create();
    
    if (key_len < 8) {
      ssp_err_quit("SSP_Enc_create: key too small\n");
    }
    key = (unsigned char*) malloc(sizeof(unsigned char) * key_len);
    if (!key) {
      ssp_err_quit("SSP_Enc_create: malloc failed 2\n");
    }
    
    SSP_Enc_set(enc, SSP_BLOWFISH_ALG, key, key_len, SSP_BLOWFISH_BLOCK_SIZE, bf, BF_init, 
		BF_key_chg, BF_enc, BF_dec);	
  }  
  return enc;
}

/* SSP_Enc_destroy -----------------------------------------------------------------------------
   It frees any memory allocated for a SSP_Enc data structure.
-----------------------------------------------------------------------------------------------*/
void SSP_Enc_destroy(SSP_Enc *enc) {
  my_free((char**)&(enc->key));
  
  if(enc->name == SSP_BLOWFISH_ALG) {
    BF_Alg *bf = (BF_Alg*)(enc->info);
    BF_Alg_free(&bf);
    enc->info = NULL;
  }
}



