/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */

/***********************************************************************************************/
/* scatter.h                                                                                   */
/*                                                                                             */
/* John Schultz                                                                                */
/* Created: June 23, 1999                                                                      */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#ifndef _INC_SCATTER_H_
#define _INC_SCATTER_H_

#include "sp.h"

int Is_legal_scat_pos(const scatter *scat, unsigned int e_index, 
		      unsigned int buff_index);
int Is_end_of_scat(const scatter *scat, unsigned int e_index, unsigned int buff_index);

void scat_init(scatter *scat);
int  scat_destroy(scatter *scat);
int  scat_cap(scatter *scat);

int  scat_skip(const scatter *scat, unsigned int *elem_index, unsigned int *buf_index, 
	       unsigned int fixed_elem_size, unsigned int skip_bytes);

int  scat_copy (scatter *dst, const scatter *src, unsigned int num_bytes);
int  scat_copy2(char *dst,    const scatter *src, unsigned int num_bytes);
int  scat_copy3(scatter *dst, char *src,          unsigned int num_bytes);

int  scat_get(scatter *dst, int dst_elem_index, unsigned int dst_fixed_elem_size, 
	      unsigned int dst_index, const scatter *src, int src_elem_index, 
	      unsigned int src_fixed_elem_size, unsigned int src_index, unsigned int num_bytes);
int  scat_get2(char *dst, const scatter *src, int src_elem_index, 
	       unsigned int src_fixed_elem_size, unsigned int src_index, unsigned int num_bytes); 
int  scat_get3(scatter *dst, int dst_elem_index, unsigned int dst_fixed_elem_size, 
	       unsigned int dst_index, char *src, unsigned int num_bytes);
int scat_get10(scatter *dst, int *dst_elem_index, unsigned int dst_fixed_elem_size, 
	       unsigned int *dst_index, const scatter *src, int *src_elem_index, 
	       unsigned int src_fixed_elem_size, unsigned int *src_index, unsigned int num_bytes);
int scat_get11(char *dst, const scatter *src, int *src_elem_index, 
	       unsigned int src_fixed_elem_size, unsigned int *src_index, unsigned int num_bytes);
int scat_get12(scatter *dst, int *dst_elem_index, unsigned int dst_fixed_elem_size, 
	       unsigned int *dst_index, char *src, unsigned int num_bytes);

int  scat_alloc(scatter *scat, unsigned int mess_len);
int  scat_set(scatter *dst, const scatter *src, int fixed_elem_size, unsigned int mess_len);

int  scat_dup(scatter *dst, scatter *src);
int  scat_dup2(scatter *dst, scatter *src, unsigned int size);

#endif /*  _INC_SCATTER_H_ */











