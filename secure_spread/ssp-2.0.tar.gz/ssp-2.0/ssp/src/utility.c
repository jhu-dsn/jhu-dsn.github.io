/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */

/***********************************************************************************************/
/* utility.c                                                                                   */
/*                                                                                             */
/* John Schultz                                                                                */
/* Created: June 23, 1999                                                                      */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#include <stdlib.h>
#include <string.h>

#include "utility.h"

#ifdef USE_DMALLOC
#include <dmalloc.h>
#endif



/* The my_strdup fcn returns a pointer to a new string which is a duplicate of string src. Memory
   for the new string is obtained with malloc, and can be freed with free.  If src is 0, 0 is returned */

char *my_strdup(const char *src){ 
  char *toRet;
  
  if (!src || !(toRet = (char*) malloc((strlen(src) + 1)* sizeof(char))))
    return 0;

  return strcpy(toRet, src); 
}

int strptrcmp(const void *arg1, const void *arg2) { 
return strcmp(*(char**) arg1, *(char**) arg2); 
}

void* c_my_malloc(size_t size){
    void* toRet = 0;
    int i = 0;

    while(i < 100 && !toRet) {
	toRet = malloc(size);
	i++; 
    }

    return toRet;
}

void *c_my_realloc(void *ptr, size_t size) {   
    void* toRet = 0;
    int i = 0;

    while(i < 100 && !toRet) {
	toRet = realloc(ptr, size);
	i++;
    }
    
    return toRet;
}

int need_to_realloc_rarely(size_t size, size_t cap) {
  int toRet = -1;

  if (size > cap || size <= cap >> 2){
    toRet = !!size;

    while (toRet < size)
      toRet <<= 1;

    if (toRet - size < toRet >> 2)
      toRet <<= 1;
  }

  return toRet;
}

void *realloc_rarely(void *ptr, size_t size, size_t *cap){
  int new_cap;

  if ((new_cap = need_to_realloc_rarely(size, *cap)) >= 0) {
    if (!(ptr = realloc(ptr, new_cap)))
      return 0;

    *cap = new_cap;
  }
  return ptr;
}

void my_free(char **c) {
  if(*c) {
    free(*c);
    *c = NULL;
  }
}











