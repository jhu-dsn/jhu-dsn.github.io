/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */

/***********************************************************************************************/
/* ssp_dbg.c                                                                                   */
/* debug functions                                                                             */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: Nov 4, 2000                                                                        */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#include <stdlib.h>
#include <stdio.h>

#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/time.h>
#include <string.h>

#ifdef USE_DMALLOC
#include <dmalloc.h>
#endif

void DEBUG_enter(FILE *f, char *fcn_name) {
#ifdef DEBUG_MSG
  if(f) {
    fprintf(f, "%s: ENTER\n", fcn_name);
    fflush(f);
  }
#endif
}

void DEBUG_leave(FILE *f, char *fcn_name, int ret) {
#ifdef DEBUG_MSG
  if(f) {
    fprintf(f, "%s: LEAVE, returning %d\n", fcn_name, ret);
    fflush(f);
  }
#endif
}

void DEBUG_leave_ptr(FILE *f, char *fcn_name, void* ret) {
#ifdef DEBUG_MSG
  if(f) {
    fprintf(f, "%s: LEAVE, returning %p\n", fcn_name, ret);
    fflush(f);
  }
#endif
}

void DEBUG_msg(FILE *f, char *fcn_name, char *msg_dbg) {
#ifdef DEBUG_MSG
  if(f) {
    fprintf(f, "%s: %s\n", fcn_name, msg_dbg);
    fflush(f);
  }
#endif
}


void DEBUG_open(FILE** f, char *f_name) { 
#ifdef DEBUG_MSG
  if(f_name != NULL) {
    *f = fopen(f_name, "w");
  }
  else {
    *f = fdopen(2, "w");
  }
#endif
}

void DEBUG_close(FILE** f) {
#ifdef DEBUG_MSG
  if(*f) {
    fclose(*f);
    *f = NULL;
  }
#endif
}








