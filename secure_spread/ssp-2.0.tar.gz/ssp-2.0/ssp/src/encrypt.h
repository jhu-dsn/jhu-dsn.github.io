/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */

/* ******************************************************************************************* */
/* encrypt.h                                                                                   */
/* Encrypt info                                                                                */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: June 28, 1999                                                                      */
/* Modified: June 23, 2000 by Cristina Nita-Rotaru                                             */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/* ******************************************************************************************* */

  
#ifndef _ENCRYPT_H_
#define _ENCRYPT_H_

#include "blowfish.h"

/* ------------------------  BLOWFISH ALGORITHM --------------------------------------------- */

#define SSP_BLOWFISH_ALG 1
#define SSP_BLOWFISH_BLOCK_SIZE 8

typedef struct dummy_BF_Alg {
    UWORD_32bits *bf_P;        
    UWORD_32bits (*bf_S)[256]; 
} BF_Alg;

BF_Alg * BF_Alg_create();
void BF_Alg_free(BF_Alg **bf);

/* wrapper fcns that implement the "generic" encryption interface */
unsigned int BF_init(unsigned char* key, unsigned int key_len, void *void_info);
unsigned int BF_key_chg(unsigned char* key, unsigned int key_len, void *void_info);
unsigned int BF_enc(char *buf, unsigned int count, void *void_info, int endian);
unsigned int BF_dec(char *buf, unsigned int count, void *void_info, int endian);

/* ----------------------- END BLOWFISH ----------------------------------------------------- */

#endif /* ENCRYPT_H_ */






