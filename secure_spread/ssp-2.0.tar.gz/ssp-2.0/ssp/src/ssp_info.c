/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 2.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */

/***********************************************************************************************/
/* ssp_info.c                                                                                  */
/* Connection, group and message info                                                          */
/*                                                                                             */
/* Cristina Nita-Rotaru and John Schultz                                                       */
/* Created: June 23, 1999                                                                      */
/* Modified: June 23, 2000 by Cristina Nita-Rotaru                                             */ 
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>

#include "ssp_info.h"
#include "scatter.h"
#include "utility.h"
#include "init_encrypt.h"
#include "init_key_alg.h"
#include "ssp_dbg.h"
#include "ssp_error.h"

#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif

extern FILE *f_dbg;

/* ============================  message info functions  ===================================== */

/* SSP_Msg_init --------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------- */
void SSP_Msg_init(SSP_Msg *msg) { 
  msg->mbox         = 0;
  msg->serv_type    = 0;
  msg->sender       = 0;
  msg->max_num_grps = 0;
  msg->num_grps     = 0;
  msg->grps         = 0;
  msg->msg_type     = 0;
  msg->endian_mism  = 0;
  msg->msg_len      = 0;
  msg->scat         = 0; 
}

/* SSP_Msg_set -------------------------------------------------------------------------------
   This function does not allocate any memory, just sets the pointer for the char arrays
--------------------------------------------------------------------------------------------- */
static void SSP_Msg_set(SSP_Msg *msg, mailbox mbox, service serv, char *sender, 
			int max_grps, int num_grps, char grps[][MAX_GROUP_NAME], int16 msg_type, 
			int endian_mism, int msg_len, scatter *scat) {
  msg->mbox         = mbox;
  msg->serv_type    = serv;
  msg->sender       = sender;
  msg->max_num_grps = max_grps;
  msg->num_grps     = num_grps;
  msg->grps         = grps;
  msg->msg_type     = msg_type;
  msg->endian_mism  = endian_mism;
  msg->msg_len      = msg_len;
  msg->scat         = scat;
}

/* SSP_Msg_copy -------------------------------------------------------------------------------
   This function creates a message as following:
   senderorGroup: allocates memory then copies data
   grps : it makes a local copy.
   scatter: it allocates memory for it then copies the data
   data: it allocates memory then copies the data
---------------------------------------------------------------------------------------------- */
static void SSP_Msg_copy(SSP_Msg *msg, mailbox mbox, service serv, char *sender, 
			 int max_grps, int num_grps, char grps[][MAX_GROUP_NAME], 
			 int16 msg_type, int endian_mism, int msg_len, scatter *scat) {
  int grps_size = num_grps * MAX_GROUP_NAME, err;
  
  SSP_Msg_set(msg, mbox, serv, my_strdup(sender), max_grps, num_grps, 
	      (grps_size) ? (char(*)[MAX_GROUP_NAME]) malloc(grps_size) : 0, msg_type, 
	      endian_mism, msg_len, 0);
  
  memcpy(msg->grps, grps, grps_size);
  msg->scat = malloc(sizeof(scatter));
  
  err = scat_dup2(msg->scat, scat, msg_len);
  if (Is_reg_memb_mess(serv) && scat) {
    int elem_ind = -1;
    unsigned int buff_ind = 0;
    err = scat_get11((char*) &msg->gid, scat, &elem_ind, 0, &buff_ind, sizeof(group_id));
    if (err != sizeof(group_id)) {
      ssp_err_quit("SSP_Mess_copy: scat_get11 failed %d, 1\n", err);
    }
  }
}


/* SSP_Msg_destroy ----------------------------------------------------------------------------
   This function frees only what  SSP_Msg_copy allocated: senderOrGroup, groups,
   mess, delta.
--------------------------------------------------------------------------------------------- */
static void SSP_Msg_destroy(SSP_Msg *msg) {
  my_free(&msg->sender);

  if(msg->grps) {
    free(msg->grps);
    msg->grps = NULL;
  }

  if (msg->scat) {
    scat_destroy(msg->scat); 
    free(msg->scat);
    msg->scat = NULL;
  }
}

/* SSP_MSG_create -------------------------------------------------------------------------------
   This function is called to make a copy of a message.  All of the parameters that are passed 
   contain the data of the message to be stored.  It also reallocs the memory to src_mess if 
   requested.
-----------------------------------------------------------------------------------------------*/
SSP_Msg *SSP_Msg_create(mailbox mbox, service *serv_type, char sender[MAX_GROUP_NAME], 
			int max_grps, int *num_grps, char grps[][MAX_GROUP_NAME],int16 *msg_type,
			int *endian_mism, int msg_len, char src_grps[][MAX_GROUP_NAME], 
			scatter *src_msg, int fixed_elem_size, int realloc) {
  int err;
  SSP_Msg *msg = NULL;
  
  msg = (SSP_Msg*) malloc(sizeof(SSP_Msg));
  if (!msg) { 
    ssp_err_quit("SSP_Msg_create: malloc failed\n");
  }
  
  SSP_Msg_init(msg);  
  SSP_Msg_copy(msg, mbox, *serv_type, sender, max_grps, *num_grps, src_grps, *msg_type, 
	       *endian_mism, 0, 0);
  msg->msg_len = msg_len;
  err = scat_set(msg->scat, src_msg, fixed_elem_size, msg_len);   
  if (err != 0) {
    ssp_err_quit("SSP_Msg_create: scat_set failed\n");
  }  

  if (realloc) {  
    err = scat_alloc(src_msg, msg_len);
    if (err < 0) { 
      ssp_err_quit("SSP_Msg_create: scat_alloc failed\n");
    }
  }
  
  return msg;
}

/* SSP_Msg_free ------------------------------------------------------------------------------
   This function destroys and frees a SSP_Msg data structure. 
--------------------------------------------------------------------------------------------- */
void SSP_Msg_free(SSP_Msg **msg) {
  if(*msg) {
    SSP_Msg_destroy(*msg);
    free(*msg);
    *msg = NULL;
  }
}

/* ============================  encrypt info functions  ===================================== */

/* SSP_Enc_free -------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------- */
static void SSP_Enc_free(SSP_Enc **enc) {
  if(*enc) {
    SSP_Enc_destroy(*enc);
    free(*enc);
    *enc = NULL;
  }
}

/* SSP_Enc_set --------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------- */
void SSP_Enc_set(SSP_Enc *enc, int name, unsigned char *key, int key_len, int block_size, 
		 void *info, unsigned int (*init_fcn)(unsigned char*, unsigned int, void*),
		 unsigned int (*chg_key_fcn)(unsigned char*, unsigned int, void*),
		 unsigned int (*enc_fcn)(char*, unsigned int, void*, int),
		 unsigned int (*dec_fcn)(char*, unsigned int, void*, int)) {
  enc->name        = name;
  enc->key         = key;
  enc->key_len     = key_len;
  enc->block_size  = block_size;
  enc->info        = info;
  enc->init_fcn    = init_fcn;
  enc->chg_key_fcn = chg_key_fcn;
  enc->enc_fcn     = enc_fcn;
  enc->dec_fcn     = dec_fcn;
}

/* SSP_Enc_print_key ---------------------------------------------------------------------------
   Just a helper function that prints the key
-----------------------------------------------------------------------------------------------*/
void SSP_Enc_print_key(SSP_Enc *enc) {
  int i;
  
  if(enc) {
    printf("The key is: 0x");
    for (i = 0; i < enc->key_len; i++){
      printf("%02X", ((unsigned char*)(enc->key))[i]);
    }
    printf("\n");
  } 
}

/* =================================  key alg functions  ==================================== */

/* SSP_Ka_free --------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------- */
static void SSP_Ka_free(SSP_Ka **ka) {
  if(*ka) {
    if((*ka)->vs_membs) {
      free((*ka)->vs_membs);
      (*ka)->vs_membs = NULL;
    }
    stdhash_destruct(&(*ka)->vs_membs_hash);
    
    SSP_Ka_destroy(*ka);
    free(*ka);
    *ka = NULL;
  }
}

/* SSP_Ka_set ---------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------- */
void SSP_Ka_set(SSP_Ka *ka, int name, void* info, unsigned int key_len,
		int (*handles_msg_fcn)(SSP_Msg*, SSP_Grp*),
		int (*handle_recv_fcn)(SSP_Con*, SSP_Grp*, SSP_Msg*),
		int (*handle_fl_ok_fcn)(SSP_Con*, SSP_Grp*),
		int (*handle_send_fcn)(SSP_Con*, SSP_Grp*)) {
  ka->name             = name;
  ka->info             = info;
  ka->handles_msg_fcn  = handles_msg_fcn;
  ka->handle_recv_fcn  = handle_recv_fcn;
  ka->handle_fl_ok_fcn = handle_fl_ok_fcn;
  ka->handle_send_fcn  = handle_send_fcn;
  ka->key_len          = key_len;

  ka->vs_membs = 0;
  stdhash_construct(&ka->vs_membs_hash, sizeof(char*), 0, grp_name_ptr_eq, grp_name_ptr_hashcode); 
}


/* ============================  group info functions  ======================================= */

/* grp_name_hashcode -------------------------------------------------------------------------
  This function is passed to the stdhash data structure, it needs to have this signature.
--------------------------------------------------------------------------------------------- */
size_t grp_name_hashcode(const void *str) {
  const unsigned char *key = (const unsigned char*) str, *end = key + MAX_GROUP_NAME;
  size_t ret = 0;
  
  while (key != end && *key != 0) 
    ret = ret * 33 + *key++;
  
  return ret;
}

/* grp_name_ptr_eq ----------------------------------------------------------------------------
  This function is passed to the stdhash data structure, it needs to have this signature.
-------------------------------------------------------------------------------------------- */
stdbool grp_name_ptr_eq(const void *strptr1, const void *strptr2) {
  return !strncmp(*(const char**) strptr1, *(const char**) strptr2, MAX_GROUP_NAME);
}

/* grp_name_ptr_hashcode  --------------------------------------------------------------------
  This function is passed to the stdhash data structure, it needs to have this signature.  
--------------------------------------------------------------------------------------------- */
size_t grp_name_ptr_hashcode(const void *strptr) {
  return grp_name_hashcode(*(const void**) strptr);
}

/* SSP_Grp_init -------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------- */
static void SSP_Grp_init(SSP_Grp *grp) {
  grp->name     = 0;
  memset(&grp->gid, 0, sizeof(group_id));
  grp->num_membs     = 0;
  grp->num_vs_membs  = 0;
  grp->curr_membs    = 0;
  grp->prev_membs    = 0;
  grp->vs_membs      = 0;
  grp->enc           = 0;
  grp->ka            = 0;
  stdhash_construct(&(grp->curr_membs_hash), sizeof(char*), 0,  grp_name_ptr_eq, grp_name_ptr_hashcode);
  stdhash_construct(&(grp->prev_membs_hash), sizeof(char*), 0,  grp_name_ptr_eq, grp_name_ptr_hashcode);
  stdhash_construct(&(grp->vs_membs_hash), sizeof(char*), 0, grp_name_ptr_eq, grp_name_ptr_hashcode);
  grp->joiner        = 0;
  grp->leaver        = 0;
  grp->state         = JOIN_CALLED;
}

/* SSP_Grp_init_vs_and_prev -------------------------------------------------------------------
   Init vs with me (private name). The prev memb is initiated with me because the secure
   layers computes the secure vs set starting with the previous memb. Our convention is that
   I am part of my vs set.
--------------------------------------------------------------------------------------------- */
static void SSP_Grp_init_vs_and_prev(SSP_Grp *grp, char priv_name[MAX_GROUP_NAME]) {
  char *p = 0;

  grp->num_vs_membs = 1;
  grp->vs_membs = (char(*)[MAX_GROUP_NAME]) malloc(MAX_GROUP_NAME); 
  if (!grp->vs_membs) {
    ssp_err_quit("SSP_Con_addGrp: malloc 1 failed\n");
  }  
  memcpy(grp->vs_membs, priv_name, MAX_GROUP_NAME);
  p = grp->vs_membs[0];
  stdhash_insert(&grp->vs_membs_hash, 0, &p, 0);

  grp->prev_membs = (char(*)[MAX_GROUP_NAME]) malloc(MAX_GROUP_NAME); 
  if (!grp->prev_membs) {
    ssp_err_quit("SSP_Con_addGrp: malloc 2 failed\n");
  }  
  memcpy(grp->prev_membs, priv_name, MAX_GROUP_NAME);
  p = grp->prev_membs[0];
  stdhash_insert(&grp->prev_membs_hash, 0, &p, 0);
}

/* SSP_Grp_destroy ----------------------------------------------------------------------------
--------------------------------------------------------------------------------------------- */
static void SSP_Grp_destroy(SSP_Grp *grp) {
  my_free(&(grp->name));
  if(grp->curr_membs) {
    free(grp->curr_membs);
    grp->curr_membs = NULL;
  }
  if(grp->prev_membs) {
    free(grp->prev_membs);
    grp->prev_membs = NULL;
  }
  if(grp->vs_membs) {
    free(grp->vs_membs);
    grp->vs_membs = NULL;
  }

  SSP_Enc_free(&(grp->enc));
  SSP_Ka_free(&(grp->ka));
	
  stdhash_destruct(&(grp->curr_membs_hash));
  stdhash_destruct(&(grp->prev_membs_hash));
  stdhash_destruct(&(grp->vs_membs_hash));

 if(grp->joiner) {
    free(grp->joiner);
    grp->joiner = NULL;
  }
 if(grp->leaver) {
    free(grp->leaver);
    grp->leaver = NULL;
  }

}

/* SSP_Grp_free -------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------- */
static void SSP_Grp_free(SSP_Grp **grp) {
  if(*grp) {
    SSP_Grp_destroy(*grp);
    free(*grp);
    *grp = NULL;
  }
}

/* ==================================  connection functions  ================================== */

/* SSP_Con_init --------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------- */
static void SSP_Con_init(SSP_Con* con) {
  con->mbox         = 0;
  con->priority     = 0; 
  con->grp_notify   = 0; 
  con->daemon_name  = 0; 
  con->con_name     = 0; 
  con->priv_name    = 0; 
  con->enc          = 0;
  stdhash_construct(&(con->grps_hash), sizeof(char*), sizeof(SSP_Grp*), 
		    grp_name_ptr_eq, grp_name_ptr_hashcode);
  stddll_construct(&(con->deliv_deque), sizeof(SSP_Msg*));
}

/* SSP_Con_set ---------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------- */
static void SSP_Con_set(SSP_Con* dest,  mailbox mbox, int priority, int grp_notify, 
			char* daemon_name, char* con_name, char* priv_name, SSP_Enc *enc) {
  dest->mbox         = mbox;
  dest->priority     = priority;
  dest->grp_notify   = grp_notify;
  dest->daemon_name  = daemon_name;
  dest->con_name     = con_name;
  dest->priv_name    = priv_name;
  dest->enc          = enc;  
}

/* SSP_Con_destroy -----------------------------------------------------------------------------
---------------------------------------------------------------------------------------------- */
static void SSP_Con_destroy(SSP_Con* c) {
  stddll_it lit;
  stdhash_it hit;
  SSP_Grp *grp = NULL;
  SSP_Msg *msg = NULL;

  for(stddll_begin(&(c->deliv_deque), &lit); !stddll_it_is_end(&lit); stddll_it_next(&lit)) {
    msg = *(SSP_Msg**) stddll_it_val(&lit);
    SSP_Msg_destroy(msg);
    free(msg);
  }
  stddll_destruct(&(c->deliv_deque));

  for(stdhash_begin(&(c->grps_hash), &hit); !stdhash_it_is_end(&hit); stdhash_it_next(&hit)) {
    grp = *(SSP_Grp**) stdhash_it_val(&hit);
    SSP_Grp_free(&grp);
  }
  stdhash_destruct(&(c->grps_hash));

  
  my_free(&(c->daemon_name));
  my_free(&(c->con_name));
  my_free(&(c->priv_name));

  SSP_Enc_free(&(c->enc));
}

/* SSP_Con_create ------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------- */
SSP_Con * SSP_Con_create(mailbox mbox, int priority, int grp_memb, char *spread, char *private, 
			 char *priv_grp) {
   SSP_Con *con = (SSP_Con*) malloc(sizeof(SSP_Con));
   spread  = my_strdup(spread);
   private = my_strdup(private);
   priv_grp = my_strdup(priv_grp);
    
   if (!con || !spread || !private || !priv_grp) {
     ssp_err_quit("SSP_Con_create: malloc or my_strdup failed\n");
   }
    
   SSP_Con_init(con);
   SSP_Con_set(con, mbox, priority, grp_memb, spread, private, priv_grp, 0);

   return con;
}

/* SSP_Con_free --------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------- */
void SSP_Con_free(SSP_Con **con) {
  if(*con) {
    SSP_Con_destroy(*con);
    free(*con);
    *con = NULL;
  }
}

/* SSP_Con_delGrp ------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------- */
void SSP_Con_delGrp(SSP_Con *con, const char *grp_name) {
  stdhash_it hit;
  char *grp_name_ptr;
  SSP_Grp *grp = NULL;

  grp_name_ptr = (char*)grp_name;
  stdhash_find(&(con->grps_hash), &hit, &grp_name_ptr);
  grp = *(SSP_Grp**) stdhash_it_val(&hit);
  assert(!stdhash_it_is_end(&hit));
  stdhash_erase(&hit);
  SSP_Grp_free(&grp);
}

/* SSP_Con_addGrp ------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------- */
SSP_Grp *SSP_Con_addGrp(SSP_Con *con, const char *g_name) {
  SSP_Grp *grp  = (SSP_Grp*)malloc(sizeof(SSP_Grp));
  char *grp_name_ptr;
  
  SSP_Grp_init(grp);
  SSP_Grp_init_vs_and_prev(grp, con->priv_name);
  grp->name = my_strdup(g_name);
  grp_name_ptr = grp->name;
  stdhash_insert(&con->grps_hash, 0, &grp_name_ptr, &grp);

  return grp;
}

/* SSP_Con_getGrp -----------------------------------------------------------------------------
---------------------------------------------------------------------------------------------- */
SSP_Grp *SSP_Con_getGrp(SSP_Con *con, const char *g_name) { 
 stdhash_it hit;

 return (!stdhash_it_is_end(stdhash_find(&con->grps_hash, &hit, &g_name)) ? 
	 *(SSP_Grp**) stdhash_it_val(&hit) : 0);
}













