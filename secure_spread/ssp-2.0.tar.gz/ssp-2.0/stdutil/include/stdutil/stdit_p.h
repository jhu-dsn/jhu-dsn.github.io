/* this file should only be included from stdit.h */

#ifdef stdit_h_2000_05_12_16_33_00_jschultz_at_cnds_jhu_edu
# ifndef stdit_p_h_2000_05_12_16_35_41_jschultz_at_cnds_jhu_edu
# define stdit_p_h_2000_05_12_16_35_41_jschultz_at_cnds_jhu_edu

# include <stdutil/stddefines.h>

/* IMPORTANT C-HACK NOTE: the #define STD_MAX_ITERATOR_SIZE must be at
   least as large as the largest iterator structure with which stdit
   is supposed to work. Don't include the corresponding .h file,
   instead just do sizeof(struct { typed like biggest iterator type
   here }).  If you introduce an iterator that might be the biggest on
   one arch but not on another, then you need to do some #ifndefs
   here, or something else, to make sure that STD_MAX_ITERATOR_SIZE is
   always big enough.
*/
# define STD_MAX_ITERATOR_SIZE sizeof(struct { void *a, *b, *c; })

/* An implementation should specify a static const instance of a
   stdit_fcns that specifies the fcns that can work on that iterator
   (see stdarr.c for example) and its type.
*/
typedef struct {
  stdit_type type;

  void    *(*val)(const void *);
  size_t  (*sizeof_val)(const void *);
  stdbool (*equals)(const void *, const void *);
  stdbool (*is_begin)(const void *);
  stdbool (*is_end)(const void *);
  void    *(*seek_begin)(void *);
  void    *(*seek_end)(void *);
  void    *(*next)(void *);
  void    *(*advance)(void *, size_t);
  /* a forward iterator implements everything above here */

  void *(*prev)(void *);
  void *(*retreat)(void *, size_t);
  /* a bidirectional iterator implements everything above here */

  stdssize_t (*compare)(const void *, const void *);
  void       *(*offset)(void *, stdssize_t);
  /* a random access iterator implements everything above here */
} stdit_fcns;

/* A stdit contains, by value, an instance of a particular
   implementation of an iterator. In addition to this, it knows
   functions that can operate on that implementation of an iterator.  
*/
typedef struct { 
  char it[STD_MAX_ITERATOR_SIZE];
  const stdit_fcns *fcns;
} stdit;

# endif
#else
COMPILE-ERROR: __FILE__, line __LINE__: stdit_p.h should only be included from stdit.h!
#endif
