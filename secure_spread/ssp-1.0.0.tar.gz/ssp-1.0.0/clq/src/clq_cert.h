/*********************************************************************
 * clq_cert.h                                                        * 
 * CLQ certificate include file.                                     * 
 * Time-stamp: <1999-11-22 17:02:06 hasse>                           *
 * Wrote by:                                                         * 
 * Damian Hasse                                                      *
 *                                                                   *
 * CLIQUES Project                                                   *
 * Information Sciences Institute                                    *
 * University of Southern California                                 *
 *********************************************************************/

#ifndef CLQ_CERT_H
#define CLQ_CERT_H
#include "openssl/bio.h"
#include "openssl/err.h"
#include "openssl/dsa.h"
#include "openssl/x509.h"

#include "clq_api.h"

int clq_get_cert_error();

DSA *clq_get_dsa_key (CLQ_NAME *member_name, 
		      enum CLQ_KEY_TYPE type);

EVP_PKEY *clq_get_pkey (char *member_name);

DSA *clq_get_dsa_param();

X509 *clq_get_cert (CLQ_NAME *member_name);

X509 *clq_vrfy_cert(X509_STORE *ctx, char *file);

#endif
