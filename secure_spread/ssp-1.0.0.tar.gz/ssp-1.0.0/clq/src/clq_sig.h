/*********************************************************************
 * clq_sig.h                                                         * 
 * CLQ signature include file.                                       * 
 * Date      Tue Nov 19 10:30:07 1999                                *
 * Time-stamp: <1999-11-24 12:16:26 hasse>                           *
 * Wrote by:                                                         * 
 * Damian Hasse                                                      *
 *                                                                   *
 * CLIQUES Project                                                   *
 * Information Sciences Institute                                    *
 * University of Southern California                                 *
 *********************************************************************/
#ifndef CLQ_SIG_H
#define CLQ_SIG_H

#include "openssl/evp.h"
#include "openssl/x509.h"

#include "clq_api.h"

#ifndef SIGNATURES
#error Signatures not in used.
#endif

/* Both md below use sha1 */
#define RSA_MD() EVP_sha1() /* NID_sha1WithRSAEncryption see m_sha1.c */
#define DSA_MD() EVP_dss1() /* NID_dsaWithSHA1 see m_dss1.c */

typedef struct clq_sign_st {
  uchar *signature;
  clq_uint length;
} CLQ_SIGN;


/* clq_sign_message: It signs the token using the current user public
 * key scheme. The signature will be appended to the begining of the
 * input token
 */
int clq_sign_message(CLQ_CONTEXT *ctx, CLQ_TOKEN *input);

int clq_vrfy_sign(CLQ_CONTEXT *ctx, CLQ_TOKEN *input, 
		  CLQ_NAME *member_name, CLQ_SIGN *sign);

int clq_remove_sign(CLQ_TOKEN *input, CLQ_SIGN **sign);
int clq_restore_sign(CLQ_TOKEN *input, CLQ_SIGN **signature);

#endif
