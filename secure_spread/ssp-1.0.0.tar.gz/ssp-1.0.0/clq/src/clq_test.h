/*********************************************************************
 * clq_test.h                                                        * 
 * CLQ test include file.                                            * 
 * Wrote by:                                                         * 
 *  Damian Hasse                                                     *
 *                                                                   *
 * CLIQUES Project                                                   *
 * Information Sciences Institute                                    *
 * University of Southern California                                 *
 *********************************************************************/

#ifndef CLQ_TEST_H
#define CLQ_TEST_H

int do_update(CLQ_CONTEXT *ctx[],char user[][NAME_LENGTH], 
	      CLQ_TOKEN *in,int num_users);

#endif
