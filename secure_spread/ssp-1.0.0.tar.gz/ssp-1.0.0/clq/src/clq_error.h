/*********************************************************************
 * clq_error.h                                                       * 
 * CLQ api error codes.                                              * 
 * Date      Oct 18 20:04:07 1999                                    *
 * Time-stamp: <1999-11-24 14:36:41 hasse>                           *
 * Wrote by:                                                         * 
 *  Damian Hasse                                                     *
 *                                                                   *
 * CLIQUES Project                                                   *
 * Information Sciences Institute                                    *
 * University of Southern California                                 *
 *********************************************************************/
#ifndef CLQ_ERROR_H
#define CLQ_ERROR_H

/* Error codes */
#define OK 1
#define CTX_ERROR -1
#define INVALID_INPUT_TOKEN -10
#define INVALID_MESSAGE_TYPE -11
#define INVALID_MEMBER_NAME -12
#define INVALID_GROUP_NAME -13
#define GROUP_NAME_MISMATCH -14
#define INVALID_LGT_NAME -15
#define MEMBER_IS_IN_GROUP -16
#define MEMBER_NOT_IN_GROUP -17
#define MEMBER_NAME_MISMATCH -18
#define MEMBER_REPEATED -19
#define LIST_EMPTY -20

#define NOT_CONTROLLER -30
#define UNSYNC_EPOCH -31
#define SEVERAL_JOINS -32
#define SENDER_NOT_CONTROLLER -33

#define INVALID_DSA_PARAMS -40
#define INVALID_PUB_KEY -41
#define INVALID_PRIV_KEY -42

#define MALLOC_ERROR -50

#define INVALID_PARAM -60 /* used in clq_update_key */
#define BN_ERROR -70

#define ERROR_INT_DECODE -80

/* clq_cert errors */
#define INVALID_DSA_TYPE -100 
#define INVALID_CA_FILE -101
#define INVALID_CERT_FILE -102
#define INVALID_PKEY -103


/* Sanity check error codes */
#define GML_EMPTY -130        /* Group member list is empty */
#define ONE_RCVD -131         /* The number one has been received in
			      * the last_partial_key field.
			      */
#define ZERO_RCVD -132        /* The number zero has been received in
			      * the last_partial_key field.
			      */
#define NUM_NOT_IN_GROUP -133 /* The number received in the 
			      * last_partial_key field does NOT belong
			      * to the group.
			      */

#ifndef SIGNATURES
/* MAC ERRORS */
#define MAC_ERROR -200
#define INVALID_MAC -201
#else
#define INVALID_SIGNATURE_SCHEME -300
#define SIGNATURE_ERROR -301
#define SIGNATURE_DIFER -302
#define INVALID_SIGNATURE -303
#endif


#endif
