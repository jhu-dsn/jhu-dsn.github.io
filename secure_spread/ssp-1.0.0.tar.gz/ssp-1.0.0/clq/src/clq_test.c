/*********************************************************************
 * Copyright (c) 1998-2000 by the University of Southern California.
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and
 *
 * its documentation in source and binary forms for lawful
 * non-commercial purposes and without fee is hereby granted, provided
 * that the above copyright notice appear in all copies and that both
 * the copyright notice and this permission notice appear in supporting
 * documentation, and that any documentation, advertising materials, and
 * other materials related to such distribution and use acknowledge that
 * the software was developed by the University of Southern California,
 * Information Sciences Institute. The name of USC may not be used to
 * endorse or promote products derived from this software without
 * specific prior written permission.
 *
 * THE UNIVERSITY OF SOUTHERN CALIFORNIA MAKES NO REPRESENTATIONS
 * ABOUT THE SUITABILITY OF THIS SOFTWARE FOR ANY PURPOSE.  THIS
 * SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND
 * NON-INFRINGEMENT.
 *
 * IN NO EVENT SHALL USC OR ANY OTHER CONTRIBUTOR BE LIABLE FOR ANY
 * SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES, WHETHER IN CONTRACT,
 * TORT, OR OTHER FORM OF ACTION, ARISING OUT OF OR IN CONNECTION
 * WITH, THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * All questions concerning this software should be directed to
 * cliques@isi.edu.
 *********************************************************************/



/*********************************************************************
 * clq_test.c                                                        * 
 * CLQ test source file.                                             * 
 * Date      Tue Nov 21 22:08:07 PST 2000                            *
 * Wrote by:                                                         * 
 * Damian Hasse                                                      *
 *                                                                   *
 * CLIQUES Project                                                   *
 * Information Sciences Institute                                    *
 * University of Southern California                                 *
 *********************************************************************/


#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include <sys/types.h>
#include <sys/time.h>
#include <time.h>

#include "bn.h"
#include "clq_api.h"
#include "clq_api_misc.h"
#include "clq_merge.h"
#include "clq_error.h"

#include "clq_test_misc.h"
#include "clq_test.h"

#ifdef TIMING
extern int print;
#endif

int main(int argc, char **argv) {
  CLQ_NAME user[NUM_USERS][NAME_LENGTH];
  CLQ_NAME *users_leaving[NUM_USERS+1]={NULL};
  CLQ_CONTEXT *ctx[NUM_USERS];
  CLQ_TOKEN *out=NULL;
  CLQ_TOKEN *in=NULL;
  int ret=OK;
  int i=0;
  int r=0;
  int num_users=NUM_USERS;
  struct timeval used;

#ifdef TIMING
  print=1;
#endif
#if defined(PROFILE) | defined(TIMING)
  r=0; /* To avoid a warning during compilation */
#endif
  for (i=0; i < NUM_USERS; i++) {
    ctx[i]=NULL; 
    sprintf (user[i],"%03d",i);
  }  

  if (!parse_args(argc,argv,&num_users,user)) goto error;
  /*********************************/

  /* All the members will joing the group */
  /* First user joining group */
  ret=clq_first_user(&ctx[0],user[0],GROUP_NAME);
  printf ("clq_first_user returns %d \n",ret);
  if (ret!=1) goto error;

  /* MEM_TEST was here */

  /* All the other users joining group */
  for (i=1; i < num_users; i++) {
#ifdef TIMING
    print=1;
    /* Print stuff times for the last user only */
    /* if (i==num_users-1) print=1; */
    if ((i%5)==0) 
      { print=1; fprintf (stderr,"\n--\nNum users: %d\n--\n",i); }
#endif
    /* User 'i-1' is processing the join of user 'i' */
    ret=clq_proc_join(ctx[i-1],user[i],&out);
    printf ("clq_proc_join returns %d \n",ret);
    if (ret!=1) goto error;
    /*
    clq_print_ctx(ctx[i-1]);
    */

    in=out;
    out=NULL;
    
    /* User 'i' is joining the group (processing the output from
     * 'i-1' user) 
     */ 
    ret=clq_join(&ctx[i],user[i],GROUP_NAME,in,&out);
    printf ("clq_join returns %d \n",ret);
    if (ret!=1) goto error;
    /*
    clq_print_ctx(ctx[i]);
    */

    /* Each user will do an update key */
    ret=do_update(ctx,user,out,num_users);
    if (ret!=OK) goto error;
    
    clq_destroy_token(&out);
    clq_destroy_token(&in);
  }
  /*********************************/

#ifndef PROFILE
#ifndef TIMING

  /* Some random users will leave the group */
  /* To make it a little more interesting :) */
  srand(time(0));
  r=((int) rand()%(num_users-1))+1;
  r=1;
  printf (" %d users leaving group.\n",r);
  /* 'r' users will leave the group */
  usr_lst(users_leaving,r,num_users);

  for (i=0; i < num_users; i++) {
    gettimeofday(&used, 0);
    fprintf(stderr, "leave start = %d.%d\n", used.tv_sec, used.tv_usec);
    ret=clq_leave(&ctx[i],users_leaving,&out,1);
    gettimeofday(&used, 0);
    fprintf(stderr, "end   = %d.%d\n", used.tv_sec, used.tv_usec);
    /* Has the controller created the output token? 
     * If it has, then let's make it the input token.
     * Note: Setting r=i is used to save time for the next step (When
     * the users will re-join the group.) This avoids the need to call
     * clq_proc_join NUM_USERS times, since we know who the controller
     * is. In a real application this is not need it, since
     * clq_proc_join will return NOT_CONTROLLER and hence the output
     * token will be NULL.
     */
    if (out != NULL) { assert (in==NULL); in=out; out=NULL; r=i; }
  }
  
  /* Each user will do an update key */
  ret=do_update(ctx,user,in,num_users);
  if (ret!=OK) goto error;
  
  clq_destroy_token(&out);
  clq_destroy_token(&in);
  /*********************************/

  /* Finally the users that left will join/merge the group again. */
#ifdef MERGE
  printf (" Users will mass join the group: ");
  i=0;
  while (users_leaving[i]!=NULL)
    printf ("%s ",users_leaving[i++]);
  printf("\n");
  for (i=0; i < num_users; i++)
    /* User left */
    if (ctx[i] == NULL) {
      ret=clq_new_user(&ctx[i],user[i],GROUP_NAME,FALSE);
      printf ("clq_new_user returns %d \n",ret);
      if (ret!=1) goto error;
    }
  ret=clq_update_key(ctx[r],users_leaving,NULL,&out);
  printf ("clq_update_key returns %d \n",ret);
  if (ret!=1) goto error;
  /* In a real application the next line should not be need it because
   * the name of the receiver provided by clq_get_next_username tell us
   * who should we send this token to.
   */
  while (ctx[r]->me->next != NULL) {
    in=out; out=NULL;
    r=atoi((unsigned char*)clq_get_next_username(ctx[r]));
    ret=clq_update_key(ctx[r],NULL,in,&out);
    printf ("clq_update_key returns %d \n",ret);
    if (ret!=1) goto error;
    clq_destroy_token(&in);
  }

  in=out; out=NULL;

  for (i=0;out==NULL;i++) {
    CLQ_TOKEN *tmp_in;

    ret=clq_factor_out(ctx[i],in,&out);
    printf ("clq_factor_out (%d) returns %d \n",i,ret);
    if (ret!=1) goto error;
    if (out != NULL) {
      tmp_in=out; out=NULL;
      ret=clq_merge(ctx[r],user[i],tmp_in,&out);
      printf ("clq_merge returns %d \n",ret);
      if (ret!=1) goto error;
      clq_destroy_token(&tmp_in); 
    }
  }

  /* Each user will do an update key */
  ret=do_update(ctx,user,out,num_users);
  if (ret!=OK) goto error;

  clq_destroy_token(&out);
  clq_destroy_token(&in);

#else
  printf (" Users will join the group again.\n");

  for (i=0; i < num_users; i++)
    if (ctx[i] == NULL) {
      ret=clq_proc_join(ctx[r],user[i],&out);
      printf ("clq_proc_join returns %d \n",ret);
      if (ret!=1) goto error;
      /*
      clq_print_ctx(ctx[r]);
      */

      in=out;
      out=NULL;
    
      ret=clq_join(&ctx[i],user[i],GROUP_NAME,in,&out);
      printf ("clq_join returns %d \n",ret);
      if (ret!=1) goto error;
      /*
      clq_print_ctx(ctx[i]);
      */

      /* Each user will do an update key */
      ret=do_update(ctx,user,out,num_users);
      if (ret!=OK) goto error;
    
      clq_destroy_token(&out);
      clq_destroy_token(&in);
      r=i;
    }
#endif

  /*********************************/
#endif /* TIMING */
#endif /* PROFILE */
  for (i=0; i < num_users; i++)
    if (ctx[i]!=NULL)
      clq_print_ctx(ctx[i]);

  printf ("Users that left and then re-join/merge: ");
  for (i=0; users_leaving[i]!=NULL ; i++) printf ("%s ",users_leaving[i]);
  printf("\n");
  /* Checking if group_secrets are the same between users */
  check_group_secret(ctx, num_users);

error:

  for (i=0; i < num_users; i++) {
    if (ctx[i] != NULL) clq_destroy_ctx(&ctx[i]);
  }

  i=0;
  while (users_leaving[i] != NULL) free(users_leaving[i++]);
  
  clq_destroy_token(&out);
  clq_destroy_token(&in);

  return 1;
}


int do_update(CLQ_CONTEXT *ctx[],char user[][NAME_LENGTH], CLQ_TOKEN
	      *in, int num_users) {
  int ret=OK;
  int i;

  for (i=0; i < num_users; i++)
    if (ctx[i] != NULL) { 
      ret=clq_update_ctx(ctx[i],in);
      printf ("clq_update_ctx returns %d \n",ret);
      if (ret!=OK) break;
      /*
      clq_print_group_secret(ctx[i]);
      clq_print_ctx(ctx[i]);
      */
    } 
  return ret;
}


  /* The following code was done mainly to test memory leaks on the
   * api. It is not intended to be clear nor useful. Just ignore it.
   * 6/17/99 Dmn.- 
   */
#ifdef MEM_TEST
/*
  gets(user[2]); 
  ret=clq_refresh_key(&ctx[0],&out);
  printf("clq_refresh_key returns %d.\n",ret);
  ret=clq_update_ctx(ctx[0],out);
  clq_print_group_secret(ctx[0]);
  printf("clq_update_ctx returns %d.\n",ret);
  clq_destroy_token (&out);

  users_leaving[0]=(CLQ_NAME *) malloc(sizeof(CLQ_NAME)*NAME_LENGTH);
  sprintf (users_leaving[0],"%03d",001);
  users_leaving[1]=NULL;

  for (i=0; i < 10000; i++) {
    ret=clq_proc_join(ctx[0],user[1],&out);
    if (ret!=OK) printf("clq_proc_join returns %d.\n",ret);
    in=out; out=NULL;
    ret=clq_join(&ctx[1],user[1],GROUP_NAME,in,&out);
    if (ret!=OK) printf("clq_join returns %d.\n",ret);
    ret=clq_update_ctx(ctx[0],out);
    clq_print_group_secret(ctx[0]);
    if (ret!=OK) printf("clq_update_ctx returns %d(0).\n",ret);
    ret=clq_update_ctx(ctx[1],out);
    clq_print_group_secret(ctx[1]);
    if (ret!=OK) printf("clq_update_ctx returns %d(1).\n",ret);
    clq_destroy_token(&in);
    clq_destroy_token(&out);
    
    ret=clq_leave(&ctx[0],users_leaving,&out);
    if (ret!=OK) printf("clq_leave returns %d(0).\n",ret);
    if (out != NULL) { assert (in==NULL); in=out; out=NULL; }
    ret=clq_leave(&ctx[1],users_leaving,&out);
    if (ret!=OK) printf("clq_leave returns %d(0).\n",ret);
    if (out != NULL) { assert (in==NULL); in=out; out=NULL; }

    clq_destroy_token(&in);
    
    * after clq_proc_join only *
    clq_free_gml(ctx[0]->last);
    ctx[0]->last=ctx[0]->me;
    ctx[0]->group_members_list->next=NULL;
    clq_destroy_ctx(&ctx[1]);
    */
    /*
    static BIGNUM *Random=NULL;

    Random = clq_grt_rnd_val(ctx[0]->params);
    BN_clear_free (Random);
    */
    /*
    ret=clq_leave_update_key(ctx[0]);
    if (ret!=OK) printf("clq_leave_update_key returns %d.\n",ret);
    static CLQ_TOKEN_INFO *info;
    */
    /*
    ret=clq_refresh_key(&ctx[0],&out);
    if (ret!=OK) printf("clq_refresh_key returns %d.\n",ret);
    ret=clq_update_ctx(ctx[0],out);
    if (ret!=OK) printf("clq_update_ctx returns %d.\n",ret);
    */
    /* clq encode *
    ret=clq_create_token_info(&info,ctx[0]->group_name,KEY_UPDATE_MESSAGE, 
			 time(0),ctx[0]->member_name); 
    if (ret!=1) printf("clq_create_token_info returns %d.\n",ret);
    
    ret=clq_encode(ctx[0],&out,info);
    if (ret!=1) printf("clq_encode returns %d.\n",ret);
    
    clq_destroy_token_info(&info);
    * end of clq_encode */
    /*
    ctx[0]->epoch--;
    ret=clq_update_ctx(ctx[0],out);
    if (ret!=1) printf("clq_update_ctx returns %d.\n",ret);
    ret=clq_decode(&ctx[1],out,&info);
    printf("clq_decode returns %d.\n",ret);
    clq_destroy_ctx(&ctx[1]);
    clq_destroy_token_info(&info);
    */
    /* clq_destroy_token (&out); *
  }

  return 1;
*/
#endif /* MEM_TEST */
