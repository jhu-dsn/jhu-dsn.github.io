/*********************************************************************
 * Copyright (c) 1998-2000 by the University of Southern California.
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and
 *
 * its documentation in source and binary forms for lawful
 * non-commercial purposes and without fee is hereby granted, provided
 * that the above copyright notice appear in all copies and that both
 * the copyright notice and this permission notice appear in supporting
 * documentation, and that any documentation, advertising materials, and
 * other materials related to such distribution and use acknowledge that
 * the software was developed by the University of Southern California,
 * Information Sciences Institute. The name of USC may not be used to
 * endorse or promote products derived from this software without
 * specific prior written permission.
 *
 * THE UNIVERSITY OF SOUTHERN CALIFORNIA MAKES NO REPRESENTATIONS
 * ABOUT THE SUITABILITY OF THIS SOFTWARE FOR ANY PURPOSE.  THIS
 * SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND
 * NON-INFRINGEMENT.
 *
 * IN NO EVENT SHALL USC OR ANY OTHER CONTRIBUTOR BE LIABLE FOR ANY
 * SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES, WHETHER IN CONTRACT,
 * TORT, OR OTHER FORM OF ACTION, ARISING OUT OF OR IN CONNECTION
 * WITH, THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * All questions concerning this software should be directed to
 * cliques@isi.edu.
 *********************************************************************/

/*********************************************************************
 * clq_mac.c                                                         * 
 * Date      Tue Nov 21 22:08:07 PST 2000                            *
 * Wrote by:                                                         *
 *  Yongdae Kim                                                      *
 *  Damian Hasse                                                     *
 *                                                                   *
 * Module: Mac                                                       *
 *                                                                   *
 * Function: Functions to add, remove, check MAC                     *
 *                                                                   *
 * CLIQUES Project                                                   *
 * Information Sciences Institute                                    *
 * University of Southern California                                 *
 *********************************************************************/

#include <malloc.h>
#include <memory.h>

/* SSL include files */
#include "bn.h"

/* CLQ_API include files */
#include "clq_api.h"
#include "clq_mac.h"
#include "clq_error.h"
#include "md5.h"
#include "hmac.h"

#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif



/* add_hmac adds MAC(s) using the output of clq_encode. 
 * The length of the output token will be changed.
 * It is used when we need to send a message
 * If member_name is Null, add mac for every member(Multicast)
 * If member_name is not Null, add mac for the user
 */

int add_hmac(CLQ_CONTEXT *ctx, CLQ_NAME *member_name, CLQ_TOKEN **input){
  int i=0;
  int ret=OK;
  clq_uint pos=0;

  CLQ_TOKEN *output=NULL;

  CLQ_GML *gml=NULL;
  CLQ_GML *prev_gml=NULL;
  CLQ_GML *next_gml=NULL;

  uchar *mac_out=NULL;

  /* Basic error checking */
  if(ctx == (CLQ_CONTEXT *)NULL){
    ret = CTX_ERROR;
    goto error;
  }
  if(input == (CLQ_TOKEN **)NULL){
    ret = INVALID_INPUT_TOKEN;
    goto error;
  }
  if(*input == (CLQ_TOKEN *)NULL){
    ret = INVALID_INPUT_TOKEN;
    goto error;
  }

  output = (CLQ_TOKEN *)malloc(sizeof(CLQ_TOKEN));
  if(output == (CLQ_TOKEN *) NULL) {ret = MALLOC_ERROR; goto error;}
  output->t_data = (uchar *)malloc(sizeof(uchar) * MSG_SIZE);
  if(output->t_data == NULL) {ret = MALLOC_ERROR; goto error;} 

  if(member_name != (CLQ_NAME *)NULL) { /* Unicast case */
    gml = clq_search_gml(ctx->first, member_name);
    if (gml == (CLQ_GML *) NULL) {
      ret=MEMBER_NOT_IN_GROUP;
      goto error;
    }
    if(gml->prev != NULL) prev_gml = gml->prev;
    if(gml->next != NULL) next_gml = gml->next;
    gml->prev = gml->next = NULL;
  }
  else gml = ctx->first; /* Multicast case */


  output->length = TOTAL_INT;

  /* I should do it later */
  /* int_encode(output->t_data, &(output->length), (clq_uint)1); */
  while(gml != NULL){
    if(strcmp(gml->member->member_name, ctx->member_name)!=0){
      mac_out = output->t_data + output->length;
      if ((ret=compute_one_hmac(ctx, gml->member, *input, mac_out)) != OK)
        goto error;

      output->length += MD5_DIGEST_LENGTH;
      if(output->length > MSG_SIZE){ret=-1111; goto error;}
      i++;
    }
    if(gml->next == NULL) break;
    else gml = gml->next;
  }
  
  if(member_name != (CLQ_NAME *)NULL) {
    gml->prev = prev_gml;
    gml->next = next_gml;
  }

  int_encode(output->t_data, &pos, i);
  memcpy(output->t_data+output->length,(*input)->t_data,(*input)->length);
  output->length += (*input)->length;
  if(output->length > MSG_SIZE){ret=-1111; goto error;}
  
  clq_destroy_token(input);
  
  *input=output; 

error:
 
  return ret;
}

/* remove_hmac remove MAC for the owner of the context
 * The length of the output token will be changed.
 * It is used before decoding the token
 */

int remove_hmac(CLQ_TOKEN *input, uchar *hmc, clq_uint *num_mac){
  clq_uint pos=0;
  int ret = OK;

  if(input == (CLQ_TOKEN *)NULL) {ret=INVALID_INPUT_TOKEN; goto error;}

  ret = int_decode(input, &pos, num_mac);
  if(ret != OK) goto error;

  /*  if(*hmc != (uchar)NULL) {ret=-1234; goto error;} */
  memcpy(hmc, input->t_data + pos, MD5_DIGEST_LENGTH * (*num_mac));
  input->t_data = input->t_data + MD5_DIGEST_LENGTH * (*num_mac) + pos;
  input->length = input->length - MD5_DIGEST_LENGTH * (*num_mac) - pos;

error:

  return ret;
}

/* check_mac checks the MAC value is valid or not. Returns 1, if valid.
 * Otherwise, it returns error 
 */
int check_hmac(CLQ_CONTEXT *ctx, CLQ_TOKEN *input, 
	       uchar *hmc, CLQ_NAME *sender_name, int num_mac){
  CLQ_GML *gml=NULL;
  int i=0;
  uchar *new_mac=NULL;
  int ret=OK;
  
  /* Error checking */
  if(ctx == (CLQ_CONTEXT *) NULL) {ret=CTX_ERROR; goto error;}
  if(input == (CLQ_TOKEN *) NULL){
    ret=INVALID_INPUT_TOKEN;
    goto error;
  }
  if(hmc == (uchar *) NULL) {ret=INVALID_MAC; goto error;}
  
  /* Search the member */
  gml = ctx->first;
  
  while(strcmp(gml->member->member_name, sender_name)!=0){
    if(strcmp(gml->member->member_name, ctx->member_name)==0){
      if(gml->next != NULL) gml = gml->next;
      break;
    }
    else i++; 
    if(gml->next != NULL) gml = gml->next;
  }

  gml = clq_search_gml(ctx->first, sender_name);

  new_mac = (uchar *)malloc(sizeof(uchar) * MD5_DIGEST_LENGTH);
  if(new_mac == (uchar *)NULL) {ret=MALLOC_ERROR; goto error;}

  compute_one_hmac(ctx, gml->member, input, new_mac);

  if(num_mac == 1){
    if(strncmp(hmc + MD5_DIGEST_LENGTH * (num_mac-1),
	       new_mac,MD5_DIGEST_LENGTH)!=0) 
      {ret = MAC_ERROR; goto error;}
  }
  else{
    if(strncmp(hmc + MD5_DIGEST_LENGTH * i,
	       new_mac,MD5_DIGEST_LENGTH)!=0) 
      {ret = MAC_ERROR; goto error;}
  }

error:
  if(new_mac != NULL) free(new_mac);

  return ret;
}

/* restore_token restore input token to original token...
 * I need to do this, since I need to recover previous value
 */
int restore_hmac(CLQ_TOKEN *input, int num_mac){
  clq_uint pos=INT_SIZE+LENGTH_SIZE;
  
  /* I want to compute previous position */
  if(num_mac < 0) return OK;
  if (input->t_data == NULL) return OK;

  input->t_data = input->t_data - MD5_DIGEST_LENGTH * num_mac - pos;
  input->length += MD5_DIGEST_LENGTH * num_mac + pos;

  return OK;
}

/* compute_one_hmac computes MAC for the "member"
 * Inside this function, we generate long_term_key, if we don't have
 */
int compute_one_hmac(CLQ_CONTEXT *ctx, CLQ_GM *member,
		CLQ_TOKEN *input, uchar *mac_out){

  char *tmp_str=NULL;
  uchar *tmp_mac_key=NULL;
  int ret = OK;
  int mac_out_len=-1;

  /* Doing some error checking */

  if(member == NULL) {ret=INVALID_MEMBER_NAME; goto error;}
  if(member->long_term_key == NULL) clq_compute_one_lt_key(ctx, member);

  tmp_str=BN_bn2hex(member->long_term_key);
  if (tmp_str == NULL) { ret=MALLOC_ERROR; goto error; }
  tmp_mac_key = (uchar *) malloc(sizeof(uchar) * MD5_DIGEST_LENGTH);
  if(tmp_mac_key == NULL) {ret=MALLOC_ERROR; goto error; }
  MD5(tmp_str, strlen(tmp_str), tmp_mac_key);
  
  HMAC(EVP_md5(),
       tmp_mac_key, MD5_DIGEST_LENGTH,
       input->t_data, input->length,
       mac_out, &mac_out_len);
  
  if (mac_out_len != MD5_DIGEST_LENGTH) { ret=MAC_ERROR; goto error; }

error:
  if(tmp_str != NULL) free(tmp_str);
  if(tmp_mac_key != NULL) free(tmp_mac_key);

  return ret;
} 
