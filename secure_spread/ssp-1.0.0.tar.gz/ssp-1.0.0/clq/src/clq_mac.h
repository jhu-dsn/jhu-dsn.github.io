#ifndef CLQ_MAC_H
#define CLQ_MAC_H

#include "clq_api.h"

/* add_hmac adds MAC(s) using the output of clq_encode. 
 * The length of the output token will be changed.
 * It is used when we need to send a message
 * If member_name is not null, unicast mac will be generated
 * IF member_name is null, multicast mac will be generated
 */
int add_hmac(CLQ_CONTEXT *ctx, CLQ_NAME *member_name, CLQ_TOKEN **input);

/* remove_hmac remove MAC for the owner of the context
 * The length of the output token will be changed.
 * It is used before decoding the token
 */

int remove_hmac(CLQ_TOKEN *input, uchar *hmc, clq_uint *num_mac);

/* check_mac checks the MAC value is valid or not. Returns 1, if valid.
 * Otherwise, it returns error 
 */
int check_hmac(CLQ_CONTEXT *ctx, CLQ_TOKEN *input, 
	      uchar *hmc, CLQ_NAME *sender_name, int num_mac);

/* restore_token restore input token to original token...
 * I need to do this, since I need to recover previous value
 */
int restore_hmac(CLQ_TOKEN *input, int num_mac);

/* compute_one_mac computes MAC for the "member"
 * Inside this function, we generate long_term_key, if we don't have
 */
int compute_one_hmac(CLQ_CONTEXT *ctx, CLQ_GM *member,
                    CLQ_TOKEN *input, uchar *mac_out);

#endif
