/*********************************************************************
 * clq_api.h                                                         * 
 * CLQ api include file.                                             * 
 * Time-stamp: <1999-12-20 23:37:56 hasse>                           *
 * Wrote by:                                                         * 
 * Damian Hasse                                                      *
 *                                                                   *
 * CLIQUES Project                                                   *
 * Information Sciences Institute                                    *
 * University of Southern California                                 *
 *********************************************************************/

#ifndef CLQ_API_H
#define CLQ_API_H

#include <stdio.h>
#include <time.h>
#include "openssl/bn.h"
#include "openssl/dsa.h"
#include "openssl/x509.h"
#include "openssl/asn1.h"

#define CLQ_API_VERSION "2.0a"

typedef char CLQ_NAME;

#ifndef clq_uint
typedef unsigned int clq_uint;
#endif

#ifndef uchar
typedef unsigned char uchar;
#endif

#define MAX_LGT_NAME 50 /* Maximum length a CLQ_NAME can have. */
#define INT_SIZE sizeof(int)
#define LENGTH_SIZE 4 /* The length of the size in a token */
#define TOTAL_INT INT_SIZE+LENGTH_SIZE
#define MSG_SIZE 32768
#define MAX_LIST 200 /* Maximum number of members that can leave and
		      * merge at one time. (see clq_leave &
		      * clq_update_key) 
		      */ 

#define ERR_STRM stderr /* If DEBUG is enable then extra information
			 * will be printed in ERR_STRM 
			 */


#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

/* CLQ_GM: Group member */
typedef struct clq_gm_st {
  CLQ_NAME *member_name;
#ifdef SIGNATURES
  X509 *cert;
#else
  BIGNUM *long_term_key; 
#endif
  BIGNUM *last_partial_key;
} CLQ_GM;

/* CLQ_GML: Group member list */
typedef struct clq_gml_st { 
  CLQ_GM *member;
  struct clq_gml_st *prev;
  struct clq_gml_st *next;
} CLQ_GML;


/* CLQ_CONTEXT: Cliques context */
typedef struct clq_context_st {
  CLQ_NAME *member_name;
  CLQ_NAME *group_name;
  BIGNUM *key_share; /* session_random */
  BIGNUM *group_secret; 
  uchar *group_secret_hash; /* session_key */
  CLQ_GML *group_members_list; /* use first instead, eventually this
				  pointer will be removed */
  CLQ_GML *first;
  CLQ_GML *last;
  CLQ_GML *me; /* my position in group_members */
  /* The next field is not yet implemented in cliques! (but it is in
     ckd) */
  CLQ_GML *controller; /* controller position in group_members */
  CLQ_GML *gml_cache;
  DSA *params;
#ifndef SIGNATURES
  DSA *private; /* Private and Public key of the user */
#else
  EVP_PKEY *pkey;
#endif
  clq_uint epoch;
} CLQ_CONTEXT;

/* MESSAGE TYPE definitions */
enum MSG_TYPE { NEW_MEMBER, 
		KEY_UPDATE_MESSAGE,
		KEY_MERGE_UPDATE,
		MERGE_FACTOR_OUT,
		MERGE_BROADCAST,
		MASS_JOIN,
		CKD_NEW_KEY_SHARE,
		CKD_OLD_KEY_SHARE,
		CKD_INDIVIDUAL_SHARE,
		CKD_NEW_SESSION_KEY,
		INVALID };

/* CLQ_KEY_TYPE definitions, used by clq_read_dsa */
enum CLQ_KEY_TYPE { CLQ_PARAMS,
		    CLQ_PRV,
		    CLQ_PUB};

typedef struct clq_token_st {
  clq_uint length;
  uchar *t_data;
/*
  Data contains (in this order):
  CLQ_NAME *group_name;
  enum MSG_TYPE message_type;
  time_t time_stamp;
  CLQ_NAME *sender_name;
  clq_uint epoch; -> This one comes from ctx.
  CLQ_GML *group_member_list; (Without long term key)
*/
} CLQ_TOKEN;

typedef struct clq_token_info {
  CLQ_NAME *group_name;
  enum MSG_TYPE message_type;
  time_t time_stamp;
  CLQ_NAME *sender_name;
  /*  clq_uint epoch; */
} CLQ_TOKEN_INFO;

/* clq_join is called by a new group member who has received a
 * NEW_MEMBER message from the current controller.
 */
int clq_join (CLQ_CONTEXT **ctx, CLQ_NAME *member_name, 
	      CLQ_NAME *group_name, CLQ_TOKEN *input, 
	      CLQ_TOKEN **output);

/* clq_proc_join (clq process join) is called by the current
 * controller to hand over group context to a new member (who will
 * become the next controller). 
 * ctx is modified.
 */
int clq_proc_join (CLQ_CONTEXT *ctx, CLQ_NAME *member_name, 
		   CLQ_TOKEN **output);

/* clq_update_ctx is called by a member upon reception of a
 * KEY_UPDATE_MESSAGE from the current group controller 
 */
int clq_update_ctx (CLQ_CONTEXT *ctx, CLQ_TOKEN *input);

/* Change of gears... (i.e. It does not follow what is written in the
 * API documentation.)
 * clq_leave is called by every group member right after a member
 * leaves the group or a partition occurs (i.e. several members
 * left). This function will remove all the valid members in
 * member_list from the group_member_list. It does NOT depend on the
 * type of the user. 
 * Once all the deletion has been achieved, then if the user is the
 * controller (i.e. ctx->last == ctx->me) then an output token will be
 * generated. Otherwise output token will be NULL.
 *
 * Only the members that are found in the group_members_list will be
 * deleted. Any invalid member in member_list will be ignored.
 *
 * Parameters:
 *  ctx
 *   Group context (modified).
 *  member_list
 *   List of names of users leaving the group.
 *  output
 *   New key updated message generated to be broadcasted to the group.
 *  flag
 *   if it is 1, then compute the real values... Otherwise, just remove members
 *
 * If ctx->me is NULL after the deletion, then ctx will be destroyed.
 * Preconditions: member_list has to be NULL terminated. 
 *                *output should be empty.
 *                The size of member_list should be less than MAX_LIST
 */
int clq_leave (CLQ_CONTEXT **ctx, CLQ_NAME *member_list[], 
               CLQ_TOKEN **output, int flag);

/* clq_refresh_key is called by the controller only, when
 * group_secret needs to be updated.
 */
int clq_refresh_key (CLQ_CONTEXT **ctx, CLQ_TOKEN **output);

/* clq_destroy_token_info: It frees the memory of the token. */
void clq_destroy_token_info (CLQ_TOKEN_INFO **info);

/* clq_destroy_token: It frees the memory of the token. */
void clq_destroy_token (CLQ_TOKEN **token);

/* clq_destroy_ctx is called by clq_leave.
 * It frees the space occupied by the current context.
 */
void clq_destroy_ctx (CLQ_CONTEXT **ctx);

/***********************/
/*CLQ private functions*/
/***********************/

/* clq_encode using information from the current context, it generates
 * the output token.
 */
#define clq_encode(ctx,output,info) clq_grl_encode(ctx,output,info,TRUE)
int clq_grl_encode(CLQ_CONTEXT *ctx, CLQ_TOKEN **output,
		   CLQ_TOKEN_INFO *info, int include_last_partial);

/* clq_decode using information from the input token, it creates
 * ctx. info is also created here. It contains data recovered from
 * input such as message_type, sender, etc. (See structure for more
 * details) in readable format. 
 */
int clq_decode(CLQ_CONTEXT **ctx, CLQ_TOKEN *input, CLQ_TOKEN_INFO **info);

/* int_endoce: It puts an integer number in stream. Note that the size
 * of the integer number is addded to the stream as well.
 */
/* NOTE: HTONL should be added here */
void int_encode(uchar *stream, clq_uint *pos, clq_uint data);


/* int_decode: It gets an integer number from input->t_data. Note that
 * the size of the integer number is decoded first, and then the
 * actual number is decoded.
 * Returns: 1 succeed.
 *          0 Fails.
 */
int int_decode(const CLQ_TOKEN *input,clq_uint *pos, clq_uint *data);

/* string_encode: It puts the valid 'c' string into stream. It first
 * stores the message length (including \0) and the the actual
 * message.
 */
void string_encode (uchar *stream, clq_uint *pos, char *data);

/* string_decode: It restores a valid 'c' string from
 * input->t_data. First the string length is decode (this one should
 * have \0 already), and the actual string.
 * Returns: 1 succeed.
 *          0 Fails.
 */
int string_decode (const CLQ_TOKEN *input, clq_uint *pos, char *data);

/* bn_encode: BIGNUM encoding. */
void bn_encode (uchar *stream, clq_uint *pos, BIGNUM *num);

/* bn_decode: BIGNUM decoding.
 * Preconditions: num has to be different from NULL.
 * Returns: 1 succeed.
 *          0 Fails.
 */
int bn_decode (const CLQ_TOKEN *input, clq_uint *pos, BIGNUM *num);

/* clq_create_token_info: It creates the info token.
 */
int clq_create_token_info (CLQ_TOKEN_INFO **info, CLQ_NAME *group, 
		      enum MSG_TYPE msg_type, time_t time, CLQ_NAME *sender/* , clq_uint epoch*/);


/* clq_read_DSA: Reads a DSA structure from disk depending on
 * CLQ_KEY_TYPE (CLQ_PARAMS, CLQ_PRIV, CLQ_PUB)
 * Returns the structure if succeed otherwise NULL is returned.
 */
DSA *clq_read_dsa(CLQ_NAME *member_name, enum CLQ_KEY_TYPE type);

/* clq_create_ctx creates the clq context.
 * Preconditions: *ctx has to be NULL.
 */
int clq_create_ctx(CLQ_CONTEXT **ctx);

#ifdef SLOW
/* clq_update_lt_key: Updates the long_term_key between this member
 * and each other member.
 */
int clq_update_lt_key(CLQ_CONTEXT *ctx);
#endif 

/* clq_compute_one_lt_key: It computes one long term key between myself
 * and member->member_name.
 * Preconditions:
 *   ctx->private should be valid.
 *   ctx->params should be valid.
 */
int clq_compute_one_lt_key (CLQ_CONTEXT *ctx, CLQ_GM* member);

/* clq_creat_new_key: Creates new key for the group members using
 * his/her new random key (key_share). The long_term_key (K) is added
 * as well to the new key.
 */
int clq_creat_new_key_rm(CLQ_CONTEXT *ctx, int AddK,int calc_inv);
#define clq_creat_new_key(ctx,addk) clq_creat_new_key_rm(ctx,addk,FALSE)

/* Frees a CLQ_GML structure */
void clq_free_gml(CLQ_GML *gml);

/* Frees a CLQ_GM structure */
void clq_free_gm(CLQ_GM *gm);

/* clq_join_update_key: It update the last_partial keys of the entire
 * group. This is necessary when a new member has joined the group. It
 * removes Kij's between the current user and everybody else's, while
 * adding a new key_share for the user. Then a new node is created
 * where the last_partial_key data for the new user is dropped.
 * Preconditions: It is assumed that the member calling this function
 * is the current controller.
 */
int clq_join_update_key(CLQ_CONTEXT *ctx,CLQ_NAME *new_user);

int clq_leave_update_key(CLQ_CONTEXT *ctx);

/* clq_sanity_check: It does a sanity check on the each member
 * last_partial_key.
 * Returns: OK succeed 
 *          GML_EMPTY: Group member list is empty.
 *          ONE_RCVD: One has been received.
 *          ZERO_RCVD: Zero has been received.
 *          NUM_NOT_IN_GROUP: Number received is not valid (invalid modulus)
 */
int clq_sanity_check(CLQ_CONTEXT *ctx);

/* clq_rand: Generates a new random number of "num" bits, using the
 * default parameters.
 * Returns: A pointer to a dsa structure where the random value
 *          resides. 
 *          NULL if an error occurs.
 */
BIGNUM *clq_rand (DSA *params,BIGNUM *num);

/* clq_grt_rnd_val: generating a random number of 'q' bits */
#define clq_grt_rnd_val(params) clq_rand(params,params->q)

/* clq_new_user: Called by the first user in the group or by new
 * users in a merge operation. 
 */
int clq_new_user(CLQ_CONTEXT **Ctx,CLQ_NAME *member_name, CLQ_NAME
		   *group_name, int set_gml);

/* clq_first_user: Called by the first user in the group only!
 * Everybody else has to call clq_join.
 */
#define clq_first_user(ctx,name,group) clq_new_user(ctx,name,group,TRUE)

/* clq_search_gml search a member in group member list. */
CLQ_GML *clq_search_gml (CLQ_GML *gml, CLQ_NAME *member_name);

CLQ_GML *clq_create_gml (CLQ_NAME *member_name);

int clq_create_name_list(CLQ_CONTEXT *ctx, CLQ_GML **static_gml, int zero_key);

/* clq_compute_secret_hash: It computes the hash of the group_secret.
 * Preconditions: ctx->group_secret has to be valid.
 */
int clq_compute_secret_hash (CLQ_CONTEXT *ctx);

/* clq_gml_update: It is used by clq_update_ctx and clq_factor_out to
 * update the group member list with the new one provided in the
 * new_ctx. 
 */
int clq_gml_update (CLQ_CONTEXT *ctx, CLQ_CONTEXT *new_ctx, 
		    enum MSG_TYPE m_type);


int clq_gml_cache_add (CLQ_CONTEXT *ctx, CLQ_GM* member);

/* clq_read_DSA stuff */
#define COMMON_FILE "public_values.clq"
#define PUB_FMT "pub"
#define PRV_FMT "priv"
#ifdef USE_CLQ_READ_DSA
#define FILE_EXT "clq"
#else
#define FILE_EXT "pem"
#endif

/* clq_get_cert stuff */
#define DSA_PARAM_CERT "dsa_param.pem"
#define PUB_CERT "cert"
#define CA_CERT_FN "cacert.pem"


/* Macros not implemented in SSL */
#ifndef d2i_DSAPublicKey_bio
#define d2i_DSAPublicKey_bio(bp,x) (DSA *)ASN1_d2i_bio((char *(*)())DSA_new, \
                (char *(*)())d2i_DSAPublicKey,(bp),(unsigned char **)(x))
#endif
#ifndef i2d_DSAPublicKey_bio
#define i2d_DSAPublicKey_bio(bp,x) ASN1_i2d_bio(i2d_DSAPublicKey,(bp), \
                (unsigned char *)(x)) 
#endif
#endif /* CLQ_API_H */
