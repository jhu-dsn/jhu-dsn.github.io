/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */




#include "ssp.h"
#include <stdio.h>
#include <stdlib.h>

#ifdef DMALLOC
#include "dmalloc.h"
#endif

static	char	User_Name[80];
static  char    Spread_Name[80];
static  char    Private_Group[MAX_GROUP_NAME];
static  mailbox Mbox;
static	int	Num_sent;
static	int	Previous_len;


static	void	Print_menu();
static	void	User_command();
static	void	Read_message();
static  int     Usage(int argc, char **argv);
static  void	Bye();

#define MESS_SIZE (131072 * sizeof(char))

int main(int argc, char *argv[]) {
  int	ret;
  int   major=-1, minor=-1, patch=-1;
  
  if(!Usage(argc, argv)) {
    return 0;
  }
  
  SSP_version(&major, &minor, &patch);
  printf("Secure Spread library version is %d.%d.%d\n", major, minor, patch);
  E_init();
  E_attach_fd(0, READ_FD, User_command, 0, NULL, LOW_PRIORITY);
  
  ret = SSP_connect(Spread_Name, User_Name, 0, 1, &Mbox, Private_Group);
  if(ret < 0) {
    SSP_error(ret);
    Bye();
  }
  printf("User: connected to %s with private group %s\n", Spread_Name, Private_Group);
  
  /*    E_attach_fd(Mbox, Read_message, 0, HIGH_PRIORITY);*/

  Print_menu();
    
  printf("\nUser> ");
  fflush(stdout);
  
  Num_sent = 0;
  
  E_handle_events();
  
  return 0;
}


static void User_command() {
  char   command[130];
  static char *mess;
  static int first_time = 1;
  char   group[80];
  char   groups[10][MAX_GROUP_NAME];
  int	 num_groups;
  int	 mess_len;
  int	 ret;
  int	 i;
    
  if (first_time) {
    first_time = 0;
    mess = (char*) malloc(MESS_SIZE);
    if (!mess) exit(fprintf(stderr, "User_command: Exception: malloc failed\n"));
  }    
  
  for(i=0; i<sizeof(command); i++) {
    command[i] = 0;
  }
  if(fgets(command, sizeof(command), stdin) == 0) {
    Bye();
  }
  
  switch(command[0]) {
  case 'j':
    ret = sscanf(&command[2], "%s", group);
    if(ret < 1) {
      printf(" invalid group \n");
      break;
    }
    ret = SSP_join(Mbox, group);
    if(ret < 0){
      SSP_error(ret);
    }
    
    break;
    
  case 'l':
    ret = sscanf(&command[2], "%s", group);
    if(ret < 1) {
      printf(" invalid group \n");
      break;
    }
    ret = SSP_leave(Mbox, group);
    if(ret < 0) {
      SSP_error(ret);
    }
    
    break;
    
  case 's':
    num_groups = sscanf(&command[2], "%s%s%s%s%s%s%s%s%s%s", 
			groups[0], groups[1], groups[2], groups[3], groups[4],
			groups[5], groups[6], groups[7], groups[8], groups[9]);
    if(num_groups < 1) {
      printf(" invalid group \n");
      break;
    }
    printf("enter message: ");
    ret = (int) fgets(mess, MESS_SIZE, stdin);
    
    if(ret == 0) {
      Bye();
    }
    
    mess_len = strlen(mess);
    ret = SSP_multicast(Mbox, RELIABLE_MESS, (char*) groups, 1, mess_len, mess);
    if(ret < 0) {
      SSP_error(ret);
      Bye();
    }
    Num_sent++;
    
    break;
 
  case 'n':
    num_groups = sscanf(&command[2], "%s%s%s%s%s%s%s%s%s%s", 
			groups[0], groups[1], groups[2], groups[3], groups[4],
			groups[5], groups[6], groups[7], groups[8], groups[9]);
    if(num_groups < 1) {
      printf(" invalid group \n");
      break;
    }
    
    printf("enter message: ");
    ret = (int) fgets(mess, MESS_SIZE, stdin);
    
    if(ret == 0) {
      Bye();
    }
    
    mess_len = strlen(mess);
    ret = SSP_multicast(Mbox, SAFE_MESS | ENCRYPT_MESS, groups[0], 1, mess_len, mess);
    if(ret < 0) {
      SSP_error(ret);
      Bye();
    }
    Num_sent++;
    break;
    
  case 'b':
    ret = sscanf(&command[2], "%s", group);
    if(ret !=  1) {
      strcpy(group, "dummy_group_name");
    }
    printf("enter size of each message: ");
    ret = (int) fgets(mess, MESS_SIZE, stdin);
    if(ret == 0) {
      Bye();
    }
    ret = sscanf(mess, "%d", &mess_len);
    if(ret != 1) {
      mess_len = Previous_len;
    }
    if(mess_len < 0) {
      mess_len = 0;
    }
    Previous_len = mess_len;
    printf("sending 10 messages of %d bytes\n", mess_len );
    for(i=0; i<10; i++){
      Num_sent++;
      sprintf(mess, "mess num %d ", Num_sent);
      ret = SSP_multicast(Mbox, FIFO_MESS, group, 2, mess_len, mess);
      if(ret < 0) {
	SSP_error(ret);
	Bye();
      }
      printf("sent message %d (total %d)\n", i+1, Num_sent);
    }
    
    break;
    
  case 'r':	
    Read_message();
    break;
    
  case 'p':
    ret = SSP_poll(Mbox);
    printf("Polling sais: %d\n", ret);
    break;
    
  case 'q':
    SSP_disconnect(Mbox);
    free(mess);
    Bye();
    break;
	
  case 'f':
    ret = sscanf(&command[2], "%s", group);
    if(ret < 1) {
      printf(" invalid group \n");
      break;
    }
    ret = SSP_flush(Mbox, group);
    if(ret < 0){
      SSP_error(ret);
    }
    break;

  default:
    printf("\nUnknown commnad\n");
    Print_menu();
    break;
  }
  printf("\nUser> ");
  fflush(stdout);
}

static void Print_menu() {
    printf("\n");
    printf("==========\n");
    printf("User Menu:\n");
    printf("----------\n");
    printf("\n");
    printf("\tj <group> -- join a group\n");
    printf("\tl <group> -- leave a group\n");
    printf("\tf <group> -- send flush ok to a group\n");
    printf("\n");
    printf("\ts <group> -- send a message\n");
    printf("\tn <group> -- send an encrypt message\n");
    printf("\tb <group> -- send a burst of messages\n");
    printf("\n");
    printf("\tr -- receive a message (stuck) \n");
    printf("\tp -- poll for a message \n");
    printf("\n");
    printf("\tq -- quit\n");
    fflush(stdout);
}


static void Read_message() {
  static char  mess[131072];
  char         sender[MAX_GROUP_NAME];
  char         target_groups[100][MAX_GROUP_NAME];
  group_id     *grp_id;
  int	       num_vs;
  char	       *vs_members;
  int	       num_groups;
  int	       num_bytes;
  int	       service_type=0;
  int16	       mess_type;
  int	       endian_mismatch;
  int          more_mess;
  int	       i;
  int	       ret;

  printf("\n============================\n");
  ret = SSP_receive( Mbox, &service_type, sender, 100, &num_groups, target_groups, 
		     &mess_type, &endian_mismatch, sizeof(mess), mess, &more_mess );
  if(ret < 0) {
    SSP_error(ret);
    Bye();
  }
  
  if(Is_regular_mess( service_type )) {
    mess[ret] = 0;
    if(Is_unreliable_mess(service_type)) {
      printf("received UNRELIABLE ");
    }
    else if(Is_reliable_mess(service_type)) {
      printf("received RELIABLE ");
    }
    else if(Is_fifo_mess(service_type) ) {
      printf("received FIFO ");
    }
    else if(Is_causal_mess(service_type)) {
      printf("received CAUSAL ");
    }
    else if(Is_agreed_mess(service_type)) {
      printf("received AGREED ");
    }
    else if(Is_safe_mess(service_type)) {
      printf("received SAFE ");
    }
    printf("message from %s, of type %d, (endian %d) to %d groups \n(%d bytes): %s\n",
	   sender, mess_type, endian_mismatch, num_groups, ret, mess );
  }
  else if(Is_flush_req_mess(service_type)) {
    printf("Received FLUSH_REQ for group %s with %d members, where I am member %d:\n",
	   sender, num_groups, mess_type);
  }
  else if(Is_membership_mess(service_type)) {
    if(Is_reg_memb_mess(service_type)) {
      char key[100];
      int key_len = 0;

      num_bytes = 0;
      grp_id = (group_id *)&mess[num_bytes];
      num_bytes += sizeof(group_id);
      memcpy(&num_vs, mess + num_bytes, sizeof(int32));
      num_bytes += sizeof(int32);
      vs_members = &mess[num_bytes];
      
      printf("Received REGULAR membership for group %s with %d members, where I am member %d:\n",
	     sender, num_groups, mess_type);
      
      for(i=0; i < num_groups; i++) {
	printf("\t%s\n", &target_groups[i][0] );
      }
      printf("grp id is %d %d %d\n",grp_id->id[0], grp_id->id[1], grp_id->id[2] );
      
      if(Is_caused_join_mess(service_type)) {
	printf("Due to the JOIN of %s\n", vs_members);
      }
      else if(Is_caused_leave_mess(service_type)) {
	printf("Due to the LEAVE of %s\n", vs_members);
      }
      else if(Is_caused_disconnect_mess(service_type)) {
	printf("Due to the DISCONNECT of %s\n", vs_members);
      }
      else if(Is_caused_network_mess(service_type)) {
	printf("Due to NETWORK change. ");
	printf("VS set has %d members:\n", num_vs );
	for(i=0; i < num_vs; i++, vs_members+= MAX_GROUP_NAME) {
	  printf("-----------  ");printf("\t%s\n", vs_members );
	}
      }

      SSP_get_key(Mbox, sender, key, &key_len);
      printf("The group key is: 0x");
      for (i = 0; i < key_len; i++){
	printf("%02X", ((unsigned char*)(key))[i]);
      }
      printf("\n");
    }
    else if(Is_transition_mess(service_type)) {
      printf("received TRANSITIONAL membership for group %s\n", sender);
    }
    else if(Is_caused_leave_mess(service_type)) {
      printf("received membership message that left group %s\n", sender );
    }
    else {
      printf("received incorrecty membership message of type %d\n", service_type );
    }
  }
  else {
    printf("received message of unknown message type %d with ret %d\n", service_type, ret);
  }
  
    
    printf("\n");
    printf("User> ");
    fflush(stdout);
}

int Usage(int argc, char **argv) {
    sprintf(User_Name, "user");
    sprintf(Spread_Name, "3333@localhost");
    while(--argc > 0){
	argv++;
	
	if(!strcmp(*argv, "-u") && (argv[1] != NULL)){
	    strcpy(User_Name, argv[1]);
	    argc--; argv++;
	}
	else if (!strcmp(*argv, "-s") && (argv[1] != NULL)){
	    strcpy(Spread_Name, argv[1]); 
	    argc--; argv++;
	}
	else{
	    printf( "Usage: user\n%s\n%s\n",
		    "\t[-u <user name>]  : unique (in this machine) user name",
		    "\t[-s <address>]    : either port or port@machine");
	    return 0;
	}
    }

    return 1;
}

static void Bye() {
    printf("\nBye.\n");
    exit(0);
}
