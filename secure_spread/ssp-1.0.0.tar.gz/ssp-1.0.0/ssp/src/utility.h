/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */




#ifndef INC_UTILITY_H
#define INC_UTILITY_H

char *my_strdup(const char *src);
int   strptrcmp(const void *arg1, const void *arg2);
void *c_my_malloc(size_t size);
void *c_my_realloc(void *ptr, size_t size);
void my_free(char **);

int need_to_realloc_rarely(size_t size, size_t cap);
void *realloc_rarely(void *ptr, size_t size, size_t *cap);

#endif
