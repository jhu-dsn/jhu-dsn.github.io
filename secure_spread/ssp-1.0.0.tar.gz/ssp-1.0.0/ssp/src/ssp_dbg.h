/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */


/***********************************************************************************************/
/* ssp_dbg.h                                                                                   */
/* debug functions                                                                             */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: Nov 4, 2000                                                                        */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#ifndef _SSP_DBG_H_
#define _SSP_DBG_H_

void DEBUG_enter(FILE*, char*);
void DEBUG_leave(FILE*, char*, int);
void DEBUG_leave_ptr(FILE*, char*, void*);
void DEBUG_msg(FILE*, char*, char*);
void DEBUG_open(FILE**, char*);
void DEBUG_close(FILE**);


#if DEBUG_MSG
 
#define ON_DEBUG(x) x
#else
#define ON_DEBUG(x)
#endif

#if TEST_CASCADING 
#define ON_TEST_CASCADING(x) x
#else
#define ON_TEST_CASCADING(x)
#endif

#ifdef TEST_CASCADING
#define TIMEOUT_CASCADING          10
#endif

#if TIMING 
#define ON_TIMING(x) x
#else
#define ON_TIMING(x)
#endif

#if PRINT_TIMING 
#define ON_PRINT_TIMING(x) x
#else
#define ON_PRINT_TIMING(x)
#endif

#if CLQ_TIMING 
#define ON_CLQ_TIMING(x) x
#else
#define ON_CLQ_TIMING(x)
#endif

#if CLQ_PRINT_TIMING 
#define ON_CLQ_PRINT_TIMING(x) x
#else
#define ON_CLQ_PRINT_TIMING(x)
#endif


#endif /*_SSP_AGENT_H_*/























