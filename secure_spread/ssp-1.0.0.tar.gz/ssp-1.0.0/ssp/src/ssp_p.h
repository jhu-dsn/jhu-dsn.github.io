/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */


/***********************************************************************************************/
/* ssp_p.h                                                                                     */
/*                                                                                             */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: Feb 12, 2001                                                                       */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#ifndef _SSP_P_H_
#define _SSP_P_H_

#include "ssp_info.h"

#ifndef SSP_ENCRYPT_MESS_TYPE 
#define SSP_ENCRYPT_MESS_TYPE               ((int16) -32765)
#endif

#ifndef Is_encrypt_mess_type
#define Is_encrypt_mess_type(type)          (type == SSP_ENCRYPT_MESS_TYPE)
#endif

#ifndef SSP_Is_illegal_mess_type
#define SSP_Is_illegal_mess_type(mess_type) (Is_encrypt_mess_type(mess_type))
#endif

#ifndef SSP_NOTHING_TO_DELIVER
#define SSP_NOTHING_TO_DELIVER              -2147483644
#endif

#ifndef SSP_SCAT_ELEM_SIZE
#define SSP_SCAT_ELEM_SIZE (MAX_MESS_SIZE / FL_MAX_SCATTER_ELEMENTS + 1)
#endif

#ifndef SSP_STATIC_KEY_SIZE
#define SSP_STATIC_KEY_SIZE 16 /* to be changed */
#endif

#ifndef MAX_MESS_SIZE
#define MAX_MESS_SIZE  131072
#endif

#ifndef MAX_NUM_GRPS
#define MAX_NUM_GRPS 1024
#endif


void gen_and_push_msg(SSP_Con *con, SSP_Grp *grp, service serv_type);
int  comp_added_membs(SSP_Grp *grp, stdarr* join_set);
int  comp_leave_membs(SSP_Grp *grp, stdarr* leave_set);
int  is_old_member(SSP_Grp *grp);
void choose(char **name, SSP_Grp *grp);
void init_vs_set(SSP_Grp *grp);
int  upd_vs_set_and_get_join_leave_set(SSP_Grp * grp, service serv_type, 
				       stdarr *join_set, stdarr *leave_set);
void set_vs_set_memb_msg(SSP_Msg *msg, SSP_Grp *grp);

#endif /* _SSP_P_H_*/
































