/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */

/***********************************************************************************************/
/* init_key_alg.h                                                                              */
/* These functions create snd destroy SSP_Key_Alg_Info, with the data specific to a key        */
/* agreement algorithm. For now it supports only CLIQUES and CLIQUES CENTRALIZED               */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: July 9, 1999                                                                       */
/* Modified: Jun 23 by Cristina Nita-Rotaru                                                    */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/


#ifndef INIT_KEY_ALG_H
#define INIT_KEY_ALG_H

#include "ssp_info.h"

SSP_Ka* SSP_Ka_create(unsigned int key_len, int alg);
void SSP_Ka_destroy(SSP_Ka *ka);

#endif /* INIT_KEY_ALG_H */
