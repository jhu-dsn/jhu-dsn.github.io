
/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */

/* ******************************************************************************************* */
/* encrypt.c                                                                                   */
/* Encrypt info                                                                                */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: June 28, 1999                                                                      */
/* Modified: June 23, 2000 by Cristina Nita-Rotaru                                             */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/* ******************************************************************************************* */

#include <stdlib.h>
#include <netinet/in.h>
#include <stdio.h>


#include "utility.h"
#include "encrypt.h"

#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif

/* ============================  blowfish algorithm specific  ================================ */

/* BF_Alg_init ---------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------*/
static void BF_Alg_init(BF_Alg *bf) {
  bf->bf_P = 0;
  bf->bf_S = 0;
}

/* BF_Alg_destroy ------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------*/
static void BF_Alg_destroy(BF_Alg *bf) {
  if(bf->bf_P) {
    free(bf->bf_P);
    bf->bf_P = NULL;
  }
  
  if(bf->bf_S) {
    free(bf->bf_S);
    bf->bf_S = NULL;
  }
}

/* BF_Alg_free ----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------*/
void BF_Alg_free(BF_Alg **bf) {
  if(*bf) {
    BF_Alg_destroy(*bf);
    free(*bf);
    *bf = NULL;
  }  
}

/* BF_Alg_create -------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------*/
BF_Alg *BF_Alg_create() {
  BF_Alg *bf = (BF_Alg*) malloc(sizeof(BF_Alg));
  
  if(!bf) {
    exit(fprintf(stderr, "BF_Alg_create: malloc failed 1\n"));
  }
  
  bf->bf_P = (UWORD_32bits*) malloc((bf_N + 2) * sizeof(UWORD_32bits));
  bf->bf_S = (UWORD_32bits(*)[256]) malloc(4 * 256 * sizeof(UWORD_32bits));
  
  if (!bf->bf_P || !bf->bf_S) {
    exit(fprintf(stderr, "BF_Alg_create: mymalloc failed 2\n"));
  }

  return bf;
}

/* endian_flip_32 -------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------*/
static void endian_flip32(char *buf) {
  char tmp;
  
  tmp    = buf[0];
  buf[0] = buf[3];
  buf[3] = tmp;
  
  tmp    = buf[1];
  buf[1] = buf[2];
  buf[2] = tmp;
}

/* ============================  wrapper functions for blowfish  ============================= */

/* BF_init --------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------*/
unsigned int BF_init(unsigned char* key, unsigned int keybytes, void *void_info) {
  return 0;
}

/* BF_key_chg ----------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------*/
unsigned int BF_key_chg(unsigned char* key, unsigned int keybytes, void *void_info) {
  BF_Alg *bf = (BF_Alg*) void_info;
  
  if(keybytes < 8) {
    exit(fprintf(stderr, "BF_key_chg: key length too small\n"));
  }
  
  Blowfish_initialize(bf->bf_P, bf->bf_S);
  Blowfish_change_key(key, keybytes, bf->bf_P, bf->bf_S);
  
  return 0;
}

/* BF_enc --------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------*/
unsigned int BF_enc(char *buf, unsigned int count, void *void_info, int endian) {
  BF_Alg *bf = (BF_Alg*) void_info;
  
  Blowfish_encipher((UWORD_32bits*)buf, (UWORD_32bits*)(buf+4), bf->bf_P, bf->bf_S);
  
  return 8;
} 

/* BF_dec --------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------*/
unsigned int BF_dec(char *buf, unsigned int count, void *void_info, int endian) {
  BF_Alg *bf = (BF_Alg*) void_info;
  
  if(count < 8) {
    exit(fprintf(stderr, "BF_dec: count less than 8\n"));
  }
  
  if(endian) {
    endian_flip32(buf);
    endian_flip32(buf + 4);
  }
  
  Blowfish_decipher((UWORD_32bits*)buf, (UWORD_32bits*)(buf+4), bf->bf_P, bf->bf_S);
  
  if(endian) {
    endian_flip32(buf);
    endian_flip32(buf + 4);
  }
    
  return 8;
}











