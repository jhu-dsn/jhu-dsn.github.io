/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */


/***********************************************************************************************/
/* scatter.c                                                                                   */
/*                                                                                             */
/* John Schultz                                                                                */
/* Created: June 23, 1999                                                                      */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "utility.h"
#include "scatter.h"

#ifdef USE_DMALLOC
#include <dmalloc.h>
#endif

/**** NEED TO CHECK THAT scatter_extract2 and scatter_extract3 are passing proper 
      values to scatter_extract!! ****/

/* The scatter structure is defined in sp.h. In the functions below the following set ups of 
   scatter structures are considered
   illegal:  The num_elements field is less than zero or greater than MAX_SCATTER_ELEMENTS or 
   an element's length is less than zero.
   
   Most functions will return ILLEGAL_MESSAGE on detecting an illegal structure. However, since 
   most detections will occur iteratively as the structure is gone through the fcns might affect 
   the legal portions of the structure. Note however, that some functions can succeed with an 
   illegal scatter structure.  For example, if you call scatter_alloc with a mess_len == 0 then 
   nothing is done and it immediately returns.
*/

int Is_legal_scat_position(const scatter *scat, unsigned int e_index, unsigned int buff_index) {
  return scat->num_elements >= 0 && scat->num_elements <= MAX_SCATTER_ELEMENTS &&
    ((e_index < scat->num_elements && scat->elements[e_index].len >= 0 && 
      buff_index < scat->elements[e_index].len) || 
     (e_index == scat->num_elements && buff_index == 0));
}


int Is_end_of_scat(const scatter *scat, unsigned int e_index, unsigned int buff_index) {
  return scat->num_elements == e_index && buff_index == 0;
}

void scat_init(scatter *scat) { scat->num_elements = 0; }

/* int scatter_destroy: frees all buffers of len > 0. Returns ILLEGAL_MESSAGE for illegal 
   structs and 0 on success */
int scat_destroy(scatter *scat) {
  int i, num_elems, ret = 0;

  if ((num_elems = scat->num_elements) < 0 || num_elems > MAX_SCATTER_ELEMENTS)
    return ILLEGAL_MESSAGE;  
  
  for (i = 0; i < num_elems; ++i) {
    if (scat->elements[i].len > 0)
      free(scat->elements[i].buf);
    
    else if (scat->elements[i].len < 0)
      ret = ILLEGAL_MESSAGE;
  }
  return ret;
}

/* int scatter_capacity: returns the maximum amount of data this structure can hold. */
int scat_cap(scatter *scat) {
  int total, num_elems, i;
  
  if ((num_elems = scat->num_elements) < 0 || num_elems > MAX_SCATTER_ELEMENTS)
    return ILLEGAL_MESSAGE;
  
  total = 0;
  for (i = 0; i < num_elems; ++i)
    if (scat->elements[i].len < 0)
      return ILLEGAL_MESSAGE;
    else
      total += scat->elements[i].len;

  return total;
}

/* int scatter_copy: copies the first num_bytes bytes from the src scatter structure to 
   the dst scatter structure. If dst is too small to hold num_bytes, then as much as can 
   be copied will be copied and BUFFER_TOO_SHORT will be returned.  On an illegal structure 
   ILLEGAL_MESSAGE is returned, otherwise the number of bytes copied will be returned. 
*/
int scat_copy(scatter *dst, const scatter *src, unsigned int num_bytes) { 
  return scat_get(dst, 0, 0, 0, src, 0, 0, 0, num_bytes); 
}

int scat_copy2(char *dst, const scatter *src, unsigned int num_bytes) {
  scatter dest;
  
  dest.num_elements    = 1;
  dest.elements[0].buf = dst;
  dest.elements[0].len = num_bytes;
  
  return scat_copy(&dest, src, num_bytes);
}

int scat_copy3(scatter *dst, char *src, unsigned int num_bytes) {
  scatter srce;
  
  srce.num_elements    = 1;
  srce.elements[0].buf = src;
  srce.elements[0].len = num_bytes;

  return scat_copy(dst, &srce, num_bytes);
}

/* scatter_skip: returns the number of bytes skipped and modifies elem_index and buf_index 
   only if it can successfully skip skip_bytes bytes.  If it cannot successfully skip 
   skip_bytes bytes then elem_index and buf_index are uneffected and it returns the maximum 
   number of bytes it could have successfully skipped.
*/
int scat_skip(const scatter *scat, unsigned int *elem_index, unsigned int *buff_index, 
		 unsigned int fixed_elem_size, unsigned int skip_bytes) {
  int skip_bytes2, skip_bytes3, first_skip;
  unsigned int e_index, b_index, num_elems;
  
  if (skip_bytes == 0)
    return 0;
  
  else if (!Is_legal_scat_position(scat, *elem_index, *buff_index))
    return ILLEGAL_MESSAGE;
  
  else if (Is_end_of_scat(scat, *elem_index, *buff_index)) /* can't skip any if you 
							      are at end of scatter */
    return 0;
  
  skip_bytes2 = skip_bytes3 = skip_bytes;
  num_elems   = scat->num_elements;
  e_index     = *elem_index;
  b_index     = *buff_index;
  first_skip  = scat->elements[e_index].len - b_index; 
  
  if (skip_bytes2 < first_skip) {
    *buff_index += skip_bytes2;
    return skip_bytes2;
  }
  else {
    skip_bytes2 -= first_skip;
    e_index++;
  }

  if (fixed_elem_size > 0) {
    e_index += skip_bytes2 / fixed_elem_size;
    b_index  = skip_bytes2 % fixed_elem_size;
    
    if (!Is_legal_scat_position(scat, e_index, b_index))
      return (num_elems - *elem_index - 1) * fixed_elem_size + first_skip;
  }
  else {
    for (; e_index < num_elems; ++e_index) {
      if (scat->elements[e_index].len < 0)
	return ILLEGAL_MESSAGE;
      
      else if ((skip_bytes2 -= scat->elements[e_index].len) < 0) {
	skip_bytes2 += scat->elements[e_index].len;
	break;
      }
    }
    if (e_index == num_elems && skip_bytes2)
      return skip_bytes3 - skip_bytes2;
    
    else 
      b_index = skip_bytes2;
  }

  *elem_index = e_index;
  *buff_index  = b_index;

  return skip_bytes3;;
}

int scat_get(scatter *dst, int dst_elem_index, unsigned int dst_fixed_elem_size, 
	     unsigned int dst_index, const scatter *src, int src_elem_index, 
	     unsigned int src_fixed_elem_size, unsigned int src_index, unsigned int num_bytes) {
  unsigned int dst_num_elems, src_num_elems, dstCurrInd, srcCurrInd;
  unsigned int dstLeft, srcLeft, org_len, copySize, i, j;
  int err;
  
  if (num_bytes == 0)
    return 0;
  
  else if (dst->num_elements < 0 || dst->num_elements > MAX_SCATTER_ELEMENTS || 
	   src->num_elements < 0 || src->num_elements > MAX_SCATTER_ELEMENTS)
    return ILLEGAL_MESSAGE;
  
  dst_num_elems = dst->num_elements;
  src_num_elems = src->num_elements;
  
  /*
    printf("SCATTER_EXTRACT: d_elem %d, d_fixed %u, d_index %d, s_elem %d, s_fixed %u, 
    s_index %u, copy_size %u\n"
    "\td_num_elems %d, s_num_elems %d\n",
    dst_elem_index, dst_fixed_elem_size, dst_index, src_elem_index, src_fixed_elem_size, 
    src_index, num_bytes,
    dst_num_elems, src_num_elems);
  */

  /* These two if-else statements find the starting points for the copy in the dst and 
     src respectively. */
  /* i indexes the current element of dst, j indexes the current element of src */ 
  /* dstCurrInd is an index into dst->elements[i].buf, srcCurrInd is an index into 
     src->elements[j].buf */
  /* dstLeft == dst->elements[i].len - dstCurrInd, srcLeft == 
     src->elements[j].len - srcCurrInd */
  /* num_bytes indicates how much is left of the message to copy */
  
  if (dst_elem_index >= 0){
    i          = dst_elem_index;
    dstCurrInd = dst_index;
    
    if (!Is_legal_scat_position(dst, i, dstCurrInd))
      return ILLEGAL_MESSAGE;
  }
  else
    {
      i          = 0;
      dstCurrInd = 0;
      
      if ((err = scat_skip(dst, &i, &dstCurrInd, dst_fixed_elem_size, dst_index)) != dst_index) {
	if (err >= 0)
	  return ILLEGAL_MESSAGE;    /* index out of range */
	else                         
	  return err;                /* an illegal structure or something */
      }
    }
  
  if (src_elem_index >= 0) {
    j          = src_elem_index;
    srcCurrInd = src_index;
    
    if (!Is_legal_scat_position(src, j, srcCurrInd))
      return ILLEGAL_MESSAGE;
  } 
  else {
    j          = 0;
    srcCurrInd = 0;
    
    if ((err = scat_skip(src, &j, &srcCurrInd, src_fixed_elem_size, src_index)) != src_index) {
      if (err >= 0)
	return ILLEGAL_MESSAGE;    /* index out of range */
      else
	return err;                /* an illegal structure or something */
    }
  }

  if (Is_end_of_scat(dst, i, dstCurrInd) || Is_end_of_scat(src, j, srcCurrInd)) 
    /* copy size ( > 0) goes out of range */
    return ILLEGAL_MESSAGE;
  
  dstLeft = dst->elements[i].len - dstCurrInd;
  srcLeft = src->elements[j].len - srcCurrInd;
  org_len = num_bytes;                          /* keep a copy of the original copy size */
  
  /*
  printf("SCATTER_EXTRACT: after skip: i %d, dstCurrInd %d, j %d, srcCurrInd %d, dstLeft %d, 
  srcLeft %d\n", 
  i, dstCurrInd, j, srcCurrInd, dstLeft, srcLeft);
  */
  
  while (i < dst_num_elems && j < src_num_elems && num_bytes) { 
    copySize = (dstLeft < srcLeft) ? dstLeft : srcLeft;
    copySize = (copySize < num_bytes) ? copySize : num_bytes;   /* copySize = min(dstLeft, srcLeft, num_bytes); */
    
    if (copySize < 0)             /* implies either dstLeft or srcLeft was negative */
      return ILLEGAL_MESSAGE;
    
    memcpy(dst->elements[i].buf + dstCurrInd, src->elements[j].buf + srcCurrInd, copySize); 
    num_bytes -= copySize; 

    if (copySize == dstLeft) {   /* copied what was left of dst->elements[i].buf */
      dstCurrInd = 0; 
      if (++i < dst_num_elems)
	dstLeft = dst->elements[i].len;
    } 
    else { 
      dstCurrInd += copySize; 
      dstLeft    -= copySize; 
    } 
    
    if (copySize == srcLeft) {   /* copied what was left of src->elements[j].buf */
      srcCurrInd = 0;
      if (++j < src_num_elems)
	srcLeft = src->elements[j].len;
    } 
    else { 
      srcCurrInd += copySize; 
      srcLeft    -= copySize; 
    } 
  }
  
  if (num_bytes) { /* not all of message was copied */
    if (j == src_num_elems) {
      exit(fprintf(stderr, "Exception: scatter_extract: source scatter structure wasn't large "
		   "enough\n"));
      return ILLEGAL_MESSAGE;
    }
    else return BUFFER_TOO_SHORT;
  }
  return org_len;  
}

int scat_get2(char *dst, const scatter *src, int src_elem_index, 
	      unsigned int src_fixed_elem_size, unsigned int src_index, unsigned int num_bytes) { 
  scatter dest;
  
  dest.num_elements    = 1;
  dest.elements[0].buf = dst;
  dest.elements[0].len = num_bytes;
  
  return scat_get(&dest, 0, 0, 0, src, src_elem_index, src_fixed_elem_size, src_index, num_bytes);
}

/* int scatter_extract3: is actually more like a scatter_copy.  It copies num_bytes bytes 
   from the src to the dst after skipping over dst_index bytes in the dst. 
*/
int scat_get3(scatter *dst, int dst_elem_index, unsigned int dst_fixed_elem_size, 
	      unsigned int dst_index, char *src, unsigned int num_bytes) {
  scatter srce;
  
  srce.num_elements    = 1;
  srce.elements[0].buf = src;
  srce.elements[0].len = num_bytes;

  return scat_get(dst, dst_elem_index, dst_fixed_elem_size, dst_index, &srce, 0, 0, 0, num_bytes);
}

int scat_get10(scatter *dst, int *dst_elem_index, unsigned int dst_fixed_elem_size, 
	       unsigned int *dst_index, const scatter *src, int *src_elem_index, 
	       unsigned int src_fixed_elem_size, 
	       unsigned int *src_index, unsigned int num_bytes) {
  unsigned int dst_num_elems, src_num_elems, dstCurrInd, srcCurrInd;
  unsigned int dstLeft, srcLeft, org_len, copySize, i, j;
  int err;
  
  if (num_bytes == 0)
    return 0;
  
  else if (dst->num_elements < 0 || dst->num_elements > MAX_SCATTER_ELEMENTS || 
	   src->num_elements < 0 || src->num_elements > MAX_SCATTER_ELEMENTS)
    return ILLEGAL_MESSAGE;
  
  dst_num_elems = dst->num_elements;
  src_num_elems = src->num_elements;
  
  /*
    printf("SCATTER_EXTRACT: d_elem %d, d_fixed %u, d_index %d, s_elem %d, s_fixed %u, 
    s_index %u, copy_size %u\n"
    "\td_num_elems %d, s_num_elems %d\n",
    dst_elem_index, dst_fixed_elem_size, dst_index, src_elem_index, src_fixed_elem_size, 
    src_index, num_bytes,
    dst_num_elems, src_num_elems);
  */
  
  /* These two if-else statements find the starting points for the copy in the dst and src 
     respectively. */
  /* i indexes the current element of dst, j indexes the current element of src */ 
  /* dstCurrInd is an index into dst->elements[i].buf, srcCurrInd is an index into 
     src->elements[j].buf */
  /* dstLeft == dst->elements[i].len - dstCurrInd, srcLeft == src->elements[j].len - srcCurrInd */
  /* num_bytes indicates how much is left of the message to copy */
  
  if (*dst_elem_index >= 0) {
    i          = *dst_elem_index;
    dstCurrInd = *dst_index;

    if (!Is_legal_scat_position(dst, i, dstCurrInd))
      return ILLEGAL_MESSAGE;
  }
  else {
    i          = 0;
    dstCurrInd = 0;
    
    if ((err = scat_skip(dst, &i, &dstCurrInd, dst_fixed_elem_size, *dst_index)) != *dst_index) {
      if (err >= 0)
	return ILLEGAL_MESSAGE;    /* index out of range */
      else                         
	return err;                /* an illegal structure or something */
    }
  }

  if (*src_elem_index >= 0) {
    j          = *src_elem_index;
    srcCurrInd = *src_index;
    
    if (!Is_legal_scat_position(src, j, srcCurrInd))
      return ILLEGAL_MESSAGE;
  } 
  else {
    j          = 0;
    srcCurrInd = 0;
    
    if ((err = scat_skip(src, &j, &srcCurrInd, src_fixed_elem_size, *src_index)) != *src_index) {
      if (err >= 0)
	return ILLEGAL_MESSAGE;    /* index out of range */
      else
	return err;                /* an illegal structure or something */
    }
  }

  if (Is_end_of_scat(dst, i, dstCurrInd) || Is_end_of_scat(src, j, srcCurrInd)) 
    /* copy size ( > 0) goes out of range */
    return ILLEGAL_MESSAGE;
  
  dstLeft = dst->elements[i].len - dstCurrInd;
  srcLeft = src->elements[j].len - srcCurrInd;
  org_len = num_bytes;                          /* keep a copy of the original copy size */

  /*
    printf("SCATTER_EXTRACT: after skip: i %d, dstCurrInd %d, j %d, srcCurrInd %d, 
    dstLeft %d, srcLeft %d\n", 
    i, dstCurrInd, j, srcCurrInd, dstLeft, srcLeft);
  */
  
  while (i < dst_num_elems && j < src_num_elems && num_bytes) { 
    copySize = (dstLeft < srcLeft) ? dstLeft : srcLeft;
    copySize = (copySize < num_bytes) ? copySize : num_bytes;   
    /* copySize = min(dstLeft, srcLeft, num_bytes); */
    
    if (copySize < 0)             /* implies either dstLeft or srcLeft was negative */
      return ILLEGAL_MESSAGE;
    
    memcpy(dst->elements[i].buf + dstCurrInd, src->elements[j].buf + srcCurrInd, copySize); 
    num_bytes -= copySize; 
    
    if (copySize == dstLeft) {   /* copied what was left of dst->elements[i].buf */
      dstCurrInd = 0; 
      if (++i < dst_num_elems)
	dstLeft = dst->elements[i].len;
    } 
    else { 
      dstCurrInd += copySize; 
      dstLeft    -= copySize; 
    } 
    
    if (copySize == srcLeft) {   /* copied what was left of src->elements[j].buf */
      srcCurrInd = 0;
      if (++j < src_num_elems)
	srcLeft = src->elements[j].len;
    } 
    else { 
      srcCurrInd += copySize; 
      srcLeft    -= copySize; 
    } 
  }
  
  if (num_bytes) { /* not all of message was copied */
    if (j == src_num_elems) {
      exit(fprintf(stderr, "Exception: scatter_extract: source scatter structure wasn't "
		   "large enough\n"));
      return ILLEGAL_MESSAGE;
    }
    else return BUFFER_TOO_SHORT;
  }

  *dst_elem_index = i;
  *dst_index      = dstCurrInd;
  *src_elem_index = j;
  *src_index      = srcCurrInd;

  return org_len;  
}

int scat_get11(char *dst, const scatter *src, int *src_elem_index, 
	       unsigned int src_fixed_elem_size, unsigned int *src_index, unsigned int num_bytes){ 
  scatter dest;
  int dst_elem_index = -1;
  unsigned int dst_index     = 0;

  dest.num_elements    = 1;
  dest.elements[0].buf = dst;
  dest.elements[0].len = num_bytes;

  return scat_get10(&dest, &dst_elem_index, 0, &dst_index, src, src_elem_index, 
		    src_fixed_elem_size, src_index, num_bytes);
}

int scat_get12(scatter *dst, int *dst_elem_index, unsigned int dst_fixed_elem_size, 
	       unsigned int *dst_index, char *src, unsigned int num_bytes)  {
  scatter srce;
  int src_elem_index = -1;
  unsigned int src_index     = 0;

  srce.num_elements    = 1;
  srce.elements[0].buf = src;
  srce.elements[0].len = num_bytes;

  return scat_get10(dst, dst_elem_index, dst_fixed_elem_size, dst_index, &srce, 
		    &src_elem_index, 0, &src_index, num_bytes);
}

/* int scatter_alloc: allocates new buffers for scatter elements (with the same buffer length) 
   that contain any portion of the first mess_len bytes of storage in the structure. It returns 
   the number of bytes malloc'ed on success and ILLEGAL_MESSAGE on failure. 
*/
int scat_alloc(scatter *scat, unsigned int in_len) {
  int i, num_elems, size, mess_len = in_len, org_len = mess_len;
  
  if (mess_len == 0)
    return 0;
  
  else if ((num_elems = scat->num_elements) < 0 || num_elems > MAX_SCATTER_ELEMENTS)
    return ILLEGAL_MESSAGE;
  
  for (i = 0; i < num_elems && mess_len > 0; ++i) 
    if ((size = scat->elements[i].len) >= 0) {
      scat->elements[i].buf = size ? (char*) malloc(size) : 0;
      mess_len -= size;
      
      if (!scat->elements[i].buf && size) { 
	exit(fprintf(stderr, "Exception: scatter_alloc: %p = malloc(%d) failed\n", scat->elements[i].buf, size));
    }
    }
    else return ILLEGAL_MESSAGE;

  if (mess_len > 0)
    return ILLEGAL_MESSAGE;
  
  return org_len - mess_len;
}

/* int scatter_set: sets the dst to point to the buffers in src that contain any portion 
   of the first mess_len bytes of source data. Returns ILLEGAL_MESSAGE on detection of an 
   illegal structure, 0 on success. 
*/
int scat_set(scatter *dst, const scatter *src, int fixed_elem_size, unsigned int in_len) {
  int i, num_elems, src_num_elems, mess_len = in_len;
  
  if (mess_len == 0)
    dst->num_elements = 0;

  else if ((src_num_elems = src->num_elements) < 0 || src_num_elems > MAX_SCATTER_ELEMENTS)
    return ILLEGAL_MESSAGE;

  else if (fixed_elem_size > 0) {
    /* calculate number of effected scat_elements */
    if ((num_elems = mess_len / fixed_elem_size + !!(mess_len % fixed_elem_size)) 
	> MAX_SCATTER_ELEMENTS)
      return ILLEGAL_MESSAGE;
    
    memcpy(dst->elements, src->elements, num_elems * sizeof(scat_element));
    dst->num_elements = num_elems;
  }
  else {
    for (i = 0; i < src_num_elems && mess_len > 0; ++i) {
      if (src->elements[i].len < 0)
	return ILLEGAL_MESSAGE;

      dst->elements[i] = src->elements[i];
      mess_len -= src->elements[i].len;
    }
    dst->num_elements = i;   

    if (mess_len > 0)
      return ILLEGAL_MESSAGE;
  }
  return 0;
}

/* returns < 0 on error, the capacity of the dupped object otherwise */

int scat_dup(scatter *dst, scatter *src) {
  int i, num_elems, size, ret = 0;
  
  if (!src) {
    if (dst)
      dst->num_elements = 0;
    return 0;
  }
  else if (!dst)
    return ILLEGAL_MESSAGE;

  else if ((num_elems = src->num_elements) < 0 || num_elems > MAX_SCATTER_ELEMENTS)
    return ILLEGAL_MESSAGE;

  for (i = 0; i < num_elems; ++i) {
    if ((size = src->elements[i].len) < 0)
      break;                              /* clean up stuff already allocated */

    dst->elements[i].len = size;
    dst->elements[i].buf = size ? (char*) malloc(size) : 0;

    if (!dst->elements[i].buf && size) {
      exit(fprintf(stderr, "Exception: scatter_dup: malloc failed\n"));
    }

    memcpy(dst->elements[i].buf, src->elements[i].buf, size);
    ret += size;
  }

  dst->num_elements = i;

  if (dst->num_elements != num_elems) {
    scat_destroy(dst);
    dst->num_elements = 0;
    return ILLEGAL_MESSAGE;
  }
  return ret;
}

int scat_dup2(scatter *dst, scatter *src, unsigned int in_size) {
  int i, num_elems, cpy_size, size = in_size;

  if (!src) {
    if (dst)
      dst->num_elements = 0;
    return 0;
  }
  else if (!dst)
    return ILLEGAL_MESSAGE;

  else if ((num_elems = src->num_elements) < 0 || num_elems > MAX_SCATTER_ELEMENTS)
    return ILLEGAL_MESSAGE;

  for (i = 0; i < num_elems && size; ++i)  {
    cpy_size = size < src->elements[i].len ? size : src->elements[i].len;
    
    if (cpy_size < 0) 
      break;                           /* clean up stuff already allocated */

    dst->elements[i].len = cpy_size;
    dst->elements[i].buf = cpy_size ? (char*) malloc(cpy_size) : 0;
    

    if (!dst->elements[i].buf && cpy_size) {
      exit(fprintf(stderr, "Exception: scatter_dup: malloc(%d) failed2\n", cpy_size));
    }
    
    memcpy(dst->elements[i].buf, src->elements[i].buf, cpy_size);
    size -= cpy_size;
  }

  dst->num_elements = i;

  if (size != 0) {
    scat_destroy(dst);                /* clean up any buffers we might have constructed */
    dst->num_elements = 0;
    return ILLEGAL_MESSAGE;
  }
  return in_size;
}






