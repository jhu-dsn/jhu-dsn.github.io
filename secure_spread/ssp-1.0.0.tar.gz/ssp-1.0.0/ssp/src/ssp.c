/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */


/***********************************************************************************************/
/* ssp.c                                                                                       */
/* Secure spread implementation                                                                */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: June 22, 1999                                                                      */
/* Modified: Jun 29, 2000 by Cristina Nita-Rotaru                                              */
/* Modified: Nov 5, 2000 by Cristina Nita-Rotaru                                               */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "utility.h"
#include "encrypt.h"
#include "ssp_info.h"
#include "scatter_cryptor.h"
#include "init_encrypt.h"
#include "init_key_alg.h"
#include "clq_alg.h"
#include "ssp_dbg.h"
#include "ssp_p.h"
#include "ssp.h"


#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif

#ifdef TIMING
#include "timing.h"
#endif

static int Conns_Size = 0, Num_Conns = 0;
static SSP_Con **Conns = 0;

static scatter *Glb_Buff = 0;
static char (*Glb_Grps)[MAX_GROUP_NAME] = 0;

static int const SSP_MAJOR_VERSION = 1;
static int const SSP_MINOR_VERSION = 0;
static int const SSP_PATCH_VERSION = 0;

/* logging to stderr */
FILE *f_dbg; 
char *dbg_file = NULL;

/* decomment to log to a file */
/* char *dbg_file = "ssp.log"; */

/* ====================== nonvisible library functions ======================================= */

/* creates_glb ---------------------------------------------------------------------------------
   This function is called after the first connection was establish. It allocates the global
   buffers. It exits if malloc fails.
-----------------------------------------------------------------------------------------------*/
static void create_glb() {
  int i;

  DEBUG_enter(f_dbg, "create_glb");
  
  if(Num_Conns != 1 || Conns_Size || Conns || Glb_Buff || Glb_Grps) {
    exit(fprintf(stderr, "create_glb: library in incosistent state\n"));
  }
  
  Glb_Grps = (char(*)[MAX_GROUP_NAME]) malloc(MAX_NUM_GRPS * MAX_GROUP_NAME);
  Glb_Buff = (scatter*) malloc(sizeof(scatter));  
  if(!Glb_Grps || !Glb_Buff) {
    exit(fprintf(stderr, "create_glb: malloc failed\n"));  
  }

  Glb_Buff->num_elements = FL_MAX_SCATTER_ELEMENTS; 
  for(i = 0; i < FL_MAX_SCATTER_ELEMENTS; ++i) {
    Glb_Buff->elements[i].len = SSP_SCAT_ELEM_SIZE;
    Glb_Buff->elements[i].buf = (char*) malloc(SSP_SCAT_ELEM_SIZE);
    if(!Glb_Buff->elements[i].buf) {
      exit(fprintf(stderr, "create_glb: malloc failed 2\n"));
    }
  } 

  DEBUG_leave(f_dbg, "create_glb", 0);  
}


/* free_glb ------------------------------------------------------------------------------------
   This function is called after no connection exists, and it frees whatever SSP_init allocated.
-----------------------------------------------------------------------------------------------*/
static void free_glb() {
  DEBUG_enter(f_dbg, "free_glb");
  
  if(Num_Conns != 0 || !Conns_Size || !Conns || !Glb_Buff || !Glb_Grps) {
    exit(fprintf(stderr, "free_glb: library in incosistent state\n"));
  }
  
  free(Glb_Grps);
  free(Conns);
  scat_destroy(Glb_Buff);
  free(Glb_Buff);
  
  Conns      = 0;
  Conns_Size = 0;
  Glb_Grps   = 0;
  Glb_Buff   = 0;

  DEBUG_leave(f_dbg, "free_glb", 0);
}


/* glb_2_user -----------------------------------------------------------------------------------
   This function is called when a message that was just received from Flush, will be delivered
   to the apllication. In this case the message does not get stacked in the connection queue
   so all data, but the 'big ones' (message and groups) are already set in the variables provided
   by the user. The only things that need to be 'filled' are the groups and the body message.
   Note: groups and message body are not read in user's buffers, but in some global buffers.
---------------------------------------------------------------------------------------------- */
static int glb_2_usr(int max_grps, int *num_grps, char grps[][MAX_GROUP_NAME], int msg_len, 
		     scatter *body, char src_grps[][MAX_GROUP_NAME], scatter *src_msg) {
  int cpy_num_grps;
  int ret;

  DEBUG_enter(f_dbg, "glb_2_usr");
  
  if (*num_grps <= max_grps) {
    cpy_num_grps = *num_grps;
  }
  else {
    cpy_num_grps = max_grps > 0 ? max_grps : 0;
    *num_grps = -*num_grps;
  }
  
  memcpy(grps, src_grps, cpy_num_grps * MAX_GROUP_NAME);
  ret = scat_copy(body, src_msg, msg_len);
  
  DEBUG_leave(f_dbg, "glb_2_usr", ret);
  return ret;
}

/* deliv_msg ----------------------------------------------------------------------------------
   This function is called when the message is delivered to the application from the connection
   queue (this is the most common case). In this case all the variables provided by the user
   needs to be 'filled'; 
---------------------------------------------------------------------------------------------- */
int deliv_msg(SSP_Msg *msg, service *serv_type, char sender[MAX_GROUP_NAME], int max_grps, 
	      int *num_grps, char grps[][MAX_GROUP_NAME], int16 *msg_type, int *endian_mism, 
	      scatter *scat) {
  int ret = 0;
  int cpy_num_grps;

  DEBUG_enter(f_dbg, "deliv_msg");

  if (msg->num_grps < 0) {
    exit(fprintf(stderr, "deliv_msg: expect mess->num_groups(%d) to be non-negative", 
		 msg->num_grps));
  }
  else if (msg->num_grps <= max_grps) {
    cpy_num_grps = msg->num_grps;
    *num_grps  = msg->num_grps;
  }
  else {
    cpy_num_grps = max_grps > 0 ? max_grps : 0;
    *num_grps  = -msg->num_grps;
  }
  *serv_type = msg->serv_type; 
  strcpy(sender, msg->sender); 
  memcpy(grps, msg->grps, cpy_num_grps * MAX_GROUP_NAME);
  *msg_type = msg->msg_type;
  *endian_mism = msg->endian_mism; 
  ret = msg->msg_len;
  if(msg->msg_len > 0) {
    ret = scat_copy(scat, msg->scat, msg->msg_len);
  }

  DEBUG_leave(f_dbg, "deliv_msg", ret);
  return ret;
}



/* add_group  ----------------------------------------------------------------------------------
   This function creates the group info for a new member joining a group. If it does not
   succeed, it returns a negative value and it sets *group = NULL. Otherwise, *group indicates
   the new group created.
-----------------------------------------------------------------------------------------------*/
static int add_group(SSP_Con *con, SSP_Grp **grp, char *join){
  SSP_Grp *grp_ptr;
  SSP_Enc *enc;
  SSP_Ka  *ka;
  int ret = 0;
  
  DEBUG_enter(f_dbg, "add_group");
  
  grp_ptr = SSP_Con_addGrp(con, join);	
  enc = SSP_Enc_create(SSP_STATIC_KEY_SIZE, SSP_BLOWFISH_ALG);
  if(enc == NULL) {
    SSP_Con_delGrp(con, join);    
    ret = ENCRYPTION_NOT_SUPPORTED;
    *grp = NULL;
    goto end;
  }

  ka = SSP_Ka_create(SSP_STATIC_KEY_SIZE, SSP_CLIQUES_ALG);
  
  if(ka == NULL) {
    SSP_Con_delGrp(con, join);    
    ret = KEY_AGR_NOT_SUPPORTED;
    *grp = NULL;
    goto end;
  }
  
  grp_ptr->enc = enc;
  grp_ptr->ka = ka;
  (*grp_ptr->enc->init_fcn)(grp_ptr->enc->key, grp_ptr->enc->key_len, grp_ptr->enc->info); 
  *grp = grp_ptr;
  
 end:
  DEBUG_leave(f_dbg, "add_group", ret);
  return ret;
}

/* upd_grp_membs --------------------------------------------------------------------------------
   This function updates the information about the previous and the cuurent members list for a
   group, using the membership information. It also sets the vs set. If the event was a join
   the joiner field will be set, otherwise joiner is NULL. If the event was a leave event,
   the leaver field will contain the leaver, otherwise null.

  The memb message provides the following information:
       group_id; 
       int num_members; 
       char groups[][MAX_GROUP_NAME]; 
       The content of the groups array is dependent upon the type of the membership change: 
       CAUSED_BY_JOIN:       Groups contains the private group of the joining process. 
       CAUSED_BY_LEAVE:      Groups contains the private group of the leaving process. 
       CAUSED_BY_DISCONNECT: Groups contains the private group of the disconnecting process. 
       CAUSED_BY_NETWORK:    Groups contains the group names of the members of the new membership
                             who came with me (the current process) to the new membership. The 
			     new members can be determined by comparing it with the groups 
			     parameter of the SP_receive call. 

       If this is a MEMB_MESSAGE (i.e. membership message) and it is neither a REG_MEMB_MESS or 
       a TRANS_MEMB_MESS, then it represents exactly the situation where the member receiving 
       this message has left a group and this is notification that the leave has occured, thus 
       it is sometimes called a self-leave message. 
--------------------------------------------------------------------------------------------- */
static void upd_grp_membs(SSP_Grp *grp, SSP_Msg *msg) {
  int size, i;
  
  DEBUG_enter(f_dbg, "upd_grp_membs");

  if(grp->curr_membs) {            /* move curr_membs to prev_membs */
    if(grp->prev_membs) {
      free(grp->prev_membs);
    }
    grp->prev_membs = grp->curr_membs;
    stdhash_destruct(&grp->prev_membs_hash);
    stdhash_copy_construct(&grp->prev_membs_hash, &grp->curr_membs_hash);
    stdhash_clear(&grp->curr_membs_hash);
  }

  ON_DEBUG(
    printf("-------------: Prev sp membership\n");
    for (i = 0; i < stdhash_size(&grp->prev_membs_hash); ++i){
      char *p = grp->prev_membs[i];
      printf("----------->   %s\n", p);
    }
  )

  grp->num_membs = msg->num_grps;
  ON_DEBUG(
    printf("-------------: New sp membership  %d members:\n", grp->num_membs);
  )
  size = msg->num_grps * MAX_GROUP_NAME;
  grp->curr_membs = (char(*)[MAX_GROUP_NAME]) malloc(size); 
  if (!grp->curr_membs) {
    exit(fprintf(stderr, "upd_grp_membs: malloc1 failed\n"));
  }
  memcpy(grp->curr_membs, msg->grps, size);
  for (i = 0; i < grp->num_membs; ++i){
    char *p = grp->curr_membs[i];
    ON_DEBUG(
      printf("----------->   %s\n", p);
    )
    stdhash_insert(&grp->curr_membs_hash, 0, &p, 0);
  }

  /* clean joner, leaver */
  if(grp->joiner) {
    free(grp->joiner);
    grp->joiner = NULL;
  }
  if(grp->leaver) {
    free(grp->leaver);
    grp->leaver = NULL;
  }

  /* get new information from the body of the message */
  if(Is_reg_memb_mess(msg->serv_type)) {
    if(Is_caused_join_mess(msg->serv_type)) { 
      grp->joiner = (char*) malloc(MAX_GROUP_NAME);
      if(!grp->joiner) {
	exit(fprintf(stderr, "upd_grp_membs: malloc2 failed\n"));
      }
      
      i = scat_get2(grp->joiner, msg->scat, -1, 0, sizeof(group_id) + sizeof(int), MAX_GROUP_NAME);
      if (i != MAX_GROUP_NAME) {
	exit(fprintf(stderr, "upd_grp_membs: scatter_get2 1 failed\n"));
      }	
    }	      
    else if(Is_caused_leave_mess(msg->serv_type) || Is_caused_disconnect_mess(msg->serv_type)) {
      stdhash_it  hit_find;	

      grp->leaver = (char*) malloc(MAX_GROUP_NAME);
      if(!grp->leaver) {
	exit(fprintf(stderr, "upd_grp_membs: malloc3 failed\n"));
      }
      
      i = scat_get2(grp->leaver, msg->scat, -1, 0, sizeof(group_id) + sizeof(int), MAX_GROUP_NAME);
      if (i != MAX_GROUP_NAME) {
	exit(fprintf(stderr, "upd_grp_membs: scatter_get2 2 failed\n"));
      }

      /* update vs_hash, delete only from vs_membs_hash  */
      if(!stdhash_it_is_end(stdhash_find(&grp->vs_membs_hash, &hit_find, &grp->leaver))) { 
	stdhash_erase(&hit_find);	
      }
    }
    else if(Is_caused_network_mess(msg->serv_type)) {
      int size;
      if(grp->vs_membs) {
	free(grp->vs_membs);
	grp->vs_membs = NULL;
      }
      stdhash_clear(&grp->vs_membs_hash);
      grp->num_vs_membs = 0;
  
      i = scat_get2((char*)&grp->num_vs_membs, msg->scat, -1, 0, sizeof(group_id), sizeof(int));
      if(i != sizeof(int)) {
	exit(fprintf(stderr, "upd_grp_membs: scat_get2 3 failed\n"));
      }
      size = grp->num_vs_membs * MAX_GROUP_NAME;
      grp->vs_membs = (char(*)[MAX_GROUP_NAME]) malloc(size); 
      if(!grp->vs_membs) {
	exit(fprintf(stderr, "upd_grp_membs: malloc 4 failed\n"));
      }
      i = scat_get2((char*)grp->vs_membs, msg->scat, -1, 0, sizeof(group_id)+sizeof(int), size);
      if(i != size) {
	exit(fprintf(stderr, "upd_grp_membs: scat_get2 4 failed\n"));
      }
      for(i = 0; i < grp->num_vs_membs; ++i){
	char *p = grp->vs_membs[i];
	stdhash_insert(&grp->vs_membs_hash, 0, &p, 0);
      }
    }
  }

  DEBUG_leave(f_dbg, "upd_grp_membs", 0);
}

/* handle_reg_msg  ----------------------------------------------------------------------------
   This function is called when a regular message is handled by ssp, it decrypts the message
   and it puts back the service type ENCRYPT_MESS, if the messages was encrypted. If it
   fails, it returns a negative value. 
-----------------------------------------------------------------------------------------------*/
static int handle_reg_msg(SSP_Grp *grp, SSP_Msg *msg) {
  int ret = msg->msg_len;
  
  DEBUG_enter(f_dbg, "handle_reg_msg");
  
  if(Is_encrypt_mess_type(msg->msg_type)) {
    msg->serv_type |= ENCRYPT_MESS; 
    if((ret = Dec_Scat(msg->scat, grp->enc->dec_fcn, grp->enc->block_size, grp->enc->info, 
		       (unsigned int) msg->msg_len, &msg->msg_type, msg->endian_mism)) < 0) {
      ret = DECRYPT_FAILED;
    }
  }
  else {
    msg->serv_type &= ~ENCRYPT_MESS;
  }
  
  DEBUG_leave(f_dbg, "handle_reg_msg", ret);
  return ret;
}

/* handle_memb_msg -----------------------------------------------------------------------------
   This function uses the membership information to manage group information. 
   If this is a membership that announces a leave from a group, it removes group from list. If 
   this is the memebrship that announces the join for a new group, it adds the group in list. 
   If this is a membership for a group that exists, it updatea members list for that group.
--------------------------------------------------------------------------------------------- */
static void handle_memb_msg(SSP_Con *con, SSP_Grp **grp_ptr, SSP_Msg *msg) {
  SSP_Grp *grp = *grp_ptr;
  
  DEBUG_enter(f_dbg, "handle_memb_msg");
 
  if(Is_self_leave_mess(msg->serv_type)) {
    SSP_Con_delGrp(con, msg->sender);
    *grp_ptr = 0;
  }
  else if(Is_reg_memb_mess(msg->serv_type)) {
    if(!grp) { 
      add_group(con, grp_ptr, msg->sender);
      grp = *grp_ptr;
    }
    upd_grp_membs(grp, msg);
  }
  
  DEBUG_leave(f_dbg, "handle_memb_msg", 0);
}

/* handle_flush_msg  -------------------------------------------------------------------------
   This function sends the flush ok message due to a flush request from the flusher layer.
------------------------------------------------------------------------------------------- */
int handle_flush_msg(SSP_Con *con, SSP_Grp *grp) {
  int ret;
  
  DEBUG_enter(f_dbg, "handle_flush_msg");
  
  if ((ret = FL_flush(con->mbox, grp->name)) == CONNECTION_CLOSED || ret == ILLEGAL_SESSION) {
    SSP_disconnect(con->mbox);
    return ret;
  }
  grp->state = FLUSH_OK_SENT;
  
  DEBUG_leave(f_dbg, "handle_flush_msg", ret);
  return ret;    
}

/* recv_and_handle_msg --------------------------------------------------------------------------
  It returns: 
    -  NOTHING_TO_DELIVER if the message will not be delivered (this is a very big negative number)
    -  the number of bytes received from Flush
    -  errors returned by FL_scat_receive (negative but different from NOTHING_TO_DELIVER
    -  DECRYPT_FAILED (if the message was encrypted)
---------------------------------------------------------------------------------------------- */
static int recv_and_handle_msg(mailbox mbox, service *serv_type, char sender[MAX_GROUP_NAME],
			       int max_grps, int *num_grps, char grps[][MAX_GROUP_NAME],
			       int16 *msg_type, int *endian_mism, scatter *scat, int *more_msgs, 
			       SSP_Con *con) {
  int     ret = 0;
  int     deliv_msg = DELIV_MSG;
  SSP_Grp *grp = 0;
  SSP_Msg *msg = 0;
  
  DEBUG_enter(f_dbg, "recv_and_handle_msg");
  
  ON_TIMING ( 
    times[time_index][bef]  = get_time_timeofday();
    rtimes[time_index][bef] = get_time_rusage();
  )

  if((ret = FL_scat_receive(mbox, serv_type, sender, MAX_NUM_GRPS, num_grps, Glb_Grps, msg_type, 
			    endian_mism, Glb_Buff, more_msgs)) 
     == CONNECTION_CLOSED || ret == ILLEGAL_SESSION) {
    SSP_disconnect(mbox);
    goto end;
  }
  
  ON_TIMING ( 
    times[time_index][aft]  = get_time_timeofday();
    rtimes[time_index][aft] = get_time_rusage();

    ON_PRINT_TIMING(  
      printf("FL_receive:\trtime %22.6f\ttime %22.6f\tindex %d\n", 
	     rtimes[time_index][aft]- rtimes[time_index][bef], 
	     times[time_index][aft]- times[time_index][bef], time_index);
    )
  )

  if (ret == ILLEGAL_MESSAGE || ret == BUFFER_TOO_SHORT) {
    exit(fprintf(stderr, "recv_and_handle_msg: global buffer failure\n"));
  }
  
  if (ret < 0) {     /* return other error codes immediately */
    goto end;
  }
  else if(*num_grps < 0) {
    exit(fprintf(stderr, "recv_and_handle_msg: not enough global groups\n"));
  }
    
  grp = SSP_Con_getGrp(con, Is_regular_mess(*serv_type) ? Glb_Grps[0] : sender);
  msg = SSP_Msg_create(mbox, serv_type, sender, max_grps, num_grps, grps, msg_type, endian_mism,
		       ret, Glb_Grps, Glb_Buff, SSP_SCAT_ELEM_SIZE, 1);

  if(Is_regular_mess(*serv_type)) {
    if (!grp) {
      if (Is_private_group(msg->grps[0]) && !strcmp(con->priv_name, msg->grps[0])) {
	char from_group[MAX_GROUP_NAME];
	memcpy(from_group, msg->grps[msg->num_grps-1], MAX_GROUP_NAME);
	grp = SSP_Con_getGrp(con, from_group);
      }
      else exit(fprintf(stderr, "recv_and_handle_msg: uknown message type!\n"));
    }
    else {
      if(grp->ka->key_state == ESTABLISH) {
	ret = handle_reg_msg(grp, msg); /* return DECRYPT_FAILED immediately */
	deliv_msg = DELIV_MSG;
	if(ret < 0) goto end;
      }
    }
  }
  else if(Is_flush_req_mess(*serv_type)) {
    ON_TIMING (
      rtimes[time_index][REQ_TIME] = get_time_rusage();
      times[time_index][REQ_TIME]  = get_time_timeofday();
     
      ON_PRINT_TIMING(
        printf("FL_REQ:     \trtime %22.6f\ttime %22.6f\tindex %d\n", rtimes[time_index][REQ_TIME], 
	       times[time_index][REQ_TIME], time_index);
      )
    )
  }
  else if(Is_membership_mess(*serv_type)) {
    ON_TIMING (
      if (Is_caused_leave_mess(*serv_type) || Is_caused_join_mess(*serv_type) ||
	  Is_caused_network_mess(*serv_type) || Is_caused_disconnect_mess(*serv_type)) {
	times[time_index][FL_MEMB_TIME]  = get_time_timeofday();
	rtimes[time_index][FL_MEMB_TIME] = get_time_rusage();
	
	ON_PRINT_TIMING(  
	  printf("FL_MEMB:     \trtime %22.6f\ttime %22.6f\tindex %d\n", rtimes[time_index][FL_MEMB_TIME],
		 times[time_index][FL_MEMB_TIME], time_index);
	)
      }
    )

    handle_memb_msg(con, &grp, msg);
    deliv_msg = con->grp_notify ? DELIV_MSG : DONT_DELIV_MSG; /* ? */
  }
  else {
    exit(fprintf(stderr, "recv_and_handle_msg: uknown message type (%d) \n", *serv_type));
  }
  
  if(grp && (*grp->ka->handles_msg_fcn)(msg, grp)) {
    ON_TIMING ( 
      times[time_index][bef]  = get_time_timeofday();
      rtimes[time_index][bef] = get_time_rusage();
    )

    deliv_msg = (*grp->ka->handle_recv_fcn)(con, grp, msg);

    ON_TIMING ( 
      times[time_index][aft]  = get_time_timeofday();
      rtimes[time_index][aft] = get_time_rusage();

      ON_PRINT_TIMING(  
        printf("clq_fcn:     \trtime %22.6f\ttime %22.6f\tindex %d\n", 
	       rtimes[time_index][aft]- rtimes[time_index][bef], 
	       times[time_index][aft]- times[time_index][bef], time_index);
      )
    )
  }

  if(deliv_msg == DELIV_MSG) { /* deliver message in user's buffer */
    ret = glb_2_usr(max_grps, num_grps, grps, ret, scat, msg->grps, msg->scat);
    SSP_Msg_free(&msg);
  }
  else { 
    ret = SSP_NOTHING_TO_DELIVER;
    if(deliv_msg == DONT_DELIV_AND_FREE_MSG) {
      SSP_Msg_free(&msg);
    }
  }
  
 end:
  DEBUG_leave(f_dbg, "recv_and_handle_msg", ret);
  return ret;    
}


/* ====================== visible library functions ========================================== */


/* SSP_version ---------------------------------------------------------------------------------
   It returns the version (major, minor, patch) in variables provided by the user.
   On success it returns 1, otherwise 0.
-----------------------------------------------------------------------------------------------*/
int SSP_version(int *major_version, int *minor_version, int *patch_version) {
  int ret = 1;
  if((major_version == NULL) || (minor_version == NULL) || (patch_version == NULL)) {
    ret = 0;
  }
  
  *major_version = SSP_MAJOR_VERSION;
  *minor_version = SSP_MINOR_VERSION;
  *patch_version = SSP_PATCH_VERSION;

  return ret;
}


/* SSP_connect ----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------*/
int SSP_connect(char *spread, char *private, int priority, int grp_memb, mailbox *mbox, 
		char *priv_grp) {
  int ret;
  
  DEBUG_open(&f_dbg, dbg_file);
  DEBUG_enter(f_dbg, "SSP_connect");
  
  if((ret = FL_connect(spread, private, priority,  mbox, priv_grp)) == ACCEPT_SESSION) {
    if(++Num_Conns == 1) {
      create_glb(); 
    }
    
    if(*mbox >= Conns_Size) {
      int old_conns = Conns_Size;
      
      Conns_Size  = (*mbox + 1) << 1;
      Conns = (SSP_Con**) realloc(Conns, Conns_Size * sizeof(SSP_Con*));
      if (!Conns) {
	exit(fprintf(stderr, "SSP_connect: realloc failed\n"));
      }
      memset(Conns + old_conns, 0, (Conns_Size - old_conns) * sizeof(SSP_Con*));      
    }

    Conns[*mbox] = SSP_Con_create(*mbox, priority, grp_memb, spread, private, priv_grp);
  }

  DEBUG_leave(f_dbg, "SSP_connect", ret);
  return ret;
}


/* SSP_disconnect -------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------- */
int SSP_disconnect(mailbox mbox){
  int ret;
  
  DEBUG_enter(f_dbg, "SSP_disconnect");
  
  if(mbox < 0 || mbox >= Conns_Size || !Conns[mbox]) {
    ret = ILLEGAL_SESSION;
  }
  else {
    SSP_Con_free(&Conns[mbox]);
    
    if(--Num_Conns == 0) {
      free_glb(); 
    }
    ret = FL_disconnect(mbox);    
  }
  
  DEBUG_leave(f_dbg, "SSP_disconnect", ret);
  DEBUG_close(&f_dbg);
  return ret;
}


/* SSP_join ------------------------------------------------------------------------------------
   This function calls FL_join, the caller will be member of the group after it gets the
   membership.
---------------------------------------------------------------------------------------------- */
int SSP_join(mailbox mbox, char *group) {
  int ret;
  
  DEBUG_enter(f_dbg, "SSP_join");
  
  ON_TIMING (
    rtimes[time_index][REQ_TIME] = get_time_rusage();
    times[time_index][REQ_TIME]  = get_time_timeofday();

    ON_PRINT_TIMING(
      printf("JOIN FL_REQ: \trtime %22.6f\ttime %22.6f\tindex %d\n", rtimes[time_index][REQ_TIME],  
	     times[time_index][REQ_TIME], time_index); 
    )
  )

  if(mbox < 0 || mbox >= Conns_Size || !Conns[mbox]) {
    ret = ILLEGAL_SESSION;
  }
  else if((ret = FL_join(mbox, group)) == CONNECTION_CLOSED || ret == ILLEGAL_SESSION) {
    SSP_disconnect(mbox);
  }

  DEBUG_leave(f_dbg, "SSP_join", ret);
  return ret;
}


/* SSP_leave ------------------------------------------------------------------------------------
   This function just calls FL_leave; The caller will be removed from the group after he gets the
   membership.
---------------------------------------------------------------------------------------------- */
int SSP_leave(mailbox mbox, char *group_name) {
  int ret;
  SSP_Grp *grp;
  SSP_Con *con;
  
  DEBUG_enter(f_dbg, "SSP_leave");
  
  ON_TIMING (
    rtimes[time_index][REQ_TIME] = get_time_rusage();
    times[time_index][REQ_TIME]  = get_time_timeofday();

    ON_PRINT_TIMING(
      printf("LEAVE FL_REQ:\trtime %22.6f\ttime %22.6f\tindex %d\n", rtimes[time_index][REQ_TIME], 
	     times[time_index][REQ_TIME], time_index);
    )
  )

  if(mbox < 0 || mbox >= Conns_Size || !(con = Conns[mbox])) {
    ret = ILLEGAL_SESSION;
  }    
  else if(!(grp = SSP_Con_getGrp(con, group_name)) || grp->state == LEAVE_CALLED) {
    ret = 0;
  }
  else if(!(ret = FL_leave(mbox, group_name))) {
    grp->state = LEAVE_CALLED;
  }  
  else if(ret == CONNECTION_CLOSED || ret == ILLEGAL_SESSION) {
    SSP_disconnect(mbox);
  }
  
  DEBUG_leave(f_dbg, "SSP_leave", ret);
  return ret;
}

/* SSP_get_key ---------------------------------------------------------------------------------
   This function returns the group key, if the group is in stable state.
-----------------------------------------------------------------------------------------------*/
int SSP_get_key(mailbox mbox, const char *group_name, char *key, int *key_len) {
  int ret = 0;
  SSP_Grp *grp = NULL;
  SSP_Con  *con;
 
  if(mbox < 0 || mbox >= Conns_Size || !(con = Conns[mbox])) {
    ret = ILLEGAL_SESSION;
  } 
  else if (!(((grp = SSP_Con_getGrp(con, group_name))) || 
	     Is_private_group(group_name)) || grp->ka->key_state == NOT_ESTABLISH) {
    ret = ILLEGAL_GROUP;
  } 
  else {
    memcpy(key, grp->enc->key, grp->enc->key_len);
    memcpy(key_len, &grp->enc->key_len, sizeof(int));
  }
  
  return ret;
}

/* SSP_flush  ----------------------------------------------------------------------------------
   This function sends the flush ok message;
-----------------------------------------------------------------------------------------------*/
int SSP_flush(mailbox mbox, const char* grp_name) {
  int ret;
  SSP_Grp *grp;
  
  DEBUG_enter(f_dbg, "SSP_flush");

  if ((grp = SSP_Con_getGrp(Conns[mbox], grp_name)) == NULL) {
    ret =  ILLEGAL_GROUP;
  }
  else {
    grp->state = FLUSH_OK_SENT;
    ret = (*grp->ka->handle_fl_ok_fcn)(Conns[mbox], grp);
  }  

  DEBUG_leave(f_dbg, "SSP_flush", ret);
  return ret;    
}


/* SSP_multicast --------------------------------------------------------------------------------
   This function multicasts a message to a group.
-----------------------------------------------------------------------------------------------*/
int SSP_multicast(mailbox mbox, service service_type, char *group,int16 mess_type, int mess_len,
		  char *mess) {
  int     ret;
  scatter toSend;
  
  DEBUG_enter(f_dbg, "SSP_multicast");

  if(mess_len < 0) {
    return ILLEGAL_MESSAGE;
  }
  
  toSend.num_elements    = 1;
  toSend.elements[0].len = mess_len;
  toSend.elements[0].buf = mess;
  
  ret = SSP_scat_multicast(mbox,service_type, group, mess_type, &toSend );
  
  DEBUG_leave(f_dbg, "SSP_multicast", ret);
  return ret;
}


/* SSP_scat_multicast ---------------------------------------------------------------------------
   This function multicasts a message, where the data is provided in a scatter.
-----------------------------------------------------------------------------------------------*/
int SSP_scat_multicast(mailbox mbox, service serv, char *grp_name, int16 m_type, scatter *scat) {
  SSP_Con *con;
  SSP_Grp *grp;
  int     ret;
  int     is_encrypted;
  
  DEBUG_enter(f_dbg, "SSP_scat_multicast");
  
  if (mbox < 0 || mbox >= Conns_Size || !(con = Conns[mbox])) {
    ret = ILLEGAL_SESSION;
  }
  else if (SSP_Is_illegal_mess_type(m_type)) {
    ret = ILLEGAL_MESSAGE;
  }
  else if (!(((grp = SSP_Con_getGrp(con, grp_name))) || Is_private_group(grp_name))) {
    ret = ILLEGAL_GROUP;
  }
  else {
    scat_element elem = {0};
    int new_size = 0, org_size = 0, diff_size = 0;
    if((ret = (*grp->ka->handle_send_fcn)(con, grp)) == DONT_SEND_MSG) {
      ret = NOT_ALLOWED_TO_SEND;
      goto end;
    }
    
    if((is_encrypted = Is_encrypt_mess(serv))) {
      if(grp->ka->key_state == NOT_ESTABLISH) {
	ret = GROUP_NOT_SECURE;
	goto end;
      }
      else {
	if(scat->num_elements < 0 || scat->num_elements > SSP_MAX_SCATTER_ELEMENTS) {
	  ret = ILLEGAL_MESSAGE;
	  goto end;
	}
	
	elem = scat->elements[scat->num_elements];
	if((new_size = Enc_Scat(scat, grp->enc->enc_fcn, grp->enc->block_size, grp->enc->info,
				(unsigned int*) &org_size, m_type, 0)) < 0) { 
	  ret = ENCRYPT_FAILED;
	  goto end;
	}
	m_type     = SSP_ENCRYPT_MESS_TYPE;
	serv      &= ~ENCRYPT_MESS;
	diff_size  = new_size - org_size;
      }
    }
    
    if ((ret = FL_scat_multicast(mbox, serv, grp_name, m_type, scat)) 
	== CONNECTION_CLOSED || ret == ILLEGAL_SESSION) {
      SSP_disconnect(mbox);
    }
    
    if (is_encrypted) {
      if (ret == ILLEGAL_MESSAGE) {
	exit(fprintf(stderr, "SSP_scat_multicast: ILLEGAL_MESSAGE but Enc_Scat succeeded!\n"));
      }
      if (ret >= 0) {
	if (ret != new_size) {
	  exit(fprintf(stderr, "SSP_scat_multicast: send error\n"));	
	}

	ret -= diff_size;
      }
      scat->num_elements--;
      free(scat->elements[scat->num_elements].buf);
      scat->elements[scat->num_elements] = elem;
    }
  }
  
 end:
  DEBUG_leave(f_dbg, "SSP_scat_multicast", ret);
  return ret;
}


/* SSP_receive ----------------------------------------------------------------------------------
   This function receives a message from Flush.
 --------------------------------------------------------------------------------------------- */
int SSP_receive(mailbox mbox, service *serv_type, char sender[MAX_GROUP_NAME], int max_grps,
		int *num_grps, char grps[][MAX_GROUP_NAME], int16 *msg_type, 
		int *endian_mism, int max_msg_len, char *msg, int *more_msgs) {
  int     ret;
  scatter scat;
  
  DEBUG_enter(f_dbg, "SSP_receive");
  
  scat.num_elements    = 1;
  scat.elements[0].len = max_msg_len;
  scat.elements[0].buf = msg;
  
  ret = SSP_scat_receive(mbox, serv_type, sender, max_grps, num_grps, grps, msg_type, 
			 endian_mism, &scat, more_msgs);
  
  DEBUG_leave(f_dbg, "SSP_receive", ret);
  return ret;
}

/* SSP_scat_receive -----------------------------------------------------------------------------
   This function delivers a message to the application. If there is something in the connection
   queue will deliver from the queue, otherwise it reads from Flush. This function can block.
   Call it with DONT_BLOCK if you want your read to be non-blocking.
   On success, returns the size of the message received, or a negative value in case of error.
---------------------------------------------------------------------------------------------- */
int SSP_scat_receive(mailbox mbox, service *serv_type, char sender[MAX_GROUP_NAME],
		     int max_grps, int *num_grps, char grps[][MAX_GROUP_NAME],
		     int16 *msg_type, int *endian_mism, scatter *scat, int *more_msgs) {
  SSP_Con   *con;
  int       ret = 0;
  stddll_it lit;

  DEBUG_enter(f_dbg, "SSP_scat_receive");
  
  if(mbox < 0 || mbox >= Conns_Size || !(con = Conns[mbox])) {
    ret = ILLEGAL_SESSION;
    goto end;
  }
  
  do {
    if(stddll_size(&con->deliv_deque)) {
      SSP_Msg *msg = *(SSP_Msg**)stddll_it_val(stddll_begin(&con->deliv_deque, &lit));
      stddll_erase(&lit);  

      ret = deliv_msg(msg, serv_type, sender, max_grps, num_grps, grps, msg_type, endian_mism, scat); 

      SSP_Msg_free(&msg);
    }
    else {
      ret = recv_and_handle_msg(mbox, serv_type, sender, max_grps, num_grps, grps, msg_type, 
				endian_mism, scat, more_msgs, con);
    }
    *more_msgs += stddll_size(&con->deliv_deque);
  } while(ret == SSP_NOTHING_TO_DELIVER);	
  
  ON_TIMING (
    if (Is_caused_leave_mess(*serv_type) || Is_caused_join_mess(*serv_type) ||
	Is_caused_network_mess(*serv_type) || Is_caused_disconnect_mess(*serv_type)) {
      times[time_index][SSP_MEMB_TIME]  = get_time_timeofday();
      rtimes[time_index][SSP_MEMB_TIME] = get_time_rusage();
 
      ON_PRINT_TIMING (
        printf("SSP SSP_MEMB:\trtime %22.6f\ttime %22.6f\tindex %d\n", rtimes[time_index][SSP_MEMB_TIME], 
	       times[time_index][SSP_MEMB_TIME],  time_index);
        printf("--------------------------------------------------------------------------- \n");
        printf("FL          :\trtime %22.6f\ttime %22.6f  \n", 
	       rtimes[time_index][FL_MEMB_TIME] - rtimes[time_index][REQ_TIME] ,
	       times[time_index][FL_MEMB_TIME] - times[time_index][REQ_TIME]);
        printf("SSP         :\trtime %22.6f\ttime %22.6f  \n",  
		rtimes[time_index][SSP_MEMB_TIME] - rtimes[time_index][FL_MEMB_TIME],
		times[time_index][SSP_MEMB_TIME] - times[time_index][FL_MEMB_TIME]);
        printf("Total       :\trtime %22.6f\ttime %22.6f  \n", 
	       rtimes[time_index][FL_MEMB_TIME] - rtimes[time_index][REQ_TIME] +
	       rtimes[time_index][SSP_MEMB_TIME] - rtimes[time_index][FL_MEMB_TIME],
	       times[time_index][FL_MEMB_TIME] - times[time_index][REQ_TIME]+
	       times[time_index][SSP_MEMB_TIME] - times[time_index][FL_MEMB_TIME]);
	printf("--------------------------------------------------------------------------- \n");
	printf("--------------------------------------------------------------------------- \n");
      )
      stype[time_index] = *serv_type;
      ++time_index;
    }
  )
 
 end:
  DEBUG_leave(f_dbg, "SSP_scat_receive", ret);
  return ret;
}

/* int SSP_poll ---------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------- */
int SSP_poll(mailbox mbox) {
  return FL_poll(mbox);
}


/* void SSP_error -------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------- */
void SSP_error(int err) {

 switch (err) {
 case DECRYPT_FAILED:
    printf("SSP_error: (%d) Decrypting of the messages failed.\n", err);
    break;

  case  ENCRYPT_FAILED:
    printf("SSP_error: (%d) Encrypting of the messages failed.\n", err);
    break;

 case GROUP_NOT_SECURE:
   printf("SSP_error: (%d) Group not secure, not allwed to send.\n", err);
   break;
            
 case ENCRYPTION_NOT_SUPPORTED:
   printf("SSP_error: (%d) Encryption algorithm not supported.\n", err);
   break; 
   
 case KEY_AGR_NOT_SUPPORTED:
   printf("SSP_error: (%d) Key Agreement algorithm not supported.\n", err);
   break; 
   
 case FLUSH_OK_ALREADY_SENT:
   printf("SSP_error: (%d) Flush OK already sent.\n", err);
   break;
   
 case NOT_ALLOWED_TO_SEND:   
   printf("SSP_error: (%d) Not allowed to send.\n", err);
   break;
   
 default:
   FL_error(err);
   break;
 }
}






