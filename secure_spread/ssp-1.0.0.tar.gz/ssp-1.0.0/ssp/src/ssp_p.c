/*
 * The contents of this file are subject to the Secure Spread Non-Commercial 
 * License, Version 1.0 (the ``License''); you may not use this file except 
 * in compliance with the License.  A copy of the licence can be found in the 
 * file ``SSP_LICENSE'' found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Original Code is:
 *    The Secure Spread Library.
 *     
 * The Initial Developers of the Original Code are:
 *    Yair Amir, Cristina Nita-Rotaru, John Schultz and Jonathan Stanton.
 *
 *    All Rights Reserved.
 *
 */
                                                                                  

/***********************************************************************************************/
/* ssp_p.c                                                                                     */
/*                                                                                             */
/* Cristina Nita-Rotaru                                                                        */
/* Created: Feb 12, 2001                                                                       */
/*                                                                                             */
/* The Center for Networking and Distributed Systems                                           */
/* The Johns Hopkins University                                                                */
/***********************************************************************************************/

#include <stdlib.h>


#include "ssp_info.h"
#include "scatter.h"
#include "ssp_dbg.h"
#include "utility.h"

#include <stdutil/stddefines.h>
#include <stdutil/stderror.h>
#include <stdutil/stddll.h>
#include <stdutil/stdhash.h>
#include <stdutil/stdarr.h>

#include "fl.h"

#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif

extern FILE *f_dbg;


/* gen_and_push_msg  -----------------------------------------------------------------------------
   This function generates a message  and push it in the connection delivery queue.
   The accepted message types are FLUSH_REQ_MESS and TRANSITIONL_MESS 
-----------------------------------------------------------------------------------------------*/
void gen_and_push_msg(SSP_Con *con, SSP_Grp *grp, service serv_type) {
  SSP_Msg *msg = NULL;
  
  if(serv_type == FLUSH_REQ_MESS || serv_type == TRANSITION_MESS) {
    msg = (SSP_Msg*)malloc(sizeof(SSP_Msg));
    if(!msg) {
      exit(fprintf(stderr, "gen_and_push_msg: malloc failed\n"));  
    }
    SSP_Msg_init(msg);
    msg->mbox = con->mbox;
    msg->serv_type = serv_type;
    msg->sender = my_strdup(grp->name);
    
    stddll_push_back(&con->deliv_deque, &msg); 
  }
  else {
    exit(fprintf(stderr, "gen_and_push_msg: illegal service type\n"));
  }
}

/* comp_added_membs ---------------------------------------------------------------------------
   It computes the list of new members added to the group: 
   new_guys = is_in(current gc memb) && !is_in(gc_vs set).
   The current membership and the gv vs set were already computed, they are in the grp data
   structure.

   The list is setted in the array join_set. This needs to be null terminated because it will
   be passed to Cliques calls.

   It returns 1 if new members were added to the group.
-----------------------------------------------------------------------------------------------*/
int comp_added_membs(SSP_Grp *grp, stdarr* join_set) {
  stdhash    *vs = &grp->vs_membs_hash;
  stdhash    *curr = &grp->curr_membs_hash;
  stdhash_it hit, hit_find;
  int        ret = 0;

  for(stdhash_begin(curr, &hit); !stdhash_it_is_end(&hit); stdhash_it_next(&hit)) {
    if (stdhash_it_is_end(stdhash_find(vs, &hit_find, stdhash_it_key(&hit)))) {
      stdarr_push_back(join_set, stdhash_it_key(&hit));
    }
  }
  if(stdarr_size(join_set) > 0) { 
    ret = 1;
  }  
 
  ON_DEBUG(
    {
      stdarr_it  ait;  	
      printf("------------------ \n These members added the group:\n");
      for (stdarr_begin(join_set, &ait); !stdarr_it_is_end(&ait); stdarr_it_next(&ait)) {
        printf("%s\n", *(char**) stdarr_it_val(&ait));
      }
    }
  )
   
  return ret;
}

/* comp_leave_membs ---------------------------------------------------------------------------
   It computes the list of members that left the group: 
   left guys = is_in(prev gc memb) && !is_in(gc_vs set).
   The current membership and the gv vs set were already computed, they are in the grp data
   structure.

   The list is setted in the array leavee_set. This needs to be null terminated because it will
   be passed to Cliques calls.

   It returns 1 if members left the group.
-----------------------------------------------------------------------------------------------*/
int comp_leave_membs(SSP_Grp *grp, stdarr* leave_set) {
  stdhash    *vs = &grp->vs_membs_hash;
  stdhash    *prev = &grp->prev_membs_hash;
  stdhash_it hit, hit_find;
  int        ret = 0;

  for(stdhash_begin(prev, &hit); !stdhash_it_is_end(&hit); stdhash_it_next(&hit)) {
    if (stdhash_it_is_end(stdhash_find(vs, &hit_find, stdhash_it_key(&hit)))) {
      stdarr_push_back(leave_set, stdhash_it_key(&hit));
    }
  }
  if(stdarr_size(leave_set) > 0) { 
    ret = 1;
  }  

  ON_DEBUG(
    {
      stdarr_it  ait;  	
      printf("------------------ \n These members left the group:\n");
      for (stdarr_begin(leave_set, &ait); !stdarr_it_is_end(&ait); stdarr_it_next(&ait)) {
        printf("%s\n", *(char**) stdarr_it_val(&ait));
      }
    }
  )

  return ret;
}

/* is_old_member -------------------------------------------------------------------------------
   This function checks if a member is an old member. Right now the heiristic is to look at the
   first member in the current membership. Then each member checks if the chosen member is
   or not in their vs set.

   It returns 1 if the member is an old member. 
---------------------------------------------------------------------------------------------- */
int is_old_member(SSP_Grp *grp) {
 stdhash_it hit;
  char      *master = (char*)grp->curr_membs;
  int       old = !stdhash_it_is_end(stdhash_find(&grp->vs_membs_hash, &hit, &master));
  
  return old;
}

/* choose -----------------------------------------------------------------------------------
   This function picks a members from the list of the current members. The member is used when
   the algorithm needs to restart. 

   It returs nothing.
--------------------------------------------------------------------------------------------- */
void choose(char **name, SSP_Grp *grp) {
  *name = (char*)grp->curr_membs[0];
}


/* init_vs_set ---------------------------------------------------------------------------------
   This function initialize the vs_set to be the previous group communication membership.
   It is called every time the key agreement is started (i.e a gc membership was received).
-----------------------------------------------------------------------------------------------*/
void init_vs_set(SSP_Grp *grp) {
  int  size, i, num;

  if(grp->ka->vs_membs) {
    free(grp->ka->vs_membs);
    grp->ka->vs_membs = NULL;
  }
  stdhash_clear(&grp->ka->vs_membs_hash);
  
  num = stdhash_size(&grp->prev_membs_hash);
  size = num * MAX_GROUP_NAME;
  if(size == 0) { /* join with only me in group */
    goto end;
  }
  grp->ka->vs_membs = (char(*)[MAX_GROUP_NAME]) malloc(size); 
  if (!grp->ka->vs_membs) {
    exit(fprintf(stderr, "init_vs_set: malloc failed\n"));
  }
  memcpy(grp->ka->vs_membs, grp->prev_membs, size);
  for (i = 0; i < num; ++i){
    char *p = grp->ka->vs_membs[i];
    stdhash_insert(&grp->ka->vs_membs_hash, 0, &p, 0);
  }

  ON_DEBUG(
    printf("VS set initialized:\n");
    for (i = 0; i < stdhash_size(&grp->ka->vs_membs_hash); ++i){
      char *p = grp->ka->vs_membs[i];
      printf("%s\n", p);
    }
  )

 end:
}

/* upd_vs_set_and_get_join_leave_set ------------------------------------------------------------
   This function maintains the next secure vs set. It removes from the vs set from the ka
   data structure, members that left the group from the last gc membership. It is used together 
   with init_vs_set to compute a new vs set in case of cascading memberships. The function 
   removes only the pointers from the vs_set_hash. So the new vs can always be found from 
   the hash and not from the array.

   The function returns 0 if no members left the group, 1, otherwise.
--------------------------------------------------------------------------------------------- */
int upd_vs_set_and_get_join_leave_set(SSP_Grp * grp, service serv_type, 
				      stdarr *join_set, stdarr *leave_set) {
  int             ret = 0;
  stdhash_it      hit;	
  stdarr_it       ait;
  char            *p, *tmp = 0;

  if(Is_reg_memb_mess(serv_type)) {
    if(Is_caused_join_mess(serv_type)) { 
      p = grp->joiner; 
      stdarr_push_back(join_set, &p);
      stdarr_push_back(join_set, &tmp);        /* NULL terminate for CLQs */
    }	      
    else if(Is_caused_leave_mess(serv_type) || Is_caused_disconnect_mess(serv_type)) {
      p = grp->leaver;
      stdarr_push_back(leave_set, &p);
      stdarr_push_back(leave_set, &tmp);        /* NULL terminate for CLQs */
      
      /* update ka vs set */
      if(!stdhash_it_is_end(stdhash_find(&grp->ka->vs_membs_hash, &hit, &grp->leaver))) { 
	stdhash_erase(&hit);	
      }
      
      ret = 1; 
    }
    else if(Is_caused_network_mess(serv_type)) {
      ret = comp_leave_membs(grp, leave_set); /* order is important, first leave, then join */
      comp_added_membs(grp, join_set);
      
      /* remove the guys that left from ka->vs_membs_hash */
      for (stdarr_begin(leave_set, &ait); !stdarr_it_is_end(&ait); stdarr_it_next(&ait)) {
	p = *(char**) stdarr_it_val(&ait);
	if(!stdhash_it_is_end(stdhash_find(&grp->ka->vs_membs_hash, &hit, &p))) {
	  stdhash_erase(&hit);
	}
      }
  
      ON_DEBUG(
        printf("------------------ \n This is the secure vs set:\n");
        for (stdhash_begin(&grp->ka->vs_membs_hash, &hit); !stdhash_it_is_end(&hit); 
	     stdhash_it_next(&hit)) {
	  printf("%s\n", *(char**) stdhash_it_key(&hit));
	}
      )
	
      stdarr_push_back(leave_set, &tmp);        /* NULL terminate for CLQs */
      stdarr_push_back(join_set, &tmp);         /* NULL terminate for CLQs */
    }
  }

  return ret;
}

/* set_vs_set_memb_msg ---------------------------------------------------------------------------
   This function sets the vs set information in the body of the membership message. It is
   called when the key agreement is ready and the messages are moved from the key agreement
   buffers to the connection bufferes. The secure vs set is given by ka->vs_membs_hash, which
   keeps pointers to member names. The actual names are in ka->vs_membs. NOTE that clq->vs_membs
   contains more than the secure vs set and it order to get the secure vs set needs to be used
   in combination with clq->vs_membs_hash.
   IMPORTANT: 
   The whole buffer is build in memory and then copied in the scatter. I did it this way because
   the scatter that I am using allows me to do copy only at the beginning of the scatter and not
   to move inside a scatter. Flush's scatter is smarter (thanks to John), but I need then to 
   change all the code to use scatp instead of scatter. Future work ... :)  
-----------------------------------------------------------------------------------------------*/
void set_vs_set_memb_msg(SSP_Msg *msg, SSP_Grp *grp) {
  int        num_vs=0, size=0;
  char       *buf, *ptr;
  stdhash_it hit;	

  num_vs = stdhash_size(&grp->ka->vs_membs_hash);
  size = sizeof(group_id) + sizeof(int32) + num_vs * MAX_GROUP_NAME;
  buf = (char*)malloc(size * sizeof(char));
  if(!buf) {
    exit(fprintf(stderr, "set_vs_set_memb_msg: malloc failed\n"));
  }  
  ptr = buf;
  memcpy(ptr, (char*)&grp->gid, sizeof(group_id));
  ptr += sizeof(group_id);
  memcpy(ptr, (char*)&num_vs, sizeof(int32));
  ptr += sizeof(int32);

  ON_DEBUG(
      printf("This is the new secure vs set\n");
  )
  for(stdhash_begin(&grp->ka->vs_membs_hash, &hit); !stdhash_it_is_end(&hit); stdhash_it_next(&hit)) {
    char *p = *(char**) stdhash_it_key(&hit);
    ON_DEBUG(
      printf("%s\n", p);
    )
    memcpy(ptr, p, MAX_GROUP_NAME);
    ptr += MAX_GROUP_NAME;
  }
  scat_copy3(msg->scat, buf, size);

  msg->msg_len = size;

  if(buf) {
    free(buf);
    buf = NULL;
  }
}













