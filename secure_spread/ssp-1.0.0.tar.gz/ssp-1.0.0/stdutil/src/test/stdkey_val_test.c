#include <stdio.h>
#include <stdutil/stdhash.h> // the associative DS in question

#define NUM_SHORTS 17        // constant defined somehow

typedef struct {             // the key-val type I want to store
  int lookup_key;
  short data[NUM_SHORTS];
} my_key_val_pair;

int main(void) {
  stdkey_val_info my_type_info; // used to specify that type to an associative DS
  stdhash my_hash;              // the associative DS in question
  stdhash_it my_it;             // an iterator to make sure it works

  short tmp_data[NUM_SHORTS] = { 5, 28, 18, 20 };  // some junk data
  my_key_val_pair *kvp;
  int i = 27;

  // first I specify the type of key-val pair I want my hash to contain
  my_type_info.ksize  = sizeof(int);
  my_type_info.vsize  = NUM_SHORTS * sizeof(short);
  my_type_info.kalign = sizeof(int);
  my_type_info.valign = sizeof(short);

  // now I declare and construct an associative DS using that type info
  stdhash_construct(&my_hash, my_type_info, 0, 0);

  // insert a key-val pair and have my_it ref to it
  stdhash_insert(&my_hash, &my_it, &i, &tmp_data);

  // grab a ptr to the key-val pair out from the iterator
  kvp = (my_key_val_pair*) stdhash_it_key_val(&my_it);

  // this should print key = 27 data[0] = 5 data[1] = 28 data[2] = 18 data[3] = 20
  // followed by thirteen data[4-16] = 0 (of course it will put newlines, etc.)

  printf("key = %d\n", kvp->lookup_key);
  for (i = 0; i < NUM_SHORTS; ++i)
    printf(" data[%d] = %d\n", i, kvp->data[i]);

  return 0;
}
