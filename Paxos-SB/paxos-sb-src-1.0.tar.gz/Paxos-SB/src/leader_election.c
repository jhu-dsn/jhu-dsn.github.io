/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#include <stdlib.h>
#include "leader_election.h"
#include "p_server.h"
#include "packets.h"
#include "paxos_protocol.h"
#include "retrans.h"

extern Server_struct    Server_State;
extern VC_struct        View_State;
extern Parameter_struct Params;
extern Network_struct   Network_State;

void VC_Message_Handler(sys_scatter *msg)
{
  switch(Server_State.state) {

  case LEADER_ELECTION:
    Apply_VC_Message(msg);
    break;
    
  case REG_LEADER:
  case REG_NONLEADER:
    /*  Ignore the ViewChange message if not in LEADER_ELECTION state*/
    Alarm(DEBUG, "Ignoring, not in leader election.\n");
    break;
  }
}

void VC_Proof_Message_Handler(sys_scatter *msg)
{
  header *h;

  h = (header *)msg->elements[0].buf;

  switch(Server_State.state) {
  case LEADER_ELECTION:
    if(h->viewNum > View_State.last_installed) {
      View_State.last_attempted = h->viewNum;
      Alarm(PRINT, "Using proof to jump to last_attempt = %d\n", h->viewNum);
      fflush(stdout);
      
      /* Shift either to Reg_Leader or Reg_Nonleader depending on
       * whether I am the leader of the view to which I just
       * jumped. */
      if((h->viewNum % Params.Num_Servers) == 
	 (Server_State.id % Params.Num_Servers))
	Shift_to_Reg_Leader();
      else
	Shift_to_Reg_Nonleader();
    }
    break;
  case REG_NONLEADER:
  case REG_LEADER:
    break;
  }
}

void Apply_VC_Message(sys_scatter *msg)
{
  header *h;
  int id;

  h  = (header *)msg->elements[0].buf;
  id = h->serverID;

  /*  Do not process the packet if it is a duplicate or an old message.  
   *  If it isn't, update my state.
   *
   *  If VC is for the current attempt, count it.  
   *    If this brings the count to a majority: 
   *        If we are the leader, start to prepare the view 
   *        Otherwise, set the view timer, waiting for Prepare
   *
   *  If the VC is for a greater view, and the ViewTimer is not set
   *        Jump to higher view and propose the leader of this view.
   */
  
  if(h->viewNum < View_State.last_attempted) {
    Alarm(DEBUG, "Server %d received old attempt from %d: %d %d\n", 
	  Server_State.id, h->serverID, h->viewNum, View_State.last_attempted);
    return;
  }

  if(h->viewNum == View_State.last_attempted) {
    if(!View_State.attempt_received[id]) {
      View_State.attempt_received[id] = 1;
      View_State.num_received++;
      
      if(View_State.num_received == Params.Majority) {
	if((Server_State.id % Params.Num_Servers)== 
	   (h->viewNum % Params.Num_Servers) ) {
	  Alarm(DEBUG, "Need to start prepare phase.\n");
	  Shift_to_Reg_Leader();
	}
	else {
	  Alarm(DEBUG, "Waiting for Prepare message.\n");
	  Refresh_Progress_Timer();
	}
      }
    }
  }
  else if((h->viewNum > View_State.last_attempted) && 
	  (View_State.progress_timer_is_set == 0)) {
    Alarm(DEBUG, "Server %d received greater view: %d %d.\n",
	  Server_State.id, h->viewNum, View_State.last_attempted);
    Shift_to_Leader_Election(h->viewNum);
  }
}

void VC_Proof_Timer_Handler(void)
{
  sys_scatter *msg;

  msg = new_ref_cnt(SYS_SCATTER);
  Construct_VC_Proof_Message(msg);

  Send_MCast(msg);
  dec_ref_cnt(msg->elements[0].buf);
  dec_ref_cnt(msg);

  Schedule_VC_Proof_Event();
}


void Initialize_View_State(uint32_t viewNum)
{
  int i;

  for(i = 1; i <= MAX_SERVERS; i++)
    View_State.attempt_received[i] = 0;

  View_State.last_attempted    = viewNum;
  View_State.num_received      = 0;
}

void Schedule_VC_Proof_Event()
{
  sp_time t;

  t.sec  = VC_PROOF_TIMER_SEC;
  t.usec = VC_PROOF_TIMER_USEC + (rand() % 5000);

  E_queue(Timer_Dispatcher, VC_PROOF_TIMER, NULL, t);
}

void Progress_Timer_Handler()
{
  uint32_t viewNum;

  View_State.progress_timer_is_set = 0;

  switch(Server_State.state) {
  case LEADER_ELECTION:
    /*
     * Self-loop from Leader_Election to Leader_Election.  TODO: Maybe set
     * the timer for twice as long when it is set.
     */
    viewNum = View_State.last_attempted + 1;
    Shift_to_Leader_Election(viewNum);
    break;

  case REG_LEADER:
    Cancel_All_Proposal_Retransmissions();
    Shift_to_Leader_Election(View_State.last_attempted+1);
    break;

  case REG_NONLEADER:
    Alarm(PRINT, "Shifting to leader election.\n");
    fflush(stdout);
    Shift_to_Leader_Election(View_State.last_attempted+1);
    break;
  }
}

void Refresh_Progress_Timer()
{
  sp_time t;

  t.sec  = PROGRESS_TIMER_SEC;
  t.usec = PROGRESS_TIMER_USEC;

  E_queue(Timer_Dispatcher, PROGRESS_TIMER, NULL, t);

  View_State.progress_timer_is_set = 1;
}

void Cancel_Progress_Timer()
{
  E_dequeue(Timer_Dispatcher, PROGRESS_TIMER, NULL);
  View_State.progress_timer_is_set = 0;

}
