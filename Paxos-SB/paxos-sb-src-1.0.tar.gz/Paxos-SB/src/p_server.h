/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#ifndef PFSB_P_SERVER_H
#define PFSB_P_SERVER_H

#include <stdint.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "net.h"
#include "util_include.h"
#include "def.h"
#include "stdutil/stddll.h"
#include "stdutil/stdhash.h"
#include "reconc.h"
#include "prepare_phase.h"

/* Structure to store system parameters */
typedef struct param_struct {
  uint32_t Faults;      /* Total number of supported faults             */
  uint32_t Majority;    /* What constitutes a majority, based on Faults */
  uint32_t Num_Servers; /* Total number of potential servers in system  */
} Parameter_struct;

/* Structure to store state information for this server */
typedef struct server_struct {  
  uint32_t id;     /* Unique identifier of this server */
  uint32_t state;  /* What state this server is in     */
  uint32_t aru;    /* This server's local aru value    */

  /* Used for global flow control.  global_aru is the minimum of the arus 
   * of the servers I think are alive.  Arus stores these arus. */
  uint32_t global_aru;
  uint32_t arus[MAX_SERVERS+1];
  uint32_t views[MAX_SERVERS+1];

  /* Used for garbage collection */
  uint32_t white_line;
  uint32_t stable_arus[MAX_SERVERS+1];

  sys_scatter *recovered_updates[MAX_CLIENTS+1];
} Server_struct;

/* Structure to store networking information for this server */
typedef struct network_struct {

  int sd;          /* Socket descriptor for unicast messages */
  int32_t address; /* IP address of this server */
  int32_t server_addresses[MAX_SERVERS+1]; /* IP Address of all servers */
  sys_scatter Recv_Msg; /* The one and only packet used for reception */

#ifdef USE_TRUE_MCAST
  int msd; /* Socket descriptor for multicast */
  int32_t mcast_addr;
#else
  int start_server;   /* Server to start with when "multicasting" */
#endif

  /* Socket on which to listen for client connections */
  int listen_sd;

  /* Array to map client_id to appropriate socket descriptor */
  int Client_to_Sd[MAX_CLIENTS+1];
  
} Network_struct;

/* Structure used to store Benchmark-related variables. */
typedef struct dummy_benchmark_struct {
  sp_time start_time;
  sp_time end_time;

  int write_count;

  sp_time total_write_time;
  sp_time proposal_write_times[BENCHMARK_END_SEQ*2];
  sp_time order_write_times[BENCHMARK_END_SEQ*2];

  uint32_t total_updates;
  uint32_t start_updates;
} Benchmark_struct;

/* Structure used to store variables for writing to disk. */
typedef struct dummy_disk_struct {
  int view_fd;
  int log_fd;
  uint32_t sync_flag;

  char log_file_name[128];
  FILE *debug_fp;

} Disk_struct;

/* Structure to store view change information for this server */
typedef struct view_change_struct {
  uint32_t last_attempted;
  uint32_t last_installed;

  uint32_t max_view;
  uint32_t attempt_received[MAX_SERVERS+1];
  uint32_t num_received;

  uint32_t progress_timer_is_set;
} VC_struct;

typedef struct retrans_struct {
  sys_scatter *buf[MAX_PACKET_TYPES];
  int packet_types[MAX_PACKET_TYPES];
} Retrans_struct;

typedef struct dummy_prepare_struct {
  uint32_t view_is_prepared;
  uint32_t prepare_ok_completed[MAX_SERVERS+1];
  uint32_t num_completed;

  prepare_session Sending_Session;
  prepare_session Receiving_Sessions[MAX_SERVERS+1];
  uint32_t indices[MAX_SERVERS+1];

  stddll rejected_queue;
} Prepare_struct;

typedef struct dummy_client_struct {
  stddll update_queue;

  uint32_t last_executed[MAX_CLIENTS+1];

  /* To prevent the same update from being queued twice in the same view */
  uint32_t last_enqueued[MAX_CLIENTS+1];

  /* To ensure reliability of the link between non-leader that forward updates
   * and the leader, each server keeps the latest pending update it has
   * from each client.  If the update isn't ordered in time, the server
   * reforwards it.*/
  sys_scatter *pending_updates[MAX_CLIENTS+1];
  int indices[MAX_CLIENTS+1];

  stddll aggregation_update_queue;
  stddll forward_queue;
} Client_struct;

typedef struct dummy_proposal_struct {
  sys_scatter *window[WINDOW_SIZE];
  uint32_t last_proposed;
  uint32_t window_end;

  float congestion_window;
  uint32_t num_outstanding_proposals;

  int indices[WINDOW_SIZE];

  stddll proposal_queue;
  stddll accept_queue;

} Proposal_struct;

typedef struct dummy_accept_node
{
  uint32_t accept_received[MAX_SERVERS+1];
  uint32_t num_received;
  uint32_t viewNum;
} accept_node;


typedef struct dummy_accept_struct {
  stdhash latest_accepted;
  stdhash stats;
  stdhash ordered_updates;
} Accept_struct;

typedef struct dummy_alive_struct {
  uint32_t is_alive[MAX_SERVERS+1];
  uint32_t num_alive;

  /* Used to pass indices to E_queue */
  uint32_t members[MAX_SERVERS+1];

  stddll anti_entropy_queue;
} Alive_struct;

typedef struct dummy_reconc_struct {
  reconc_session Sending_Sessions[MAX_SERVERS+1];
  reconc_session Receiving_Session;

  uint32_t num_consecutive_failures;
  uint32_t random_tried[MAX_SERVERS+1];

} Reconc_struct;


enum states {LEADER_ELECTION, REG_LEADER, REG_NONLEADER};

#define RETRANS_TIMER          -1
#define PROPOSAL_RETRANS_TIMER -2
#define VC_PROOF_TIMER         -3
#define PROGRESS_TIMER         -4
#define ALIVE_TIMER            -5
#define MEMBERSHIP_TIMER       -6
#define RECONC_TIMER           -7
#define UPDATE_TIMER           -8
#define RECONC_RESPONSE_TIMER  -9
#define ACK_TIMER              -10
#define ANTI_ENTROPY_TIMER     -11
#define PREPARE_RETRANS_TIMER  -12
#define PREPARE_ACK_TIMER      -13
#define AGGREGATION_TIMER      -14
#define AGGREGATION_UPDATE_TIMER -15

#endif
