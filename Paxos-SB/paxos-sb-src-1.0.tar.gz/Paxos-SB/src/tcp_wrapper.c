/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#include <sys/types.h>
#include <unistd.h>
#include "tcp_wrapper.h"
#include "util_include.h"

int TCP_Read(int sd, void *dummy_buf, int nBytes)
{
  int ret, nRead, nRemaining;
  char *buf;

  nRemaining = nBytes;
  nRead      = 0;

  buf = (char *)dummy_buf;

  while(1) {
    ret = read(sd, &buf[nRead], nRemaining);

    if(ret <= 0)
      break;

    nRead      += ret;
    nRemaining -= ret;

    if(nRead == nBytes)
      break;
  }
  return ret;
}

int TCP_Write(int sd, void *dummy_buf, int nBytes)
{
  int ret, nWritten, nRemaining;
  char *buf;
  
  buf        = (char *)dummy_buf;
  nWritten   = 0;
  nRemaining = nBytes;

  while(1) {
    ret = write(sd, &buf[nWritten], nRemaining);
  
    if(ret <= 0)
      break;

    nWritten   += ret;
    nRemaining -= ret;

    if(nRemaining == 0)
      break;
  }
  return ret;
}
