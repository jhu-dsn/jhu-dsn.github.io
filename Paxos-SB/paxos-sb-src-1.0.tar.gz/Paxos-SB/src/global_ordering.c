/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include "global_ordering.h"
#include "p_server.h"
#include "def.h"
#include "packets.h"
#include "retrans.h"
#include "net.h"
#include "membership.h"
#include "paxos_protocol.h"
#include "client_handling.h"
#include "disk.h"
#include "leader_election.h"
#include "tcp_wrapper.h"
#include "aggregation.h"
#include "util.h"

/*---------------------------------------------------------------------*/
static void Propose_Next_Off_Queue    (int32_t seq, void *data);
static void Propose_Constrained_Update(uint32_t seq);
static void Store_Proposal_In_Window  (sys_scatter *proposal, uint32_t seq);
static void Respond_to_Proposal       (sys_scatter *proposal);
static void Remove_Accept_Storage     (uint32_t seq);
static int  Update_Aru                (uint32_t seq);
static void Advance_Window            (int num_slots);
#ifndef AGGREGATION
static void Accept_Sender             (int seq, void *data);
#endif
/*---------------------------------------------------------------------*/

extern Proposal_struct  Proposal_State;
extern Server_struct    Server_State;
extern Network_struct   Network_State;
extern VC_struct        View_State;
extern Accept_struct    Accept_State;
extern Client_struct    Client_State;
extern Parameter_struct Params;
extern Reconc_struct    Reconc_State;
extern Prepare_struct   Prepare_State;
extern Disk_struct      Disk_State;

#ifdef SERVER_BENCHMARKING
extern Benchmark_struct Benchmark_State;
#endif

void Send_Some_Proposals()
{
  uint32_t seq;
  int i;

  /* We can send a maximum of as many Proposals as are remaining in
   * the congestion window. */

    for(i = Proposal_State.num_outstanding_proposals; 
	i < (int) Proposal_State.congestion_window; i++) {

      /* Get the next sequence number to be proposed */
      seq = Proposal_State.last_proposed + 1;

#ifdef GLOBAL_FLOW_CONTROL
      /* Oly send if everyone alive is caught up */
      if(seq > (Server_State.global_aru + (WINDOW_SIZE*2))) {
	/* Alarm(DEBUG,"Global FC: seq = %d, global_aru = %d,
	   local_aru = %d\n", 
	   seq, Server_State.global_aru, Server_State.aru);
	   fflush(stdout);*/
	return;
      }
#endif
      
      /* If this sequence number is constrained, use the constraining
       * proposal.  Otherwise, if there is something on the queue,
       * propose it.  Otherwise stop. */
      
      /* If it's ordered, skip it, pretending like we proposed
       * it. This can occur after a view change. */
      if(Is_Ordered(seq)) {
	Proposal_State.last_proposed++;
	Proposal_State.num_outstanding_proposals++;
	continue;
      }
      
      if(UTIL_Get_Latest_Accepted(seq) != NULL) {
	Alarm(PRINT, "Proposing constrained update for seq %d\n", seq);
	fflush(stdout);
	Proposal_State.num_outstanding_proposals++;
	Propose_Constrained_Update(seq);
	return;
      }
      
      if(stddll_empty(&Client_State.update_queue))
	return;
      else {
	/*Alarm(DEBUG, "Proposing the next off queue with seq %d.\n", seq);*/
	Proposal_State.num_outstanding_proposals++;
	Propose_Next_Off_Queue(seq, NULL);
      }
    }
}

static void Propose_Next_Off_Queue(int32_t seq, void *dummy)
{
  sys_scatter *proposal;

  /*Alarm(DEBUG, "Proposing off of queue: seq %d\n", seq);*/
  
  /* Make an aggregated Proposal with one or more updates */
  proposal = new_ref_cnt(SYS_SCATTER);
  Construct_Aggregated_Proposal_Message(proposal, seq);

  /* Update leader's state to store the Proposal */
  Apply_Proposal(proposal, seq);

  /* Adjust the window */
  Store_Proposal_In_Window(proposal, seq);

  /* Store the proposal for retransmission */
  Schedule_Proposal_Retransmission(seq);

  /* Send out the Proposal message. */
  Send_MCast(proposal);

#ifdef SERVER_BENCHMARKING
  /* Benchmarking: Start the clock before sending the first Proposal */
  if(Proposal_State.last_proposed == BENCHMARK_START_SEQ) {
    Benchmark_State.start_time = E_get_time();
    Benchmark_State.start_updates = Benchmark_State.total_updates;
  }
#endif

#ifdef AGGREGATION
  Aggregation_Enqueue_Proposal(proposal);
  Schedule_Aggregation_Event();
#else
  {
    sp_time t;
    /* Proposal is dec_ref'd in Accept_Sender */
    t.sec = 0; t.usec = 0;
    E_queue(Accept_Sender, seq, proposal, t);
  }
#endif
}

static void Propose_Constrained_Update(uint32_t seq)
{
  header *h;
  sys_scatter *proposal;
  sys_scatter *new_prop;
  proposal_specific *ps;

  /* Copy the Proposal but change the view number and serverID to
   * reflect the fact that it is being proposed in this view by this
   * leader. */
  UTIL_Assert_Latest_Accepted(seq);

  proposal = UTIL_Get_Latest_Accepted(seq);

  new_prop = new_ref_cnt(SYS_SCATTER);
  new_prop->num_elements = 1;
  new_prop->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);
  new_prop->elements[0].len = proposal->elements[0].len;
  memcpy(new_prop->elements[0].buf, proposal->elements[0].buf, 
	 proposal->elements[0].len);

  h = (header *)new_prop->elements[0].buf;
  h->serverID = Server_State.id;
  h->viewNum  = View_State.last_installed;

  ps = (proposal_specific *)(h+1);

  Alarm(PRINT, "Constrained update.\n");
  fflush(stdout);

  Apply_Proposal(new_prop, seq);
  Store_Proposal_In_Window(new_prop, seq);
  Schedule_Proposal_Retransmission(seq);

#ifdef SERVER_BENCHMARKING
  if(Proposal_State.last_proposed == 1)
    Benchmark_State.start_time = E_get_time();
#endif

  /* Send out the Proposal message. */
  Send_MCast(new_prop);

#ifdef AGGREGATION
  Aggregation_Enqueue_Proposal(new_prop);
  Schedule_Aggregation_Event();
#else
  {
    sp_time t;
    /* Proposal is dec_ref'd in Accept_Sender */
    t.sec = 0; t.usec = 0;
    E_queue(Accept_Sender, seq, new_prop, t);
  }
#endif
}

/* Returns 1 if this server stored the proposal, 0 if this server already
 * had this proposal, and -1 otherwise.*/
int Apply_Proposal(sys_scatter *proposal, uint32_t seq)
{
  sys_scatter *old;
  header *old_h;
  header *new_h;
  int ret;
  
  ret = -1;

  /* This Proposal is from my current view, and I already ordered the thing.
   * So it should always be safe to send an Accept.*/
  if(Is_Ordered(seq))
    return 0;

  /* If there is something OLDER in this slot, clear it out */
  if((old = UTIL_Get_Latest_Accepted(seq)) != NULL) {
    old_h = (header *)old->elements[0].buf;
    new_h = (header *)proposal->elements[0].buf;

    if(new_h->viewNum > old_h->viewNum) {
      dec_ref_cnt(old->elements[0].buf);
      dec_ref_cnt(old);
      UTIL_Remove_Latest_Accepted(seq);
    }
    else if(new_h->viewNum == old_h->viewNum)
      ret = 0;
  }

  /* If the slot is now empty, store the new one */
  if(UTIL_Get_Latest_Accepted(seq) == NULL) {
    inc_ref_cnt(proposal);
    inc_ref_cnt(proposal->elements[0].buf);
    UTIL_Insert_Latest_Accepted(seq, proposal);
    ret = 1;
  }

  return ret;
}


static void Store_Proposal_In_Window(sys_scatter *proposal, uint32_t seq)
{
  int index;

  Proposal_State.last_proposed = seq;

  index = seq % WINDOW_SIZE;
  if(Proposal_State.window[index] != NULL) {
    Print_Packet(Proposal_State.window[index]);
    Print_Packet(proposal);
    fflush(stdout);
    assert(Proposal_State.window[index] == NULL);
  }

  inc_ref_cnt(proposal);
  inc_ref_cnt(proposal->elements[0].buf);
  Proposal_State.window[index] = proposal;
}
 
void Proposal_Message_Handler(sys_scatter *msg)
{
  header *h;
  
  h = (header *)msg->elements[0].buf;

  /* Garbage collection: if I get a Proposal either from this view or 
   * an older view, then I shouldn't have a Prepare sending session open 
   * except for my current view. */
  if(Prepare_State.Sending_Session.state != PREPARE_INACTIVE) {
    if(h->viewNum == View_State.last_installed ||
       Prepare_State.Sending_Session.view < View_State.last_attempted) {
      Clear_Prepare_Session(&Prepare_State.Sending_Session);
      Alarm(PRINT, "Server %d cleared Prepare sending session.\n",
	    Server_State.id);
      fflush(stdout);
    }
  }
  
  /* Only process the proposal if it is from your view */
  if(h->viewNum != View_State.last_attempted) {
    Alarm(PRINT, "Server %d discarding Proposal, wrong view.\n", 
	  Server_State.id);
    fflush(stdout);
    return;
  }
  switch(Server_State.state) {
  case LEADER_ELECTION:
    /* Ignore until I receive proof of leader election completion */
    Alarm(PRINT, "Server %d discarding Proposal, LE.\n", Server_State.id);
    fflush(stdout);
    break;
      
  case REG_NONLEADER:
    Respond_to_Proposal(msg);
    break;
    
  case REG_LEADER:
    abort();
    /* The leader processes its own Proposal specially, ignore it here */
    break;
  }
}


static void Respond_to_Proposal(sys_scatter *proposal)
{
  int ret;
  header *h;
  proposal_specific *p;
  sys_scatter *my_proposal;

  h = (header *)proposal->elements[0].buf;
  p = (proposal_specific *)(h+1);

  /* Reconciliation: Attempt to reconcile because you're far behind */
  if(p->seq > (Server_State.aru + WINDOW_SIZE)) {
    Reconcile_to_Seq(p->seq, RECONC_RANDOM_PEER);
    /*Reconcile_to_Seq(p->seq - WINDOW_SIZE, RECONC_RANDOM_PEER);*/
    return;
  }

  /* Make my own copy of the proposal to store if necessary */
  my_proposal = new_ref_cnt(SYS_SCATTER);
  my_proposal->num_elements = 1;

  inc_ref_cnt(proposal->elements[0].buf);
  my_proposal->elements[0].buf = proposal->elements[0].buf;
  my_proposal->elements[0].len = proposal->elements[0].len;

  ret = Apply_Proposal(my_proposal, p->seq);

  /* We should NOT send an Accept message in response */
  if(ret == -1) {
    dec_ref_cnt(my_proposal->elements[0].buf);
    dec_ref_cnt(my_proposal);
    return;
  }
  
#ifdef AGGREGATION
  Aggregation_Enqueue_Proposal(my_proposal);
  Schedule_Aggregation_Event();
#else
    /* my_proposal is dec_ref'd in Accept_Sender, which also writes to disk */ 
    Accept_Sender(p->seq, my_proposal);
#endif
}

#ifndef AGGREGATION
static void Accept_Sender(int seq, void *data)
{
  sys_scatter *accept;
  sys_scatter *proposal;

  accept = new_ref_cnt(SYS_SCATTER);
  Construct_Accept_Message(accept, seq);
  
  /* I only need to apply the accept and write to disk if I haven't already
   * ordered this sequence number.  If I have, then I will always respond to
   * a Prepare message with the proposal from my ordered update.  Since 
   * no later proposal can be built with a conflicting update, it doesn't
   * matter what view the proposal I send is, since it matches whatever
   * the latest is. */
  if(!Is_Ordered(seq)) {
    Apply_Accept(accept);
    Attempt_to_Order(seq);
  }
  
  proposal = (sys_scatter *)data;

#ifdef WRITE_TO_DISK
  if(!Is_Ordered(seq))
    Write_Message(proposal, PROPOSAL_TYPE);
#endif  

  /* Send the Accept */

#ifdef INSTRUMENT
  if(seq != 1001 || View_State.last_installed != 1)
#endif
    Send_MCast(accept);

  dec_ref_cnt(accept->elements[0].buf);
  dec_ref_cnt(accept);
  
  dec_ref_cnt(proposal->elements[0].buf);
  dec_ref_cnt(proposal);
}
#endif


void Accept_Message_Handler(sys_scatter *msg)
{
  header *h;
  accept_specific *a;
  int aru_flag = 0;
  
  h = (header *)msg->elements[0].buf;
  a = (accept_specific *)(h+1);

  /* Ignore your own Accept message because you process it specially  */
  if(h->serverID == Server_State.id)
    return;

#ifdef AGGREGATION
  Aggregation_Process_Accept(msg);
  return;
#endif

  /* Infer the sending server's local_aru minimum from the sequence
   * number.  A server only sends an ACCEPT if it is within one WINDOW
   * of its local_aru.  Thus, the server's local_aru must be at least 
   * (seq - WINDOW).  Update it to reflect this if necessary.  Only do 
   * this if we're beyond the first window to avoid underflow. */
  if( (Server_State.arus[h->serverID] < (a->seq - WINDOW_SIZE)) &&
      (a->seq >= WINDOW_SIZE) ) {
    Server_State.arus[h->serverID] = (a->seq - WINDOW_SIZE);
    Server_State.global_aru = Compute_Global_Aru_of_Alive_in_View();
    aru_flag = 1;
  }
 
 /* If I have already ordered this sequence number, ignore the accept */
  if(!Is_Ordered(a->seq)) {
    Apply_Accept(msg);
    Attempt_to_Order(a->seq);
  }

  /* If this opens the global flow control window and I'm the leader, try 
   * to send some more proposals.*/
  if(aru_flag)
    if((Server_State.state == REG_LEADER) && (Prepare_State.view_is_prepared))
      Send_Some_Proposals();
}

void Apply_Accept(sys_scatter *accept)
{
  header *h;
  accept_node *a;
  accept_specific *as;
  int i;

  h  = (header *)accept->elements[0].buf;
  as = (accept_specific *)(h+1);

  /* If there is no entry for this slot, initialize the slot */
  if(UTIL_Get_Stats(as->seq) == NULL) {
    a = new_ref_cnt(ACCEPT_NODE);
    for(i = 1; i <= MAX_SERVERS; i++)
      a->accept_received[i] = 0;
    a->num_received = 0;
    a->viewNum      = 1;
    UTIL_Insert_Stats(as->seq, a);
  }

  /*
   * If we have already accepted a proposal for this seq, we'll do either:
   *   1. If it's for the same view and is not a duplicate, add to tally
   *   2. If it's for a later view, erase what was there and count anew
   */

  a = UTIL_Get_Stats(as->seq);
  if(h->viewNum == a->viewNum) {
    if(!a->accept_received[h->serverID]) {
      a->viewNum = h->viewNum;
      a->accept_received[h->serverID] = 1;
      a->num_received++;
    }
  }
  else if(h->viewNum > a->viewNum) {
    a->num_received = 1; /* This one */
    a->viewNum      = h->viewNum;

    for(i = 1; i <= MAX_SERVERS; i++)
      a->accept_received[i] = 0;

    a->accept_received[h->serverID] = 1;
  }
}

void Attempt_to_Order(uint32_t seq)
{
  sys_scatter *proposal;
  accept_node *a;
  header *h;
  proposal_specific *ps;

  /* If this sequence number is already ordered, don't do it again */
  if(Is_Ordered(seq))
    return;

  /* We better have at least some accept information */
  UTIL_Assert_Stats(seq);

  a = UTIL_Get_Stats(seq);

  /* If we don't have a Proposal yet, don't order */
  if((proposal = UTIL_Get_Latest_Accepted(seq)) == NULL)
    return;

  if(a->num_received < Params.Majority) {
    /*Alarm(DEBUG, "Not ordering because only have %d of %d accepts\n",
      a->num_received, Params.Majority);*/
    return;
  }
  
  /* Ready to order this update:
   *   1. Store the proposal, which includes the update and sequence number 
   *   2. Remove old storage from data structures 
   *   3. Update my aru
   *   4. Respond to client if it's my client
   *   5. Update client state
   */

  /* Store the Proposal as a globally ordered update */
  UTIL_Insert_Ordered_Update(seq, proposal);
  inc_ref_cnt(proposal);
  inc_ref_cnt(proposal->elements[0].buf);
  
  h  = (header *)proposal->elements[0].buf;
  ps = (proposal_specific *)(h+1);

#ifdef SERVER_BENCHMARKING
  Benchmark_State.total_updates += ps->num_updates;
#endif 

  Upon_Ordering(seq);
}

void Upon_Ordering(int seq)
{
  int ret;

  Remove_Accept_Storage(seq);

  ret = Update_Aru(seq);

#ifdef SERVER_BENCHMARKING
  if((seq % (BENCHMARK_END_SEQ / 10)) == 0) {
#else
    if((seq % 1000) == 0) {
#endif
    if(Server_State.state == REG_LEADER)
      Alarm(PRINT, "***Ordered update %d, My_Aru = %d\n", 
	    seq, Server_State.aru);
    else
      Alarm(PRINT, "Ordered update %d, My_Aru = %d\n", seq, Server_State.aru);
    fflush(stdout);
  }

  /* Reconciliation: If ordering this update did not increase my ARU, then 
   * I must have ordered it out of order.  I need to set up a reconciliation
   * session to request the updates I'm missing. */
  if(ret == 0) {
    Reconcile_to_Seq(seq, RECONC_RANDOM_PEER);
    assert(seq-1 > Server_State.aru);
    /*Reconcile_to_Seq(seq-1, RECONC_RANDOM_PEER);*/
  }

  switch(Server_State.state) {
  case REG_LEADER:
    /* Advance the window by the number of slots by which the aru increased */
    Advance_Window(ret);

    Cancel_Proposal_Retransmission(seq);

#ifdef SERVER_BENCHMARKING
    if((seq == BENCHMARK_END_SEQ) && (Server_State.id == 1))
      Cleanup();
#endif    

    /*Send_Some_Proposals();*/
    break;
  }
  
  Respond_to_Client(seq, NULL);

  /* The ordering is considered global progress if it advances my aru */
  if(Server_State.state != LEADER_ELECTION && ret > 0)
    Refresh_Progress_Timer();
}

static void Remove_Accept_Storage(uint32_t seq)
{
  sys_scatter *proposal;
  accept_node *a;

  /* Proposal is now stored in ordered_updates, so clear it out of here */
  proposal = UTIL_Get_Latest_Accepted(seq);
  dec_ref_cnt(proposal->elements[0].buf);
  dec_ref_cnt(proposal);
  UTIL_Remove_Latest_Accepted(seq);
 
  /* Also clear the slot used for storing accept information */
  a = UTIL_Get_Stats(seq);
  dec_ref_cnt(a);
  UTIL_Remove_Stats(seq);
}

/* Returns the amount by which the aru was increased */
static int Update_Aru(uint32_t seq)
{
  int i;
  int original_aru;
  int num_advanced;
  sys_scatter *proposal;

  original_aru = Server_State.aru;
  i            = Server_State.aru + 1;

  while(1) {
    if((proposal = UTIL_Get_Ordered_Update(i)) != NULL) {
#ifdef WRITE_TO_DISK
      Write_Message(proposal, ORDER_TYPE);
#endif
      Update_Client_Last_Executed(i);
      Server_State.aru++;
      i++;
    }
    else
      break;
  }

  /* Update my slot in arus for global flow control purposes, then recompute
   * the global_aru. */
  Server_State.arus[Server_State.id] = Server_State.aru;
  Server_State.global_aru = Compute_Global_Aru_of_Alive_in_View();

  /* Garbage collection */
  Server_State.stable_arus[Server_State.id] = Server_State.aru;

  num_advanced = (Server_State.aru - original_aru);

  /* Congestion control */
  if(num_advanced == 0) {
    Proposal_State.congestion_window = Proposal_State.congestion_window / 2.0;

    if(Proposal_State.congestion_window < 1.0)
      Proposal_State.congestion_window = 1.0;
  }
  else {
    int divisor;

#ifdef WRITE_TO_DISK
    divisor = 2.0;
#else
    divisor = 200; /* Could be 150 */
#endif
    Proposal_State.congestion_window += 
      (1.0 / (Proposal_State.congestion_window * divisor)); 

    if(Proposal_State.congestion_window > WINDOW_SIZE)
      Proposal_State.congestion_window = WINDOW_SIZE;
  }

  /* Reconciliation: If I have an outstanding request, but I get what I 
   * need before the reply comes back, cancel the potential session.
   *
   * If I have a receiving session open, update the window 
   */
  if(Reconc_State.Receiving_Session.state == RECONC_REQUESTING) {
    if(Server_State.aru >= Reconc_State.Receiving_Session.session_target)
      Clear_Reconc_Session_State(&Reconc_State.Receiving_Session);
  }
  else if(Reconc_State.Receiving_Session.state == RECONC_ACKING)
    Update_Reconc_Receiver_Window(num_advanced, seq);
  
  return num_advanced;
}

static void Advance_Window(int num_slots)
{
  int start, end;
  int i;

  start = Proposal_State.window_end - WINDOW_SIZE + 1;
  end   = start + num_slots;

  for(i = start; i < end; i++) {
    /* Clear out this slot and adjust the start of the window */
    Proposal_State.window_end++;
  }

  /* Congestion control */
  Proposal_State.num_outstanding_proposals -= num_slots;
  assert(Proposal_State.num_outstanding_proposals >= 0);
}

/* Returns 1 if we have already ordered this sequence number, 0 otherwise. */
int Is_Ordered(uint32_t seq)
{
  return (seq <= Server_State.aru || (UTIL_Get_Ordered_Update(seq) != NULL));
}
