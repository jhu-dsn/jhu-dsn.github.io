/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#include <unistd.h>
#include <string.h>
#include "aggregation.h"
#include "p_server.h"
#include "def.h"
#include "paxos_protocol.h"
#include "packets.h"
#include "global_ordering.h"
#include "disk.h"
#include "tcp_wrapper.h"
#include "membership.h"
#include "util.h"
#include "client_handling.h"

/*--------------------------------------------------------------------------*/
static int  Aggregation_Process_Proposal(sys_scatter *proposal);
static void Aggregation_Send_Accept     (void);
static void Aggregation_Construct_Accept(sys_scatter *accept); 
static void Aggregation_Apply_Accept(uint32_t id, uint32_t view, 
				     uint32_t seq);  
/*--------------------------------------------------------------------------*/

extern Proposal_struct Proposal_State;
extern Disk_struct     Disk_State;
extern Server_struct   Server_State;
extern VC_struct       View_State;
extern Prepare_struct  Prepare_State;
extern Accept_struct   Accept_State;
extern Client_struct   Client_State;

void Aggregation_Enqueue_Proposal(sys_scatter *proposal)
{
  inc_ref_cnt(proposal);
  inc_ref_cnt(proposal->elements[0].buf);
  stddll_push_back(&Proposal_State.proposal_queue, &proposal);
}

void Schedule_Aggregation_Event()
{
  sp_time t;
  int r;

  /* Memory: 300, Sync: 1000*/

#ifdef WRITE_TO_DISK
  r = 1000;
#else
  r = 300;
#endif
  
  t.sec  = AGGREGATION_PERIOD_SEC;
  t.usec = AGGREGATION_PERIOD_USEC + r;

  E_queue(Timer_Dispatcher, AGGREGATION_TIMER, NULL, t);
}

void Aggregation_Timer_Handler()
{
  sys_scatter *proposal;
  stdit it;
  int num_proposals = 0;

  /* If there is nothing to do, just return gracefully. */
  if(stddll_empty(&Proposal_State.proposal_queue))
    return;
  
  stddll_begin(&Proposal_State.proposal_queue, &it);
  while(!stddll_is_end(&Proposal_State.proposal_queue, &it)) {
    proposal = *(sys_scatter **)stddll_it_val(&it);

    if(Aggregation_Process_Proposal(proposal))
      num_proposals++;
    
    dec_ref_cnt(proposal->elements[0].buf);
    dec_ref_cnt(proposal);
    stddll_it_next(&it);
  }

  /* Clean up the proposal queue */
  while(1) {
    stddll_begin(&Proposal_State.proposal_queue, &it);
    if(stddll_is_end(&Proposal_State.proposal_queue, &it))
      break;
    stddll_pop_front(&Proposal_State.proposal_queue);
  }

#ifdef WRITE_TO_DISK
  if(Disk_State.sync_flag)
    fsync(Disk_State.log_fd);
#endif

  Aggregation_Send_Accept();

  if(Server_State.state == REG_LEADER)
    Send_Some_Proposals();
}

static int Aggregation_Process_Proposal(sys_scatter *proposal)
{
  header *h;
  proposal_specific *p;
  sys_scatter *accept;

  h  = (header *)proposal->elements[0].buf;
  p  = (proposal_specific *)(h+1);

  /* Don't process a Proposal that you've already ordered.  This can
   * happen if we're the leader and we order it using our proposal and
   * other people's accept messages. */
  if(Is_Ordered(p->seq))
    return 0;

#ifdef WRITE_TO_DISK
  Write_Message(proposal, PROPOSAL_TYPE);
#endif

  /* The Proposal has already been applied, and we decided it was one
   * for which we should send an Accept message.  Construct an Accept
   * message and apply it to the data structures. */
  accept = new_ref_cnt(SYS_SCATTER);
  Construct_Accept_Message(accept, p->seq);
  Apply_Accept(accept);
  Attempt_to_Order(p->seq);

  dec_ref_cnt(proposal->elements[0].buf);
  dec_ref_cnt(proposal);

  /* Put the accept on a queue to later send and cleanup */
  inc_ref_cnt(accept);
  inc_ref_cnt(accept->elements[0].buf);
  stddll_push_back(&Proposal_State.accept_queue, &accept);

  return 1;
}

static void Aggregation_Send_Accept()
{
  sys_scatter *accept;
  stdit it;

  accept = new_ref_cnt(SYS_SCATTER);
  Aggregation_Construct_Accept(accept);
  Send_MCast(accept);

  dec_ref_cnt(accept->elements[0].buf);
  dec_ref_cnt(accept);

  /* Clean up the accept queue */
  while(1) {
    stddll_begin(&Proposal_State.accept_queue, &it);
    if(stddll_is_end(&Proposal_State.accept_queue, &it))
      break;
    accept = *(sys_scatter **)stddll_it_val(&it);
    dec_ref_cnt(accept->elements[0].buf);
    dec_ref_cnt(accept);
    stddll_pop_front(&Proposal_State.accept_queue);
  }
}

static void Aggregation_Construct_Accept(sys_scatter *accept)
{
  header *h, *qh;
  accept_specific *a, *qa;
  uint32_t *p;
  stdit it;
  int num_seqs;
  sys_scatter *q_accept;

  accept->num_elements = 1;
  accept->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);

  h = (header *)accept->elements[0].buf;

  h->packetType = ACCEPT;
  h->serverID   = Server_State.id;
  h->viewNum    = View_State.last_installed;

  a = (accept_specific *)(h+1);
  a->seq = 0;
  num_seqs = 0;

  p = (uint32_t *)&a->seq;

  /* Go through the accept queue and add the sequence number of each one
   * being accepted. */

  stddll_begin(&Proposal_State.accept_queue, &it);
  while(!stddll_is_end(&Proposal_State.accept_queue, &it)) {
    q_accept = *(sys_scatter **)stddll_it_val(&it);
    qh = (header *)q_accept->elements[0].buf;
    qa = (accept_specific *)(qh+1);

    memcpy((int *)p, &qa->seq, sizeof(uint32_t));
    dec_ref_cnt(q_accept->elements[0].buf);
    dec_ref_cnt(q_accept);
    num_seqs++;
    p++; 
    stddll_it_next(&it);
  }
  *p = 0; /* "NULL" terminate */
  num_seqs++;

  h->dataLen = sizeof(uint32_t) * num_seqs;
  /*Alarm(PRINT, "Accept dataLen = %d\n", h->dataLen);*/
  accept->elements[0].len = sizeof(header) + h->dataLen;
}

void Aggregation_Process_Accept(sys_scatter *accept)
{
  header *h;
  accept_specific *a;
  uint32_t *p;
  uint32_t seq;
  uint32_t max;
  int aru_flag = 0;

  max = 0;

  h = (header *)accept->elements[0].buf;
  a = (accept_specific *)(h+1);
  p = (uint32_t *)&a->seq;

  /* Iterate through the list of sequence numbers.  Apply each one and then
   * attempt to order it. */
  while(*p != 0) {
    seq = *p;

    if(!Is_Ordered(seq)) {
      Aggregation_Apply_Accept(h->serverID, h->viewNum, seq);
      Attempt_to_Order(seq);
    }

    if(seq > max)
      max = seq;
    p++;
  }

  /* Infer the sending server's local_aru minimum from the sequence
   * number.  A server only sends an ACCEPT if it is within one WINDOW
   * of its local_aru.  Thus, the server's local_aru must be at least 
   * (seq - WINDOW).  Update it to reflect this if necessary.  Only do 
   * this if we're beyond the first window to avoid underflow. */
  if( (Server_State.arus[h->serverID] < (max - WINDOW_SIZE)) &&
      (max >= WINDOW_SIZE) ) {
    Server_State.arus[h->serverID] = (max - WINDOW_SIZE);
    Server_State.global_aru = Compute_Global_Aru_of_Alive_in_View();
    aru_flag = 1;
  }

  /* If this opens the global flow control window and I'm the leader, try 
   * to send some more proposals.*/
  if(aru_flag)
    if((Server_State.state == REG_LEADER) && (Prepare_State.view_is_prepared))
      Send_Some_Proposals();
}

static void Aggregation_Apply_Accept(uint32_t id, uint32_t view, uint32_t seq)
{
  accept_node *a;
  int i;

  /* If there is no entry for this slot, initialize the slot */
  if(UTIL_Get_Stats(seq) == NULL) {
    a = new_ref_cnt(ACCEPT_NODE);
    for(i = 1; i <= MAX_SERVERS; i++)
      a->accept_received[i] = 0;
    a->num_received = 0;
    a->viewNum      = 1;
    UTIL_Insert_Stats(seq, a);
  }

  /*
   * If we have already accepted a proposal for this seq, we'll do either:
   *   1. If it's for the same view and is not a duplicate, add to tally
   *   2. If it's for a later view, erase what was there and count anew
   */

  a = UTIL_Get_Stats(seq);
  if(view == a->viewNum) {
    if(!a->accept_received[id]) {
      a->viewNum = view;
      a->accept_received[id] = 1;
      a->num_received++;
    }
  }
  else if(view > a->viewNum) {
    a->num_received = 1; /* This one */
    a->viewNum      = view;

    for(i = 1; i <= MAX_SERVERS; i++)
      a->accept_received[i] = 0;
    
    a->accept_received[id] = 1;
  }
}

void Aggregation_Add_Update_To_Queue(sys_scatter *msg)
{
  sys_scatter *update;

  update = new_ref_cnt(SYS_SCATTER);

  update->num_elements = 1;
  update->elements[0].buf = msg->elements[0].buf;
  update->elements[0].len = msg->elements[0].len;
  inc_ref_cnt(update->elements[0].buf);  

  /* Set the event that processes them and syncs them all to disk. */
  Schedule_Aggregation_Update_Event();
  stddll_push_back(&Client_State.aggregation_update_queue, &update);
}

void Aggregation_Update_Timer_Handler(int sync_flag)
{
  sys_scatter *update;
  stdit it;
  int num_updates = 0;

  /* Go through the queue and process each one */
  stddll_begin(&Client_State.aggregation_update_queue, &it);
  if(stddll_is_end(&Client_State.aggregation_update_queue, &it))
    return;
  
  while(!stddll_is_end(&Client_State.aggregation_update_queue, &it)) {
    update = *(sys_scatter **)stddll_it_val(&it);
    Aggregation_Handle_Update(update);
    num_updates++;

    /* Remove update from the agg_update_queue */
    dec_ref_cnt(update->elements[0].buf);
    dec_ref_cnt(update);

    stddll_it_next(&it);
  }

  /* Clean up the agg_update_queue */
  while(1) {
    stddll_begin(&Client_State.aggregation_update_queue, &it);
    if(stddll_is_end(&Client_State.aggregation_update_queue, &it))
      break;
    stddll_pop_front(&Client_State.aggregation_update_queue);
  }

#if 0
  if(Server_State.id == 1) {
    Alarm(PRINT, "Aggregated %d updates\n", num_updates);
    fflush(stdout);
  }
#endif

  /* Sync all of the pending update files */
  if(sync_flag) {
    fsync(Disk_State.log_fd);
    Aggregation_Forward_Updates();

    if(Server_State.state == REG_LEADER)
      Send_Some_Proposals();
  }
}

void Aggregation_Forward_Updates()
{
  sys_scatter *update;
  stdit it;

  /* Forward any updates that need to be forwarded */
  stddll_begin(&Client_State.forward_queue, &it);
  while(!stddll_is_end(&Client_State.forward_queue, &it)) {
    update = *(sys_scatter **)stddll_it_val(&it);
    Forward_Update(update);

    /* Remove update from forward queue */
    dec_ref_cnt(update->elements[0].buf);
    dec_ref_cnt(update);
    
    stddll_it_next(&it);
  }
  
  /* Clean up the forward queue */
  while(1) {
    stddll_begin(&Client_State.forward_queue, &it);
    if(stddll_is_end(&Client_State.forward_queue, &it))
      break;
    stddll_pop_front(&Client_State.forward_queue);
  }
}

void Aggregation_Handle_Update(sys_scatter *update)
{

  switch(Server_State.state) {

  case LEADER_ELECTION:
    if(Enqueue_Update(update))
      Add_Update_to_Pending(update);
    break;

  
  case REG_NONLEADER:
    Add_Update_to_Pending(update);
    inc_ref_cnt(update);
    inc_ref_cnt(update->elements[0].buf);
    stddll_push_back(&Client_State.forward_queue, &update);
    break;

  case REG_LEADER:
    
    if(!Prepare_State.view_is_prepared) {
      if(Enqueue_Update(update))
        Add_Update_to_Pending(update);
      return;
    }

    /* If we already have this update on the queue, ignore it */
    if(Enqueue_Update(update))
      Add_Update_to_Pending(update);
  }
}

void Schedule_Aggregation_Update_Event()
{
  sp_time t;

  t.sec  = 0;
  t.usec = 1500; /* + (rand() % 4000);*//* + (rand() % 3000);*/

  E_queue(Timer_Dispatcher, AGGREGATION_UPDATE_TIMER, NULL, t);
}
