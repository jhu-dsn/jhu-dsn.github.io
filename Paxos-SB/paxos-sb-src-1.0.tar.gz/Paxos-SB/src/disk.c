/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#include <assert.h>
#include <unistd.h>
#include "disk.h"
#include "p_server.h"
#include "packets.h"
#include "tcp_wrapper.h"

/*-------------------------------------------------*/
static void Write_Log_Type(uint32_t type);
/*-------------------------------------------------*/

extern Disk_struct      Disk_State;
extern Server_struct    Server_State;
extern Client_struct    Client_State;

#ifdef SERVER_BENCHMARKING
extern Benchmark_struct Benchmark_State;
#endif

static void Write_Log_Type(uint32_t type)
{
  size_t ret;
  
  ret = TCP_Write(Disk_State.log_fd, (uint32_t *)&type, sizeof(uint32_t));
  if(ret <= 0)
    Alarm(EXIT, "Couldn't write entry type to file...\n");
}

void Write_Message(sys_scatter *msg, uint32_t type)
{
  size_t ret;
  int total;

#ifdef SERVER_BENCHMARKING
  sp_time start, end, diff;
 
  Benchmark_State.write_count++;
  start = E_get_time();
#endif  

  Write_Log_Type(type);

  total = msg->elements[0].len;

  /* Now write the message itself */
  ret = TCP_Write(Disk_State.log_fd, (char *)msg->elements[0].buf, total);
  if(ret <= 0)
    Alarm(EXIT, "Write problem.\n");

#ifndef AGGREGATION
  if((type == PROPOSAL_TYPE) && (Disk_State.sync_flag))
    fsync(Disk_State.log_fd);
#endif

#ifdef SERVER_BENCHMARKING
  /* Compute the total write time for benchmarking purposes */
  end  = E_get_time();
  diff = E_sub_time(end, start);
  Benchmark_State.total_write_time = 
    E_add_time(Benchmark_State.total_write_time, diff);

  if(type == PROPOSAL_TYPE)
    Benchmark_State.proposal_write_times[Server_State.aru] = diff;
  else
    Benchmark_State.order_write_times[Server_State.aru] = diff;
#endif

  /* For debugging: write the ordered updates to disk, in sequence. */
#ifdef DEBUG_LOG
  if(type == ORDER_TYPE) {
    header *h;
    update_header *uh;
    proposal_specific *ps;
    char *p;
    int i;

    h  = (header *)msg->elements[0].buf;
    ps = (proposal_specific *)(h+1);
    uh = (update_header *)(ps+1);

    for(i = 0; i < ps->num_updates; i++) {
      fprintf(Disk_State.debug_fp, "Seq %6d: Client %6d, TS %6d\n", 
	    ps->seq, uh->clientID, uh->timestamp);
      p = (char *)(uh + 1);
      p += uh->dataLen;
      uh = (update_header *)p;
    }    
    
    fflush(Disk_State.debug_fp);
  }
#endif  
}

void Write_Pending_Update_to_Disk(sys_scatter *update)
{
  update_header *uh;
  size_t ret;
 
  uh = (update_header *)update->elements[0].buf;
  assert(uh);
  assert(Client_State.pending_updates[uh->clientID]);
 
  Write_Log_Type(UPDATE_TYPE);  
  ret = TCP_Write(Disk_State.log_fd, (char *)uh, update->elements[0].len);
  
  if(ret <= 0)
    Alarm(EXIT, "Problem writing pending update to disk for client %d\n",
	  uh->clientID);
  
#ifndef UPDATE_INITIATION_AGGREGATION
  if(Disk_State.sync_flag)
    fsync(Disk_State.log_fd);
#endif

#ifdef DEBUG_LOG
  fprintf(Disk_State.debug_fp, "Client %6d, TS %6d\n", 
	  uh->clientID, uh->timestamp);
  fflush(Disk_State.debug_fp);
#endif  

}

void Write_View_to_Disk(uint32_t *view)
{
  int fd, ret;

  fd = Disk_State.view_fd;

  lseek(fd, 0, SEEK_SET);

  ret = TCP_Write(fd, (uint32_t *)view, sizeof(uint32_t));
  if(ret <= 0)
    Alarm(EXIT, "Problem writing view to disk for view %d\n", *view);

  if(Disk_State.sync_flag)
    fsync(fd);
}

void Write_White_Line_to_Disk(uint32_t *white_line)
{
  ssize_t ret;
  
  Write_Log_Type(WHITE_LINE_TYPE);

  ret = TCP_Write(Disk_State.log_fd, (uint32_t *)white_line, sizeof(uint32_t));
  if(ret <= 0)
    Alarm(EXIT, "Problem writing white_line to disk for WL %d\n", *white_line);
}
