/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include "net_include.h"
#include "def.h"
#include "p_server.h"
#include "paxos_protocol.h"
#include "net.h"
#include "util_include.h"
#include "packets.h"
#include "membership.h"
#include "global_ordering.h"
#include "client_handling.h"

/*----------------------------------------*/
static void Initialize(void);
static void Initialize_Memory_Objects();
static void Initialize_Data_Structures();
static void Read_Configuration_File(void);
static void Usage(int argc, char **argv);
static void Print_Usage_String(void);
/*----------------------------------------*/

Parameter_struct Params;
Server_struct    Server_State;
Network_struct   Network_State;
Disk_struct      Disk_State;
VC_struct        View_State;
Retrans_struct   Retrans_State;
Prepare_struct   Prepare_State;
Client_struct    Client_State;
Proposal_struct  Proposal_State;
Accept_struct    Accept_State;
Alive_struct     Alive_State;
Reconc_struct    Reconc_State;

#ifdef SERVER_BENCHMARKING
Benchmark_struct Benchmark_State;
#endif

int main(int argc, char **argv)
{
  Usage(argc, argv); 
  Read_Configuration_File();

  Initialize();
  Recovery();

  E_handle_events();

  return 0;
}

static void Initialize()
{
  Alarm(PRINT, "Initializing state.\n");
  Initialize_Memory_Objects();
  Initialize_Network();
  Initialize_Data_Structures();
}

static void Initialize_Data_Structures()
{
  int i;

  /* Seed random number generator with server id */
  srand(Server_State.id);

  Server_State.aru        = 0; 
  Server_State.global_aru = 0;
  Server_State.white_line = 0;
  for(i = 1; i <= MAX_SERVERS; i++) {
    Server_State.arus[i]        = 0;
    Server_State.stable_arus[i] = 0;
    Server_State.views[i]       = 0;
  }

  for(i = 1; i <= MAX_CLIENTS; i++)
    Server_State.recovered_updates[i] = NULL;

  View_State.last_attempted        = 0;
  View_State.last_installed        = 0;
  View_State.max_view              = 0;
  View_State.num_received          = 0;
  View_State.progress_timer_is_set = 0;
  for(i = 1; i <= MAX_SERVERS; i++)
    View_State.attempt_received[i] = 0;

  for(i = 0; i < MAX_PACKET_TYPES; i++) {
    Retrans_State.buf[i]          = NULL;
    Retrans_State.packet_types[i] = i;
  }

  Prepare_State.view_is_prepared            = 0;
  Prepare_State.num_completed               = 0;
  stddll_construct(&Prepare_State.rejected_queue, sizeof(anti_entropy_obj *));

  Clear_Prepare_Session(&Prepare_State.Sending_Session);
  for(i = 1; i <= MAX_SERVERS; i++) {
    Prepare_State.prepare_ok_completed[i] = 0;
    Clear_Prepare_Session(&Prepare_State.Receiving_Sessions[i]);
    Prepare_State.indices[i] = i;
  }

  stddll_construct(&Client_State.update_queue, sizeof(sys_scatter *));
  for(i = 1; i <= MAX_CLIENTS; i++) {
    Client_State.last_executed[i]    = 0;
    Client_State.last_enqueued[i]    = 0;
    Client_State.pending_updates[i]  = NULL;
    Client_State.indices[i]          = i;
  }

  Proposal_State.last_proposed = 0;
  Proposal_State.window_end    = WINDOW_SIZE;
  for(i = 0; i < WINDOW_SIZE; i++) {
    Proposal_State.window[i]            = NULL;
    Proposal_State.indices[i]           = i;
  }

  Proposal_State.congestion_window         = 1.0;
  Proposal_State.num_outstanding_proposals = 0;

  stdhash_construct(&Accept_State.latest_accepted, sizeof(uint32_t),
		    sizeof(sys_scatter *), NULL, NULL, STDHASH_OPTS_DEFAULTS);
  stdhash_construct(&Accept_State.stats, sizeof(uint32_t),
		    sizeof(accept_node *), NULL, NULL, STDHASH_OPTS_DEFAULTS);
  stdhash_construct(&Accept_State.ordered_updates, sizeof(uint32_t),
		    sizeof(sys_scatter *), NULL, NULL, STDHASH_OPTS_DEFAULTS);

  for(i = 1; i <= MAX_CLIENTS; i++)
    Network_State.Client_to_Sd[i] = -1;

  for(i = 1; i <= MAX_SERVERS; i++) {
    Alive_State.is_alive[i] = 0;
    Alive_State.members[i]  = i;
  }
  Alive_State.is_alive[Server_State.id] = 1;
  Alive_State.num_alive = 1;
  stddll_construct(&Alive_State.anti_entropy_queue,sizeof(anti_entropy_obj *));

  Schedule_Alive_Event();

  for(i = 1; i <= MAX_SERVERS; i++) {
    Clear_Reconc_Session_State(&Reconc_State.Sending_Sessions[i]);
    Reconc_State.random_tried[i] = 0;
  }
  Clear_Reconc_Session_State(&Reconc_State.Receiving_Session);
  Reconc_State.num_consecutive_failures = 0;

#ifdef SERVER_BENCHMARKING
  Benchmark_State.write_count            = 0;
  Benchmark_State.total_write_time.sec   = 0;
  Benchmark_State.total_write_time.usec  = 0;
  Benchmark_State.total_updates          = 0;
  Benchmark_State.start_updates          = 0;
#endif

#ifdef AGGREGATION
  stddll_construct(&Proposal_State.proposal_queue, sizeof(sys_scatter *));
  stddll_construct(&Proposal_State.accept_queue, sizeof(sys_scatter *));
  srand(Server_State.id);
#endif

#ifdef UPDATE_INITIATION_AGGREGATION
  stddll_construct(&Client_State.aggregation_update_queue, 
		   sizeof(sys_scatter *));
  stddll_construct(&Client_State.forward_queue, sizeof(sys_scatter *));
#endif

}

static void Initialize_Memory_Objects()
{
  Mem_init_object(SYS_SCATTER, sizeof(sys_scatter), 100, 20);
  Mem_init_object(PACK_BODY_OBJ, sizeof(char) * MAX_PACKET_SIZE, 100, 20);
  Mem_init_object(ACCEPT_NODE, sizeof(accept_node), WINDOW_SIZE, WINDOW_SIZE);
  Mem_init_object(ANTI_ENTROPY_OBJ, sizeof(anti_entropy_obj), 20, 1);
}


static void Read_Configuration_File()
{
  FILE *f;
  char buf[128];
  int i, len;
#ifdef WRITE_TO_DISK
  int ret;
#endif

  if((f = fopen("paxos.config", "r")) == NULL)
    Alarm(EXIT, "Could not open configuration file for reading.\n");

  i = 1;

  while((fgets(buf, 128, f)) != NULL) {
    /* Ignore comment and blank lines */
    if( (buf[0] == '#') || (buf[0] == '\n') )
      continue;
    
    len = strlen(buf);
    buf[len-1] = '\0';
    inet_pton(AF_INET, buf, &Network_State.server_addresses[i]);

    /* If this is me, set my address */
    if(i == Server_State.id) {
      Network_State.address = htonl(Network_State.server_addresses[i]); 
    }
    
    /* To make it work with datalink...*/
    Network_State.server_addresses[i] = 
      htonl(Network_State.server_addresses[i]);
    
    i++;
  }
  fclose(f);

#ifdef WRITE_TO_DISK
  sprintf(Disk_State.log_file_name, "logs/server_%d.log", Server_State.id);

  /* If log file exists, open it.  Otherwise, create it. */
  ret = open(Disk_State.log_file_name, O_RDWR);
  
  if(ret < 0) {
    ret = open(Disk_State.log_file_name, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
    if(ret < 0) {
      perror("open log file");
      exit(0);
    }
  }
  Disk_State.log_fd = ret;

  sprintf(buf, "/logs/server_%d.view", Server_State.id);
  ret = open(buf, O_RDWR);
  if(ret < 0) {
    ret = open(buf, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
    if(ret < 0) {
      perror("open view file");
      exit(0);
    }
  }
  Disk_State.view_fd = ret;

#ifdef DEBUG_LOG
  sprintf(buf, "/logs/server_%d.debug", Server_State.id);
  Disk_State.debug_fp = fopen(buf, "a+");
#endif

#endif
}

static void Print_Usage_String()
{
  fprintf(stderr, "Usage: p_server <server_id> <num_servers> [--sync]\n");
}

static void Usage(int argc, char **argv)
{
  char **p;

  Disk_State.sync_flag = 0;

  if(argc < 3) {
    Print_Usage_String();
    exit(1);
  }

  Server_State.id    = atoi(argv[1]);
  Params.Num_Servers = atoi(argv[2]);

  /* Validate the number of servers */
  if(Params.Num_Servers < 1 || Params.Num_Servers > MAX_SERVERS) {
    Print_Usage_String();
    exit(1);
  }

  /* Validate the server ID */
  if(Server_State.id < 1 || Server_State.id > Params.Num_Servers) {
    fprintf(stderr, "Server ID must be between 1 and num_servers\n");
    exit(1);
  }
  
  Params.Majority = (Params.Num_Servers / 2) + 1;

  p = &(argv[3]);

  while(*p != NULL) {
    if(!strncmp(*p, "--sync", 6))
      Disk_State.sync_flag = 1;
    else {
      Print_Usage_String();
      exit(1);
    }
    p++;
  }
}
