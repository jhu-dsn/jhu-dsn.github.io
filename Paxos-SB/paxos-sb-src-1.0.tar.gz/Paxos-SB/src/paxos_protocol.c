/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#include <unistd.h>
#include <stdlib.h>
#include "paxos_protocol.h"
#include "p_server.h"
#include "packets.h"
#include "retrans.h"
#include "net.h"
#include "util_include.h"
#include "leader_election.h"
#include "membership.h"
#include "global_ordering.h"
#include "prepare_phase.h"
#include "client_handling.h"
#include "disk.h"
#include "tcp_wrapper.h"
#include "aggregation.h"
#include "util.h"

/*---------------------------------------------------*/
#ifdef WRITE_TO_DISK
static void Process_Log_File      (void);
static void Process_View_File     (void);
static void Process_Client_State  (void);
static uint32_t Read_Log_Type     (void);
static void Log_Process_White_Line(void);
static void Log_Process_Update    (void);
static void Log_Process_Proposal  (void);
static void Log_Process_Ordered   (void);
static void Log_Read_Proposal     (sys_scatter *msg);
#endif
/*---------------------------------------------------*/

extern Parameter_struct Params;
extern Server_struct    Server_State;
extern Network_struct   Network_State;
extern VC_struct        View_State;
extern Retrans_struct   Retrans_State;
extern Prepare_struct   Prepare_State;
extern Proposal_struct  Proposal_State;
extern Accept_struct    Accept_State;
extern Alive_struct     Alive_State;
extern Client_struct    Client_State;
extern Disk_struct      Disk_State;
extern Reconc_struct    Reconc_State;

#ifdef SERVER_BENCHMARKING
extern Benchmark_struct Benchmark_State;
#endif

void Timer_Dispatcher(int code, void *data)
{
  switch(code) {
  case RETRANS_TIMER:
    Retrans_Timer_Handler((int *)data);
    break;
  case VC_PROOF_TIMER:
    VC_Proof_Timer_Handler();
    break;
  case PROPOSAL_RETRANS_TIMER:
    Proposal_Retrans_Timer_Handler((int *)data);
    break;
  case PROGRESS_TIMER:
    Progress_Timer_Handler();
    break;
  case ALIVE_TIMER:
    Alive_Timer_Handler();
    break;
  case MEMBERSHIP_TIMER:
    Membership_Timer_Handler(*(int *)data);
    break;
  case UPDATE_TIMER:
    Update_Timer_Handler(*(int *)data);
    break;
  case RECONC_RESPONSE_TIMER:
    Reconc_Response_Timer_Handler();
    break;
  case ACK_TIMER:
    Reconc_Ack_Timer_Handler();
    break;
  case ANTI_ENTROPY_TIMER:
    Reconc_Anti_Entropy_Timer_Handler(*(int *)data);
    break;
  case PREPARE_RETRANS_TIMER:
    Prepare_Retrans_Timer_Handler(*(int *)data);
    break;
  case PREPARE_ACK_TIMER:
    Prepare_Ack_Timer_Handler(*(int *)data);
    break;
  case AGGREGATION_TIMER:
    Aggregation_Timer_Handler();
    break;
  case AGGREGATION_UPDATE_TIMER:
    Aggregation_Update_Timer_Handler(1); /* Called from timer, should sync */
    break;
  default:
    Alarm(EXIT, "Unexpected timer code: %d\n", code);
  }
}

void Message_Dispatcher(int sd, int code, void *data)
{
  sys_scatter *msg;
  header *h;
  int nRead;

  if((nRead = DL_recv(sd, &Network_State.Recv_Msg)) < 
     sizeof(header))
    Alarm(EXIT, "Received invalid packet (too small): %d\n", nRead);

  Network_State.Recv_Msg.elements[0].len = nRead;
  msg = (sys_scatter *)&(Network_State.Recv_Msg);

  h = (header *)msg->elements[0].buf;

  /* Filter out my own messages for those that are multicast */
  switch(h->packetType) {

  case VC:
  case VC_PROOF:
  case PREPARE:
  case PROPOSAL:
  case ACCEPT:
  case ALIVE:
    if(h->serverID == Server_State.id)
      goto finish;
    break;
  }

  switch(h->packetType) {
  case VC:
    VC_Message_Handler(msg);
    break;
  case VC_PROOF:
    VC_Proof_Message_Handler(msg);
    break;
  case PREPARE:
    Prepare_Message_Handler(msg);
    break;
  case PREPARE_OK: /* Unicast */
    Prepare_Ok_Message_Handler(msg);
    break;
  case PREPARE_PHASE: /* Unicast */
    Prepare_Phase_Message_Handler(msg);
    break;
  case PREPARE_ACK: /* Unicast */
    Prepare_Ack_Message_Handler(msg);
    break;
  case UPDATE:
    Update_Handler(msg);
    break;
  case PROPOSAL:
    Proposal_Message_Handler(msg);
    break;
  case ACCEPT:
    Accept_Message_Handler(msg);
    break;
  case ORDER: /* Unicast */
    Order_Message_Handler(msg);
    break;
  case ALIVE:
    Alive_Message_Handler(msg);
    break;
  case REQUEST: /* Unicast */
    Reconc_Request_Message_Handler(msg);
    break;
  case RECONC_RESPONSE: /* Unicast */
    Reconc_Response_Message_Handler(msg);
    break;
  case RECONC_ACK: /* Unicast */
    Reconc_Ack_Message_Handler(msg);
    break;
  default:
    Alarm(EXIT, "Unexpected packet received: %d\n", h->packetType);
  }

 finish:

  Network_State.Recv_Msg.elements[0].len = MAX_PACKET_SIZE;

  if(get_ref_cnt(Network_State.Recv_Msg.elements[0].buf) > 1) {
    dec_ref_cnt(Network_State.Recv_Msg.elements[0].buf);
    Network_State.Recv_Msg.elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);
  } 
}

void Shift_to_Leader_Election(uint32_t viewNum)
{
  sys_scatter *msg;
  int i;

  Server_State.state = LEADER_ELECTION;

  Initialize_View_State(viewNum);

  Cancel_Retrans(VC);

  msg = new_ref_cnt(SYS_SCATTER);
  Construct_VC_Message(msg);
  
  Schedule_Retrans(msg, VC);

  Apply_VC_Message(msg);

  Send_MCast(msg);

  dec_ref_cnt(msg->elements[0].buf);
  dec_ref_cnt(msg);

  /* Set up periodic broadcast of latest installed view */
  Schedule_VC_Proof_Event();

  /* We don't expect progress to be made while in leader election state until
   * we are waiting for the Prepare phase to end. */
  Cancel_Progress_Timer();

  /* Cancel all timeouts associated with Prepare phase */
  for(i = 1; i <= MAX_SERVERS; i++) {
    Clear_Prepare_Session(&Prepare_State.Receiving_Sessions[i]);
    E_dequeue(Timer_Dispatcher, PREPARE_RETRANS_TIMER, 
	      &Prepare_State.indices[i]);
  }

  Clear_Prepare_Session(&Prepare_State.Sending_Session);
  Clear_Prepare_Ok_Rejected();

  for(i = 1; i <= MAX_CLIENTS; i++)
    Client_State.last_enqueued[i] = 0;
}

void Shift_to_Reg_Leader()
{
  sys_scatter *msg;
  int i;
  sp_time t;

  Server_State.state = REG_LEADER;
  
  /* We have now completed leader election and installed the view */
  View_State.last_installed = View_State.last_attempted;
  Alarm(PRINT, "***************************\n");
  Alarm(PRINT, "Leader, installed view %d\n", View_State.last_installed);
  Alarm(PRINT, "***************************\n");
  Cancel_Retrans(VC);

  fflush(stdout);

#ifdef WRITE_TO_DISK
  Write_View_to_Disk(&View_State.last_installed);
#endif

  /* Simulate reception of your own Prepare message */
  Prepare_State.num_completed = 1;
  for(i = 1; i <= MAX_SERVERS; i++)
    Prepare_State.prepare_ok_completed[i] = 0;
  Prepare_State.prepare_ok_completed[Server_State.id] = 1;
  Prepare_State.view_is_prepared                      = 0;
  Clear_Prepare_Ok_Rejected();

  /* Initialize all potential Prepare receiving sessions, and send 
   * Prepare (i.e., "request") message on each. */
  for(i = 1; i <= Params.Num_Servers; i++) {
    if(i == Server_State.id)
      continue;
    
    Create_Prepare_Receiving_Session(&Prepare_State.Receiving_Sessions[i], i);

    msg = new_ref_cnt(SYS_SCATTER);
    Construct_Prepare_Message(msg, i);
    
    Send_UCast(Network_State.sd, msg, i);
    dec_ref_cnt(msg->elements[0].buf);
    dec_ref_cnt(msg);

    t.sec  = PREPARE_RETRANS_SEC;
    t.usec = PREPARE_RETRANS_USEC;
    E_queue(Timer_Dispatcher, PREPARE_RETRANS_TIMER, 
	    &Prepare_State.indices[i], t);
  }

  Refresh_Progress_Timer();

  /* Reinitialize the window for this view */
  Proposal_State.last_proposed = Server_State.aru;
  Proposal_State.window_end    = Server_State.aru + WINDOW_SIZE;

  for(i = 1; i <= MAX_CLIENTS; i++)
    Client_State.last_enqueued[i] = 0;
}

void Shift_to_Reg_Nonleader()
{
  int i;
  uint32_t previous_state;

  previous_state     = Server_State.state;
  Server_State.state = REG_NONLEADER;

  /* Leader election is now complete, install */
  View_State.last_installed = View_State.last_attempted;
  Alarm(PRINT, "***************************\n");
  Alarm(PRINT, "Non_Leader, installed view %d\n", View_State.last_installed);
  Alarm(PRINT, "***************************\n");

  fflush(stdout);

#ifdef WRITE_TO_DISK
  Write_View_to_Disk(&View_State.last_installed);
#endif

  Cancel_Retrans(VC);
  
  for(i = 1; i <= MAX_SERVERS; i++) {
    Clear_Prepare_Session(&Prepare_State.Receiving_Sessions[i]);
    E_dequeue(Timer_Dispatcher, PREPARE_RETRANS_TIMER, 
	      &Prepare_State.indices[i]);
  }
  Clear_Prepare_Session(&Prepare_State.Sending_Session);
  Clear_Prepare_Ok_Rejected();

  Refresh_Progress_Timer();

  /* Update handling: If I was the leader and now I'm a non-leader, all of 
   * my updates should be forwarded properly to the new leader, since they
   * are in pending_updates and when the timeout expires I will now send
   * them to the new leader.  However, someone in leader election that was
   * queuing updates needs to forward them to the new leader. */
  if(previous_state == LEADER_ELECTION)
    Forward_Queued_Updates();
}

uint32_t Compute_White_Line()
{
  int i;
  int min = 0;

  for(i = 1; i <= Params.Num_Servers; i++) {
    if(i == 1)
      min = Server_State.stable_arus[i];
    else if(Server_State.stable_arus[i] < min)
      min = Server_State.stable_arus[i];
  }
  return min;
}

void Garbage_Collect(uint32_t new_white_line)
{
  int i;
  sys_scatter *msg;
  accept_node *a;

#if 0
  Alarm(PRINT, "Attempting to GC from %d to %d\n", 
	Server_State.white_line, new_white_line);
  fflush(stdout);
#endif

  /* Remove any memory storage associated with sequence number */
  for(i = Server_State.white_line+1; i <= new_white_line; i++) {
    msg = UTIL_Get_Latest_Accepted(i);
    if(msg) {
      dec_ref_cnt(msg->elements[0].buf);
      dec_ref_cnt(msg);
      UTIL_Remove_Latest_Accepted(i);
    }
    
    a = UTIL_Get_Stats(i);
    if(a) {
      dec_ref_cnt(a);
      UTIL_Remove_Stats(i);
    }

    msg = UTIL_Get_Ordered_Update(i);
    if(msg) {
      dec_ref_cnt(msg->elements[0].buf);
      dec_ref_cnt(msg);
      UTIL_Remove_Ordered_Update(i);
    }
  }
}

uint32_t Is_Session_Open()
{
  int i; 

  /* Now check Prepare phase */
  if(Prepare_State.Sending_Session.state != PREPARE_INACTIVE) {
    Alarm(PRINT, "Prepare sending session open.\n");
    fflush(stdout);
    return 1;
  }

  for(i = 1; i <= Params.Num_Servers; i++) {
    if(Prepare_State.Receiving_Sessions[i].state != PREPARE_INACTIVE) {
      Alarm(PRINT, "Prepare receiving session open with %d.\n", i);
      fflush(stdout);
      return 1;
    }
  }

  return 0;
}

void Recovery()
{
  uint32_t leader;

  Alarm(PRINT, "Server %d, recovering.\n", Server_State.id);
  fflush(stdout);

#ifdef WRITE_TO_DISK  
  Process_Log_File();
  Process_Client_State();
  Process_View_File();
#endif

  leader = (View_State.last_installed) % (Params.Num_Servers);
  if(leader == 0)
    leader = Params.Num_Servers;

  /* If I was leader of my last installed view, shift to one higher */
  if(View_State.last_installed == 0 || Server_State.id == leader) {
    Shift_to_Leader_Election(View_State.last_installed + 1);
    Alarm(PRINT, "Shifting to leader election for view %d\n",
	  View_State.last_installed + 1);
  }
  else {
    Shift_to_Leader_Election(View_State.last_installed + 1);
    Alarm(PRINT, "Shifting to leader election for view %d\n",
	  View_State.last_installed + 1);
  }
}

#ifdef WRITE_TO_DISK
static void Process_Log_File()
{
  int fd;
  uint32_t type;

  /* Go through my log file.  For each log entry:
   *    1. If it's a Proposal type, add it to latest_accepted. 
   *    2. If it's an Ordered type:
   *       a. Remove a Proposal if I have one
   *       b. Add it to ordered_updates
   *       c. Update my aru
   *       d. Update Last_Executed based on client
   */

  fd = Disk_State.log_fd;
  assert(fd != -1);

  while((type = Read_Log_Type()) != 0) {
    switch(type) {

    case PROPOSAL_TYPE:
      Log_Process_Proposal();
      break;

    case ORDER_TYPE:
      Log_Process_Ordered();
      break;

    case UPDATE_TYPE:
      Log_Process_Update();
      break;
      
    case WHITE_LINE_TYPE:
      Log_Process_White_Line();
      break;

    default:
      Alarm(EXIT, "Unexpected log entry type: %u\n", type);
    }
  }
}
#endif

#ifdef WRITE_TO_DISK
static uint32_t Read_Log_Type()
{
  int ret;
  uint32_t type;

  ret = TCP_Read(Disk_State.log_fd, (uint32_t *)&type, sizeof(uint32_t));

  if(ret < 0) {
    perror("read log type");
    exit(0);
  }

  if(ret == 0)
    return 0;

  return type;
}
#endif

#ifdef WRITE_TO_DISK
static void Log_Process_White_Line()
{
  uint32_t white_line;
  int ret;
  
  ret = TCP_Read(Disk_State.log_fd, (uint32_t *)&white_line, sizeof(uint32_t));

  if(ret < 0) {
    perror("read meta");
    exit(0);
  }
  
  assert(white_line >= Server_State.white_line);
  Garbage_Collect(white_line);
  Server_State.white_line = white_line;
}  
#endif

#ifdef WRITE_TO_DISK
static void Log_Process_Update()
{
  sys_scatter *update;
  sys_scatter *old_update;
  update_header *uh;
  ssize_t ret;
  int len;

  update                  = new_ref_cnt(SYS_SCATTER);
  update->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);
  update->num_elements    = 1;

  /* First read in the update header */
  if((ret = TCP_Read(Disk_State.log_fd, update->elements[0].buf, 
		     sizeof(update_header))) < 0) {
    perror("read update header");
    exit(0);
  }

  if(ret == 0)
    Alarm(EXIT, "Unexpected EOF reading update header.\n");

  uh  = (update_header *)update->elements[0].buf;
  len = sizeof(update_header) + uh->dataLen;

  if((ret = TCP_Read(Disk_State.log_fd, (char *)(uh+1), uh->dataLen))< 0){
    perror("read update.");
    exit(0);
  }
  if(ret == 0)
    Alarm(EXIT, "Unexpected EOF reading update.\n");

  update->elements[0].len = len;

  /* Place the update into the recovery array.  We'll store one update per
   * client, and then process them all at the end to determine which ones
   * are still pending (not equal to last executed). */

  old_update = Server_State.recovered_updates[uh->clientID];
  if(old_update != NULL) {
    dec_ref_cnt(old_update->elements[0].buf);
    dec_ref_cnt(old_update);
  }
  Server_State.recovered_updates[uh->clientID] = update;
}
#endif

#ifdef WRITE_TO_DISK
static void Log_Process_Proposal()
{
  sys_scatter *msg;
  header *h;
  proposal_specific *ps;
  
  msg                  = new_ref_cnt(SYS_SCATTER);
  msg->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);
  msg->num_elements    = 1;

  Log_Read_Proposal(msg);

  h  = (header *)msg->elements[0].buf;
  ps = (proposal_specific *)(h+1);

  if(Is_Ordered(ps->seq)) {
    Alarm(PRINT, "Server %d found a Proposal log entry for seq %d, where "
	  "it was already ordered.\n", Server_State.id, ps->seq);
    fflush(stdout);
    assert(0);
  }
  
  if(ps->seq > Server_State.white_line)
    Apply_Proposal(msg, ps->seq);

  dec_ref_cnt(msg->elements[0].buf);
  dec_ref_cnt(msg);
}
#endif

#ifdef WRITE_TO_DISK
static void Log_Read_Proposal(sys_scatter *msg)
{
  ssize_t ret;
  char *p;
  header *h;

  if((ret = TCP_Read(Disk_State.log_fd, (char *)msg->elements[0].buf, 
		     sizeof(header))) < 0) {
    perror("read log entry");
    exit(0);
  }
  
  if(ret == 0)
    Alarm(EXIT, "Unexpected EOF while reading Proposal header.\n");
  
  h  = (header *)msg->elements[0].buf;
  p  = (char *)(h+1);

  /* Read in the rest of the Proposal based on length */
  if((ret = TCP_Read(Disk_State.log_fd, p, h->dataLen)) < 0) {
    perror("read proposal");
    exit(0);
  }
  
  if(ret == 0)
    Alarm(EXIT, "Unexpected EOF while reading Proposal\n");
  
  msg->elements[0].len = sizeof(header) + h->dataLen;
}
#endif

#ifdef WRITE_TO_DISK
static void Log_Process_Ordered()
{
  sys_scatter *msg;
  sys_scatter *proposal;
  header *h;
  proposal_specific *ps;

  msg                  = new_ref_cnt(SYS_SCATTER);
  msg->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);
  msg->num_elements    = 1;

  Log_Read_Proposal(msg);

  h  = (header *)msg->elements[0].buf;
  ps = (proposal_specific *)(h+1);

  if((proposal = UTIL_Get_Latest_Accepted(ps->seq)) != NULL) {
    dec_ref_cnt(proposal->elements[0].buf);
    dec_ref_cnt(proposal);
    UTIL_Remove_Latest_Accepted(ps->seq);
  }
     
  inc_ref_cnt(msg->elements[0].buf);
  inc_ref_cnt(msg);
  UTIL_Insert_Ordered_Update(ps->seq, msg);
      
  if(ps->seq != (Server_State.aru + 1)) {
    Alarm(PRINT, "Server %d found an order log entry for seq %d, where "
	  "aru = %u\n", Server_State.aru);
    fflush(stdout);
    assert(0);
  }

  Server_State.aru                          = ps->seq;
  Server_State.stable_arus[Server_State.id] = ps->seq;
  Server_State.arus[Server_State.id]        = ps->seq;
      
  Update_Client_Last_Executed(ps->seq);

  if(ps->seq <= Server_State.white_line) {
    dec_ref_cnt(msg->elements[0].buf);
    dec_ref_cnt(msg);
    UTIL_Remove_Ordered_Update(ps->seq);
  }

  dec_ref_cnt(msg->elements[0].buf);
  dec_ref_cnt(msg);
}
#endif  

#ifdef WRITE_TO_DISK
static void Process_Client_State()
{
  int i;
  sys_scatter *update;
  update_header *uh;

  /* We stored the last pending update from each client in an array.  Go 
   * through the array, and see if it is one that has already been executed.
   * If so, we can ignore it.  Otherwise, we need to add it to pending. */

  for(i = 1; i <= MAX_CLIENTS; i++) {
    if(Server_State.recovered_updates[i] != NULL) {
      update = Server_State.recovered_updates[i];
      uh = (update_header *)update->elements[0].buf;

      if(uh->timestamp > Client_State.last_executed[i]) {
	sp_time t;
	inc_ref_cnt(update);
	inc_ref_cnt(update->elements[0].buf);
	Client_State.pending_updates[uh->clientID] = update; 
	
	t.sec = UPDATE_TIMER_SEC;
	t.usec = (UPDATE_TIMER_USEC + (rand() % 900000)) % 1000000;
	E_queue(Timer_Dispatcher, UPDATE_TIMER, 
		&Client_State.indices[uh->clientID], t);
      }      

      dec_ref_cnt(Server_State.recovered_updates[i]->elements[0].buf);
      dec_ref_cnt(Server_State.recovered_updates[i]);
      Server_State.recovered_updates[i] = NULL;
    }
  }

  /* We should never enqueue updates we've already executed */
  for(i = 1; i <= MAX_CLIENTS; i++)
    Client_State.last_enqueued[i] = Client_State.last_executed[i];
  
  for(i = 1; i <= 20; i++)
    Alarm(PRINT, "Client %d, last_executed %d\n", i, 
	  Client_State.last_executed[i]);

  Alarm(PRINT, "Done reading log file, aru = %d, white_line = %d\n", 
	Server_State.aru, Server_State.white_line);
  fflush(stdout);
}
#endif

#ifdef WRITE_TO_DISK
static void Process_View_File()
{
  uint32_t v;
  int ret;
  
  ret = TCP_Read(Disk_State.view_fd, (uint32_t *)&v, sizeof(uint32_t));

  if(ret < 0) {
    perror("read view");
    exit(0);
  }
  
  /* If the file is empty, write a view of 0 */
  if(ret == 0) {
    v = 0;
#ifdef WRITE_TO_DISK
    Write_View_to_Disk(&v);
#endif
    View_State.last_installed = 0;
    View_State.last_attempted = 0;
  }
  else {
    View_State.last_installed = v;
    View_State.last_attempted = v;
  }

  Alarm(PRINT, "Recovered with last_installed %d\n", 
	View_State.last_installed);
}
#endif

void Cleanup()
{
#ifdef SERVER_BENCHMARKING
  sp_time t;
  double total;
#endif

  fflush(stdout);

#ifdef WRITE_TO_DISK
  close(Disk_State.view_fd);
  close(Disk_State.log_fd);
#endif

#ifdef SERVER_BENCHMARKING
  /* Benchmark: Stop the clock and compute time  */
  Benchmark_State.end_time = E_get_time();
  t = E_sub_time(Benchmark_State.end_time, Benchmark_State.start_time);

  total = t.sec + ((float)t.usec / 1000000.0);
  Alarm(PRINT, "Total ordering time: %f seconds\n", total);

  Alarm(PRINT, "Throughput: %f updates per second\n", 
	(Benchmark_State.total_updates - Benchmark_State.start_updates)/total);
#endif

  exit(0);
}

