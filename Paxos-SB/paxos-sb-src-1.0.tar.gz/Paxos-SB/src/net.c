/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#include <string.h>
#include <stdlib.h>
#include <sys/un.h>
#include "net_include.h"
#include "net.h"
#include "def.h"
#include "p_server.h"
#include "paxos_protocol.h"
#include "packets.h"
#include "util_include.h"
#include "client_handling.h"

/*-------------------------------------------------------------------------*/
/* Maximize the send and receive buffers.  Thanks to Nilo Rivera. */
static int max_rcv_buff(int sk);
static int max_snd_buff(int sk);
/*-------------------------------------------------------------------------*/

extern Parameter_struct Params;
extern Server_struct    Server_State;
extern Network_struct   Network_State;

void Initialize_Network()
{
#ifdef USE_LOCAL_SOCKETS
  struct sockaddr_un server_addr;
  char buf[128];
#endif
#ifdef USE_TCP_SOCKETS
  struct sockaddr_in server_addr;
#endif
  int allow_reuse = 0;
  int32_t ucast_addr = 0;
  long on            = 1;

  Alarm(PRINT, "Initializing networking.\n");

  /* Set up UDP channel for unicast.  Add my ID to the base port to
   * get a unique port number. */
  allow_reuse = 0;
  Network_State.sd = DL_init_channel(SEND_CHANNEL | RECV_CHANNEL, 
				     PAXOS_UDP_BASE_PORT + Server_State.id, 
				     ucast_addr, 0, allow_reuse);  

#ifdef USE_TRUE_MCAST
  /* Allow the address to be reused so that multiple servers can run 
   * on the same machine. */
  Network_State.mcast_addr = MCAST_ADDRESS;
  allow_reuse = 1;
  Network_State.msd = DL_init_channel(SEND_CHANNEL | RECV_CHANNEL, 
				      PAXOS_MCAST_PORT, 
				      Network_State.mcast_addr, 
				      0, allow_reuse);
#endif

  memset(&server_addr, 0, sizeof(server_addr));

#ifdef USE_LOCAL_SOCKETS
  if((Network_State.listen_sd = socket(AF_LOCAL, SOCK_STREAM, 0)) < 0) {
    perror("socket");
    exit(0);
  }
  /* Build a unique pathname for this server */
  snprintf(buf, 128, "/tmp/unix_pserver_%d.str", Server_State.id);
  unlink(buf);
  
  server_addr.sun_family      = AF_LOCAL;
  strcpy(server_addr.sun_path, buf);
#endif

#ifdef USE_TCP_SOCKETS
  if((Network_State.listen_sd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
    perror("socket");
    exit(0);
  }

  server_addr.sin_family      = AF_INET;
  server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  server_addr.sin_port        = htons(PAXOS_TCP_BASE_PORT + Server_State.id);
#endif

  if((setsockopt(Network_State.listen_sd, SOL_SOCKET, SO_REUSEADDR, &on, 
		 sizeof(on))) < 0) {
    perror("setsockopt");
    exit(0);
  }
  
  if((bind(Network_State.listen_sd, (struct sockaddr *)&server_addr, 
	   sizeof(server_addr))) < 0) {
    perror("bind");
    exit(0);
  }
  Alarm(DEBUG, "Bound the listening socket.\n");
  
  if((listen(Network_State.listen_sd, 100)) < 0) {
    perror("listen");
    exit(0);
  }
  Alarm(DEBUG, "Listening on the socket.\n");

  max_rcv_buff(Network_State.sd);
  max_snd_buff(Network_State.sd);

#ifdef USE_TRUE_MCAST
  max_rcv_buff(Network_State.msd);
  max_snd_buff(Network_State.msd);
#endif

  /* Set up the one and only packet for reception */
  Network_State.Recv_Msg.elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);
  Network_State.Recv_Msg.elements[0].len = MAX_PACKET_SIZE;
  Network_State.Recv_Msg.num_elements    = 1;

#ifndef USE_TRUE_MCAST
  Network_State.start_server = 1;
#endif

  E_init();
  E_attach_fd(Network_State.sd, READ_FD, Message_Dispatcher, 0, NULL, 
	      HIGH_PRIORITY);

  E_attach_fd(Network_State.listen_sd, READ_FD, Client_Connection_Acceptor, 0,
	      NULL, HIGH_PRIORITY);

#ifdef USE_TRUE_MCAST
  E_attach_fd(Network_State.msd, READ_FD, Message_Dispatcher, 0, NULL,
	      HIGH_PRIORITY);
#endif

}

void Send_UCast(int sd, sys_scatter *msg, int id)
{
  ssize_t ret;

  ret = DL_send(sd, Network_State.server_addresses[id], 
		PAXOS_UDP_BASE_PORT + id, msg);
  /*Alarm(DEBUG, "Sent %d bytes to server %d\n", ret, id);*/
}

void Send_MCast(void *data)
{
  sys_scatter *msg = (sys_scatter *)data;

#ifdef USE_TRUE_MCAST
  ssize_t ret;
#else
  int i, next;
  sp_time t;
  ssize_t ret;
#endif
  header *h;

  h = (header *)msg->elements[0].buf;
  
#ifdef USE_TRUE_MCAST
  ret = DL_send(Network_State.msd, Network_State.mcast_addr, 
		PAXOS_MCAST_PORT, msg);
  
  if(ret < 0) {
    Alarm(PRINT, "Error in Send_MCast (true mcast), msd = %d, port = %d\n",
	  Network_State.msd, PAXOS_MCAST_PORT);
    perror("DL_send");
  }
#else

  /* Send starting with a different server each time */
  next = Network_State.start_server;
  t.sec  = 0;
  t.usec = 0;

  for(i = 1; i <= Params.Num_Servers; i++) {
    if(next != Server_State.id) {
      ret = DL_send(Network_State.sd, Network_State.server_addresses[next], 
		    PAXOS_UDP_BASE_PORT + next, msg);
      
      if(ret < 0)
	Alarm(EXIT, "Sending problem!\n");
    }
    next = (next == Params.Num_Servers) ? 1 : (next+1);
  }

  /* Next time start with a random server. */
  Network_State.start_server = (rand() % Params.Num_Servers) + 1;
#endif

}

static int max_rcv_buff(int sk)
{
  /* Increasing the buffer on the socket */
  int i, val, ret;
  unsigned int lenval;
  
  for(i=10; i <= 100; i+=5) {
    val = 1024*i;
    ret = setsockopt(sk, SOL_SOCKET, SO_RCVBUF, (void *)&val, sizeof(val));
    if (ret < 0)
      break;
    lenval = sizeof(val);
    ret= getsockopt(sk, SOL_SOCKET, SO_RCVBUF, (void *)&val, &lenval);
    if(val < i*1024 )
      break;
  }
  return(1024*(i-5));
}

static int max_snd_buff(int sk)
{
  /* Increasing the buffer on the socket */
  int i, val, ret;
  unsigned int lenval;
  
  for(i=10; i <= 100; i+=5) {
    val = 1024*i;
    ret = setsockopt(sk, SOL_SOCKET, SO_SNDBUF, (void *)&val, sizeof(val));
    if (ret < 0)
      break;
    lenval = sizeof(val);
    ret = getsockopt(sk, SOL_SOCKET, SO_SNDBUF, (void *)&val,  &lenval);
    if(val < i*1024)
      break;
  }
  return(1024*(i-5));
}
