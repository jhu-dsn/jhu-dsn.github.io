/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#ifndef PFSB_NET_H
#define PFSB_NET_H

#include "util_include.h"

void Initialize_Network(void);

/*Send a unicast message to the given id*/
void Send_UCast(int sd, sys_scatter *msg, int id);

/* Send a multicast message.  If USE_TRUE_MCAST is defined, then the function
 * uses IP-multicast.  Otherwise, it simulates multicast by sending on 
 * point-to-point links. */
void Send_MCast(void *msg);

#endif
