/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#ifndef PFSB_PAXOS_PROTOCOL_H
#define PFSB_PAXOS_PROTOCOL_H

#include "util_include.h"

/* Dispatcher functions */
void Timer_Dispatcher  (int code, void *data);
void Message_Dispatcher(int sd, int code, void *data);

/* Procedures to shift between states */
void Shift_to_Leader_Election(uint32_t viewNum);
void Shift_to_Reg_Leader     (void);
void Shift_to_Reg_Nonleader  (void);

/* Garbage collection procedures */
uint32_t Compute_White_Line(void);
void     Garbage_Collect   (uint32_t new_white_line);
uint32_t Is_Session_Open   (void);

/* Recovery procedure */
void Recovery(void);

void Cleanup(void);

#endif
