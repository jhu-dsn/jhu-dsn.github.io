/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#include <assert.h>
#include "util.h"

extern Accept_struct Accept_State;

sys_scatter *UTIL_Get_Ordered_Update(uint32_t seq)
{
  sys_scatter *msg;
  stdit it;

  stdhash_find(&Accept_State.ordered_updates, &it, &seq);

  if(stdhash_is_end(&Accept_State.ordered_updates, &it))
    return NULL;

  msg =  *(sys_scatter **)stdhash_it_val(&it);
  return msg;
}

sys_scatter *UTIL_Get_Latest_Accepted(uint32_t seq)
{
  sys_scatter *msg;
  stdit it;

  stdhash_find(&Accept_State.latest_accepted, &it, &seq);

  if(stdhash_is_end(&Accept_State.latest_accepted, &it))
    return NULL;

  msg =  *(sys_scatter **)stdhash_it_val(&it);
  return msg;
}

accept_node *UTIL_Get_Stats(uint32_t seq)
{
  accept_node *a;
  stdit it;

  stdhash_find(&Accept_State.stats, &it, &seq);

  if(stdhash_is_end(&Accept_State.stats, &it))
    return NULL;

  a =  *(accept_node**)stdhash_it_val(&it);
  return a;
}

void UTIL_Remove_Latest_Accepted(uint32_t seq)
{
  stdhash_erase_key(&Accept_State.latest_accepted, &seq);
}

void UTIL_Remove_Ordered_Update(uint32_t seq)
{
  stdhash_erase_key(&Accept_State.ordered_updates, &seq);
}

void UTIL_Remove_Stats(uint32_t seq)
{
  stdhash_erase_key(&Accept_State.stats, &seq);
}

void UTIL_Insert_Ordered_Update(uint32_t seq, sys_scatter *msg)
{
  stdit it; 

  stdhash_insert(&Accept_State.ordered_updates, &it, &seq, &msg); 
}

void UTIL_Insert_Latest_Accepted(uint32_t seq, sys_scatter *msg)
{
  stdit it; 

  stdhash_insert(&Accept_State.latest_accepted, &it, &seq, &msg); 
}

void UTIL_Insert_Stats(uint32_t seq, accept_node *a)
{
  stdit it; 

  stdhash_insert(&Accept_State.stats, &it, &seq, &a); 
}

void UTIL_Assert_Ordered_Update(uint32_t seq)
{

  if(!stdhash_contains(&Accept_State.ordered_updates, &seq))
    assert(0);
}

void UTIL_Assert_Latest_Accepted(uint32_t seq)
{

  if(!stdhash_contains(&Accept_State.latest_accepted, &seq))
    assert(0);
}

void UTIL_Assert_Stats(uint32_t seq)
{

  if(!stdhash_contains(&Accept_State.stats, &seq))
    assert(0);
}
