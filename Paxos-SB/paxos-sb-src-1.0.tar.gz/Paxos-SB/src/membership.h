/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#ifndef PFSB_MEMBERSHIP_H
#define PFSB_MEMBERSHIP_H

#include "util_include.h"

/* Message and Timer Handlers */
void Alive_Message_Handler   (sys_scatter *msg);
void Alive_Timer_Handler     (void);
void Membership_Timer_Handler(int index);

/* Set the timer for sending the next Alive message */
void Schedule_Alive_Event(void);

/* For global flow control.  Returns, out of the set of servers
 * currently believed to be alive, the maximum sequence number such
 * that all servers in the set have globally ordered all sequence
 * numbers up to that sequence number. */
uint32_t Compute_Global_Aru_of_Alive_in_View(void);

/* If there is a pending anti-entropy session on our queue (pending
 * because we were in the middle of another session when this one
 * expired), try to process it now. */
void Process_Next_Anti_Entropy(void);

typedef struct dummy_anti_entropy_obj {
  uint32_t serverID;
  uint32_t target;
} anti_entropy_obj;

#endif
