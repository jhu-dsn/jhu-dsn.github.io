/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#include <assert.h>
#include <stdlib.h>
#include "reconc.h"
#include "p_server.h"
#include "packets.h"
#include "global_ordering.h"
#include "paxos_protocol.h"
#include "membership.h"
#include "util.h"

/*---------------------------------------------------------------------------*/
static void Send_Order_Message    (uint32_t seq, uint32_t id);
static void Send_Next_Batch       (uint32_t id);
static void Send_Reconc_Response  (uint32_t id, int type, sp_time timestamp);
static void Send_Reconc_Ack              (int type);
static void Create_Reconc_Sending_Session(sys_scatter *msg);
static void Update_Reconc_Sending_Window (reconc_session *rs,int num_advanced);
static uint32_t Reconc_Should_Send_Nack  (reconc_session *rs);
static void Process_NackList         (uint32_t *nacklist, uint32_t num_nacks, 
				      uint32_t peer);
static uint32_t Get_Random_Peer          (void);
static void Reset_Random_Tried           (void);
/*---------------------------------------------------------------------------*/

extern Server_struct    Server_State;
extern Reconc_struct    Reconc_State;
extern Alive_struct     Alive_State;
extern Parameter_struct Params;
extern Network_struct   Network_State;
extern Accept_struct    Accept_State;
extern Prepare_struct   Prepare_State;

/* This function is called when a server orders something out of order. */
void Reconcile_to_Seq(uint32_t seq, uint32_t peer)
{
  /* Rely on Proposal retransmissions if leader during normal-case */
  if(Server_State.state == REG_LEADER && Prepare_State.view_is_prepared) {
    /*Alarm(DEBUG, "Leader detected loss when ordering seq %d\n", seq);*/
    return;
  }

  /* If I don't have a reconciliation session open, create one.  If I do
   * have one open, DON'T create another one. */
  if(Reconc_State.Receiving_Session.state == RECONC_INACTIVE) {
    Alarm(DEBUG, "Server %d: Need to reconcile from %d to %d\n", 
	  Server_State.id, Server_State.aru+1, seq);
    Create_Reconc_Receiving_Session(seq, peer);
  } 
}

void Create_Reconc_Receiving_Session(uint32_t target, uint32_t peer)
{
  uint32_t peer_id;
  sys_scatter *msg;
  sp_time t;

  /* Make sure we don't already have a receiving session open */
  assert(Reconc_State.Receiving_Session.state == RECONC_INACTIVE);
  
  if(peer == RECONC_RANDOM_PEER) {
    /* Choose a random alive peer with which to reconcile, if one exists */
    if((peer_id = Get_Random_Peer()) == -1)
      return;
  }

  else
    peer_id = peer;

  Reconc_State.Receiving_Session.state          = RECONC_REQUESTING;
  Reconc_State.Receiving_Session.peer           = peer_id;
  Reconc_State.Receiving_Session.timestamp      = E_get_time();

  Reconc_State.Receiving_Session.session_start  = Server_State.aru+1;
  Reconc_State.Receiving_Session.session_target = target;
  Reconc_State.Receiving_Session.window_start   = Server_State.aru+1;
  Reconc_State.Receiving_Session.window_end = (Server_State.aru + 
					       RECONC_WINDOW_SIZE);
  Reconc_State.Receiving_Session.batch_count = 0;
  Alarm(DEBUG, "Server %d Set up a reconc. session with server %d from %d "
	"to %d, my aru = %d\n", Server_State.id, 
	Reconc_State.Receiving_Session.peer,
	Reconc_State.Receiving_Session.session_start,
	Reconc_State.Receiving_Session.session_target, 
	Server_State.aru);

  msg = new_ref_cnt(SYS_SCATTER);
  Construct_Reconc_Request_Message(msg);
  Send_UCast(Network_State.sd, msg, peer_id);

  /* Set a timer on receiving a response.  If no response, we'll try *
   * someone else at random. */
  t.sec  = RECONC_RESPONSE_TIMER_SEC;
  t.usec = RECONC_RESPONSE_TIMER_USEC;
  E_queue(Timer_Dispatcher, RECONC_RESPONSE_TIMER, NULL, t);

  dec_ref_cnt(msg->elements[0].buf);
  dec_ref_cnt(msg);
}

static void Create_Reconc_Sending_Session(sys_scatter *msg)
{
  header *h;
  reconc_request_specific *rs;
  uint32_t id;

  h  = (header *)msg->elements[0].buf;
  id = h->serverID;
  rs = (reconc_request_specific *)(h+1);

  /* Clear out any old state */
  Clear_Reconc_Session_State(&Reconc_State.Sending_Sessions[id]);
  
  Reconc_State.Sending_Sessions[id].state          = RECONC_SENDING;
  Reconc_State.Sending_Sessions[id].peer           = id;
  Reconc_State.Sending_Sessions[id].timestamp      = rs->timestamp;
  Reconc_State.Sending_Sessions[id].session_start  = rs->session_start;
  Reconc_State.Sending_Sessions[id].session_target = rs->session_target;
  Reconc_State.Sending_Sessions[id].window_start   = rs->session_start;
  Reconc_State.Sending_Sessions[id].window_end     = (rs->session_start - 1 +
						      RECONC_WINDOW_SIZE);
  Reconc_State.Sending_Sessions[id].last_sent = rs->session_start - 1;
}

void Reconc_Request_Message_Handler(sys_scatter *msg)
{
  header *h;
  reconc_request_specific *rs;
  uint32_t id;

  h  = (header *)msg->elements[0].buf;
  id = h->serverID;
  rs = (reconc_request_specific *)(h+1);

  /* If I can't handle this request, send a reject */
  if(Server_State.aru < rs->session_target){
    Alarm(DEBUG, "%d Rejecting %d: My_aru = %d, target requested = %d\n",
	  Server_State.id, id, Server_State.aru, rs->session_target);
    Send_Reconc_Response(id, RECONC_REJECT, rs->timestamp);
    return;
  }

  /* If the target is less than or equal to the white line, I might need 
   * to send something garbage collected, which I shouldn't do (because 
   * the requester really has it already.  So reject in this case. */
  if(rs->session_target <= Server_State.white_line) {
    Alarm(PRINT, "Rejecting, white_line = %d, target_requested = %d\n",
	  Server_State.white_line, rs->session_target);
    Send_Reconc_Response(id, RECONC_REJECT, rs->timestamp);
    return;
  }

  /* If no session set up yet with this server, or if this is a request for
   * a later session, set up a new session. */
  if((Reconc_State.Sending_Sessions[id].state == RECONC_INACTIVE) ||
     E_compare_time(rs->timestamp, 
		    Reconc_State.Sending_Sessions[id].timestamp) == 1) {
    Create_Reconc_Sending_Session(msg);
    Send_Reconc_Response(id, RECONC_ACCEPT, rs->timestamp);
    Send_Next_Batch(id);
  }
}

static void Send_Reconc_Response(uint32_t id, int type, sp_time timestamp)
{
  sys_scatter *response;

  response = new_ref_cnt(SYS_SCATTER);
  Construct_Reconc_Response_Message(response, type, timestamp);

  Send_UCast(Network_State.sd, response, id);
  dec_ref_cnt(response->elements[0].buf);
  dec_ref_cnt(response);
}

static void Send_Next_Batch(uint32_t id)
{
  int i;
  int num_free_slots, max_packets_to_send, num_packets_to_send;
  uint32_t original_last_sent;

  num_free_slots = (Reconc_State.Sending_Sessions[id].window_end - 
		    Reconc_State.Sending_Sessions[id].last_sent);
  /*Alarm(DEBUG, "There are %d free slots.\n", num_free_slots);*/

  /* If we have more free slots than packets to send, only send the right
   * amount. */
  max_packets_to_send = (Reconc_State.Sending_Sessions[id].session_target - 
			 Reconc_State.Sending_Sessions[id].last_sent);
  if(max_packets_to_send < num_free_slots)
    num_packets_to_send = max_packets_to_send;
  else
    num_packets_to_send = num_free_slots;

  original_last_sent = Reconc_State.Sending_Sessions[id].last_sent;

  /*Alarm(DEBUG, "Num_packets to send = %d\n", num_packets_to_send);*/

  /* Send the next batch of messages to the receiver */
  for(i = 1; i <= num_packets_to_send; i++)
    Send_Order_Message(original_last_sent + i, id);
  
  Reconc_State.Sending_Sessions[id].last_sent = (original_last_sent + 
						 num_packets_to_send);
}

static void Send_Order_Message(uint32_t seq, uint32_t id)
{
  sys_scatter *proposal;
  header *h;
  uint32_t old_server_id;
  
  assert(Server_State.aru >= seq);

  /* Garbage collection: If I've already garbage collected it, it should
   * be fine that I don't send it again. */
  if((proposal = UTIL_Get_Ordered_Update(seq)) == NULL)
    return;

  /*Alarm(DEBUG, "Sending Ordered update for %d\n", seq);*/

  /* An ordered update looks like just a proposal, except for the 
   * packet type, and now the server id. The view number is irrelevant. 
   * So we'll change it, send it, and change it back. */
  
  h = (header *)proposal->elements[0].buf;
  old_server_id = h->serverID;
  h->serverID   = Server_State.id;
  h->packetType = ORDER;

  Send_UCast(Network_State.sd, proposal, id);

  h->packetType = PROPOSAL;
  h->serverID   = old_server_id;
}


void Order_Message_Handler(sys_scatter *msg)
{
  header *h;
  sys_scatter *ordered;
  order_specific *p;

  h = (header *)msg->elements[0].buf;
  p = (order_specific *)(h+1);

  if(h->serverID != Reconc_State.Receiving_Session.peer) {
    Alarm(DEBUG, "Dropping ordered update with seq %d because wrong peer."
	  " Was %d, I expected %d\n", p->seq, h->serverID, 
	  Reconc_State.Receiving_Session.peer);
    return;
  }

  /* We must get the response before we start reconciling */
  if(Reconc_State.Receiving_Session.state != RECONC_ACKING)
    return;

  /*Alarm(DEBUG, "Received ordered update with seq %d\n", p->seq);*/


  /* I don't want to order it again, but I may want to trigger a nack.
   * Pass the function num_advanced = 0. */
  if(Is_Ordered(p->seq)) {
    if((p->seq > Server_State.aru) && 
       (Reconc_State.Receiving_Session.state == RECONC_ACKING)) {
      Update_Reconc_Receiver_Window(0, p->seq);
      Alarm(DEBUG, "Already ordered %d, but calling Update_Reconc.\n", p->seq);
    }
    return;
  }

  if(p->seq % 100 == 0)
    Alarm(DEBUG, "Received Ordered Update for seq %d\n", p->seq);

#ifdef INSTRUMENT
  /* Drop some of the incoming packets to trigger nacks */
  if(p->seq % 1000 == (rand() % 1000)) {
    Alarm(DEBUG, "Dropping for seq %d\n", p->seq);
    return;
  }
#endif

  /* The ordered update is stored as a Proposal */
  h->packetType = PROPOSAL;

  ordered = new_ref_cnt(SYS_SCATTER);
  ordered->num_elements = 1;
  ordered->elements[0].buf = msg->elements[0].buf;
  ordered->elements[0].len = sizeof(header) + h->dataLen;

  /* Store it as an ordered update */
  inc_ref_cnt(ordered->elements[0].buf);
  UTIL_Insert_Ordered_Update(p->seq, ordered);

  /* Store it as a Proposal, too, so it fits seamlessly with other case */
  inc_ref_cnt(ordered->elements[0].buf);
  inc_ref_cnt(ordered);
  UTIL_Insert_Latest_Accepted(p->seq, ordered);

  Upon_Ordering(p->seq);
}

void Update_Reconc_Receiver_Window(int num_advanced, uint32_t seq)
{
  reconc_session *rs = &Reconc_State.Receiving_Session;
  sp_time now;

  assert(rs->state == RECONC_ACKING);

  /* Try to finish the session */
  if(Server_State.aru >= rs->session_target) {
    Clear_Reconc_Session_State(rs);
    return;
  }

  /* My Aru just advanced by num_advanced slots. This should allow me to 
   * slide my window along. */
  rs->window_start += num_advanced;
  rs->window_end   += num_advanced;
  rs->batch_count  += num_advanced;


  /* If num_advanced = 0, then I must have ordered something out of
   * order.  But check to make sure it's in the range of this
   * reconciliation session, and within this window.*/
  if(num_advanced == 0 && seq >= rs->window_start 
     && seq <= rs->window_end && seq <= rs->session_target){

    rs->nack_flag = 1;
    rs->nack_buildup++;

    if(Reconc_Should_Send_Nack(rs)) {
      Send_Reconc_Ack(FLOW_TYPE);
      now = E_get_time();
      rs->last_nack_sent = now;
    }
    else
      Alarm(DEBUG, "Just ordered %d.  Noticed nack, but not time yet.\n", seq);
    return;
  }    
   
  /* If I've ordered the whole window, send an ack and reset batch count */
  if(rs->batch_count == RECONC_WINDOW_SIZE) {
    Alarm(DEBUG, "Sending an ack whole after ordering %d, my_aru = %d\n", 
	  seq, Server_State.aru);
    Send_Reconc_Ack(FLOW_TYPE);
    rs->batch_count = 0;
  }
  
  /* If I've ordered between half a window and a whole window, send an 
   * ack for the half and readjust the batch count */
  else if(rs->batch_count >= (RECONC_WINDOW_SIZE / 2)) {
    Alarm(DEBUG, "Sending an ack after ordering %d\n", Server_State.aru);
    Send_Reconc_Ack(FLOW_TYPE);

    rs->batch_count = rs->batch_count - (RECONC_WINDOW_SIZE / 2);
    Alarm(DEBUG, "Batch count was set to %d\n", rs->batch_count);
  }

}

static uint32_t Reconc_Should_Send_Nack(reconc_session *rs)
{
  sp_time now, diff, nack_period;
  int ret = 0;

  /* If I haven't sent a nack in a little while, or if I've seen enough
   * packets that would have caused me to send a nack, send one now. */
  now  = E_get_time();
  diff = E_sub_time(now, rs->last_nack_sent);

  nack_period.sec  = RECONC_NACK_PERIOD_SEC;
  nack_period.usec = RECONC_NACK_PERIOD_USEC;

  if((E_compare_time(diff, nack_period) == 1) || (rs->nack_buildup > 10)) {
    Alarm(DEBUG, "Decided to send a nack.\n");
    ret = 1;
  }
  
  return ret;
}

/* Returns the number of nacks */
uint32_t Compute_NackList(uint32_t *nacklist)
{
  int i, j;
  uint32_t max;
  uint32_t num_nacks = 0; 
  reconc_session *rs = &Reconc_State.Receiving_Session;

  /* Find the highest sequence number in the window, that we're trying
   * to reconcile, that we've ordered. */
  if(rs->window_end > rs->session_target)
    max = rs->session_target;
  else
    max = rs->window_end;

  Alarm(DEBUG, "Max = %d, window_start = %d, window_end = %d, target = %d\n",
	max, rs->window_start, rs->window_end, rs->session_target);
  for(i = max; i > rs->window_start; i--) {
    if(Is_Ordered(i))
       break;
  }

  /* Nothing to be nacked */
  if(i <= rs->window_start)
    return 0;

  /* Everything in the window below i that is not ordered should be nacked */
  for(j = rs->window_start; j < i; j++) {
    if(!Is_Ordered(j)) {
      nacklist[num_nacks] = j;
      Alarm(DEBUG, "Nacking sequence number %d\n", j);
      num_nacks++;
    }
  }
  
  return num_nacks;
}


static void Send_Reconc_Ack(int type)
{
  sys_scatter *msg;
  sp_time t;
  
  msg = new_ref_cnt(SYS_SCATTER);
  Construct_Reconc_Ack_Message(msg, type);

  Alarm(DEBUG, "Server %d sent ack (%d) to %d with aru %d, target = %d\n", 
	Server_State.id, type, Reconc_State.Receiving_Session.peer,
	Server_State.aru, Reconc_State.Receiving_Session.session_target);
  if(Server_State.aru > Reconc_State.Receiving_Session.session_target) {
    Alarm(PRINT, "Server %d, aru %d, type %d, target %d\n",
	  Server_State.id, Server_State.aru, type,
	  Reconc_State.Receiving_Session.session_target);
    fflush(stdout);
    abort();
  }

  Send_UCast(Network_State.sd, msg, Reconc_State.Receiving_Session.peer);

  dec_ref_cnt(msg->elements[0].buf);
  dec_ref_cnt(msg);

  /* Reset the Ack timer */
  t.sec  = ACK_TIMER_SEC;
  t.usec = ACK_TIMER_USEC;
  E_queue(Timer_Dispatcher, ACK_TIMER, NULL, t);

  Reconc_State.Receiving_Session.nack_flag    = 0;
  Reconc_State.Receiving_Session.nack_buildup = 0;
}

void Reconc_Ack_Timer_Handler(void)
{
  /* Sends an Ack and resets the timer */
  Send_Reconc_Ack(TIMER_TYPE);
}

void Reconc_Ack_Message_Handler(sys_scatter *msg)
{
  header *h;
  reconc_ack_specific *as;
  reconc_session *rs;
  int num_advanced;

  h  = (header *)msg->elements[0].buf;
  as = (reconc_ack_specific *)(h + 1);
  rs = (reconc_session *)&Reconc_State.Sending_Sessions[h->serverID];
  
  if(rs->state != RECONC_SENDING)
    return;
  
  if(E_compare_time(rs->timestamp, as->timestamp) != 0) {
    Alarm(DEBUG, "Rejected ack because wrong timestamp.\n");
    return;
  }

  /* Process the nacklist, if any */
  if(as->num_nacks > 0)
    Process_NackList((uint32_t *)(as + 1), as->num_nacks, h->serverID);

  if(as->type == FLOW_TYPE) {
    
    /* If this doesn't advance the window at all, ignore it */
    if(as->aru < rs->window_start)
      return;

    num_advanced = as->aru - rs->window_start + 1;
    Update_Reconc_Sending_Window(rs, num_advanced);
  }

  if(as->type == TIMER_TYPE) {
    /* Check to make sure the receiver hasn't advanced its aru in 
     * a manner outside the reconciliation session -- if it has, then
     * simply sending my last packet might not help.  In this case, we want
     * to try to send some new packets and advance the window. */
    if(as->aru >= rs->window_start) {
      num_advanced = as->aru - rs->window_start + 1;
      Update_Reconc_Sending_Window(rs, num_advanced);
    }

    /* Resend the last packet, which should trigger nacks */
    Send_Order_Message(rs->last_sent, h->serverID);
    Alarm(PRINT, "Server %d responding to server %d, timer type, seq = %d, "
	  "target = %d, ack aru = %d\n", 
	  Server_State.id, h->serverID, rs->last_sent, 
	  rs->session_target, as->aru);
  }
}

static void Process_NackList(uint32_t *nacklist, uint32_t num_nacks, 
			     uint32_t peer)
{
  int i;
  
  assert(num_nacks > 0);
  
  for(i = 0; i < num_nacks; i++)
    Send_Order_Message(nacklist[i], peer);
}

static void Update_Reconc_Sending_Window(reconc_session *rs, int num_advanced)
{
  rs->window_start += num_advanced;
  rs->window_end   += num_advanced;

  /* Optimistically try to end the session */
  if(rs->window_start > rs->session_target)
    Clear_Reconc_Session_State(rs);
  else
    Send_Next_Batch(rs->peer);
}

void Reconc_Response_Message_Handler(sys_scatter *msg)
{
  header *h;
  reconc_response_specific *rs;
  int target;
  sp_time t;

  h  = (header *)msg->elements[0].buf;
  rs = (reconc_response_specific *)(h + 1);

  /* Ignore the response if I'm not currently requesting */
  if(Reconc_State.Receiving_Session.state != RECONC_REQUESTING) {
    Alarm(DEBUG, "Rejecting response because in wrong state.\n");
    return;
  }

  /* I have a session open, but is this response for the right one? */
  if(E_compare_time(rs->timestamp, 
		    Reconc_State.Receiving_Session.timestamp) != 0) {
    Alarm(DEBUG, "Rejecting response because wrong timestamp.\n");
    return;
  }

  /* Cancel the response timer */
  E_dequeue(Timer_Dispatcher, RECONC_RESPONSE_TIMER, NULL);

  /* This is what I was loooking for: an Accepted request.  Set the Ack timer,
   * which triggers retransmission of an ack if none is sent within the 
   * timeout period.*/
  if(rs->type == RECONC_ACCEPT) {
    Reconc_State.num_consecutive_failures = 0;
    Reset_Random_Tried();
    Reconc_State.Receiving_Session.state = RECONC_ACKING;
    Alarm(DEBUG, "Shifted to RECONC_ACKING\n");

    t.sec  = ACK_TIMER_SEC;
    t.usec = ACK_TIMER_USEC;
    E_queue(Timer_Dispatcher, ACK_TIMER, NULL, t);
  }

  if(rs->type == RECONC_REJECT) {
    target = Reconc_State.Receiving_Session.session_target;
    Clear_Reconc_Session_State(&Reconc_State.Receiving_Session);

    Reconc_State.num_consecutive_failures++;
    if(Reconc_State.num_consecutive_failures >= RECONC_FAILURE_THRESHOLD) {
      Alarm(PRINT, "%d Exceeded Reconc failure threshold!\n", Server_State.id);
      Reset_Random_Tried();
      /*Reconc_State.num_consecutive_failures = 0;*/
      return;
    }

    /* Clear out the "partially open" session, find a new peer and 
     * try to set up a session with that server. */
    if(Server_State.aru < target) {
      Alarm(DEBUG, "Received RECONC_REJECT, trying another peer\n");
      Create_Reconc_Receiving_Session(target, RECONC_RANDOM_PEER);
    }
  }
}

void Reconc_Response_Timer_Handler()
{
  int target;

  target = Reconc_State.Receiving_Session.session_target;
  Clear_Reconc_Session_State(&Reconc_State.Receiving_Session);

  Reconc_State.num_consecutive_failures++;
  if(Reconc_State.num_consecutive_failures >= RECONC_FAILURE_THRESHOLD) {
    Alarm(PRINT, "%d Exceeded RECONC_FAILURE_THRESHOLD!!!\n", Server_State.id);
    Reset_Random_Tried();
    /*Reconc_State.num_consecutive_failures = 0;*/
    return;
  }

  /* Clear out the "partially open" session, find a new peer and 
   * try to set up a session with that server. */
  if(Server_State.aru < target)
    Create_Reconc_Receiving_Session(target, RECONC_RANDOM_PEER);
}

void Reconc_Anti_Entropy_Timer_Handler(uint32_t id)
{
  /* I caught up to this server, no need to reconcile */
  if(Server_State.aru >= Server_State.arus[id])
    return;
  
  /* If I'm already in a session, queue this one. */
  if(Reconc_State.Receiving_Session.state != RECONC_INACTIVE) {
    anti_entropy_obj *a;

    a = new_ref_cnt(ANTI_ENTROPY_OBJ);
    a->serverID = id;
    a->target   = Server_State.arus[id];
    stddll_push_back(&Alive_State.anti_entropy_queue, &a);

    return;
  }

  Alarm(DEBUG, "%d setting up Anti-entropy session with %d, My_aru = %u, "
	"His =  %u\n", Server_State.id, id, Server_State.aru, 
	Server_State.arus[id]);
  Reconcile_to_Seq(Server_State.arus[id], id);
}

static uint32_t Get_Random_Peer()
{
  uint32_t i;
  int alive_but_tried[MAX_SERVERS+1];
  int num_alive_but_tried = 1; /* We're alive! */

  /* TODO: Implement logic so that leader gets chosen with smaller 
   * probability than the rest of the servers, since we don't want 
   * the leader to do more work than it needs to. If it's the leader, 
   * just choose a number between 1 and 100, and if it's less than, say, 
   * 70, we'll go with it, otherwise we'll try again. */

  /* If I'm the only one alive, I better not try to reconcile */
  if(Alive_State.num_alive < 2)
    return -1;

  for(i = 0; i <= MAX_SERVERS; i++)
    alive_but_tried[i] = 0;

  while(1) {
    i = (rand() % Params.Num_Servers) + 1;
    if((Alive_State.is_alive[i]) && (i != Server_State.id)) {
      /* Found someone alive that I haven't tried yet, we're happy */
      if(!Reconc_State.random_tried[i])
	break;
      /* If I've tried this one already, mark it */
      else if(alive_but_tried[i] == 0) {
	alive_but_tried[i] = 1;
	num_alive_but_tried++;

	/* Tried everyone alive, need to give up. */
	if(num_alive_but_tried >= Alive_State.num_alive)
	  return -1;
      }
    }
  }
  Reconc_State.random_tried[i] = 1;
  return i;
}


void Clear_Reconc_Session_State(reconc_session *s)
{
  uint32_t old_state;

  old_state = s->state;

  s->state          = RECONC_INACTIVE;
  s->peer           = 0;
  s->timestamp.sec  = 0;
  s->timestamp.usec = 0;
  s->session_start  = 0;
  s->session_target = 0;
  s->window_start   = 0;
  s->window_end     = 0;
  s->batch_count    = 0;
  s->last_sent      = 0;
  s->nack_flag      = 0;
  s->nack_buildup   = 0;

  s->last_nack_sent.sec  = 0;
  s->last_nack_sent.usec = 0;

  /* Cancel the Ack timer if it's set */
  E_dequeue(Timer_Dispatcher, ACK_TIMER, NULL);

  /* If I'm the leader but the view is not yet prepared and there are 
   * pending anti-entropy sessions I should try to start (with those that
   * sent me a reject), start one if possible. */
  if(Server_State.state == REG_LEADER && !Prepare_State.view_is_prepared) {
    if(!stddll_empty(&Prepare_State.rejected_queue))
      Process_Next_Prepare_Ok_Rejected();
  }
  /* If I have another potential anti-entropy session on the queue, 
   * process it, provided the session I finished was a receiving session.  */
  else {
    if(old_state == RECONC_ACKING && 
       !stddll_empty(&Alive_State.anti_entropy_queue))
      Process_Next_Anti_Entropy();
  }
}

static void Reset_Random_Tried()
{
  int i;

  for(i = 0; i <= MAX_SERVERS; i++)
    Reconc_State.random_tried[i] = 0;

}
