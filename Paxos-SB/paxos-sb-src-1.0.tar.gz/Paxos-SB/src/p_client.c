/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#include <stdlib.h>
#include <string.h>
#include <sys/un.h>
#include "net_include.h"
#include "util_include.h"
#include "def.h"
#include "packets.h"
#include "tcp_wrapper.h"

/*-----------------------------------------------*/
static void Usage(int argc, char **argv);
static void Read_Configuration_File(void);
static void Initialize(void);
static void Initialize_Memory_Objects(void);
static void Initialize_Network(void);
static void Message_Dispatcher(int s, int code, void *data);
static void Send_Next_Update(int dummy, void *dummy_data);
static void Schedule_Timeout();
static void Timer_Dispatcher(int code, void *data);
static void Cleanup(void);
static void Construct_Update(sys_scatter *msg, uint32_t timestamp);
static void Write_Update(sys_scatter *msg);
/*-----------------------------------------------*/

#define REPLY_TIMER -1

uint32_t client_id;
uint32_t server_id;

int32_t server_addresses[MAX_SERVERS];
int sd;

int32_t tcp_server_address;

sys_scatter Recv_Msg;
sys_scatter *Last_Update;
uint32_t client_timestamp;

int retrans_count = 0;
int pending_flag  = 0;
int query_flag    = 1;

#ifdef CLIENT_BENCHMARKING
typedef struct dummy_benchmark_struct {
  double latencies[400000];
  sp_time start_time;
  sp_time end_time;
  FILE *fp;

} Benchmark_struct;

Benchmark_struct Benchmark_State;
#endif

int main(int argc, char **argv)
{
#ifdef WRITE_TO_DISK
  sys_scatter *msg;
#endif

  Usage(argc, argv);
  Read_Configuration_File();

  Initialize();

  usleep(rand() % 100000);

#ifdef WRITE_TO_DISK
  /* I first need to find out what timestamp to start with.  Send a 
   * "timestamp query" that has timestamp 0. */
  msg = new_ref_cnt(SYS_SCATTER);
  Construct_Update(msg, 0);
  Last_Update = msg;
  Write_Update(msg);
  Schedule_Timeout();
#else
  Send_Next_Update(0, NULL);
#endif

  E_handle_events();

  return 0;
}

static void Timer_Dispatcher(int code, void *data)
{
  switch(code) {
  case REPLY_TIMER:
    retrans_count++;

    if(retrans_count > 0)
      Cleanup();
    
    Schedule_Timeout();
    break;
  }
}

static void Cleanup()
{
#ifdef CLIENT_BENCHMARKING
  int i;
  double sum;
  double average;

  sum = 0;
  for(i = 1; i < client_timestamp; i++)
    sum += Benchmark_State.latencies[i];

  average = sum / client_timestamp;

  Alarm(PRINT, "Client %d, Average latency = %f, %d updates\n", 
	client_id, average, client_timestamp-1);

  fprintf(Benchmark_State.fp, "%f %d\n", average, client_timestamp-1);
#endif
  exit(0);
}

static void Send_Next_Update(int dummy, void *dummy_data)
{
  sys_scatter *msg;
  
#ifdef CLIENT_BENCHMARKING
  Benchmark_State.start_time = E_get_time();
#endif

  msg = new_ref_cnt(SYS_SCATTER);
  Construct_Update(msg, client_timestamp);
  
  Last_Update = msg;

  Write_Update(msg);

  client_timestamp++; /* Increment for next time */
  Schedule_Timeout();
}

static void Write_Update(sys_scatter *msg)
{
  int ret;

#if 0
  if((client_timestamp % 500) == 0) {
    Alarm(PRINT, "Client %d sent an update with timestamp %d\n", 
	  client_id, client_timestamp);
    fflush(stdout);
  }
#endif

  ret = TCP_Write(sd, (char *)msg->elements[0].buf, UPDATE_TARGET);

  if(ret <= 0)
    Cleanup();

  Alarm(DEBUG, "Send %d bytes to server %d\n", ret, server_id);
}

static void Construct_Update(sys_scatter *msg, uint32_t timestamp)
{
  update_header *h;
  char *update_body;
  int i;

  msg->num_elements = 1;
  msg->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);

  h = (update_header *)msg->elements[0].buf;
  h->packetType = UPDATE;
  h->clientID   = client_id;
  h->serverID   = server_id;
  h->timestamp  = timestamp;
  h->dataLen    = UPDATE_SIZE;

  update_body = (char *)(h+1);

  for(i = 0; i < UPDATE_SIZE; i++)
    update_body[i] = 'A';
  
  msg->elements[0].len = sizeof(update_header) + UPDATE_SIZE;
}

static void Schedule_Timeout()
{
  sp_time t;

  t.sec  = REPLY_TIMER_SEC;
  t.usec = REPLY_TIMER_USEC; 
  E_queue(Timer_Dispatcher, REPLY_TIMER, NULL, t);
}

static void Message_Dispatcher(int s, int code, void *data)
{
  reply_specific *reply;
  int ret;

#ifdef CLIENT_BENCHMARKING
  sp_time diff;
#endif

  Alarm(DEBUG, "Dispatcher.\n");

  ret = TCP_Read(sd, (char *)Recv_Msg.elements[0].buf, sizeof(reply_specific));

  if(ret <= 0) {
    if(ret == 0){
#ifdef WRITE_TO_DISK
      if(query_flag == 1) 
	Alarm(EXIT, "Connection closed by server. "
	      "Is client %d already running?\n", client_id);
#endif
      Cleanup();
      Alarm(EXIT, "Connection closed by server.\n");
    }
  }
  Recv_Msg.elements[0].len = ret;
  reply = (reply_specific *)Recv_Msg.elements[0].buf;

  /* If this is the special reply to my initial timestamp query, then the
   * sequence number is the next timestamp I should use, and the clientID
   * field tells me whether the previous one is pending or not (which tells
   * me whether I should wait for a reply before sending the next update). */
  if(reply->timestamp == 0) {
    query_flag = 0;
    dec_ref_cnt(Last_Update->elements[0].buf);
    dec_ref_cnt(Last_Update);

    client_timestamp = reply->seq;
    if(reply->clientID == CLIENT_UPDATE_PENDING) {
      Alarm(PRINT, "Next seq will be %d, waiting for pending update reply.\n",
	    reply->seq);
      fflush(stdout);
      pending_flag = 1;
    }
    else {
      assert(reply->clientID == CLIENT_UPDATE_NONE_PENDING);
      Alarm(PRINT, "Client %d, none was pending, starting with %d\n", 
	    client_id, client_timestamp);
      Send_Next_Update(0, NULL);
    }  
  }
  
  /* If this is a reply for the last update I sent, send the next one */
  else if(reply->timestamp == (client_timestamp-1)) {
    E_dequeue(Timer_Dispatcher, REPLY_TIMER, NULL);

    if(!pending_flag) {
      dec_ref_cnt(Last_Update->elements[0].buf);
      dec_ref_cnt(Last_Update);

#ifdef CLIENT_BENCHMARKING
      Benchmark_State.end_time = E_get_time();
      diff = E_sub_time(Benchmark_State.end_time, Benchmark_State.start_time);
      Benchmark_State.latencies[(int)client_timestamp-1] = 
	(double)(diff.sec + diff.usec / 1000000.0);
#endif
    }

    if(pending_flag) {
      Alarm(PRINT, "Client %d: Got it -- timestamp was %d\n", 
	    client_id, reply->timestamp);
      fflush(stdout);
      pending_flag = 0;
    }

    Send_Next_Update(0, NULL);

    Alarm(DEBUG, "Reply was for %d, Sending next one.\n", reply->timestamp);
  }  
  else
    Alarm(PRINT, "Rejecting reply %d %d\n", reply->timestamp,client_timestamp);
  
  Recv_Msg.elements[0].len = MAX_PACKET_SIZE;

  if(get_ref_cnt(Recv_Msg.elements[0].buf) > 1) {
    dec_ref_cnt(Recv_Msg.elements[0].buf);
    Recv_Msg.elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);
  }
}

static void Initialize()
{
#ifdef CLIENT_BENCHMARKING
  char buf[128];
#endif

  Initialize_Memory_Objects();
  Initialize_Network();

  srand(client_id);

  client_timestamp = 1;
  
#ifdef CLIENT_BENCHMARKING
  sprintf(buf, "latencies/client_%d.lat", client_id);
  Benchmark_State.fp = fopen(buf, "w+");
#endif
}

static void Initialize_Memory_Objects()
{
  Mem_init_object(SYS_SCATTER, sizeof(sys_scatter), 1, 1);
  Mem_init_object(PACK_BODY_OBJ, sizeof(char) * MAX_PACKET_SIZE, 1, 1);
}

static void Initialize_Network()
{
#ifdef USE_LOCAL_SOCKETS
  struct sockaddr_un server_addr;
  char buf[128];
#endif
#ifdef USE_TCP_SOCKETS
  struct sockaddr_in server_addr;
#endif

  /* Set up the one and only packet for reception */
  Recv_Msg.elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);
  Recv_Msg.elements[0].len = MAX_PACKET_SIZE;
  Recv_Msg.num_elements    = 1;

  E_init();

  memset(&server_addr, 0, sizeof(server_addr));

#ifdef USE_LOCAL_SOCKETS
  if((sd = socket(AF_LOCAL, SOCK_STREAM, 0)) < 0) {
    perror("socket");
    exit(0);
  }

  server_addr.sun_family = AF_LOCAL;

  snprintf(buf, 128, "/tmp/unix_pserver_%d.str", server_id);
  strcpy(server_addr.sun_path, buf);
#endif

#ifdef USE_TCP_SOCKETS
  if((sd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
    perror("socket");
    exit(0);
  }
  server_addr.sin_family      = AF_INET;
  server_addr.sin_port        = htons(PAXOS_TCP_BASE_PORT + server_id);
  server_addr.sin_addr.s_addr = tcp_server_address;
#endif

  if((connect(sd, (struct sockaddr *)&server_addr, sizeof(server_addr))) < 0) {
    perror("connect");
    exit(0);
  }

  Alarm(PRINT, "Connected to server %d!\n", server_id);
  fflush(stdout);
  E_attach_fd(sd, READ_FD, Message_Dispatcher, 0, NULL, HIGH_PRIORITY);
}

static void Read_Configuration_File()
{
  FILE *f;
  char buf[128];
  int i, len;
  
  if((f = fopen("paxos.config", "r")) == NULL)
    Alarm(EXIT, "Could not open configuration file for reading.\n");

  i = 1;

  while((fgets(buf, 128, f)) != NULL) {
    /* Ignore comment and blank lines */
    if( (buf[0] == '#') || (buf[0] == '\n') )
      continue;
    
    len = strlen(buf);
    buf[len-1] = '\0';
    inet_pton(AF_INET, buf, &server_addresses[i]);
      
    if(i == server_id)
      tcp_server_address = server_addresses[i];

    /* To make it work with datalink...*/
    server_addresses[i] = htonl(server_addresses[i]);
    i++;
  } 
  fclose(f);
}

static void Usage(int argc, char **argv)
{
  if(argc != 3)
    Alarm(EXIT, "Usage: p_client client_id server_id\n");

  client_id   = atoi(argv[1]);
  server_id   = atoi(argv[2]);
}
