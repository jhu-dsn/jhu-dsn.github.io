/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#ifndef PFSB_CLIENT_HANDLING_H
#define PFSB_CLIENT_HANDLING_H

#include "util_include.h"

/* Returns 1 if the update was enqueued, 0 otherwise. */
int Enqueue_Update(sys_scatter *msg); 

/* Forward an update over to the leader of this view. */
void Forward_Update(sys_scatter *msg);

/* Adds an update to the pending_updates data structure, taking responsibilty
 * for it.  Writes it to pending updates file. */
void Add_Update_to_Pending(sys_scatter *msg);

/* Stores updates that I was previously forwarding onto my queue when I 
 * become the leader, but only if it is not already bound to a 
 * sequence number. */
void Enqueue_Unbound_Forwarded_Updates(void);

/* After becoming the leader, remove any updates from my queue that are
 * bound to a sequence number, or that I've already executed. */
void Remove_Bound_Updates_From_Queue(void);

/* Forward my own updates that were on my queue over to the new leader.  Used
 * when a leader becomes a non-leader, or when someone shifts from leader
 * election to non-leader.*/
void Forward_Queued_Updates(void);

/* Sends a response back to the client indicating that the update was done. */
void Respond_to_Client(int32_t seq, void *dummy);

void Update_Handler(sys_scatter *msg);

void Update_Timer_Handler(int index);

void Client_Connection_Acceptor(int sd, int code, void *data);

void Update_Client_Last_Executed(uint32_t seq);

#endif
