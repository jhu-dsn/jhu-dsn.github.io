/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#include <string.h>
#include <assert.h>
#include "packets.h"
#include "p_server.h"

/*--------------------------------------------------------*/
static void Print_Packet_Header           (header *h);
static void Print_Packet_Type             (uint32_t p_type);
static void Print_Response_Type           (int type);
static void Print_Ack_Type                (int type);
static void Print_Prepare_Ok_Response_Type(uint32_t type);
/*--------------------------------------------------------*/

extern Server_struct    Server_State;
extern VC_struct        View_State;
extern Reconc_struct    Reconc_State;
extern Prepare_struct   Prepare_State;
extern Client_struct    Client_State;

void Construct_VC_Message(sys_scatter *msg)
{
  header *h;

  msg->num_elements = 1;
  msg->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);

  h = (header *)msg->elements[0].buf;

  h->packetType = VC;
  h->serverID   = Server_State.id;
  h->viewNum    = View_State.last_attempted;
  h->dataLen    = 0;

  msg->elements[0].len = sizeof(header);
}

void Construct_Prepare_Message(sys_scatter *msg, uint32_t id)
{
  header *h;
  prepare_specific *p;

  msg->num_elements = 1;
  msg->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);

  h = (header *)msg->elements[0].buf;
  
  h->packetType = PREPARE;
  h->serverID   = Server_State.id;
  h->viewNum    = View_State.last_installed;
  h->dataLen    = sizeof(prepare_specific); 

  p = (prepare_specific *)(h+1);
  p->aru = Server_State.aru;
  p->timestamp = Prepare_State.Receiving_Sessions[id].timestamp;

  msg->elements[0].len = sizeof(header) + sizeof(prepare_specific);
}

void Construct_Prepare_Ok_Message(sys_scatter *msg, uint32_t type) 
{
  header *h;
  prepare_ok_specific *p;

  msg->num_elements = 1;
  msg->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);

  h = (header *)msg->elements[0].buf;

  h->packetType = PREPARE_OK;
  h->serverID   = Server_State.id;
  h->viewNum    = View_State.last_installed;
  h->dataLen    = sizeof(prepare_ok_specific);

  p = (prepare_ok_specific *)(h+1);
  p->type           = type;
  p->session_start  = Prepare_State.Sending_Session.session_start;
  p->session_target = Prepare_State.Sending_Session.session_target;
  p->timestamp      = Prepare_State.Sending_Session.timestamp;
  p->leader_aru     = Prepare_State.Sending_Session.leader_aru;

  /* If it's a reject, tell the leader what you have as session_target */
  if(type == PREPARE_OK_REJECT)
    p->session_target = Server_State.aru;

  msg->elements[0].len = sizeof(header) + sizeof(prepare_ok_specific);
}

void Construct_Prepare_Phase_Message(sys_scatter *msg, sys_scatter *proposal)
{
  header *h;
  prepare_phase_specific *p;
  char *prop_start;

  msg->num_elements = 1;
  msg->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);

  h = (header *)msg->elements[0].buf;

  h->packetType = PREPARE_PHASE;
  h->serverID   = Server_State.id;
  h->viewNum    = View_State.last_installed;
  h->dataLen    = sizeof(prepare_phase_specific) + proposal->elements[0].len;

  p = (prepare_phase_specific *)(h+1);
  p->timestamp = Prepare_State.Sending_Session.timestamp;
  
  /* Copy the Proposal */
  prop_start = (char *)(p+1);
  memcpy(prop_start, (char *)proposal->elements[0].buf, 
	 proposal->elements[0].len);
  
  msg->elements[0].len = sizeof(header) + h->dataLen;
}

void Construct_Prepare_Ack_Message(sys_scatter *msg, uint32_t type, 
				   uint32_t id)
{
  header *h;
  prepare_ack_specific *p;

  msg->num_elements = 1;
  msg->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);

  h = (header *)msg->elements[0].buf;

  h->packetType = PREPARE_ACK;
  h->serverID   = Server_State.id;
  h->viewNum    = View_State.last_installed;
  h->dataLen    = sizeof(prepare_ack_specific);

  p = (prepare_ack_specific *)(h+1);
  p->type = type;
  p->timestamp = Prepare_State.Receiving_Sessions[id].timestamp;
  p->seq       = Prepare_State.Receiving_Sessions[id].window_start - 1;

  msg->elements[0].len = sizeof(header) + h->dataLen;
}

void Construct_Proposal_Message(sys_scatter *proposal, uint32_t seq, 
				sys_scatter *update)
{
  header *h;
  update_header *uh;
  proposal_specific *p;
  char *proposal_body;
  int total_update_len;

  proposal->num_elements = 1;
  proposal->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);

  h  = (header *)proposal->elements[0].buf;
  uh = (update_header *)update->elements[0].buf;
  
  h->packetType = PROPOSAL;
  h->serverID   = Server_State.id;
  h->viewNum    = View_State.last_installed;

  p = (proposal_specific *)(h+1);
  p->seq = seq;
  
  total_update_len = sizeof(update_header) + uh->dataLen;
  
  proposal_body = (char *)(p+1);
  memcpy(proposal_body, (char *)update->elements[0].buf, total_update_len);
  
  h->dataLen = sizeof(proposal_specific) + total_update_len;
  
  proposal->elements[0].len = sizeof(header) + h->dataLen;
}

void Construct_Aggregated_Proposal_Message(sys_scatter *proposal, uint32_t seq)
{
  header *h;
  sys_scatter *u;
  update_header *uh;
  proposal_specific *ps;
  int space_remaining;
  int update_len;
  stdit it;
  char *p;  

  assert(!stddll_empty(&Client_State.update_queue));

  /* Pull off as many updates from the queue that can fit into a packet, 
   * and pack them all into a single Proposal message. */

  proposal->num_elements = 1;
  proposal->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);

  h  = (header *)proposal->elements[0].buf;
  h->packetType = PROPOSAL;
  h->serverID   = Server_State.id;
  h->viewNum    = View_State.last_installed;

  ps              = (proposal_specific *)(h+1);
  ps->seq         = seq;
  ps->num_updates = 0; /* FILL THIS IN BELOW! */
  
  /* Keep adding updates to the packet while there is space */
  p = (char *)(ps+1);
  space_remaining = MAX_PACKET_SIZE - sizeof(header) - sizeof(*ps);
  h->dataLen = sizeof(*ps);

  while(space_remaining > 0) {
    stddll_begin(&Client_State.update_queue, &it);

    if(stddll_is_end(&Client_State.update_queue, &it))
      break;

    u  = *(sys_scatter **)stddll_it_val(&it);
    uh = (update_header *)u->elements[0].buf;
    update_len = sizeof(update_header) + uh->dataLen;

    assert(uh->dataLen > 0);
    
    if((space_remaining - update_len) > 0) {
      memcpy(p, (char *)uh, update_len);
      p += update_len;
      ps->num_updates++;
      h->dataLen += update_len;
      space_remaining -= update_len;

      /* Pop the update off the queue */
      dec_ref_cnt(u->elements[0].buf);
      dec_ref_cnt(u);
      stddll_pop_front(&Client_State.update_queue);
      
#if 0
      /* Use this to only include one update per proposal (no aggregation) */
      if(ps->num_updates == 1)
	break;
#endif
    }
    else
      break;
  }
  proposal->elements[0].len = sizeof(header) + h->dataLen;
}


void Construct_Accept_Message(sys_scatter *accept, uint32_t seq)
{
  header *h;
  accept_specific *a;

  accept->num_elements = 1;
  accept->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);

  h = (header *)accept->elements[0].buf;
  
  h->packetType = ACCEPT;
  h->serverID   = Server_State.id;
  h->viewNum    = View_State.last_installed;

  a = (accept_specific *)(h+1);
  a->seq = seq;

  h->dataLen = sizeof(accept_specific);
  accept->elements[0].len = sizeof(header) + h->dataLen;
}

void Construct_VC_Proof_Message(sys_scatter *msg)
{
  header *h;

  msg->num_elements = 1;
  msg->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);

  h = (header *)msg->elements[0].buf;
  h->packetType = VC_PROOF;
  h->serverID   = Server_State.id;
  h->viewNum    = View_State.last_installed;
  h->dataLen    = 0;
  
  msg->elements[0].len = sizeof(header);
}

void Construct_Alive_Message(sys_scatter *msg)
{
  alive_header *h;

  msg->num_elements = 1;
  msg->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);

  h = (alive_header *)msg->elements[0].buf;

  h->packetType = ALIVE;
  h->serverID   = Server_State.id;
  h->local_aru  = Server_State.aru;

  /* Use the dataLen field (which will always be 0) to include the view */
  h->dataLen = View_State.last_attempted;

  msg->elements[0].len = sizeof(alive_header);
}

void Construct_Reconc_Request_Message(sys_scatter *msg)
{
  header *h;
  reconc_request_specific *rs;

  msg->num_elements = 1;
  msg->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);

  h = (header *)msg->elements[0].buf;
  h->packetType = REQUEST;
  h->serverID   = Server_State.id;
  h->viewNum    = View_State.last_installed; /* Not used */
  h->dataLen    = sizeof(reconc_request_specific);

  rs = (reconc_request_specific *)(h+1);
  rs->session_start  = Reconc_State.Receiving_Session.session_start;
  rs->session_target = Reconc_State.Receiving_Session.session_target;
  rs->timestamp      = Reconc_State.Receiving_Session.timestamp;

  msg->elements[0].len = sizeof(header) + sizeof(reconc_request_specific);
}

void Construct_Reconc_Response_Message(sys_scatter *msg, int type, 
				       sp_time timestamp)
{
  header *h;
  reconc_response_specific *rs;

  msg->num_elements = 1;
  msg->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);

  h = (header *)msg->elements[0].buf;
  h->packetType = RECONC_RESPONSE;
  h->serverID   = Server_State.id;
  h->viewNum    = View_State.last_installed; /* Not used */
  h->dataLen    = sizeof(reconc_response_specific);

  rs = (reconc_response_specific *)(h+1);
  rs->type      = type;
  rs->timestamp = timestamp; 

  msg->elements[0].len = sizeof(header) + h->dataLen;
}

void Construct_Reconc_Ack_Message(sys_scatter *msg, int type)
{
  header *h;
  reconc_ack_specific *as;
  uint32_t num_nacks;
  uint32_t nacklist[RECONC_WINDOW_SIZE];

  msg->num_elements = 1;
  msg->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);

  h = (header *)msg->elements[0].buf;
  h->packetType = RECONC_ACK;
  h->serverID   = Server_State.id;
  h->viewNum    = View_State.last_installed; /* Not used */

  num_nacks = Compute_NackList(nacklist);

  h->dataLen = sizeof(reconc_ack_specific) + (num_nacks * sizeof(uint32_t));

  as = (reconc_ack_specific *)(h + 1);
  as->type      = type;
  as->timestamp = Reconc_State.Receiving_Session.timestamp;
  as->aru       = Server_State.aru;
  as->num_nacks = num_nacks;

  if(num_nacks > 0)
    memcpy((char *)(as+1), (char *)nacklist, num_nacks * sizeof(uint32_t));
  
  msg->elements[0].len = sizeof(header) + h->dataLen;
}

void Construct_Client_Reply_Message(sys_scatter *msg, uint32_t client_id,
				    uint32_t timestamp, uint32_t seq)
{
  reply_specific *rs;

  msg->num_elements = 1;

  msg->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);
  rs = (reply_specific *)msg->elements[0].buf;
      
  rs->serverID  = Server_State.id;
  rs->clientID  = client_id;
  rs->timestamp = timestamp;
  rs->seq       = seq;
      
  msg->elements[0].len = sizeof(reply_specific);
}

void Print_Packet(sys_scatter *msg)
{
  header *h;

  h = (header *)msg->elements[0].buf;

  Print_Packet_Type(h->packetType);
  Print_Packet_Header(h);

  switch(h->packetType) {
  case VC:
    break;
  case VC_PROOF:
    break;
  case PREPARE: {
    prepare_specific *p = (prepare_specific *)(h+1);
    Alarm(PRINT, "   ARU:      %d\n", p->aru);
    Alarm(PRINT, "   Timestamp = (%d, %d)\n", 
	  p->timestamp.sec, p->timestamp.usec);
    break;
  }
  case PREPARE_OK: {
    prepare_ok_specific *p = (prepare_ok_specific *)(h+1);
    Alarm(PRINT, "   Type:     ");
    Print_Prepare_Ok_Response_Type(p->type);
    Alarm(PRINT, "   Start:    %d\n", p->session_start);
    Alarm(PRINT, "   Target:   %d\n", p->session_target);
    Alarm(PRINT, "   Timestamp = (%d, %d)\n", 
	  p->timestamp.sec, p->timestamp.usec);
    Alarm(PRINT, "   Leader ARU = %d\n", p->leader_aru);
    break;
  }
  case PREPARE_PHASE: {
    prepare_phase_specific *p = (prepare_phase_specific *)(h+1);
    Alarm(PRINT, "   Timestamp = (%d, %d)\n", 
	  p->timestamp.sec, p->timestamp.usec);
    break;
  }
  case PREPARE_ACK:
    break;
  case UPDATE:
    break;
  case PROPOSAL: {
    proposal_specific *p = (proposal_specific *)(h+1);
    Alarm(PRINT, "   Seq:      %d\n", p->seq);
    break;
  }
  case ACCEPT: {
    accept_specific *a = (accept_specific *)(h+1);
    Alarm(PRINT, "   Seq:      %d\n", a->seq);
    break;
  }
  case ALIVE:    
    break;
  case REQUEST: {
    reconc_request_specific *rs = (reconc_request_specific *)(h+1);
    Alarm(PRINT, "   Start:  %d\n", rs->session_start);
    Alarm(PRINT, "   Target: %d\n", rs->session_target);
    Alarm(PRINT, "   Timestamp = (%d, %d)\n", 
	  rs->timestamp.sec, rs->timestamp.usec);
    break;
  }
  case RECONC_RESPONSE: {
    reconc_response_specific *rs = (reconc_response_specific *)(h+1);
    Alarm(PRINT, "   Type = ");
    Print_Response_Type(rs->type);
    Alarm(PRINT, "   Timestamp = (%d, %d)\n", 
	  rs->timestamp.sec, rs->timestamp.usec);
    break;
  }
  case RECONC_ACK: {
    reconc_ack_specific *as = (reconc_ack_specific *)(h+1);
    Alarm(PRINT, "   Type = ");
    Print_Ack_Type(as->type);
    Alarm(PRINT, "   Timestamp = (%d, %d)\n", 
	  as->timestamp.sec, as->timestamp.usec);
    Alarm(PRINT, "   Aru = %d\n", as->aru);
    break;
  }
  default:
    Alarm(PRINT, "Unexpected packet type!!!\n");
  }
}

static void Print_Prepare_Ok_Response_Type(uint32_t type)
{
  switch(type) {
  case PREPARE_OK_ACCEPT:
    Alarm(PRINT, "PREPARE_OK_ACCEPT\n");
    break;
  case PREPARE_OK_REJECT:
    Alarm(PRINT, "PREPARE_OK_REJECT\n");
    break;
  default:
    Alarm(EXIT, "Unexpected Prepare_Ok response type: %d\n", type);
  }
}

static void Print_Response_Type(int type)
{
  switch(type) {
  case RECONC_ACCEPT:
    Alarm(PRINT, "RECONC_ACCEPT\n");
    break;
  case RECONC_REJECT:
    Alarm(PRINT, "RECONC_REJECT\n");
    break;
  default:
    Alarm(EXIT, "Unexpected Reconciliation response type: %d\n", type);
  }
}

static void Print_Ack_Type(int type)
{
  switch(type) {
  case FLOW_TYPE:
    Alarm(PRINT, "FLOW\n");
    break;
  case TIMER_TYPE:
    Alarm(PRINT, "TIMER\n");
    break;
  default:
    Alarm(EXIT, "Unexpected Reconciliation Ack type: %d\n", type);
  }
}

static void Print_Packet_Header(header *h)
{
  if(h->packetType == UPDATE) {
    update_header *uh = (update_header *)h;
    Alarm(PRINT, "   ClientID: %d\n", uh->clientID);
    Alarm(PRINT, "   ServerID: %d\n", uh->serverID);
    Alarm(PRINT, "   Timestamp %d\n", uh->timestamp);
    Alarm(PRINT, "   DataLen:  %d\n", uh->dataLen);
  }
  else if(h->packetType == ALIVE) {
    alive_header *ah = (alive_header *)ah;
    Alarm(PRINT, "   ServerID:  %d\n", ah->serverID);
    Alarm(PRINT, "   Local_Aru::%d\n", ah->local_aru);
  } 
  else {
    Alarm(PRINT, "   ServerID: %d\n", h->serverID);
    Alarm(PRINT, "   ViewNum:  %d\n", h->viewNum);
    Alarm(PRINT, "   DataLen:  %d\n", h->dataLen);
  }
}

static void Print_Packet_Type(uint32_t p_type)
{
  switch(p_type) {
  case VC:
    Alarm(PRINT, "VC\n");
    break;
  case VC_PROOF:
    Alarm(PRINT, "VC_PROOF\n");
    break;
  case PREPARE:
    Alarm(PRINT, "PREPARE\n");
    break;
  case PREPARE_OK:
    Alarm(PRINT, "PREPARE_OK\n");
    break;
  case PREPARE_PHASE:
    Alarm(PRINT, "PREPARE_PHASE\n");
    break;
  case PREPARE_ACK:
    Alarm(PRINT, "PREPARE_ACK\n");
    break;
  case UPDATE:
    Alarm(PRINT, "UPDATE\n");
    break;
  case PROPOSAL:
    Alarm(PRINT, "PROPOSAL\n");
    break;
  case ACCEPT:
    Alarm(PRINT, "ACCEPT\n");
    break;
  case ALIVE:
    Alarm(PRINT, "ALIVE\n");
    break;
  case REQUEST:
    Alarm(PRINT, "REQUEST\n");
    break;
  case RECONC_RESPONSE:
    Alarm(PRINT, "RECONC_RESPONSE\n");
    break;
  case RECONC_ACK:
    Alarm(PRINT, "RECONC_ACK\n");
    break;
  default:
    Alarm(PRINT, "Unexpected packet type!!!\n");
    break;
  }
}
