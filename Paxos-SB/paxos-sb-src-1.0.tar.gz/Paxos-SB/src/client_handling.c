/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#include <assert.h>
#include <stdlib.h>
#include "def.h"
#include "client_handling.h"
#include "util_include.h"
#include "p_server.h"
#include "paxos_protocol.h"
#include "packets.h"
#include "retrans.h"
#include "disk.h"
#include "membership.h"
#include "global_ordering.h"
#include "tcp_wrapper.h"
#include "util.h"
#include "aggregation.h"

/*--------------------------------------------------------------------*/
static void TCP_Update_Dispatcher         (int sd, int code, void *data);
static void Client_Timestamp_Query_Handler(uint32_t client_id);
static int  Is_Update_In_Queue            (sys_scatter *update);
/*--------------------------------------------------------------------*/

extern Parameter_struct Params;
extern Server_struct    Server_State;
extern Network_struct   Network_State;
extern Disk_struct      Disk_State;
extern VC_struct        View_State;
extern Client_struct    Client_State;
extern Proposal_struct  Proposal_State;
extern Accept_struct    Accept_State;
extern Alive_struct     Alive_State;
extern Prepare_struct   Prepare_State;

void Respond_to_Client(int32_t seq, void *dummy)
{
  sys_scatter *proposal;
  proposal_specific *ps;
  header *h;
  char *p;
  update_header *uh;
  update_header *pending_header;
  int sd;
  int id;
  int i;

  UTIL_Assert_Ordered_Update(seq);
  proposal = UTIL_Get_Ordered_Update(seq);
  h        = (header *)proposal->elements[0].buf;
  ps       = (proposal_specific *)(h+1);

  p = (char *)(ps+1);
  for(i = 0; i < ps->num_updates; i++) {
    uh = (update_header *)p;

    /* If this is a nop, don't respond */
    if(uh->timestamp == 0) {
      assert(uh->clientID == 0);
      p += sizeof(update_header) + uh->dataLen;
      continue;
    }
  
    id = uh->clientID;

    /* If this is my client */
    if(uh->serverID == Server_State.id) {
      sd = Network_State.Client_to_Sd[id];

      /* If he's still connected to me, send a reply */
      if(sd != -1) {
	sys_scatter *reply;
	int ret;

	reply = new_ref_cnt(SYS_SCATTER);
	Construct_Client_Reply_Message(reply, id, uh->timestamp, ps->seq);

	ret = TCP_Write(sd, reply->elements[0].buf, sizeof(reply_specific));

	if(ret <= 0) {
	  close(sd);
	  E_detach_fd(sd, READ_FD);
	  Network_State.Client_to_Sd[id] = -1;
	}

	dec_ref_cnt(reply->elements[0].buf);
	dec_ref_cnt(reply);
      }
      
      /* If I have a pending update from this client, see if this one
       * cancels it. */
      if(Client_State.pending_updates[id] != NULL) {
	pending_header = (update_header *)
	  Client_State.pending_updates[id]->elements[0].buf;
	if(uh->timestamp == pending_header->timestamp) {
	  /* Cancel the timeout associated with reforwarding this update.*/  
	
	  E_dequeue(Timer_Dispatcher, UPDATE_TIMER, &Client_State.indices[id]);
	  dec_ref_cnt(Client_State.pending_updates[id]->elements[0].buf);
	  dec_ref_cnt(Client_State.pending_updates[id]);
	  Client_State.pending_updates[id] = NULL;    
	}
      }
    }
    p += sizeof(update_header) + uh->dataLen;
  }
}

int Enqueue_Update(sys_scatter *msg)
{
  sys_scatter *update;
  update_header *h;

  h = (update_header *)msg->elements[0].buf;

  /* Never enqueue an update if I've already executed it */
  if(h->timestamp <= Client_State.last_executed[h->clientID]) {
    Alarm(PRINT, "Not enqueueing update, already executed, client %d, ts %d\n",
	  h->clientID, h->timestamp);
    fflush(stdout);
    return 0;
  }

  /* The last_enqueued is reset to 0 at the start of each view.  Thus, 
   * I'll enqueue updates in increasing fashion in this view.  If this 
   * check fails, then I've already enqueued either this update or a later
   * one.  In both cases, I don't want to enqueue it again. */
  if(h->timestamp <= Client_State.last_enqueued[h->clientID]) {
  Alarm(PRINT, "%d not enqueueing update, already enqueued, client %d, ts %d, "
	"Last_Enqueued = %d\n", Server_State.id, h->clientID, h->timestamp,
	  Client_State.last_enqueued[h->clientID]);
    fflush(stdout);
    return 0;
  }
  
  update = new_ref_cnt(SYS_SCATTER);

  update->num_elements = 1;
  update->elements[0].buf = msg->elements[0].buf;
  update->elements[0].len = msg->elements[0].len;

  inc_ref_cnt(update->elements[0].buf);
  stddll_push_back(&Client_State.update_queue, &update);
  Client_State.last_enqueued[h->clientID] = h->timestamp;
  /*Alarm(DEBUG, "Enqueued an update with timestamp %d.\n", h->timestamp);*/

  return 1;
}

void Forward_Update(sys_scatter *msg)
{
  update_header *h;
  uint32_t leader;

  h = (update_header *)msg->elements[0].buf;

  /* If I've already ordered this update, and it is the latest update from
   * this client, send a response to the client. */
  if(h->timestamp == Client_State.last_executed[h->clientID])
    Alarm(EXIT, "Bug: Trying to forward an update I've already executed.\n");
  else {
    leader = View_State.last_installed % Params.Num_Servers;
    if(leader == 0)
      leader = Params.Num_Servers;
    
    Send_UCast(Network_State.sd, msg, leader);
  }
}

void Add_Update_to_Pending(sys_scatter *msg)
{
  sys_scatter *update;
  update_header *uh;
  sp_time t;

  uh = (update_header *)msg->elements[0].buf;
 
  if(uh->serverID == Server_State.id) {
 
    update = new_ref_cnt(SYS_SCATTER);

    update->num_elements = 1;
    update->elements[0].buf = msg->elements[0].buf;
    update->elements[0].len = msg->elements[0].len;
    inc_ref_cnt(update->elements[0].buf);
    
    if(Client_State.pending_updates[uh->clientID] != NULL) {
      Print_Packet(Client_State.pending_updates[uh->clientID]);
      Print_Packet(update);
      fflush(stdout);
      abort();
    }
  
    Client_State.pending_updates[uh->clientID] = update;
    t.sec  = UPDATE_TIMER_SEC;
    t.usec = (UPDATE_TIMER_USEC + (rand() % 900000)) % 1000000;
    E_queue(Timer_Dispatcher, UPDATE_TIMER, 
	    &Client_State.indices[uh->clientID], t);

#ifdef WRITE_TO_DISK
    Write_Pending_Update_to_Disk(update);
#endif
  }
}

void Forward_Queued_Updates()
{
  stdit it;
  sys_scatter *update;
  update_header *uh;
 
  while(1) {
    stddll_begin(&Client_State.update_queue, &it);
    if(stddll_is_end(&Client_State.update_queue, &it))
      break;

    update = *(sys_scatter **)stddll_it_val(&it);
    uh = (update_header *)update->elements[0].buf;

    /* Only forward my updates!!! */
#if 0
    /* This is not needed.  The update was added to Pending when it was
     * first received, in which case the Update_Timer is set.  It might
     * not have been sent when in the LEADER_ELECTION state, but when the
     * server shifts to NON-LEADER it will automatically be forwarded 
     * using the Update_Timer mechanism.*/
    if(uh->serverID == Server_State.id) {
      Forward_Update(update);

      Alarm(PRINT, "Server %d forwarded queued update from client %d with ts "
	    "%d, originally to server %d, to leader.\n", 
	    Server_State.id, uh->clientID, uh->timestamp, uh->serverID);
    }
#endif
    /* Now pop it off the queue */
    dec_ref_cnt(update->elements[0].buf);
    dec_ref_cnt(update);
    stddll_pop_front(&Client_State.update_queue);
  }
}

void Enqueue_Unbound_Forwarded_Updates()
{
  int i;
  sys_scatter *msg;
  
  for(i = 1; i <= MAX_CLIENTS; i++) {

    if(E_in_queue(Timer_Dispatcher, UPDATE_TIMER, &Client_State.indices[i])) {
      
      /* I'm responsible for this update, so I want to leave the update
       * in pending_updates.  If it's already bound to a 
       * sequence number, then if I propose it at all in this view, it
       * will be as a constrained proposal.  I do not want to put it on the
       * queue again.  If the update is not bound, then I want to enqueue it, 
       * even if I already enqueued it in some previous view. */  

      msg = Client_State.pending_updates[i];
      assert(msg);
	     
      if(!Is_Bound(msg) && !Is_Update_In_Queue(msg)) {
	update_header *uh;
	uh = (update_header *)msg->elements[0].buf;
	Alarm(PRINT, "Enqueuing pending update for client %d, ts %d\n", 
	      i, uh->timestamp);
	fflush(stdout);
	Enqueue_Update(msg);
	/* TODO: Not sure if this assert is correct.  Is it possible
	 * that I've already executed the pending update?  If so, then
	 * this assert will fail because Enqueue_Update will not
	 * enqueue an update that we've already executed. */
	/*assert(Is_Update_In_Queue(msg));*/
      }
    }
  }
}

void Remove_Bound_Updates_From_Queue()
{
  stdit it;
  sys_scatter *update;
  update_header *uh;

  stddll_begin(&Client_State.update_queue, &it);
  while(1) {
    if(stddll_is_end(&Client_State.update_queue, &it))
      break;

    update = *(sys_scatter **)stddll_it_val(&it);
    uh = (update_header *)update->elements[0].buf;
    
    /* If the update is bound or already executed, remove it from the queue 
     * and set last_enqueued, because we don't want to enqueue it again this
     * view. */
    if(Is_Bound(update) || 
       (uh->timestamp <= Client_State.last_executed[uh->clientID])) {

      if(uh->timestamp > Client_State.last_enqueued[uh->clientID])
	Client_State.last_enqueued[uh->clientID] = uh->timestamp;
      
      Alarm(PRINT, "Removed bound update: client %d, ts %d\n",
	    uh->clientID, uh->timestamp);
      Alarm(PRINT, "Last executed = %d, Last enqueued = %d\n",
	    Client_State.last_executed[uh->clientID],
	    Client_State.last_enqueued[uh->clientID]);
      fflush(stdout);

      dec_ref_cnt(update->elements[0].buf);
      dec_ref_cnt(update);
      stddll_erase(&Client_State.update_queue, &it);
      stddll_begin(&Client_State.update_queue, &it);
    }
    else
      stddll_it_next(&it);
    
#if 0
    /*Also, if the update is already in the queue and it's from 
     * another server (i.e., it wasn't my pending one that I just enqueued
     * via Enqueue_Pending), remove it b/c it's a duplicate. */
    
    (uh->timestamp <= Client_State.last_enqueued[uh->clientID] &&
     uh->serverID != Server_State.id)){
    
    if(uh->timestamp > Client_State.last_enqueued[uh->clientID])
      Client_State.last_enqueued[uh->clientID] = uh->timestamp;
    
    Alarm(PRINT, "Removed bound update: client %d, ts %d\n",
	  uh->clientID, uh->timestamp);
    Alarm(PRINT, "Last executed = %d, Last enqueued = %d\n",
	  Client_State.last_executed[uh->clientID],
	  Client_State.last_enqueued[uh->clientID]);
    fflush(stdout);
    
    dec_ref_cnt(update->elements[0].buf);
    dec_ref_cnt(update);
      stddll_erase(&Client_State.update_queue, &it);
      stddll_begin(&Client_State.update_queue, &it);
#endif

  }
}

static void TCP_Update_Dispatcher(int sd, int code, void *data) 
{
  sys_scatter *msg;
  update_header *uh;
  int ret;
 
  ret = TCP_Read(sd, (char *)Network_State.Recv_Msg.elements[0].buf, 
		 UPDATE_TARGET);

  if(ret <= 0) {
    close(sd);
    E_detach_fd(sd, READ_FD);
  }
  else {
    Network_State.Recv_Msg.num_elements    = 1;
    Network_State.Recv_Msg.elements[0].len = ret;
    msg = (sys_scatter *)&(Network_State.Recv_Msg);

    uh = (update_header *)msg->elements[0].buf;
    assert(uh->packetType == UPDATE);

    /* If this server already has a connection to this client open, close
     * this one. */
    if(uh->timestamp == 0 && Network_State.Client_to_Sd[uh->clientID] != -1) {
      close(sd);
      E_detach_fd(sd, READ_FD);
    }
    else {
      /* Store the mapping of client_id to socket descriptor */
      Network_State.Client_to_Sd[uh->clientID] = sd;
      
      /* The first "update" from a client is really a query, asking for 
       * the next timestamp it should use.  If so, handle it. */
      if(uh->timestamp == 0)
	Client_Timestamp_Query_Handler(uh->clientID);
      else
	Update_Handler(msg);
    }
  }

  Network_State.Recv_Msg.elements[0].len = MAX_PACKET_SIZE;

  if(get_ref_cnt(Network_State.Recv_Msg.elements[0].buf) > 1) {
    dec_ref_cnt(Network_State.Recv_Msg.elements[0].buf);
    Network_State.Recv_Msg.elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);
  } 
  
  /*Alarm(PRINT, "Finished TCP reader.\n");*/
}

void Client_Connection_Acceptor(int sd, int code, void *data)
{
  struct sockaddr_in client_addr;
  socklen_t len;
  int connfd;

  len    = sizeof(client_addr);
  if((connfd = accept(sd, (struct sockaddr *)&client_addr, &len)) < 0) {
    perror("accept");
    exit(0);
  }
  Alarm(PRINT, "Accepted a connection!\n");
  E_attach_fd(connfd, READ_FD, TCP_Update_Dispatcher, 0, NULL, 
	      HIGH_PRIORITY);
}

void Update_Timer_Handler(int index)
{
  uint32_t leader;
  sp_time t;
  update_header *h;

  /* This client's update was not yet ordered, even though I forwarded it
   * to the leader.  Reforward it now.*/
  leader = View_State.last_installed % Params.Num_Servers;
  if(leader == 0)
    leader = Params.Num_Servers;

  t.sec  = UPDATE_TIMER_SEC;
  t.usec = UPDATE_TIMER_USEC + (rand() % 5000);
  E_queue(Timer_Dispatcher, UPDATE_TIMER, &Client_State.indices[index], t);
  
  assert(Client_State.pending_updates[index]);

  /* Only re-forward the update if I'm a non-leader, since the leader
   * already has it. */
  if(Server_State.state == REG_NONLEADER) {
    h = (update_header *)Client_State.pending_updates[index]->elements[0].buf;
    
    /*Alarm(PRINT, "Reforwarded update %d from client %d to leader (%d).\n", 
      h->timestamp, index, leader);*/
    Send_UCast(Network_State.sd, Client_State.pending_updates[index], leader);
  }
}

void Update_Handler(sys_scatter *msg)
{
  update_header *uh;
  uh = (update_header *)msg->elements[0].buf;

  switch(Server_State.state) {

  case LEADER_ELECTION:
    /* No leader yet.  If this is not from one of my clients, I have no
     * obligation to it, so I'll drop it.  Otherwise, try to enqueue the 
     * update.  If I enqueued it, take responsibility for it. */
    Alarm(DEBUG, "Received updated in LEADER_ELECTION\n");
    if(uh->serverID != Server_State.id)
      return;

#ifdef UPDATE_INITIATION_AGGREGATION
    Aggregation_Add_Update_To_Queue(msg);
    return;
#endif

    if(Enqueue_Update(msg))
      Add_Update_to_Pending(msg);
    break;
  
  case REG_NONLEADER:
    /* Forward the update, and take responsibility for it (if it's from one
     * of my clients) by adding it to pending if you do. */
    if(uh->serverID == Server_State.id) {

#ifdef UPDATE_INITIATION_AGGREGATION
      Aggregation_Add_Update_To_Queue(msg);
      return;
#endif 

      Add_Update_to_Pending(msg);
      Forward_Update(msg);
    }
    break;

  case REG_LEADER:
    /*Alarm(DEBUG, "Received an update.\n");*/
    
    /* If the view is not yet prepared, enqueue the update.  If it's from
     * one of my clients and I did enqueue it, then take responsibility for
     * it by adding it to pending. */

#ifdef UPDATE_INITIATION_AGGREGATION
    if(uh->serverID == Server_State.id) {
      Aggregation_Add_Update_To_Queue(msg);
      return;
    }
#endif

    if(!Prepare_State.view_is_prepared) {
      if(Enqueue_Update(msg))
	Add_Update_to_Pending(msg);
      Alarm(PRINT, "View is not prepared.\n");
      fflush(stdout);
      return;
    }

    /* If we already have this update on the queue, ignore it */
    if(Enqueue_Update(msg))
      Add_Update_to_Pending(msg);
    else
      return;
    
    /* At this point, the update was placed on the queue and the view
     * is prepared.  Try to send some proposals if the window allows. */
    /*Alarm(DEBUG, "Calling Send_Some from Update_Handler\n");*/
    Send_Some_Proposals();
    break;
  }
}

static void Client_Timestamp_Query_Handler(uint32_t client_id)
{
  sys_scatter *msg;
  update_header *uh;
  uint32_t seq;
  uint32_t pending_flag;
  int ret, sd;

  /* Write the next client_timestamp this client should use.  Then write
   * CLIENT_UPDATE_PENDING or CLIENT_UPDATE_NONE_PENDING to signal the client 
   * to wait or write. */
  Alarm(PRINT, "Received a client query from client %d\n", client_id);
  fflush(stdout);

  if(Client_State.pending_updates[client_id] == NULL) {
    seq          = Client_State.last_executed[client_id] + 1;
    pending_flag = CLIENT_UPDATE_NONE_PENDING;
  }
  else {
    uh = (update_header *)
      Client_State.pending_updates[client_id]->elements[0].buf;
    seq = uh->timestamp + 1;
    pending_flag = CLIENT_UPDATE_PENDING;
  }

  /* Create a "dummy" reply message, setting the client_id field to the
   * flag to indicate whether or not the client should wait.  The timestamp
   * is 0, corresponding the client query. */
  msg = new_ref_cnt(SYS_SCATTER);
  Construct_Client_Reply_Message(msg, pending_flag, 0, seq);

  sd  = Network_State.Client_to_Sd[client_id];
  ret = TCP_Write(sd, (char *)msg->elements[0].buf, sizeof(reply_specific));

  if(ret <= 0) {
    close(sd);
    E_detach_fd(sd, READ_FD);
    Network_State.Client_to_Sd[client_id] = -1;
  }

  dec_ref_cnt(msg->elements[0].buf);
  dec_ref_cnt(msg);
}

void Update_Client_Last_Executed(uint32_t seq)
{
  sys_scatter *proposal;
  header *h;
  proposal_specific *ps;
  update_header *uh;
  char *p;
  int i;

  UTIL_Assert_Ordered_Update(seq);

  proposal = UTIL_Get_Ordered_Update(seq);
  h        = (header *)proposal->elements[0].buf;
  ps       = (proposal_specific *)(h+1);
 
  /* Iterate over all updates in the proposal ordered with sequence seq */
  p = (char *)(ps+1);
  for(i = 0; i < ps->num_updates; i++) {
    uh  = (update_header *)p;

    /* If this is a nop, this is irrelevant. */
    if(uh->timestamp == 0) {
      assert(uh->clientID == 0);
      p += sizeof(update_header) + uh->dataLen;
      continue;
    }

    /* There should be no holes in the execution of client updates */
    if(uh->timestamp != (Client_State.last_executed[uh->clientID] + 1)) {
      Alarm(PRINT, "Client %d, ts %d, last_executed %d\n", uh->clientID,
	    uh->timestamp, Client_State.last_executed[uh->clientID]);
      fflush(stdout);
      abort();
    }
    Client_State.last_executed[uh->clientID] = uh->timestamp;
    p += sizeof(update_header) + uh->dataLen;
  }
}

static int Is_Update_In_Queue(sys_scatter *update)
{
  int ret;
  stdit it;
  update_header *uh, *quh;
  sys_scatter *queue_update;
  
  ret = 0;

  uh = (update_header *)update->elements[0].buf;

  stddll_begin(&Client_State.update_queue, &it);
  while(1) {
    if(stddll_is_end(&Client_State.update_queue, &it))
      break;

    queue_update = *(sys_scatter **)stddll_it_val(&it);
    quh          = (update_header *)queue_update->elements[0].buf;
    
    if(uh->clientID  == quh->clientID &&
       uh->timestamp == quh->timestamp) {
      ret = 1;
      break;
    }
    stddll_it_next(&it);
  }
  return ret;
}
