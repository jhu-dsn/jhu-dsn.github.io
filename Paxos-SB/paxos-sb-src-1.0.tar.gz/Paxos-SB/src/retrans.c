/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#include <stdlib.h>
#include "retrans.h"
#include "p_server.h"
#include "paxos_protocol.h"
#include "packets.h"

extern Server_struct   Server_State;
extern Network_struct  Network_State;
extern Retrans_struct  Retrans_State;
extern Proposal_struct Proposal_State;

void Schedule_Retrans(sys_scatter *msg, int typ)
{
  sp_time t;
  
  assert((typ >= 0) && (typ < MAX_PACKET_TYPES));

  /* If there is something in this slot, just clear it out */
  if( (Retrans_State.buf[typ] != NULL) && (Retrans_State.buf[typ] != msg) ){
    dec_ref_cnt(Retrans_State.buf[typ]->elements[0].buf);
    dec_ref_cnt(Retrans_State.buf[typ]);
    Retrans_State.buf[typ] = NULL;
  }
	
  /* If we replaced a previous message or are adding a message for the 
   * first time, increment the ref counts. */
  if(Retrans_State.buf[typ] == NULL) {
    Retrans_State.buf[typ] = msg;
    inc_ref_cnt(Retrans_State.buf[typ]);
    inc_ref_cnt(Retrans_State.buf[typ]->elements[0].buf);
  }  

  t.sec  = RETRANS_PERIOD_SEC;
  t.usec = RETRANS_PERIOD_USEC;
  
  E_queue(Timer_Dispatcher, RETRANS_TIMER, 
	  (int *)&(Retrans_State.packet_types[typ]), t);
}

void Cancel_Retrans(int typ)
{
  assert((typ >= 0) && (typ < MAX_PACKET_TYPES));

  if(Retrans_State.buf[typ] != NULL) {
    dec_ref_cnt(Retrans_State.buf[typ]->elements[0].buf);
    dec_ref_cnt(Retrans_State.buf[typ]);
    Retrans_State.buf[typ] = NULL;
  }
  
  E_dequeue(Timer_Dispatcher, RETRANS_TIMER, 
	    (int *)&(Retrans_State.packet_types[typ]));
}

void Schedule_Proposal_Retransmission(uint32_t seq)
{
  int index;
  sp_time t;

  index = seq % WINDOW_SIZE;
  assert(Proposal_State.window[index] != NULL);
  
  /*Set up the new event*/
  t.sec  = PROPOSAL_RETRANS_PERIOD_SEC;
  t.usec = PROPOSAL_RETRANS_PERIOD_USEC + (rand() % 100000);

  E_queue(Timer_Dispatcher, PROPOSAL_RETRANS_TIMER, 
	  (int *)&Proposal_State.indices[index], t);
}  

void Cancel_Proposal_Retransmission(uint32_t seq)
{
  int index;

  index = seq % WINDOW_SIZE;
  
  if(Proposal_State.window[index]) {
    dec_ref_cnt(Proposal_State.window[index]->elements[0].buf);
    dec_ref_cnt(Proposal_State.window[index]);
    Proposal_State.window[index] = NULL;

    E_dequeue(Timer_Dispatcher, PROPOSAL_RETRANS_TIMER,
	      (int *)&Proposal_State.indices[index]);
  }
}

void Cancel_All_Proposal_Retransmissions()
{
  int i;

  for(i = 0; i < WINDOW_SIZE; i++)
    Cancel_Proposal_Retransmission(i);
}

void Retrans_Timer_Handler(int *typ)
{
  switch(Server_State.state) {
    /* Retransmission event. */
  case LEADER_ELECTION:
  case REG_NONLEADER:    
  case REG_LEADER:
    Send_MCast(Retrans_State.buf[*typ]);
    Schedule_Retrans(Retrans_State.buf[*typ], *typ);
  }
}

void Proposal_Retrans_Timer_Handler(int *index)
{
  switch(Server_State.state) {
    
  case LEADER_ELECTION:
  case REG_NONLEADER:
    Alarm(EXIT, "Proposal Retransmission timer expired in state other than"
	  " REG_LEADER.\n");
    break;
    
  case REG_LEADER:
    Send_MCast(Proposal_State.window[*index]);
#if 1
    Alarm(PRINT, "Sent a Proposal retransmission for index %d!\n", *index);
    fflush(stdout);
#endif

    Proposal_State.congestion_window = Proposal_State.congestion_window / 2.0; 
    if(Proposal_State.congestion_window < 1.0)
      Proposal_State.congestion_window = 1.0;

    /* This function really expects a sequence number, but because it
     * is already taken modulo the window size, the end result is the
     * same inside of the retransmission function. */
    Schedule_Proposal_Retransmission(*index);
    break;
  }
}
