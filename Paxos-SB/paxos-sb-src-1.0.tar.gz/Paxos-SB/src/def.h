/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#ifndef PFSB_DEF_H
#define PFSB_DEF_H

/*--------------------------------------------------------------------------
 * The following options can be toggled on and off independently
 * to control the behavior of the system.
 *-------------------------------------------------------------------------*/

/* Uncomment this line if IP-multicast is available.  Otherwise, send
 * "multicasts" by sending UDP messages via unicast links. */
/*#define USE_TRUE_MCAST*/

/* Comment this line to remove all disk writes.  Note: this does not
 * preserve safety in the face of crashes and recoveries!  Remember
 * that sync'ing is controlled by a command-line parameter */
/*#define WRITE_TO_DISK*/

/* Comment this out to let servers some servers potentially fall behind */
#define GLOBAL_FLOW_CONTROL

/* Uncomment this to write ordered updates to a log for debugging */
/*#define DEBUG_LOG*/

/* Turn this on to trigger some instrumented behavior designed to test 
 * error handling capabilities. */
/*#define INSTRUMENT*/

/* Keep this uncommented to use aggregation: multiple updates in a single
 * Proposal, multiple Proposals for a single Accept. */
#define AGGREGATION

/* Keep this uncommented to aggregate syncing of updates initiated by
 * local clients (i.e., one disk write for multiple such updates). */
#define UPDATE_INITIATION_AGGREGATION

/* Controls how the client connects to the server. Exactly one of
 * these must be set at a time! */
#define USE_LOCAL_SOCKETS
/*#define USE_TCP_SOCKETS*/

/* Uncomment one or both of these lines to output benchmarking information. */
/*#define SERVER_BENCHMARKING*/
/*#define CLIENT_BENCHMARKING*/

/*-------------------------------------------------------------------------
 * The following defines are global values that can be adjusted as needed.
 *------------------------------------------------------------------------*/

/* When running benchmarks, set the starting and ending sequence
 * numbers for timing purposes.  For example, if set to 10K and 400K,
 * the system will run for 400K updates but will only start timing at
 * 10K. */
#define BENCHMARK_START_SEQ 10000
#define BENCHMARK_END_SEQ   50000

#define MAX_SERVERS      50
#define MAX_CLIENTS      500

#define PAXOS_UDP_BASE_PORT 25750
#define PAXOS_MCAST_PORT    26750
#define PAXOS_TCP_BASE_PORT 30000

#define MCAST_ADDRESS (224 << 24 | 0 << 16 | 0 << 8 | 117)

#define UPDATE_SIZE 200
#define WINDOW_SIZE 100 
/* Memory: 300, Sync: 100 */

/* Window size used by selective-repeat reconciliation protocol. */
#define RECONC_WINDOW_SIZE 20

/* Don't touch this one unless you need to add more packet types. */
#define MAX_PACKET_TYPES 20

/* Internally used, don't change */
#define CLIENT_UPDATE_PENDING      1
#define CLIENT_UPDATE_NONE_PENDING 2
#define UPDATE_TARGET sizeof(update_header) + UPDATE_SIZE

/*--------------------------------------------------------------------------
 * The following timeout values can be adjusted as needed.  Fields are
 * for seconds and microseconds.
 *-------------------------------------------------------------------------*/

/* Retransmission timeout, for those packets controlled by the mechanism in
 * retrans.c (view change). */
#define RETRANS_PERIOD_SEC  1
#define RETRANS_PERIOD_USEC 0

/* Proposal retransmission timeout, for determining how long the
 * leader waits, without ordering a proposal it has sent, before
 * retransmitting it. */
#define PROPOSAL_RETRANS_PERIOD_SEC  0
#define PROPOSAL_RETRANS_PERIOD_USEC 500000

/* How long the client waits for a reply to its update before giving up. */
#define REPLY_TIMER_SEC  30
#define REPLY_TIMER_USEC 0 

/* How often to send the VC_proof message. */
#define VC_PROOF_TIMER_SEC  1
#define VC_PROOF_TIMER_USEC 0

/* How long to wait before suspecting the leader. */
#define PROGRESS_TIMER_SEC  5
#define PROGRESS_TIMER_USEC 0

/* How often to send an Alive message (for loose membership, garbage
 * collection, and global flow control. */
#define ALIVE_TIMER_SEC  1
#define ALIVE_TIMER_USEC 0

/* How long to wait before removing a server from your loose
 * membership. */
#define MEMBERSHIP_TIMER_SEC  3
#define MEMBERSHIP_TIMER_USEC 500000

/* How long to wait before retransmitting a forwarded update to the
 * leader. */
#define UPDATE_TIMER_SEC  3
#define UPDATE_TIMER_USEC 0

/* How long to wait to receive a response to your reconciliation request. */
#define RECONC_RESPONSE_TIMER_SEC  1 
#define RECONC_RESPONSE_TIMER_USEC 0
/* With memory, 20ms; sync: 1 second */

/* Don't send another nack if you've sent one within this amount of time. */
#define RECONC_NACK_PERIOD_SEC  0
#define RECONC_NACK_PERIOD_USEC 1000

/* Timer used in reconciliation. */
#define ACK_TIMER_SEC  0
#define ACK_TIMER_USEC 100000

/* How long to wait before deciding to initiate an Anti-entropy session. */
#define ANTI_ENTROPY_TIMER_SEC  0
#define ANTI_ENTROPY_TIMER_USEC 10000 /* was 300000 */
/* Memory: 10ms, Sync:10ms  */

/* Number of times the Prepare should be retransmitted before the leader*
 * suspects itself. */
#define PREPARE_RETRANS_THRESHOLD 5

/* How long to wait before retransmitting the Prepare message. */
#define PREPARE_RETRANS_SEC  0
#define PREPARE_RETRANS_USEC 500000

/* Timer used in prepare session reconciliation. */
#define PREPARE_ACK_TIMER_SEC  0
#define PREPARE_ACK_TIMER_USEC 100000

/* What the aggregation interval is (i.e., how long to wait before
 * taking action.  See Schedule_Aggregation_Event in aggregation.c. */
#define AGGREGATION_PERIOD_SEC  0
#define AGGREGATION_PERIOD_USEC 0

#endif
