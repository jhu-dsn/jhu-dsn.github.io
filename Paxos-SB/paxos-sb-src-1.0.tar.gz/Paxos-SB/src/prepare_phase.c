/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#include <string.h>
#include "prepare_phase.h"
#include "p_server.h"
#include "packets.h"
#include "retrans.h"
#include "global_ordering.h"
#include "paxos_protocol.h"
#include "client_handling.h"
#include "disk.h"
#include "membership.h"
#include "util.h"

/*------------------------------------------------------------------------*/
static void Create_Prepare_Sending_Session  (sys_scatter *prepare);
static void Finish_Prepare_Receiving_Session(uint32_t id);
static void Finish_Prepare_Phase            (void);

static void Send_Next_Prepare_Batch   (void);
static void Send_Prepare_Ok           (uint32_t type);
static void Send_Prepare_Phase_Message(uint32_t seq);
static void Send_Prepare_Ack          (uint32_t type, uint32_t id);

/* Functions to decide what to include in the Prepare_OK datalist */
static uint32_t Get_First_Accepted  (uint32_t aru);
static uint32_t Get_Highest_Accepted(uint32_t aru);

/* Constructs a nop and applies it to the server's data structures */
static void Apply_Nop_to_Hole(uint32_t seq);
/*------------------------------------------------------------------------*/


extern VC_struct        View_State;
extern Prepare_struct   Prepare_State;
extern Parameter_struct Params;
extern Server_struct    Server_State;
extern Network_struct   Network_State;
extern Accept_struct    Accept_State;
extern Reconc_struct    Reconc_State;

void Prepare_Message_Handler(sys_scatter *msg)
{
  header *h;
  prepare_specific *p;

  h = (header *)msg->elements[0].buf;
  p = (prepare_specific *)(h+1);

  /* Do not process this Prepare message if it is your own (because you 
   * process it specially when sending) or if it is not from your view */
  if(h->serverID == Server_State.id)
    return;

  if(h->viewNum != View_State.last_attempted) {
    Alarm(DEBUG, "Dropping Prepare, wrong attempt: %d %d\n", 
	  h->viewNum, View_State.last_attempted);
    return;
  }

  /* Process your own specially, ignore it here */
  if(Server_State.state == REG_LEADER)
    return;

  if(Server_State.state == LEADER_ELECTION)
    Shift_to_Reg_Nonleader();

  /* If I know more than the leader, send a REJECT, which will tell him
   * that he needs to reconcile with me. */
  if(Server_State.aru > p->aru) {
    Alarm(PRINT, "Server %d sending a Prepare_OK reject, my_aru = %d, "
	  "his = %d.\n", Server_State.id, Server_State.aru, p->aru);
    fflush(stdout);
    Send_Prepare_Ok(PREPARE_OK_REJECT);
    return;
  }

  /* If the aru in the Prepare is less than the white line, then I
   * might need to send something that I've already garbage collected,
   * which I shouldn't do (and he really has everything up to that
   * point, anyway).  So make him send me a Prepare with his true
   * aru. */
  if(p->aru < Server_State.white_line) {
    Alarm(PRINT, "Server %d sending a Prepare_OK reject, white_line = %d, "
	  "his = %d.\n", Server_State.id, Server_State.white_line, p->aru);
    fflush(stdout);
    Send_Prepare_Ok(PREPARE_OK_REJECT);
  }

  /* If there is no active session open, or if this Prepare has a later
   * timestamp, set up a new session. */
  if((Prepare_State.Sending_Session.state == PREPARE_INACTIVE) ||
     E_compare_time(p->timestamp, Prepare_State.Sending_Session.timestamp)==1){
    Create_Prepare_Sending_Session(msg);
    Send_Prepare_Ok(PREPARE_OK_ACCEPT);
    Send_Next_Prepare_Batch();
  }
}

static void Create_Prepare_Sending_Session(sys_scatter *prepare)
{
  header *h;
  prepare_specific *p;
  prepare_session *ps;

  h = (header *)prepare->elements[0].buf;
  p = (prepare_specific *)(h+1);

  ps = &Prepare_State.Sending_Session;

  Alarm(DEBUG, "Creating a Prepare Sending Session\n");
  
  /* Clear out any old state */
  Clear_Prepare_Session(ps);
  
  ps->state      = PREPARE_SENDING;
  ps->view       = h->viewNum;
  ps->timestamp  = p->timestamp;
  ps->leader_aru = p->aru;
  
  ps->last_sent    = 0;
  ps->window_start = Get_First_Accepted(ps->leader_aru);
  
  ps->session_start  = ps->window_start;
  ps->session_target = Get_Highest_Accepted(ps->leader_aru);

  Alarm(DEBUG, "Server %d set up a sending session in view %d from %d to %d, "
	"leader_aru = %d\n", Server_State.id, h->viewNum, 
	ps->session_start, ps->session_target, ps->leader_aru);
}

/* Returns the sequence number of the highest proposal above the leader's
 * ARU, or the ARU if none. */
static uint32_t Get_First_Accepted(uint32_t aru)
{
  uint32_t i;

  for(i = aru+1; i <= aru + 2*WINDOW_SIZE; i++) {
    if(Is_Ordered(i) || (UTIL_Get_Latest_Accepted(i) != NULL))
      return i;
  }
  return aru;
}

static uint32_t Get_Highest_Accepted(uint32_t aru)
{
  uint32_t i;

  for(i = aru + 2*WINDOW_SIZE; i >= aru+1; i--) {
    if(Is_Ordered(i) || (UTIL_Get_Latest_Accepted(i) != NULL))
      return i;
  }
  return aru;
}

void Create_Prepare_Receiving_Session(prepare_session *p, uint32_t id)
{
  /* Clear out any old state */
  Clear_Prepare_Session(p);

  p->state     = PREPARE_REQUESTING;
  p->peer      = id;
  p->view      = View_State.last_installed;
  p->timestamp = E_get_time();

  p->last_sent      = 0;
  p->window_start   = Server_State.aru + 1;
  p->session_start  = Server_State.aru + 1;
  p->session_target = 0;
}

static void Send_Next_Prepare_Batch()
{
  prepare_session *ps;

  ps = (prepare_session *)&Prepare_State.Sending_Session;

  /* If I have nothing to send, just return */
  if(ps->window_start == ps->leader_aru)
    return;

  /* If I can send something, send it */
  if(ps->last_sent < ps->window_start) {
    Alarm(DEBUG, "Server %d sending Proposal for seq %d in view %d\n", 
	  Server_State.id, ps->window_start, ps->view);
    fflush(stdout);
    Send_Prepare_Phase_Message(ps->window_start);
    
    ps->last_sent = ps->window_start;
    fflush(stdout);
  }
}

static void Send_Prepare_Phase_Message(uint32_t seq)
{
  sys_scatter *msg;
  sys_scatter *proposal;
  uint32_t leader;

  /* Find the Proposal: either ordered or a received Proposal  */
  if(Is_Ordered(seq) && (UTIL_Get_Ordered_Update(seq) != NULL))
    proposal = UTIL_Get_Ordered_Update(seq);
  else {
    UTIL_Assert_Latest_Accepted(seq);
    proposal = UTIL_Get_Latest_Accepted(seq);
  }

  /* Wrap the Proposal in a new Prepare_Phase message */
  msg = new_ref_cnt(SYS_SCATTER);
  Construct_Prepare_Phase_Message(msg, proposal);

  /* Send the Proposal off to the leader */
  leader = (View_State.last_installed) % (Params.Num_Servers);
  if(leader == 0)
    leader = Params.Num_Servers;

  Send_UCast(Network_State.sd, msg, leader);

  dec_ref_cnt(msg->elements[0].buf);
  dec_ref_cnt(msg);
}

void Prepare_Phase_Message_Handler(sys_scatter *msg)
{
  header *h, *prop_h;
  prepare_phase_specific *p;
  proposal_specific *prop;
  prepare_session *ps;
  sys_scatter *my_prop;

  h = (header *)msg->elements[0].buf;
  p = (prepare_phase_specific *)(h + 1);

  prop_h = (header *)(p + 1);
  prop = (proposal_specific *)(prop_h + 1);

#ifdef INSTRUMENT
  /* Drop a packet with some probability */
  if((rand() % 2) == 0)
    return;
#endif

  Alarm(DEBUG, "Received a Prepare Phase message from %d for seq %d.\n",
	h->serverID, prop->seq);
  fflush(stdout);

  /* Make sure: correct timestamp, I'm in REG_LEADER, the view is not
   * prepared, I'm acking, it's the one I'm looking for.*/
  if(Server_State.state != REG_LEADER || Prepare_State.view_is_prepared)
    return;

  ps = (prepare_session *)&Prepare_State.Receiving_Sessions[h->serverID];
  if( (E_compare_time(p->timestamp, ps->timestamp) != 0) ||
      (ps->state != PREPARE_ACKING))
    return;

  if(prop->seq != ps->window_start) {
    Alarm(PRINT, "Dropping Prepare phase for seq %d, was expecting %d\n",
	  prop->seq, ps->window_start);
    fflush(stdout);
  }

  /* This is the message I was looking for.  Apply it to my data structures
   * and then send an acknowledgement. */
  if(!Is_Ordered(prop->seq)) {

    /* Make my own copy of the Proposal */
    my_prop = new_ref_cnt(SYS_SCATTER);

    my_prop->num_elements = 1;
    my_prop->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);
    my_prop->elements[0].len = sizeof(header) + prop_h->dataLen;
    memcpy(my_prop->elements[0].buf, (char *)prop_h, my_prop->elements[0].len);

    /* Incs the ref count if it stores it */
    if(Apply_Proposal(my_prop, prop->seq)) {
      Alarm(DEBUG, "Applied the proposal from server %d\n", h->serverID);
    }
    
    dec_ref_cnt(my_prop->elements[0].buf);
    dec_ref_cnt(my_prop);
  }

  /* Signal the fact that I got this one, and try to finish the session. */
  ps->window_start++;
  
  if(ps->window_start > ps->session_target)
    Finish_Prepare_Receiving_Session(h->serverID);
  
  Send_Prepare_Ack(PREPARE_FLOW_TYPE, h->serverID);
}

static void Send_Prepare_Ack(uint32_t type, uint32_t id)
{
  sys_scatter *msg;
  
  msg = new_ref_cnt(SYS_SCATTER);
  Construct_Prepare_Ack_Message(msg, type, id);
  Send_UCast(Network_State.sd, msg, id);

  dec_ref_cnt(msg->elements[0].buf);
  dec_ref_cnt(msg);
}

void Prepare_Ack_Message_Handler(sys_scatter *msg)
{
  header *h;
  prepare_ack_specific *p;
  prepare_session *ps;

  h = (header *)msg->elements[0].buf;
  p = (prepare_ack_specific *)(h+1);

  ps = (prepare_session *)&Prepare_State.Sending_Session;

  /* Make sure I'm expecting this message. */
  if( ps->state != PREPARE_SENDING ||
      E_compare_time(p->timestamp, ps->timestamp) != 0 ||
      h->viewNum != ps->view)
    return;

  if(p->type == PREPARE_FLOW_TYPE) {
    if(p->seq == ps->last_sent) {
      ps->window_start++;
      Send_Next_Prepare_Batch();
    }
  }
  else if(p->type == PREPARE_TIMER_TYPE)
    Send_Prepare_Phase_Message(ps->last_sent);

  /* Try to finish the session cleanly */
  if(ps->window_start > ps->session_target)
    Clear_Prepare_Session(ps);
}

static void Send_Prepare_Ok(uint32_t type)
{
  sys_scatter *msg;
  uint32_t leader;
  
  msg = new_ref_cnt(SYS_SCATTER);
  Construct_Prepare_Ok_Message(msg, type);

  leader = (View_State.last_installed) % (Params.Num_Servers);
  if(leader == 0)
    leader = Params.Num_Servers;

  Send_UCast(Network_State.sd, msg, leader);

  dec_ref_cnt(msg->elements[0].buf);
  dec_ref_cnt(msg);
}

void Prepare_Ok_Message_Handler(sys_scatter *msg)
{
  uint32_t id;
  header *h;
  prepare_session *ps;
  prepare_ok_specific *pok;
  sp_time t;

  h   = (header *)msg->elements[0].buf;
  pok = (prepare_ok_specific *)(h + 1);
  id = h->serverID;
  ps = (prepare_session *)&Prepare_State.Receiving_Sessions[id];

  /* Conflict check */
  if((Server_State.state != REG_LEADER) || 
     (h->viewNum != View_State.last_installed) || 
     (Prepare_State.view_is_prepared) ||
     (Prepare_State.prepare_ok_completed[h->serverID]))
    return;

  /* Ignore if I'm not requesting */
  if(ps->state != PREPARE_REQUESTING)
    return;

  /* I have a session open, but is this response for the right one? */
  if(E_compare_time(pok->timestamp, ps->timestamp) != 0)
    return;

  /* This is what I was looking for: a response to my latest Prepare */
  if(pok->type == PREPARE_OK_ACCEPT) {
    Alarm(DEBUG, "Received a Prepare_OK_Accept from %d, shifting to "
	  "PREPARE_ACKING\n", id);
    ps->state = PREPARE_ACKING;
    E_dequeue(Timer_Dispatcher, PREPARE_RETRANS_TIMER, 
	      &Prepare_State.indices[id]);
    
    ps->leader_aru     = pok->leader_aru;
    ps->session_start  = pok->session_start;
    ps->session_target = pok->session_target;

    /* If there are no proposals coming, finish the session immediately */
    if(ps->session_target == ps->leader_aru) {
      Finish_Prepare_Receiving_Session(id);
      Send_Prepare_Ack(PREPARE_FLOW_TYPE, h->serverID);
      return;
    }

    /* Set the Prepare_Ack timer */
    Alarm(DEBUG, "Setting the Prepare_Ack_Timer for id %d\n", id);
    t.sec  = PREPARE_ACK_TIMER_SEC;
    t.usec = PREPARE_ACK_TIMER_USEC;
    E_queue(Timer_Dispatcher, PREPARE_ACK_TIMER, 
	    &Prepare_State.indices[id], t);
  }

  if(pok->type == PREPARE_OK_REJECT) {
    Alarm(DEBUG, "Received a Prepare_OK reject from %d\n", id);
    if(Server_State.aru < pok->session_target) {
      if(Reconc_State.Receiving_Session.state == RECONC_INACTIVE)
	Reconcile_to_Seq(pok->session_target, id);
      else {
	anti_entropy_obj *pr;

	Alarm(PRINT, "Added a Prepare_Rejected obj for server %d, target %d\n",
	      id, pok->session_target);
	pr = new_ref_cnt(ANTI_ENTROPY_OBJ);
	pr->serverID = id;
	pr->target   = pok->session_target;
	stddll_push_back(&Prepare_State.rejected_queue, &pr);
      }
    }
  }
}

static void Finish_Prepare_Receiving_Session(uint32_t id)
{
  int i;

  assert(Prepare_State.prepare_ok_completed[id] == 0);
  Prepare_State.prepare_ok_completed[id] = 1;
  Prepare_State.num_completed++;
  Clear_Prepare_Session(&Prepare_State.Receiving_Sessions[id]);
  Alarm(PRINT, "Finished Prepare receiving session for %d\n", id);
  fflush(stdout);

  if(Prepare_State.num_completed == Params.Majority) {
    Finish_Prepare_Phase();

    Prepare_State.view_is_prepared = 1;

    /* Cancel all timeouts associated with Prepare phase */
    for(i = 1; i <= MAX_SERVERS; i++) {
      Clear_Prepare_Session(&Prepare_State.Receiving_Sessions[i]);
      E_dequeue(Timer_Dispatcher, PREPARE_RETRANS_TIMER, 
		&Prepare_State.indices[i]);
    }
    Clear_Prepare_Session(&Prepare_State.Sending_Session);
    Send_Some_Proposals();
  }
}

static void Finish_Prepare_Phase()
{
  int i;
  uint32_t max_accepted;

  Alarm(PRINT, "Finished prepare phase.\n");
  fflush(stdout);
  Prepare_State.view_is_prepared = 1;

  /* Cancel all timeouts associated with Prepare phase */
  for(i = 1; i <= MAX_SERVERS; i++) {
    Clear_Prepare_Session(&Prepare_State.Receiving_Sessions[i]);
    E_dequeue(Timer_Dispatcher, PREPARE_RETRANS_TIMER, 
	      &Prepare_State.indices[i]);
  }
  Clear_Prepare_Session(&Prepare_State.Sending_Session);
  
  /* Fill in any holes with nops, which will be dummy constraints. */
  max_accepted = Get_Highest_Accepted(Server_State.aru);
  for(i = Server_State.aru+1; i <= max_accepted; i++) {
    if((!Is_Ordered(i)) && (UTIL_Get_Latest_Accepted(i) == NULL))
      Apply_Nop_to_Hole(i);
  }

  /* Enqueue any of my updates that I was previously forwarding that are also 
   * not currently bound to a sequence number.*/
  Enqueue_Unbound_Forwarded_Updates();

  /* Remove any update from the queue that is bound to a sequence number. */
  Remove_Bound_Updates_From_Queue();
  
  /* Go! */
  Send_Some_Proposals();
}

static void Apply_Nop_to_Hole(uint32_t seq)
{
  sys_scatter *nop;
  sys_scatter *update;
  update_header *uh;
  char *update_body;
  int i;

  Alarm(PRINT, "Applied a nop to seq %d\n", seq);
  fflush(stdout);

  /* First build an update */
  update = new_ref_cnt(SYS_SCATTER);
  update->num_elements = 1;

  update->elements[0].buf = new_ref_cnt(PACK_BODY_OBJ);
  update->elements[0].len = sizeof(update_header) + UPDATE_SIZE;

  uh = (update_header *)update->elements[0].buf;
  uh->packetType = UPDATE;
  uh->clientID   = 0; /* Not a real client */
  uh->serverID   = Server_State.id;
  uh->timestamp  = 0; /* Not a real timestamp */
  uh->dataLen    = UPDATE_SIZE;

  update_body = (char *)(uh+1);
  for(i = 0; i < UPDATE_SIZE; i++)
    update_body[i] = 'B';

  /* Now use the update to construct a Proposal */
  nop = new_ref_cnt(SYS_SCATTER);
  Construct_Proposal_Message(nop, seq, update);

  dec_ref_cnt(update->elements[0].buf);
  dec_ref_cnt(update);

  i = Apply_Proposal(nop, seq);
  if(i == 1) {
    Alarm(PRINT, "Applied the nop for seq %d\n", seq);
    fflush(stdout);
  }
  else {
    Alarm(PRINT, "Did not apply the nop for seq %d\n", seq);
    fflush(stdout);
  }
  dec_ref_cnt(nop->elements[0].buf);
  dec_ref_cnt(nop);
}

uint32_t Is_Bound(sys_scatter *update)
{
  int i, j;
  uint32_t max_accepted;
  sys_scatter *proposal;
  header *h;
  update_header *old_uh;
  update_header *this_uh;
  proposal_specific *ps;
  char *p;

  max_accepted = Get_Highest_Accepted(Server_State.aru);
  for(i = Server_State.aru+1; i <= max_accepted; i++) {
    if(Is_Ordered(i))
      proposal = UTIL_Get_Ordered_Update(i);
    else if(UTIL_Get_Latest_Accepted(i) != NULL)
      proposal = UTIL_Get_Latest_Accepted(i);
    else
      continue;

    h      = (header *)proposal->elements[0].buf;
    ps     = (proposal_specific *)(h+1);
    p      = (char *)(ps+1);

    this_uh = (update_header *)update->elements[0].buf;

    for(j = 0; j < ps->num_updates; j++) {
      old_uh = (update_header *)(p);

      /* Compare this update to the old one */
      if(old_uh->clientID  == this_uh->clientID &&
	 old_uh->timestamp == this_uh->timestamp) {
	Alarm(PRINT, "Client %d TS %d is bound.\n", 
	      old_uh->clientID, old_uh->timestamp);
	fflush(stdout);
	return 1;
      }
      else
	p += sizeof(update_header) + old_uh->dataLen;
    }
  }
  
  return 0;
}

void Prepare_Retrans_Timer_Handler(int id)
{
  sp_time t;
  sys_scatter *msg;

  assert(Server_State.state == REG_LEADER);

  /* We haven't switched to acking yet for this peer.  Make a new session
   * and try again. */
  Create_Prepare_Receiving_Session(&Prepare_State.Receiving_Sessions[id], id);

  msg = new_ref_cnt(SYS_SCATTER);
  Construct_Prepare_Message(msg, id);
  
  Send_UCast(Network_State.sd, msg, id);
  dec_ref_cnt(msg->elements[0].buf);
  dec_ref_cnt(msg);

  t.sec  = PREPARE_RETRANS_SEC;
  t.usec = PREPARE_RETRANS_USEC;
  E_queue(Timer_Dispatcher, PREPARE_RETRANS_TIMER, 
	  &Prepare_State.indices[id], t);
}

void Prepare_Ack_Timer_Handler(int id)
{
  sp_time t;

  assert(Server_State.state == REG_LEADER);

  Send_Prepare_Ack(PREPARE_TIMER_TYPE, id);

  t.sec  = PREPARE_ACK_TIMER_SEC;
  t.usec = PREPARE_ACK_TIMER_USEC;
  E_queue(Timer_Dispatcher, PREPARE_ACK_TIMER, &Prepare_State.indices[id], t);
}

void Clear_Prepare_Session(prepare_session *p)
{
  p->state = PREPARE_INACTIVE;
  p->view  = 0;
  
  p->last_sent      = 0;
  p->window_start   = 0;
  p->session_start  = 0;
  p->session_target = 0;

  /* Clear the Prepare ack timer */
  E_dequeue(Timer_Dispatcher, PREPARE_ACK_TIMER, 
	    &Prepare_State.indices[p->peer]);
  p->peer = 0;
}

void Process_Next_Prepare_Ok_Rejected()
{
  stdit it;
  anti_entropy_obj *pr;

  assert(!stddll_empty(&Prepare_State.rejected_queue));
  assert(Server_State.state == REG_LEADER && !Prepare_State.view_is_prepared);

  while(1) {
    stddll_begin(&Prepare_State.rejected_queue, &it);
    if(stddll_is_end(&Prepare_State.rejected_queue, &it))
      break;

    pr = *(anti_entropy_obj **)stddll_it_val(&it);
    
    if(Server_State.aru < pr->target) {
      Reconcile_to_Seq(pr->target, pr->serverID);
      dec_ref_cnt(pr);
      stddll_pop_front(&Prepare_State.rejected_queue);
      break;
    }

    dec_ref_cnt(pr);
    stddll_pop_front(&Prepare_State.rejected_queue);
  }
}

void Clear_Prepare_Ok_Rejected()
{
  stdit it;
  anti_entropy_obj *pr;

  while(1) {
    stddll_begin(&Prepare_State.rejected_queue, &it);
    if(stddll_is_end(&Prepare_State.rejected_queue, &it))
      break;

    pr = *(anti_entropy_obj **)stddll_it_val(&it);
    
    dec_ref_cnt(pr);
    stddll_pop_front(&Prepare_State.rejected_queue);
  }
  assert(stddll_empty(&Prepare_State.rejected_queue));
}
