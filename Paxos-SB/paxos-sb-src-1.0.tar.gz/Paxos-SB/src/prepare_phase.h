/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#ifndef PFSB_PREPARE_PHASE_H
#define PFSB_PREPARE_PHASE_H

#include "util_include.h"

/* A non-leader sends a Prepare_OK_Accept when the leader knows at
 * least as much as the server does.  It sends a reject if the leader
 * knows less or if the aru contained in the Prepare has already been
 * garbage collected. */
enum prepare_ok_types {PREPARE_OK_ACCEPT, PREPARE_OK_REJECT};

/* The leader is REQUESTING on a session when it sent a Prepare to
 * that server but hasn't received a response.  The leader is ACKING
 * when the response is received and they participate in the send and
 * wait protocol.  A non-leader is SENDING when it has sent a response
 * and is trying to send its messages to the leader.  Otherwise a
 * server is INACTIVE. */
enum prepare_session_states {PREPARE_INACTIVE, PREPARE_SENDING, 
			     PREPARE_REQUESTING, PREPARE_ACKING};

/* Acks are either triggered in the normal flow of messages, or in
 * response to a timer event. */
enum prepare_ack_types {PREPARE_FLOW_TYPE, PREPARE_TIMER_TYPE};

typedef struct dummy_prepare_session {
  uint32_t state;
  uint32_t peer;
  uint32_t view;
  sp_time  timestamp;
  uint32_t leader_aru;

  uint32_t last_sent;    /* Sequence number of last packet I sent */
  uint32_t window_start;

  uint32_t session_start;
  uint32_t session_target;

} prepare_session;

/* Message Handlers */
void Prepare_Message_Handler      (sys_scatter *msg);
void Prepare_Ok_Message_Handler   (sys_scatter *msg);
void Prepare_Phase_Message_Handler(sys_scatter *msg);
void Prepare_Ack_Message_Handler  (sys_scatter *msg);

/* Timer Handlers */
void Prepare_Retrans_Timer_Handler(int id);
void Prepare_Ack_Timer_Handler    (int id);

/* Functions to manage session state. */
void Clear_Prepare_Session           (prepare_session *p);
void Create_Prepare_Receiving_Session(prepare_session *p, uint32_t id);

/* Returns 1 if the update is already bound to a sequence number, 0
 * otherwise */
uint32_t Is_Bound(sys_scatter *update);

/* Prepare_OK_Rejects imply that the leader should try to bring itself
 * up to date with other servers via reconciliation.  The rejects are
 * stored in a queue so that when one reconciliation is finished, the
 * leader can go to the next one. */
void Process_Next_Prepare_Ok_Rejected(void);
void Clear_Prepare_Ok_Rejected       (void);
#endif
