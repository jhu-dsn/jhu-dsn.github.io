/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#ifndef PFSB_LEADER_ELECTION_H
#define PFSB_LEADER_ELECTION_H

#include "util_include.h"

/* Message handlers */
void VC_Message_Handler      (sys_scatter *msg);
void VC_Proof_Message_Handler(sys_scatter *msg);

/* Apply the VC message to data structures. */
void Apply_VC_Message(sys_scatter *msg);

/* Clear out view-related variables. */
void Initialize_View_State(uint32_t viewNum);

/* Schedule and handle the next sending of the VC_PROOF message. */
void Schedule_VC_Proof_Event(void);
void VC_Proof_Timer_Handler  (void);

/* Procedures to manage the Progress timer */                      
void Refresh_Progress_Timer(void);
void Cancel_Progress_Timer (void);
void Progress_Timer_Handler(void);
#endif
