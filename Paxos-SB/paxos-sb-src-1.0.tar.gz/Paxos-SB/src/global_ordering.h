/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#ifndef PFSB_GLOBAL_ORDERING_H
#define PFSB_GLOBAL_ORDERING_H

#include "util_include.h"

/* Send the Proposal */
void Send_Some_Proposals(void);

/* Process the Proposal and Respond */
void Proposal_Message_Handler(sys_scatter *msg);
int  Apply_Proposal          (sys_scatter *proposal, uint32_t seq);

/* Process the Accept */
void Accept_Message_Handler  (sys_scatter *msg);
void Apply_Accept            (sys_scatter *accept);

/* Order the Update */
void Attempt_to_Order(uint32_t seq);
void Upon_Ordering(int seq);

/* Useful predicate */
int Is_Ordered (uint32_t seq);

#endif
