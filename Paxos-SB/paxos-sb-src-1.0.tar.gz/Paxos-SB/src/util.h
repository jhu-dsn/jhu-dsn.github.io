/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#ifndef PFSB_UTIL_H
#define PFSB_UTIL_H

#include "p_server.h"

sys_scatter *UTIL_Get_Ordered_Update (uint32_t seq);
sys_scatter *UTIL_Get_Latest_Accepted(uint32_t seq);
accept_node *UTIL_Get_Stats          (uint32_t seq);

void UTIL_Remove_Latest_Accepted(uint32_t seq);
void UTIL_Remove_Ordered_Update (uint32_t seq);
void UTIL_Remove_Stats          (uint32_t seq);

void UTIL_Insert_Latest_Accepted(uint32_t seq, sys_scatter *msg);
void UTIL_Insert_Ordered_Update (uint32_t seq, sys_scatter *msg);
void UTIL_Insert_Stats          (uint32_t seq, accept_node *a);

void UTIL_Assert_Latest_Accepted(uint32_t seq);
void UTIL_Assert_Ordered_Update (uint32_t seq);
void UTIL_Assert_Stats          (uint32_t seq);
#endif
