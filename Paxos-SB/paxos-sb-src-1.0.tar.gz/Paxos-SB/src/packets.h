/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#ifndef PFSB_PACKETS_H
#define PFSB_PACKETS_H

#include "util_include.h"

enum packetTypes {PREPARE, PREPARE_OK, PROPOSAL, ACCEPT, RECONC_ACK, 
		  PREPARE_ACK, ORDER, VC, VC_PROOF, UPDATE, REQUEST, 
		  ALIVE, REPLY, RECONC_RESPONSE, PREPARE_PHASE};

/* Generic header used for many packet types */
typedef struct dummy_header {
  uint32_t    packetType;  /*Type of the message*/
  uint32_t    serverID;    /*Identifier of the sender*/
  uint32_t    viewNum;     /*View number associated with message*/
  uint32_t    dataLen;     /*Length of the data field*/
} header;

/* Prepare */
typedef struct dummy_prepare_specific {
  uint32_t aru;
  sp_time  timestamp;
} prepare_specific;

/* Prepare_OK */
typedef struct dummy_prepare_ok_specific {
  uint32_t type;            /* ACCEPT or REJECT */
  uint32_t session_start;   /* Lowest seq of Proposal being sent in session  */
  uint32_t session_target;  /* Highest seq of Proposal being sent in session */
  sp_time  timestamp;
  uint32_t leader_aru;

} prepare_ok_specific;

/* Prepare_Phase messages wrap the Proposals that are included in the
 * datalist so that the leader knows to handle them as part of the
 * Prepare phase. */
typedef struct dummy_prepare_phase_specific {
  sp_time timestamp;
  /* The Proposal follows */
} prepare_phase_specific;

/* Prepare_Ack */
typedef struct dummy_prepare_ack {
  uint32_t type; /* Flow or timer */
  sp_time  timestamp;
  uint32_t seq; /* Last seq I've ordered from you */
} prepare_ack_specific;

/* Update Header */
typedef struct dummy_update_header {
  uint32_t packetType;
  uint32_t clientID;
  uint32_t serverID;
  uint32_t timestamp;
  uint32_t dataLen;

  /* The update follows */
} update_header;

/* Proposal */
typedef struct dummy_proposal_specific {
  uint32_t seq;
  uint32_t num_updates; /* Number of updates packed into this Proposal */
  /* The update follows */
} proposal_specific;

/* Accept */
typedef struct dummy_accept_specific {
  uint32_t seq;
} accept_specific;

/* Order (a globally ordered update) */
typedef struct dummy_order_specific {
  uint32_t seq;
  /* The ordered update follows */
} order_specific;

/* Reply (to the client) */
typedef struct dummy_reply {
  uint32_t serverID;
  uint32_t clientID;
  uint32_t timestamp;
  uint32_t seq;
} reply_specific;

/* Alive */
typedef struct dummy_alive_header {
  uint32_t packetType;
  uint32_t serverID;
  uint32_t local_aru;
  uint32_t dataLen;
} alive_header;

/* Reconciliation request */
typedef struct dummy_reconc_request_specific {
  uint32_t session_start;
  uint32_t session_target;
  sp_time  timestamp;

} reconc_request_specific;

/* Reconciliation response */
typedef struct dummy_reconc_response_specific {
  uint32_t type; /* ACCEPT, REJECT */
  sp_time  timestamp;
} reconc_response_specific;

/* Reconciliation Acknowledgement */
typedef struct dummy_reconc_ack_specific {
  uint32_t type; /* FLOW, TIMER */
  sp_time  timestamp;
  uint32_t aru;
  uint32_t num_nacks; /* Number of nacks contained in following nacklist */
  /* The nackList follows, if any */
} reconc_ack_specific;

/* Packet constructor functions */
void Construct_Alive_Message     (sys_scatter *msg);
void Construct_VC_Message        (sys_scatter *msg);
void Construct_VC_Proof_Message  (sys_scatter *msg);
void Construct_Prepare_Message   (sys_scatter *msg, uint32_t id);
void Construct_Prepare_Ok_Message(sys_scatter *msg, uint32_t type);
void Construct_Proposal_Message  (sys_scatter *msg,  uint32_t seq, 
				  sys_scatter *update);

void Construct_Aggregated_Proposal_Message(sys_scatter *msg, uint32_t seq);

void Construct_Accept_Message    (sys_scatter *msg, uint32_t seq);

void Construct_Reconc_Request_Message (sys_scatter *msg);
void Construct_Reconc_Response_Message(sys_scatter *msg, int type, 
				       sp_time timetstamp);
void Construct_Reconc_Ack_Message     (sys_scatter *msg, int type);

void Construct_Prepare_Phase_Message(sys_scatter *msg, sys_scatter *proposal);
void Construct_Prepare_Ack_Message  (sys_scatter *msg, uint32_t type, 
				     uint32_t id);

void Construct_Client_Reply_Message(sys_scatter *msg, uint32_t client_id,
				    uint32_t timestamp, uint32_t seq);

/* Function to print packets */
void Print_Packet(sys_scatter *msg);

#endif

