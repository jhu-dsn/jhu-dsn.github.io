/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#include <assert.h>
#include <stdlib.h>
#include <unistd.h>
#include "membership.h"
#include "packets.h"
#include "p_server.h"
#include "paxos_protocol.h"
#include "global_ordering.h"
#include "disk.h"

extern Parameter_struct Params;
extern Alive_struct     Alive_State;
extern Server_struct    Server_State;
extern Prepare_struct   Prepare_State;
extern Network_struct   Network_State;
extern Reconc_struct    Reconc_State;
extern Disk_struct      Disk_State;
extern VC_struct        View_State;

void Alive_Message_Handler(sys_scatter *msg)
{
  alive_header *h;
  sp_time t;
  uint32_t new_white_line;
  uint32_t view;

  Alarm(DEBUG, "White line: %d\n", Server_State.white_line);

  h = (alive_header *)msg->elements[0].buf;
  view = h->dataLen;

  /* Ignore my own alive message */
  if(h->serverID == Server_State.id)
    return;

  /* If this server is not in my list, add him and update count */
  if(Alive_State.is_alive[h->serverID] == 0) {
    Alive_State.is_alive[h->serverID] = 1;
    Alive_State.num_alive++;
  }

  t.sec  = MEMBERSHIP_TIMER_SEC;
  t.usec = MEMBERSHIP_TIMER_USEC;

  /* Reset the timeout for this server */
  E_queue(Timer_Dispatcher, MEMBERSHIP_TIMER, 
	  &Alive_State.members[h->serverID], t);

  /* Reconciliation: "anti-entropy."  If this server has a higher ARU than
   * I do, then wait a little bit to see if I catch up.  If not, set up 
   * a session with him. */
  if(h->local_aru > Server_State.aru) {
    t.sec  = ANTI_ENTROPY_TIMER_SEC;
    t.usec = ANTI_ENTROPY_TIMER_USEC;
    E_queue(Timer_Dispatcher, ANTI_ENTROPY_TIMER, 
	    &Alive_State.members[h->serverID], t);
  }

  /* Flow control: Process this server's local_aru information */
  if(Server_State.views[h->serverID] <= view) {
    Server_State.views[h->serverID] = view;
    if(Server_State.arus[h->serverID] < h->local_aru)
      Server_State.arus[h->serverID] = h->local_aru;
  }
  
  Server_State.global_aru = Compute_Global_Aru_of_Alive_in_View();

  /* Garbage collection */
  if(Server_State.stable_arus[h->serverID] < h->local_aru)
    Server_State.stable_arus[h->serverID] = h->local_aru;

  new_white_line = Compute_White_Line();
  Alarm(DEBUG, "Computed new white line to %d\n", new_white_line);
  fflush(stdout);
  if(new_white_line > Server_State.white_line) {
    /* Don't garbage collect if I have a sending session open */
    if(!Is_Session_Open()) {
#ifdef WRITE_TO_DISK
      Write_White_Line_to_Disk(&new_white_line);
#endif
      Garbage_Collect(new_white_line);
      Server_State.white_line = new_white_line;
    }
  }
  
  if((Server_State.state == REG_LEADER) && (Prepare_State.view_is_prepared))
    Send_Some_Proposals();
}

void Alive_Timer_Handler(void)
{
  sys_scatter *msg;

  msg = new_ref_cnt(SYS_SCATTER);
  Construct_Alive_Message(msg);

  /* Garbage collection: sync to disk so that you really have what your aru
   * reports. */
#ifdef WRITE_TO_DISK
  if(Disk_State.sync_flag) {
    fsync(Disk_State.log_fd);
  }
#endif

  /* Make sure my view is updated */
  Server_State.views[Server_State.id] = View_State.last_attempted;
  
  /* Send out an alive messsage to everyone */
  Send_MCast(msg);
  dec_ref_cnt(msg->elements[0].buf);
  dec_ref_cnt(msg);

  /* Reschedule the alive event */
  Schedule_Alive_Event();
}

void Membership_Timer_Handler(int index)
{
  int target;

  /* This server is now believed dead */
  Alarm(PRINT, "Diagnosed server %d as dead.\n", index);
  Alive_State.is_alive[index] = 0;
  Alive_State.num_alive--;

  /* JK set this for benchmarking: when everyone detects the leader
   * has crashed, have them shut down, too. */
  if(index == 1) {
    ;/*exit(0);*/
  }

  /* Reconciliation: If I had a receiving session open with this peer, 
   * close it and start a new one with a random peer. */
  if(Reconc_State.Receiving_Session.peer == index) {
    target = Reconc_State.Receiving_Session.session_target;
    Clear_Reconc_Session_State(&Reconc_State.Receiving_Session);

    Reconc_State.num_consecutive_failures++;
    if(Reconc_State.num_consecutive_failures < RECONC_FAILURE_THRESHOLD) {
      if(Server_State.aru < target)
	Create_Reconc_Receiving_Session(target, RECONC_RANDOM_PEER);
    }
  }
  
  /* Reset this server's flow control information.  Let him tell you what
   * he has on recovery instead of assuming he still has what he used to. */
  Server_State.arus[index] = 0;
  Server_State.global_aru = Compute_Global_Aru_of_Alive_in_View();

  if(Server_State.state == REG_LEADER && Prepare_State.view_is_prepared)
    Send_Some_Proposals();
}

void Schedule_Alive_Event()
{
  sp_time t;

  t.sec  = ALIVE_TIMER_SEC;
  t.usec = ALIVE_TIMER_USEC + (rand() % 5000);

  E_queue(Timer_Dispatcher, ALIVE_TIMER, NULL, t);
}

uint32_t Compute_Global_Aru_of_Alive_in_View()
{
  int i;
  int min = 0;
  
  for(i = 1; i <= Params.Num_Servers; i++) {
    if(Alive_State.is_alive[i] && 
       Server_State.views[i] == View_State.last_installed) {
      if(min == 0)
	min = Server_State.arus[i];
      else if(Server_State.arus[i] < min)
	min = Server_State.arus[i];
    }
  }
  
  if(Server_State.state == REG_LEADER)
    Alarm(DEBUG, "Global Aru = %d\n", min);
  return min;
}

void Process_Next_Anti_Entropy()
{
  stdit it;
  anti_entropy_obj *a;

  assert(!stddll_empty(&Alive_State.anti_entropy_queue));
  
  while(1) {
    stddll_begin(&Alive_State.anti_entropy_queue, &it);
    if(stddll_is_end(&Alive_State.anti_entropy_queue, &it))
      break;

    a = *(anti_entropy_obj **)stddll_it_val(&it);
    
    if(Server_State.aru < a->target) {
      Reconcile_to_Seq(a->target, a->serverID);
      dec_ref_cnt(a);
      stddll_pop_front(&Alive_State.anti_entropy_queue);
      break;
    }

    dec_ref_cnt(a);
    stddll_pop_front(&Alive_State.anti_entropy_queue);
  }
}
