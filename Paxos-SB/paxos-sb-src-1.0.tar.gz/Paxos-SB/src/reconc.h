/* 
 * Paxos for System Builders.
 *     
 * The contents of this file are subject to the Paxos for System Builders 
 * Open-Source License, Version 1.0 (the "License"); you may not use
 * this file except in compliance with the License.  You may obtain a
 * copy of the License at:
 *
 * http://dsn.jhu.edu/Paxos-SB/LICENSE.txt
 *
 * or in the file "LICENSE.txt" found in this distribution.
 *
 * Software distributed under the License is distributed on an AS IS basis, 
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 * for the specific language governing rights and limitations under the 
 * License.
 *
 * The Creators of Paxos for System Builders are:
 *  Yair Amir and Jonathan Kirsch
 *
 * Special thanks to John Lane and John Schultz for their helpful 
 * discussions about Paxos for System Builders.
 *
 * Copyright (C) 2008-2012 The Johns Hopkins University
 * All Rights Reserved.
 *
 */

#ifndef PFSB_RECONC_H
#define PFSB_RECONC_H

#include "util_include.h"
#include "def.h"

/* States for a reconciliation session (defined below).  
 * 1. INACTIVE means that the server is not currently participating in that 
 *    session.  
 * 2. SENDING means the server responded to a request and is sending messages 
 *    to the receiving server.  
 * 3. REQUESTING means the server is trying to find a server that will send
 *    it missing messages.
 * 4. ACKING means the receiving server has found a sender and is participating
 *    in the selective repeat protocol by sending acks.
 */
enum reconc_states {RECONC_INACTIVE, RECONC_SENDING, 
		    RECONC_REQUESTING, RECONC_ACKING};

/* The potential sender can either accept or reject the reconciliation
 * request */
enum reconc_response_types {RECONC_ACCEPT, RECONC_REJECT};

/* Acks are either generated in the normal flow of messages or when a timer
 * expires.  The sender uses this to determine whether it can open the 
 * window or whether it needs to resend the last packet. */
enum reconc_ack_types {FLOW_TYPE, TIMER_TYPE};

#define RECONC_RANDOM_PEER       0
#define RECONC_FAILURE_THRESHOLD 20

typedef struct dummy_reconc_session {
  uint32_t state;     /* One of INACTIVE, SENDING, REQUESTING, ACKING    */
  uint32_t peer;      /* ID of the server with which you are reconciling */
  sp_time timestamp;  /* Timestamp associated with this session          */

  uint32_t session_start;  /* Starting Paxos seq for this session */
  uint32_t session_target; /* Ending   Paxos seq for this session */
  
  uint32_t window_start;
  uint32_t window_end;
  uint32_t batch_count; /* Number I've ordered before acking */
  uint32_t last_sent;

  sp_time last_nack_sent; /* When was the last nack sent? */
  uint32_t nack_flag; /* Used to signal that a nacklist should be computed */
  uint32_t nack_buildup; /* Number of packets that would have caused a nack */

} reconc_session;

/* Message handlers for reconciliation selective repeat protocol. */
void Reconc_Request_Message_Handler (sys_scatter *msg);
void Reconc_Response_Message_Handler(sys_scatter *msg);
void Order_Message_Handler          (sys_scatter *msg);
void Reconc_Ack_Message_Handler     (sys_scatter *msg);

/* Timer handlers for reconciliation selective repeat protocol. */
void Reconc_Response_Timer_Handler    (void);
void Reconc_Ack_Timer_Handler         (void);
void Reconc_Anti_Entropy_Timer_Handler(uint32_t id);

/* Functions for managing session state. */
void Clear_Reconc_Session_State     (reconc_session *s);
void Create_Reconc_Receiving_Session(uint32_t target, uint32_t peer);
void Update_Reconc_Receiver_Window  (int num_advanced, uint32_t seq);

uint32_t Compute_NackList       (uint32_t *nacklist);

/* Called to start reconciliation.  The requester tries to reconcile
 * up to sequence number seq.  Peer refers to either a specific peer
 * with which the requester would like to reconcile, or
 * RECONC_RANDOM_PEER if a random peer is to be selected. Note the
 * early returns, which allow you to call the function even when no
 * reconciliation should occur. */
void Reconcile_to_Seq(uint32_t seq, uint32_t peer);

#endif




