#include "bt_common.h"

bt_svc_node* findNode(bdaddr_t* addr, char* name, int len, bt_svc_list* list)
{
    if(list == NULL)
        return NULL;

    bt_svc_node* tmp;
    for(tmp = list->head; tmp != NULL; tmp = tmp->next)
    {
        if((bacmp(addr, &(tmp->svc->bt_addr)) == 0) && 
           (strncmp(name, tmp->svc->svc_name, len) == 0) &&
           (len == tmp->svc->name_len))
	    return tmp;
    }

    return NULL;
}

int hasService(bdaddr_t* addr, char* name, int len, bt_svc_list* list)
{
    if(findNode(addr, name, len, list) == NULL)
        return 0;
    else
        return 1;
}

bt_svc* getService(bdaddr_t* addr, char* name, int len, bt_svc_list* list)
{
    bt_svc_node* tmp = findNode(addr, name, len, list);
    if(tmp == NULL)
        return NULL;
    else
        return tmp->svc;
}

bt_svc* addService(bdaddr_t* addr, char* name, int len, 
                   uint32_t handle, bt_svc_list* list)
{
    if(list == NULL)
        return NULL;

    if(list->head == NULL)
    {
        list->head = (bt_svc_node*) malloc(sizeof(bt_svc_node));
        list->head->prev = NULL;
        list->tail = list->head;
    }
    else
    {
        list->tail->next = (bt_svc_node*) malloc(sizeof(bt_svc_node));
        list->tail->next->prev = list->tail;
        list->tail = list->tail->next;
    }

    list->tail->next = NULL;
    list->tail->svc = (bt_svc*) malloc(sizeof(bt_svc));

    memcpy(&(list->tail->svc->bt_addr), addr, sizeof(bdaddr_t));

    list->tail->svc->svc_name = (char*) malloc(len*sizeof(char));
    memcpy(list->tail->svc->svc_name, name, len);
    list->tail->svc->name_len = len;

    list->tail->svc->local_handle = handle;
    return list->tail->svc;
}

void removeService(bdaddr_t* addr, char* name, int len, bt_svc_list* list)
{
    if(list == NULL)
        return;

    bt_svc_node* tmp = findNode(addr, name, len, list);
    deleteNode(tmp, list);
}

void moveService(bdaddr_t* addr, char* name, int len, bt_svc_list* from, bt_svc_list* to)
{
    bt_svc_node* node = findNode(addr, name, len, from);
 
    if(node != NULL && to != NULL)
    {
  	if(node->next != NULL)
	    node->next->prev = node->prev;
        if(node->prev != NULL)
            node->prev->next = node->next;

        if(node == from->head)
            from->head = node->next;
        if(node == from->tail)
            from->tail = node->prev;

        to->tail->next = node;
        node->prev = to->tail;
        to->tail = node->prev;
    }
}

void deleteNode(bt_svc_node* node, bt_svc_list* list)
{
    if(node != NULL && list != NULL)
    {
        if(node->next != NULL)
	    node->next->prev = node->prev;
        if(node->prev != NULL)
            node->prev->next = node->next;

        if(node == list->head)
            list->head = node->next;
        if(node == list->tail)
            list->tail = node->prev;

        free(node->svc->svc_name);
        free(node->svc);
        free(node);
    }
}

void deleteList(bt_svc_list* list)
{
    if(list == NULL)
        return;

    bt_svc_node* tmp = list->head;
    while(tmp != NULL)
    {
        deleteNode(tmp, list);
        tmp = list->head;
    }
}

