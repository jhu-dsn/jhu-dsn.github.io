#include "bt_common.h"

//rcv thread function
void* svc_receive_thread(void* param);

//gateway bt server function
void* gw_bt_server(void* arg);

void refresh_local_services(int client, bt_svc_list** curr_list);
void search_for_services(bdaddr_t* target, int client, bt_svc_list* curr_list, bt_svc_list* new_list);
void send_record(int client, sdp_buf_t* buffer, int comm_port);
void send_device(int client, bdaddr_t* addr, char* name, int len);

const int SVC_SCAN_INTERVAL = 5;

int main(char** argc, int argv)
{
    struct sockaddr_in addr;
    int address =  (128 << 24) | (220 << 16) | (221 << 8) | 99;
    int client, err;

    fd_set timer;
    struct timeval timeout;
    
    pthread_t rcv_thread;
    err = pthread_create(&rcv_thread, NULL, svc_receive_thread, NULL);
    
    addr.sin_addr.s_addr = htonl(address);
    addr.sin_family = AF_INET;
    addr.sin_port = htons(50000);

    client = socket(AF_INET, SOCK_STREAM, 0);

    bt_svc_list* curr_list = NULL;

  //  while(1)
  //  {
 	FD_ZERO(&timer);
	timeout.tv_sec = SVC_SCAN_INTERVAL;
        timeout.tv_usec = 0;
	
	err = select(0, &timer, (fd_set*) 0, (fd_set*)0, &timeout);
        if(err != 0)
            return 0; //continue;
         
        printf("Connecting...\n");
    	if(connect(client, (struct sockaddr*)&addr, sizeof(addr)))
	{
        	printf("Error connecting to client\n");
        	return 0;  //continue;
 	}
    	else
    	{
        	printf("Connected to client!\n");
        	refresh_local_services(client, &curr_list);
    	}
    	close(client);
    //}
    while(1);
    return 0;
}

void refresh_local_services(int client, bt_svc_list** curr_list)
{
    inquiry_info *ii = NULL;
    int max_rsp, num_rsp;
    int dev_id, sock, len, flags;
    int i;
    char addr[19] = { 0 };
    char name[248] = { 0 };

    bt_svc_list* new_list = (bt_svc_list*) malloc(sizeof(bt_svc_list));

    dev_id = hci_get_route(NULL);
    sock = hci_open_dev( dev_id );
    if (dev_id < 0 || sock < 0) {
        perror("opening socket");
        exit(1);
    }

    len  = 8;
    max_rsp = 255;
    flags = IREQ_CACHE_FLUSH;
    ii = (inquiry_info*)malloc(max_rsp * sizeof(inquiry_info));
    
    num_rsp = hci_inquiry(dev_id, len, max_rsp, NULL, &ii, flags);
    if( num_rsp < 0 ) perror("hci_inquiry");

    for (i = 0; i < num_rsp; i++) {
        ba2str(&(ii+i)->bdaddr, addr);
        memset(name, 0, sizeof(name));
        if ((len = hci_read_remote_name(sock, &(ii+i)->bdaddr, sizeof(name), 
            name, 0)) < 0)
        {
            strcpy(name, "[unknown]");
            len = 9;
        }
        else
            len = strlen(name);

        if(strncmp(name, "BlueZ linux-fbe7 (0)", 20) != 0)
            continue;

        printf("Found device: %s  %s\n Searching for services...\n", addr, name);
        send_device(client, &(ii+i)->bdaddr, name, len);
        search_for_services(&(ii+i)->bdaddr, client, *curr_list, new_list);
    }

    if(*curr_list != NULL)
    {
        bt_svc_node* tmp;
        for(tmp = (*curr_list)->head; tmp != NULL; tmp = tmp->next)
	    pthread_cancel(tmp->svc->svc_thread);

        deleteList(*curr_list);
    }

    *curr_list = new_list;

    free( ii );
    close( sock );
}

void search_for_services(bdaddr_t* target, int client, bt_svc_list* curr_list, bt_svc_list* new_list)
{
    static int next_gw_port = 0;
    int err, len;
    uuid_t group;
    sdp_list_t *response_list = NULL, *search_list, *attrid_list;
    sdp_session_t *session = 0;
    sdp_buf_t buffer;

    // connect to the SDP server running on the remote machine
    session = sdp_connect( BDADDR_ANY, target, SDP_RETRY_IF_BUSY );
 
    if(session == NULL)
    {
        printf("Unable to connect to device\n");
        return;
    }

    // specify that we want a list of all the matching applications' attributes
    uint32_t range = 0x0000ffff;
    attrid_list = sdp_list_append( NULL, &range );

    sdp_uuid16_create(&group, PUBLIC_BROWSE_GROUP);
    search_list = sdp_list_append(0, &group);

    // get a list of service records that have UUID 0xabcd
    err = sdp_service_search_attr_req( session, search_list, 
            SDP_ATTR_REQ_RANGE, attrid_list, &response_list);

    sdp_list_t *r = response_list;

    if(r == NULL || err != 0)
    {
        printf("No services found\n");
        sdp_close(session);
        return;
    }

    if(curr_list == NULL)
        printf("Null!\n");

    // go through each of the service records
    for (; r; r = r->next ) {
        printf("Found service!\n");

        sdp_record_t* rec = (sdp_record_t*) r->data;
        sdp_gen_record_pdu(rec, &buffer);

	char* svc_name = (char*) malloc(128);
        sdp_get_service_name(rec, svc_name, 128);

        send_record(client, &buffer, 50000 + (++next_gw_port % 15535));

        gw_bt_server_params* params = (gw_bt_server_params*) malloc(sizeof(gw_bt_server_params));
        params->buffer.data = buffer.data;
        params->buffer.data_size = buffer.data_size;
        params->gw_port = (50000 + (next_gw_port % 15535));
        memcpy(&(params->addr), target, sizeof(bdaddr_t));

        if(!hasService(target, svc_name, strlen(svc_name), curr_list))
        {
            bt_svc* tmpSvc = addService(target, svc_name, strlen(svc_name), 0, new_list);
	    if(pthread_create(&(tmpSvc->svc_thread), NULL, gw_bt_server, (void*) params))
                printf("Error creating thread!\n");
        }
        else
	    moveService(target, svc_name, strlen(svc_name), curr_list, new_list);
    }
    sdp_close(session);
}

void send_record(int client, sdp_buf_t* buffer, int comm_port)
{
    printf("Sending service with length %d\n", buffer->data_size);
    uint8_t type = BT_SERVICE;
    int buff_size = buffer->data_size + sizeof(uint32_t) + sizeof(uint8_t) + sizeof(int);
    char* out_buf = (char*) malloc(buff_size);
    memcpy(out_buf, &(type), sizeof(type));
    memcpy(out_buf + sizeof(type), &(buffer->data_size), sizeof(uint32_t));
    memcpy(out_buf + sizeof(uint32_t) + sizeof(type), buffer->data, buffer->data_size);
    memcpy(out_buf + (buff_size - sizeof(int)), &comm_port, sizeof(int));

    send(client, out_buf, buff_size, 0);
    free(out_buf);
}

void send_device(int client, bdaddr_t* addr, char* name, int len)
{
    uint8_t type = BT_DEVICE;
    printf("Sending device: %d %d %s\n", type, len, name);
    int buff_size = len + sizeof(int) + sizeof(bdaddr_t) + sizeof(uint8_t);
    char* out_buf = (char*) malloc(buff_size);
    memcpy(out_buf, &(type), sizeof(type));
    memcpy(out_buf + sizeof(type), addr, sizeof(bdaddr_t));
    memcpy(out_buf + sizeof(type) + sizeof(bdaddr_t), &len, sizeof(len));
    memcpy(out_buf + sizeof(type) + sizeof(bdaddr_t) + sizeof(len), name, len);

    send(client, out_buf, buff_size, 0);
    free(out_buf);
}
