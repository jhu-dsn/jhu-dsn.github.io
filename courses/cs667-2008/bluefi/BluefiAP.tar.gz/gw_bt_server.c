#include "bt_common.h"

void* gw_bt_server(void* arg)
{
    printf("server thread started\n");
    gw_bt_server_params* params = (gw_bt_server_params*) arg;

    struct sockaddr_rc bt_addr = { 0 };
    struct sockaddr_in client_addr;

    int bt_sock, gwl_sock, gwc_sock, bt_port, status, scanned,
        len, msg_len, addr_len, err, open = 0;
    char buffer[512];

    fd_set sock;
    struct timeval timeout;

    sdp_record_t* rec = sdp_extract_pdu(params->buffer.data, &scanned);
    sdp_list_t* proto_list;

    if(sdp_get_access_protos(rec, &proto_list))
        return 0;
    bt_port = (int) sdp_get_proto_port(proto_list, RFCOMM_UUID);
    if(bt_port == 0)
        return 0;

    client_addr.sin_addr.s_addr = INADDR_ANY;
    client_addr.sin_family = AF_INET;
    client_addr.sin_port = htons(params->gw_port);

    gwl_sock = socket(AF_INET, SOCK_STREAM, 0);

    if(bind(gwl_sock, (struct sockaddr*)&client_addr, sizeof(client_addr)))
    {
        printf("Error binding socket\n");
	return 0;
    }

    printf("Bound socket to port %d\n", params->gw_port);
    listen(gwl_sock, 1);

    printf("Listening for connections...\n");

    bt_addr.rc_family = AF_BLUETOOTH;
    bt_addr.rc_channel = (uint8_t) bt_port;
    memcpy(&(bt_addr.rc_bdaddr), &(params->addr), sizeof(bdaddr_t));

    free(params->buffer.data);
    free(params);

    addr_len = sizeof(client_addr);
    
    while(1)
    {
	while((gwc_sock = accept(gwl_sock, (struct sockaddr*)&client_addr, &addr_len)) < 0);
	
	printf("Connected a client!\n");
	open = 1;
	
	// allocate a socket
	bt_sock = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM);

        char* straddr = (char*) malloc(32);
        ba2str(&(bt_addr.rc_bdaddr), straddr);	
        printf("Connecting to addr: %s port: %d\n", straddr, bt_port);     

	// connect to server
	status = connect(bt_sock, (struct sockaddr *)&bt_addr, sizeof(bt_addr));
	if(status != 0)
	{
		printf("Error connecting to bluetooth device\n");
		return 0;
	}
	printf("Connected to BT Client!\n");
	// receive packets and forward them to bt device
	while(1)
	{
		FD_ZERO(&sock);
		FD_SET(bt_sock, &sock);
		FD_SET(gwc_sock, &sock);

		memset(buffer, 0, len);
		len = 0;

		timeout.tv_sec = 60;
		timeout.tv_usec = 0;

		err = select((bt_sock > gwc_sock)? bt_sock + 1 : gwc_sock + 1,
			&sock, (fd_set*) 0, (fd_set*)0, &timeout);

		if(err < 0)
		printf("select error\n");
		else if(err == 0)
		printf("select timeout\n");
		else if(FD_ISSET(bt_sock, &sock))
		{
			len = read(bt_sock, &buffer, 512);
			if(len <= 0)
			printf("Client closed connection!\n");
			else
			{
//				printf("Got %d bytes of data\n", len); 
				send(gwc_sock, &len, sizeof(len), 0);
				send(gwc_sock, buffer, len, 0);
			}
		}
		else if(FD_ISSET(gwc_sock, &sock))
		{
			msg_len = receive_data(gwc_sock, &len, sizeof(len));
			if(msg_len < 0)
			{
				printf("Gateway connection closed\n");
				break;
			}
			
			msg_len = receive_data(gwc_sock, buffer, len);
			if(msg_len < len)
			{
				printf("Gateway connection closed\n");
				break;
			}

//			printf("Forwarding %d bytes of data to bt device\n", len);
			send(bt_sock, buffer, len, 0);
		}
	}
	
	
	if( status < 0 ) perror("error connecting to server!\n");
	
	close(bt_sock);
	close(gwc_sock);
    }

    close(gwl_sock);
    return 0;
}
