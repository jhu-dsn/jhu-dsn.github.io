#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <stdio.h>

int receive_data(int sock, void* buffer, int length)
{
	int offset = 0;
	int ret = 1;

	while(offset < length && ret > 0)
	{
		ret = recv(sock, (buffer + offset), (length - offset), 0);
		offset += ret;
	}
	
	if(offset != length)
		return -1;
	else
		return offset;
}

