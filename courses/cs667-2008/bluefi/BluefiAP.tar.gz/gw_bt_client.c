#include "bt_common.h"

void* gw_bt_client(void* arg)
{
    printf("Client thread started\n");
    struct timeval timeout;

    struct sockaddr_rc loc_addr = {0}, rem_addr = {0};
    socklen_t opt = sizeof(rem_addr);
    struct sockaddr_in gw_addr;
    int gw_client, gw_len, msg_len, bt_accept;

    fd_set sock;
    char buffer[512];
    int len, err, bt_client, bt_port;
    int scanned;
    uuid_t rfcomm_uuid;

    gw_bt_client_params* params = (gw_bt_client_params*) arg;

    sdp_record_t* rec = sdp_extract_pdu(params->buffer.data, &scanned);
    if(rec == NULL)
    {
        printf("Thread: rec NULL\n");
        free(params->buffer.data);
        free(params);
        return 0;
    }

    char* name = (char*) malloc(128);
    sdp_get_service_name(rec, name, 128);

    sdp_list_t* proto_list;
    if(sdp_get_access_protos(rec, &proto_list))
    {
        printf("%s: no access protos\n", name);
        free(params->buffer.data);
        free(params);
        return 0;
    }

    bt_port = (int) sdp_get_proto_port(proto_list, RFCOMM_UUID);
    if(bt_port == 0)
    {
        printf("%s: no RFCOMM port\n", name);
        free(params->buffer.data);
        free(params);
        return 0;
    }


    printf("%s: creating socket\n", name);

    bt_accept = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM);

    loc_addr.rc_family = AF_BLUETOOTH;
    loc_addr.rc_bdaddr = *BDADDR_ANY;
    loc_addr.rc_channel = (uint8_t) bt_port;

    if(bind(bt_accept, (struct sockaddr*)&loc_addr, sizeof(loc_addr)))
    {
//        printf("%s: bind failed %d\n", name, bt_port);
        loc_addr.rc_channel = 0;
        do
    	{
            loc_addr.rc_channel++;
            err = bind(bt_accept, (struct sockaddr*)&loc_addr, sizeof(loc_addr));
    	}while(err != 0 && loc_addr.rc_channel <= 30);

        if(err != 0)
        {
            printf("%s: bind failed on all ports\n", name);
            free(params->buffer.data);
            free(params);
            return 0;
    	} 

        bt_port = loc_addr.rc_channel;
        printf("%s: bind succeeded %d\n", name, bt_port);

        //the port is different, we have to update the service
	sdp_data_t *channel = 0;
	sdp_uuid16_create(&rfcomm_uuid, RFCOMM_UUID);
	channel = sdp_data_alloc(SDP_UINT8, (uint8_t*) &bt_port);

	sdp_list_t* rfcomm_list = sdp_list_find(proto_list->next, &rfcomm_uuid, sdp_uuid16_cmp);
        if(rfcomm_list == NULL)
        {
 //           printf("%s: no proto list\n", name);
            free(params->buffer.data);
            free(params);
            return 0;
    	}

        sdp_list_free(rfcomm_list->next, free);
	sdp_list_append(rfcomm_list, channel);

    	sdp_set_access_protos(rec, proto_list);

        sdp_session_t* session = NULL;
        while((session = sdp_connect( BDADDR_ANY, BDADDR_LOCAL, SDP_RETRY_IF_BUSY )) == NULL);

        if(sdp_record_update(session, rec))
	{
            printf("%s: update failed\n", name);
            sdp_close(session);
            free(params->buffer.data);
            free(params);
            return 0;
	}
        sdp_close(session);
    }

    printf("%s: listening on port %d\n", name, bt_port);

    free(params->buffer.data);
    listen(bt_accept, 1);

    while(1)
    {
        while((bt_client = accept(bt_accept, (struct sockaddr *)&rem_addr, &opt)) <= 0);

        printf("%s: Connected BT client!\n", name);

 	gw_addr.sin_addr.s_addr = params->remote_gw_addr;
        gw_addr.sin_family = AF_INET;
        gw_addr.sin_port = htons(params->gw_port);

        gw_client = socket(AF_INET, SOCK_STREAM, 0);
        if(connect(gw_client, (struct sockaddr*)&gw_addr, sizeof(gw_addr)))
        {
            printf("%s: Error connecting to client\n", name);
            return 0;
        }
        else
            printf("%s: Connected to remote gateway!\n", name);
            
        while(1)
	{
	    memset(buffer, 0, len);
	    len = 0;

	    timeout.tv_sec = 60;
            timeout.tv_usec = 0;

	    FD_ZERO(&sock);
            FD_SET(bt_client, &sock);
            FD_SET(gw_client, &sock);

            err = select((bt_client > gw_client)? bt_client + 1 : gw_client + 1,
                              &sock, (fd_set*) 0, (fd_set*)0, &timeout);

            if(FD_ISSET(bt_client, &sock))
            {
		len = read(bt_client, &buffer, 512);
                if(len <= 0)
		{
                    printf("%s: Client closed connection!\n", name);
		    break;
		}
                else
                {
//                    printf("%s: Got %d bytes of data\n", name, len); 
                    send(gw_client, &len, sizeof(len), 0);
 	     	    send(gw_client, buffer, len, 0);
                }
            }
            else if(FD_ISSET(gw_client, &sock))
            {
		msg_len = receive_data(gw_client, &len, sizeof(len));
		if(msg_len < 0)
		{
		    printf("%s: Error receiving data from gateway\n", name);
		    break;
		}
			
		msg_len = receive_data(gw_client, buffer, len);
		if(msg_len < len)
		{
		    printf("%s: Error receiving data from gateway\n", name);
		    break;
		}

//		printf("%s: Forwarding %d bytes of data to bt device\n", name, len);
		send(bt_client, buffer, len, 0);
            }
        }

	close(bt_client);
	close(gw_client);
    }

    free(params);
    close(bt_accept);
    return 0;
}
