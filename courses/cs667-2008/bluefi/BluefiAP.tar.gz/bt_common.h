#ifndef BT_COMMON_H_
#define BT_COMMON_H_

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>

#include <pthread.h>

#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>

#include <bluetooth/bluetooth.h>
#include <bluetooth/hci.h>
#include <bluetooth/hci_lib.h>
#include <bluetooth/sdp.h>
#include <bluetooth/sdp_lib.h>
#include <bluetooth/rfcomm.h>

#define BT_DEVICE  1
#define BT_SERVICE 2

/* Bluetooth Serivce List structs */
typedef struct bt_svc
{
    pthread_t svc_thread;
    bdaddr_t bt_addr;
    char* svc_name;
    int name_len;
    uint32_t local_handle;
} bt_svc;

typedef struct bt_svc_node
{
    bt_svc* svc;
    struct bt_svc_node* prev;
    struct bt_svc_node* next;
} bt_svc_node;

typedef struct bt_svc_list
{
    bt_svc_node* head;
    bt_svc_node* tail;
} bt_svc_list;

/* Thread function parameter structs */
typedef struct gw_bt_server_params
{
    bdaddr_t addr;
    sdp_buf_t buffer;
    int gw_port;
} gw_bt_server_params;

typedef struct gw_bt_client_params
{
    int gw_port;
    sdp_buf_t buffer;
    unsigned long remote_gw_addr;
} gw_bt_client_params;

/* Bluetooth Service List functions*/

int hasService(bdaddr_t* addr, char* name, int len, bt_svc_list* list);
bt_svc* getService(bdaddr_t* addr, char* name, int len, bt_svc_list* list);

void removeService(bdaddr_t* addr, char* name, int len, bt_svc_list* list);
bt_svc* addService(bdaddr_t* addr, char* name, int len, 
                uint32_t handle, bt_svc_list* list);

void moveService(bdaddr_t* addr, char* name, int len, bt_svc_list* from, bt_svc_list* to);

void deleteNode(bt_svc_node* node, bt_svc_list* list);
void deleteList(bt_svc_list* list);

/*Network utilities*/
int receive_data(int sock, void* buffer, int length);


#endif

