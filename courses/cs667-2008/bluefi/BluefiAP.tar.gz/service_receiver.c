#include "bt_common.h"

void* gw_bt_client(void* arg);

void* svc_receive_thread(void* param)
{
    struct sockaddr_in addr, client_addr, tmp_addr;
    int sock, client, addr_len, open = 0;
    int len, scanned, devname_len, gw_port;
    unsigned long rmt_addr;
    char* dev_name;
    char buffer[1024];
    
    bt_svc_list* curr_list = NULL;
    bt_svc curr_svc;

    sdp_buf_t sdp_buffer;
    sdp_session_t* session = NULL;
    uint32_t handle;
    uint8_t type;
    uuid_t svc_uuid;
    uint32_t svc_uuid_int[] = {0,0,0,0xABCD};

    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(50000);

    sock = socket(AF_INET, SOCK_STREAM, 0);
    while(bind(sock, (struct sockaddr*)&addr, sizeof(addr))) { sleep(100); };

    printf("Bound socket\n");
    listen(sock, 1);

    printf("Listening for connections...\n");
    addr_len = sizeof(client_addr);

    while(1)
    {
        if((client = accept(sock, (struct sockaddr*)&client_addr, &addr_len)) < 0)
        {
            printf("Error accepting connection\n");
            continue;
        }
        else
        {
            printf("Connected a client!\n");
            open = 1;
            getpeername(client, (struct sockaddr*)&tmp_addr, &addr_len);
            rmt_addr = tmp_addr.sin_addr.s_addr;
        }

	session = sdp_connect( BDADDR_ANY, BDADDR_LOCAL, SDP_RETRY_IF_BUSY );
	if(session == NULL)
	{
	    printf("Failed to connect to sdp server\n");
	    close(client);
	    open=0;
	}

        bt_svc_list* new_list = (bt_svc_list*) malloc(sizeof(bt_svc_list));

        while(open == 1)
        {
	    printf("Reading...\n");
            sdp_buffer.data_size = 0;
            type = 0;

            len = receive_data(client, (void*) &type, sizeof(type));
            if(len < 0)
	    {
		open=0;
		close(client);
		continue;
	    }
            
            printf("Got type %d\n", type);
            if(type == BT_DEVICE)
            {
		if(receive_data(client, (void*) &(curr_svc.bt_addr), sizeof(bdaddr_t)) < 0)
                {
                    open = 0;
                    close(client);
                    continue;
                }
		printf("Got client addr\n");
                if(receive_data(client, (void*) &(devname_len), sizeof(int)) < 0)
                {
                    open = 0;
                    close(client);
                    continue;
                }
		printf("Got name len %d\n", devname_len);
                dev_name = (char*) malloc(devname_len + 1);

		if(receive_data(client, (void*)(dev_name), devname_len) < 0)
                {
                    open = 0;
                    close(client);
		    continue;
                }
		//dev_name[curr_svc.name_len] = '\0';
		printf("Got client name %s\n", dev_name);
            }
            else if(type == BT_SERVICE)
	    {
		len = receive_data(client, &(sdp_buffer.data_size), sizeof(uint32_t));
		if(len < 0)
		{	
		    open = 0;
		    continue;
		}

		printf("Reading service of len %d\n", sdp_buffer.data_size);
		sdp_buffer.data = (uint8_t*) malloc(sdp_buffer.data_size);

		len = receive_data(client, sdp_buffer.data, sdp_buffer.data_size);
		if(len < sdp_buffer.data_size)
		{
		    printf("Error receiving service record: %d %d\n", sdp_buffer.data_size, len);
		    open = 0;
		    close(client);
		    continue;
		}

		len = receive_data(client, &gw_port, sizeof(gw_port));
		if(len < sizeof(gw_port))
		{
		    printf("Error receiving gateway port: %d %d\n", sizeof(gw_port), len);
		    open = 0;
		    close(client);
		    continue;
		}

                printf("Got service buffer\n");
		sdp_buffer.buf_size = sdp_buffer.data_size;
                sdp_record_t* svc_rec = sdp_extract_pdu(sdp_buffer.data,
                                                             &scanned);
                if(svc_rec == NULL)
                    continue;
                
	        //change name to be "remote_device_name - service_name"
	        char* name1 = (char*) malloc(128*sizeof(char));
	        sdp_get_service_name(svc_rec, name1, 128);

	        curr_svc.svc_name = (char*) malloc(devname_len + strlen(name1) + 4);
	        strncpy(curr_svc.svc_name, dev_name, devname_len);
	        strncpy(curr_svc.svc_name + devname_len, " - ", 3);
	        strncpy(curr_svc.svc_name + devname_len + 3, name1, strlen(name1));

                curr_svc.name_len = devname_len + strlen(name1) + 4;
		curr_svc.svc_name[curr_svc.name_len - 1] = '\0';

	        printf("Old name: %s\n New name: %s\n", name1, curr_svc.svc_name);
		free(name1);

                bt_svc* tmp_svc = getService(&(curr_svc.bt_addr), curr_svc.svc_name, 
                                              curr_svc.name_len, curr_list);

                if(tmp_svc == NULL)
                {
		     printf("Service not already registered, registering...\n");
		     //actually register service, it hasn't been registered yet

                     sdp_set_info_attr(svc_rec, curr_svc.svc_name, NULL, NULL);

		     sdp_uuid128_create(&svc_uuid, &svc_uuid_int);
		     sdp_set_service_id(svc_rec, svc_uuid);

		     if(sdp_record_register(session, svc_rec, 0))
			 printf("Register failed: %d!\n", errno);
		     else
                     {
                         curr_svc.local_handle = svc_rec->handle;

			 printf("Register succeeded!\n");
			 gw_bt_client_params* params = (gw_bt_client_params*) 
                                                        malloc(sizeof(gw_bt_client_params));
                         params->remote_gw_addr = rmt_addr;
			 params->buffer.data = sdp_buffer.data;
                         params->buffer.data_size = sdp_buffer.data_size;
                         params->gw_port = gw_port;

			 tmp_svc = addService(&(curr_svc.bt_addr), curr_svc.svc_name,
				        curr_svc.name_len, curr_svc.local_handle, new_list);
                         if(pthread_create(&(tmp_svc->svc_thread), NULL, gw_bt_client, params))
                             printf("Failed to create thread: %d \n", errno);
		     }
                }
		else
                {
		    printf("Service already registered, skipping...\n");
                    moveService(&(curr_svc.bt_addr), curr_svc.svc_name, curr_svc.name_len, curr_list, new_list);
                    free(sdp_buffer.data);
                }

                sdp_buffer.data_size = 0;
                sdp_buffer.buf_size = 0;
		free(curr_svc.svc_name);
            }
	    printf("done\n");
    	}

        printf("out\n");

	//unregister all remaining services
	if(curr_list != NULL)
	{
  	    bt_svc_node* tmp;
            for(tmp = curr_list->head; tmp != NULL; tmp = tmp->next)
            {
	        sdp_device_record_unregister_binary(session, &(tmp->svc->bt_addr), tmp->svc->local_handle);
                pthread_cancel(tmp->svc->svc_thread);
            }

            deleteList(curr_list);
	}

        curr_list = new_list;
	sdp_close(session);
        printf("Connection closed\n");
    }
    return 0;
}

