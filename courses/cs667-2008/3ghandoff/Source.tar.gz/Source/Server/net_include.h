#include <stdio.h>

#include <stdlib.h>

#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h> 
#include <netdb.h>

#include <errno.h>

#define CONTROL_PORT	      11020
#define CLIENT_DATA_PORT      11008
#define CLIENT_0        	0
#define CLIENT_1        	1
#define MOBILITY_SERVER 	2
#define CLIENT_CONNECT		0
#define CLIENT_START_REPLY	1
#define DATA_PACKET		2
#define SWITCH_REQUEST		3
#define SWITCH_REQUEST_REPLY	4
#define CLIENT_CALL		5
#define CLIENT_CALL_REPLY	6
#define SERVER_PORT		7
#define TERM_PACKET		8
#define MAX_MESS_LEN    	8192
#define IP_QUAD(ip)  (ip)>>24,((ip)&0x00ff0000)>>16,((ip)&0x0000ff00)>>8,((ip)&0x000000ff)
#define VALUE 0
#define NUM_PACKETS 3000
#define TRUE 1
#define FALSE 0

/*Server Data Structures*/
struct flow_table {
	int flow_id;		/*ID for a pair of clients*/
	int client_0_id;
	int client_0_sock;
	int client_1_id;
	int client_1_sock;
} flow_table;

struct ip_entry {

	int port;
	struct sockaddr_in addr;
	int socket;
}ip_entry;
	
struct client_table {
	int current_addr;
	int client_id;
	int tcp_socket;
	struct ip_entry ip1;
	struct ip_entry ip2;	
} client_table;



/*Message Set*/
/*Message Type 0*/
struct client_start_message {
	int message_type;
	int client_id;		/*ID of client sender*/
	int client_port;	/*UDP port for client to receive packets on*/
} client_start_message;

/*Message Type 1*/
struct client_start_reply {
	int message_type;
	int server_port;
	int status;		/*0 = wait to for receiver to join, 1 = ok to send*/
} client_start_reply;

/*Message Type 2*/
struct data_packet {
        int message_type;      /*Type indicates what type of packet is being sent/received*/
        int seq;               /*Sequence number of message being sent*/
	int payload_size;
} data_packet;

/*Message Type 3*/
struct switch_request {
	int message_type;
	int sender_id;
	int port;
} switch_request;

/*Message Type 4*/
struct switch_request_reply {
	int message_type;
	int status;		/*0 = wait to send on new interface, 1 = ok to send on new interface*/
} switch_request_reply;

/*Message Type 5*/
struct client_call {
        int message_type;
        int dest_id;
} client_call;

/*Message Type 6*/
struct client_call_reply {
        int message_type;
	int dest_id;
        int status;	/*0 = Client not online, 1 = Clear to send*/
} client_call_reply;

/*Message Type 7*/
struct server_port {
	int message_type;
	int port;
} server_port;


/*Message Type 8*/
struct term_packet {
	int message_type;
	int client_id;
} term_packet;



