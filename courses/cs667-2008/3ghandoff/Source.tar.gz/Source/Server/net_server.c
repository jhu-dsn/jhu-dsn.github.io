#include "net_include.h"

void udp_init();
int TCP_Write(int sd, void *dummy_buf, int nBytes);
int client_sock;
int get_index(int, int);
int get_id(int, int);


//Stores all relevant address info for each client
struct client_table 	clients[100];

int main()
{
    struct sockaddr_in 		name;
    struct sockaddr_in  	from_addr_tcp;
    struct sockaddr_in		from_addr_udp;
    struct client_start_message * cc;
    struct client_call *	c_call;
    struct client_call_reply *  c_reply;
    struct data_packet *  	data_mess;
    struct term_packet *  	term_mess;
    struct server_port *	s_port;
    struct switch_request *     switch_mess;
    struct switch_request_reply *switch_reply;
    struct data_packet		*dpkt;
    struct flow_table		flow;
    socklen_t          		from_len;
    unsigned long      		temp_addr;
    int             	        control_sock;
    int 		        client_count=0;
    fd_set        	        mask;
    int          	        recv_s[10];
    int          	        valid[10];  
    int				call_flag=0;
    int		       		packet_type;
    fd_set             		dummy_mask,temp_mask;
    int               		i,j,num;
    int                		mess_len;
    int                		bytes;
    int		       		packet_count=0;
    int				k;
    char               		mess_buf[MAX_MESS_LEN]; 
    char			output_buf[MAX_MESS_LEN];
    long               		on=1;
    struct timeval       	timer1, timer2;
    struct timeval     		timeout;

    int 			bytes_read, bytes_remaining, ret1 ;
    
    int TERM0, TERM1, START0, START1 ;
    TERM0 = TERM1 = START0 = START1 = FALSE;

    FILE *fclient0;
    FILE *fclient1;
    long int packet_times[2][NUM_PACKETS + 1];
    long int temp;
    memset(packet_times[0], VALUE, sizeof(long)*(NUM_PACKETS + 1)); 
    memset(packet_times[1], VALUE, sizeof(long)*(NUM_PACKETS + 1)); 
    
    if((fclient0 = fopen("3G-Server-client1-0.txt", "w")) == NULL) {
    	perror("fopen");
    	exit(0);
    }

    if((fclient1 = fopen("3G-Server-client0-1.txt", "w")) == NULL) {
    	perror("fopen");
    	exit(0);
    }

    control_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (control_sock<0) {
        perror("Net_server: socket");
        exit(1);
    }

    if (setsockopt(control_sock, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on)) < 0)
    {
        perror("Net_server: setsockopt error \n");
        exit(1);
    }

    name.sin_family = AF_INET;
    name.sin_addr.s_addr = INADDR_ANY;
    name.sin_port = htons(CONTROL_PORT);

    if ( bind( control_sock, (struct sockaddr *)&name, sizeof(name) ) < 0 ) {
        perror("Net_server: bind");
        exit(1);
    }

    if (listen(control_sock, 4) < 0) {
        perror("Net_server: listen");
        exit(1);
    }

    timeout.tv_sec =  0;
    timeout.tv_usec = 0;

    i = 0;
    

    FD_ZERO(&mask);
    FD_ZERO(&dummy_mask);
    FD_SET(control_sock, &mask);
    //FD_SET(client_1_sr, &mask);
    //printf("Client 0 sr: %d\n",client_0_sr);

    for(;;)
    {
        temp_mask = mask;
        num = select( FD_SETSIZE, &temp_mask, &dummy_mask, &dummy_mask, NULL);
        if (num > 0) {
            if ( FD_ISSET(control_sock,&temp_mask) ) {
		from_len = sizeof(from_addr_tcp);
	        recv_s[i] = accept(control_sock,(struct sockaddr *)&from_addr_tcp, &from_len);
		printf("Connection Accepted\n");
	  	FD_SET(recv_s[i], &mask);
                valid[i] = 1;
                i++;
            }
            for(j =0 ; j < i ; j++)
            {   
		int break_flag = 0;
	    	if (valid[j])     
                if ( FD_ISSET(recv_s[j],&temp_mask) ) {
			bytes_remaining = sizeof(int);
			bytes_read = 0;
			while(bytes_remaining > 0) { 	
			//	printf("Before recv of len\n");		    
		     		ret1 = recv(recv_s[j], &mess_buf[bytes_read], bytes_remaining, 0);			
			//	printf("After recv of len\n");	

		     		if(ret1 < 0) {
					printf("Error 1!\n");
					perror("Recv, Error 1");				
					exit(0);
		     		}

				if(ret1 == 0) {
					printf("Other side closed socket.\n");
					printf("closing %d \n",j);
                        		FD_CLR(recv_s[j], &mask);
                        		close(recv_s[j]);
                        		valid[j] = 0; 
					break_flag = 1;				
					break; 
				}

		     		bytes_read += ret1;
		     		bytes_remaining -= ret1;
               		}
			if(break_flag)
				continue;

			mess_len = *(int *)mess_buf;
			//printf("Message Length is: %d \n",mess_len);
		
			//if( mess_len > 0) {
                        //	printf("\nReceiving Message...\n");
			
			bytes_remaining = mess_len;
			bytes_read = 0;
			break_flag = 0;			
			while(bytes_remaining > 0) { 	
			//	printf("Before recv of data\n");		    
		     		ret1 = recv(recv_s[j], &mess_buf[bytes_read], bytes_remaining, 0);			
			//	printf("After recv of data\n");
		     		
				if(ret1 < 0) {
					printf("Error 2!\n");
					perror("Recv, Error 2");
					exit(0);
		     		}
				
				if(ret1 == 0) {
					printf("Other side closed socket.\n");
					printf("closing %d \n",j);
                        		FD_CLR(recv_s[j], &mask);
                        		close(recv_s[j]);
                        		valid[j] = 0;
					break_flag = 1;  
					break;
				}

		     		bytes_read += ret1;
		     		bytes_remaining -= ret1;
               		}
			
                        if(break_flag)
				continue;
			
                       			
			packet_type = (int)mess_buf[0];
                        //printf("Socket is %d ",j);                         
                        switch(packet_type) {
				

				//Client connect message received when new client connects over TCP
				//Server stores client ID and client's receive port (for UDP)				
				case CLIENT_CONNECT:	
					cc = (struct client_start_message *)mess_buf;
					printf("Received Connect message\n");
					printf("Packet Type: %d	  Client ID: %d	   Port: %d\n", cc->message_type, cc->client_id, cc->client_port);
					clients[client_count].client_id = cc->client_id;
					clients[client_count].ip1.port = cc->client_port;
					clients[client_count].current_addr = 1;
					
					if(cc->client_id == 0)
					{
						flow.client_0_id = 0;
						flow.client_0_sock = recv_s[j];
					}

					else if(cc->client_id == 1)
					{
						flow.client_1_id = 1;
						flow.client_1_sock = recv_s[j];
					}

					getpeername(recv_s[j],(struct sockaddr *)&from_addr_tcp, &from_len);

					clients[client_count].ip1.addr = from_addr_tcp;
					printf("From Address: %d.%d.%d.%d	\n",IP_QUAD(ntohl(from_addr_tcp.sin_addr.s_addr)));
					clients[client_count].ip1.addr.sin_port = htons(cc->client_port);
					clients[client_count].tcp_socket = recv_s[j];
					client_count++;	 
					break;
			
				//Upon receiving switch request, update current address
				case SWITCH_REQUEST:
					switch_mess = (struct switch_request *)mess_buf;
					switch_reply = (struct switch_request_reply *)output_buf;
					printf("\n\n***********************Getting Switch Request from*************************************\n\n");					
					printf("Message Type: %d\n", packet_type);
					printf("Received Switch request from Client %d\n", switch_mess->sender_id);
					for(k=0;k<client_count;k++) {
						if( switch_mess->sender_id == clients[k].client_id ) {
							//store new addr
							if(clients[k].current_addr == 1) {
								printf("Old Address: %d.%d.%d.%d	",IP_QUAD(ntohl(clients[k].ip1.addr.sin_addr.s_addr)));

								getpeername(recv_s[j],(struct sockaddr *)&from_addr_tcp, &from_len);

								printf("New Address: %d.%d.%d.%d\n", IP_QUAD(ntohl(from_addr_tcp.sin_addr.s_addr)));
								clients[k].ip2.addr = from_addr_tcp;
								clients[k].ip2.addr.sin_port = htons(switch_mess->port);
								printf("Port: %d\n", ntohs(clients[k].ip2.addr.sin_port));
								clients[k].tcp_socket = recv_s[j];
								clients[k].current_addr = 2;
							} else {
								printf("Old Address: %d.%d.%d.%d	",IP_QUAD(ntohl(clients[k].ip2.addr.sin_addr.s_addr)));

								getpeername(recv_s[j],(struct sockaddr *)&from_addr_tcp, &from_len);									
								printf("New Address: %d.%d.%d.%d    ", IP_QUAD(ntohl(from_addr_tcp.sin_addr.s_addr)));
								clients[k].ip1.addr = from_addr_tcp;
								clients[k].ip1.addr.sin_port = htons(switch_mess->port);
								printf("Port: %d\n", ntohs(clients[k].ip1.addr.sin_port));
								clients[k].tcp_socket = recv_s[j];
								clients[k].current_addr = 1;
							}
						}
					}
					//send out
					switch_reply->message_type = 4;
					switch_reply->status = 1;
					send(recv_s[j], output_buf, sizeof(struct switch_request_reply), 0);
					break;

				//Forward call request to receiver if receiver online
				case CLIENT_CALL:
					c_call = (struct client_call *)mess_buf;
					printf("Received Client Call Message, sending to Client %d\n", c_call->dest_id);
					c_reply = (struct client_call_reply *)output_buf;					
					c_reply->message_type = 6;					
					k = get_index(c_call->dest_id, client_count);
					if(client_count == 1) {
						c_reply->status = 0; //Other client not online
						call_flag = 1;
						//send reply
						send(recv_s[j], output_buf, sizeof(struct client_call_reply), 0);
					} else if(client_count == 2) {
						//Send call to other client
						c_call->dest_id = get_id(recv_s[j], client_count);
						send(clients[k].tcp_socket, mess_buf, sizeof(struct client_call), 0);
						//c_reply->status = 1;
						//c_reply->port = CLIENT_DATA_PORT;
					}	 
					break;

				//Reply from client receiver accepting/rejecting call
				case CLIENT_CALL_REPLY:
					printf("Received Client Call Reply\n");
					c_reply = (struct client_call_reply *)mess_buf;
					k = get_index(c_reply->dest_id, client_count);
					c_reply->dest_id = get_id(recv_s[j], client_count);
					//send(clients[k].tcp_socket, mess_buf, sizeof(client_call_reply),0);					
											
					s_port = (struct server_port *)output_buf;
					s_port->message_type = 7;
					if( c_reply->status == 1 ) {
						//Client accepted call
						s_port->port = CLIENT_DATA_PORT;
						//Init UDP port
						udp_init();
						FD_SET(client_sock, &mask);
						printf("Sending port assignment\n");
						//Send to CTS to both clients with port assignment
						send(clients[k].tcp_socket, output_buf, sizeof(struct server_port), 0);
						send(recv_s[j], output_buf, sizeof(struct server_port), 0);
						//flow.client_0_id = k;
						//flow.client_1_id = get_id(recv_s[j], client_count);
					}
					break;

				//Data packets forward based on current address within client's table of ip's
				case DATA_PACKET:
					dpkt = (struct data_packet *)mess_buf;
					if(dpkt->seq == 0)
					{
						gettimeofday(&timer1, NULL);
					}
					else if(dpkt->seq == 1000)
					{
						float sec, usec, total;
						gettimeofday(&timer2, NULL);
						
						sec  = timer2.tv_sec  - timer1.tv_sec;
						usec = timer2.tv_usec - timer1.tv_usec;

						if(usec < 0) {
							usec += 1000000;
							sec--;	
						}
						
						total = sec + (usec / 1000000.0);
						printf("Total time: = %f\n", total);
						printf("Throughput = %f packets/sec\n", 1000.0 / total); 
						exit(0);
	
					}
					if( (dpkt->seq % 100) == 0)					
						printf("Received Data Packet %d \n", dpkt->seq);

					//send(recv_s[j], &mess_len, sizeof(int), 0);
					//send(recv_s[j], mess_buf, mess_len, 0);

					if(recv_s[j] == flow.client_0_sock)
					{
						TCP_Write(flow.client_1_sock, &mess_len, sizeof(int));
						TCP_Write(flow.client_1_sock, mess_buf, mess_len);
					}
					else if(recv_s[j] == flow.client_1_sock)
					{
						TCP_Write(flow.client_0_sock, &mess_len, sizeof(int));
						TCP_Write(flow.client_0_sock, mess_buf, mess_len);
					}

					//fflush(0);
					break;
						
		        }
			//printf("\n");
			
			
		    //}
                   /*
		    else
                    {
                        printf("closing %d \n",j);
                        FD_CLR(recv_s[j], &mask);
                        close(recv_s[j]);
                        valid[j] = 0;  
                    }
			*/
                }
            }

	    if ( FD_ISSET(client_sock,&temp_mask) ) {
		fflush(stdout);
                from_len = sizeof(from_addr_udp);
                bytes = recvfrom( client_sock, mess_buf, sizeof(mess_buf), 0,  
                          (struct sockaddr *)&from_addr_udp, &from_len );
		gettimeofday(&timer1, NULL);
		temp = timer1.tv_sec*1000 + (timer1.tv_usec)/1000;
		temp_addr = ntohl(from_addr_udp.sin_addr.s_addr);
		packet_type = (int)mess_buf[0];
		//printf("\nSource: %d.%d.%d.%d\n", IP_QUAD(temp_addr));
		//printf("Message Type: %d\n", packet_type);
		switch(packet_type) {
			case DATA_PACKET:
				data_mess = (struct data_packet *)mess_buf;
				packet_count++;
				if(packet_count % 200 == 0) printf("Received %d packets\n", packet_count);
				//printf("Received data packet from Client at %d.%d.%d.%d\n", IP_QUAD(temp_addr));
				//printf("Sequence Number: %d	Payload Size: %d	Timestamp: %ld ", data_mess->seq, data_mess->payload_size, temp);
				//Determine sender				
				if( (from_addr_udp.sin_addr.s_addr == clients[flow.client_0_id].ip1.addr.sin_addr.s_addr) ||
				    (from_addr_udp.sin_addr.s_addr == clients[flow.client_0_id].ip2.addr.sin_addr.s_addr)) {
					
															
					//Send to Client 1
					//printf("From Address: %d.%d.%d.%d	",IP_QUAD(ntohl(from_addr_udp.sin_addr.s_addr)));

					/*if( clients[flow.client_0_id].current_addr == 1 )
						//printf("Client %d Address: %d.%d.%d.%d	  \n", clients[flow.client_0_id].client_id,						       							IP_QUAD(ntohl(clients[flow.client_0_id].ip1.addr.sin_addr.s_addr)));	
					else 						
						//printf("Client %d Address: %d.%d.%d.%d	  \n", clients[flow.client_0_id].client_id,						       							IP_QUAD(ntohl(clients[flow.client_0_id].ip2.addr.sin_addr.s_addr)));*/

					if( clients[flow.client_1_id].current_addr == 1 )
					{
						//printf("Sending to ");
						//printf("Client %d Address: %d.%d.%d.%d:%d	  \n", clients[flow.client_1_id].client_id,						        						IP_QUAD(ntohl(clients[flow.client_1_id].ip1.addr.sin_addr.s_addr)),ntohs(clients[flow.client_1_id].ip1.addr.sin_port));
						sendto(client_sock, mess_buf, sizeof(struct data_packet) + data_mess->payload_size, 
					       0, (struct sockaddr *)&clients[flow.client_1_id].ip1.addr, sizeof(clients[flow.client_1_id].ip1.addr));
					}	
					else
					{
						//printf("Sending to ");
						//printf("Client %d Address: %d.%d.%d.%d:%d	  \n", clients[flow.client_1_id].client_id,						       							IP_QUAD(ntohl(clients[flow.client_1_id].ip2.addr.sin_addr.s_addr)),ntohs(clients[flow.client_1_id].ip2.addr.sin_port));

						sendto(client_sock, mess_buf, sizeof(struct data_packet) + data_mess->payload_size, 
					       0, (struct sockaddr *)&clients[flow.client_1_id].ip2.addr, sizeof(clients[flow.client_1_id].ip2.addr));
					}
					
					packet_times[1][data_mess->seq] = temp;		  	    	
									
				}				
				else {
					//From Client 1, send to Client 0
					//printf("From Address: %d.%d.%d.%d	",IP_QUAD(ntohl(from_addr_udp.sin_addr.s_addr)));
					/*if( clients[flow.client_1_id].current_addr == 1 )
						//printf("Client %d Address: %d.%d.%d.%d	  \n", clients[flow.client_1_id].client_id,						        					IP_QUAD(ntohl(clients[flow.client_1_id].ip1.addr.sin_addr.s_addr)));	
					else 						
						//printf("Client %d Address: %d.%d.%d.%d	  \n", clients[flow.client_1_id].client_id,						       							IP_QUAD(ntohl(clients[flow.client_1_id].ip2.addr.sin_addr.s_addr)));	*/

					

					if( clients[flow.client_0_id].current_addr == 1 )
					{
						//printf("Sending to ");
						//printf("Client %d Address: %d.%d.%d.%d:%d	  \n", clients[flow.client_0_id].client_id,						        						IP_QUAD(ntohl(clients[flow.client_0_id].ip1.addr.sin_addr.s_addr)), ntohs(clients[flow.client_0_id].ip1.addr.sin_port));
						sendto(client_sock, mess_buf, sizeof(struct data_packet) + data_mess->payload_size, 
					       0, (struct sockaddr *)&clients[flow.client_0_id].ip1.addr, sizeof(clients[flow.client_0_id].ip1.addr));
					}	
					else
					{
						//printf("Sending to ");
						//printf("Client %d Address: %d.%d.%d.%d:%d	  \n", clients[flow.client_0_id].client_id,						       							IP_QUAD(ntohl(clients[flow.client_0_id].ip2.addr.sin_addr.s_addr)), ntohs(clients[flow.client_0_id].ip2.addr.sin_port));	

						sendto(client_sock, mess_buf, sizeof(struct data_packet) + data_mess->payload_size, 
					       0, (struct sockaddr *)&clients[flow.client_0_id].ip2.addr, sizeof(clients[flow.client_0_id].ip2.addr));
					}	 						
					
					packet_times[0][data_mess->seq] = temp;		
				}
				break;

			//Sent to terminate current session
			case TERM_PACKET:
				term_mess = (struct term_packet *)mess_buf;
				
				if(term_mess->client_id == 1 && TERM1 == FALSE)
				{
					int index, nwritten;

					for(index = 1; index <= NUM_PACKETS; index++)
					nwritten = fprintf(fclient0, "%d\t%ld\n", index, packet_times[0][index]);
					
					fclose(fclient0);


					printf("\n File Writing Compelete for client 0");
					TERM1 = TRUE;
				}
				else if(term_mess->client_id == 0 && TERM0 == FALSE)
				{
					int index, nwritten;
					
					for(index = 1; index <= NUM_PACKETS; index++)
					nwritten = fprintf(fclient1, "%d\t%ld\n", index, packet_times[1][index]);
					
					fclose(fclient1);

					printf("\n File Writing Compelete for client 1");
					TERM0 = TRUE;
				}

				if(TERM0 == TRUE && TERM1 == TRUE)
				{
					printf("EXiting\n");
					exit(0);
				}
				break;
		}
	    }
    	}
	
    }    

    return 0;

}

int TCP_Write(int sd, void *dummy_buf, int nBytes)
{
  int ret, nWritten, nRemaining;
  char *buf;
  
  buf        = (char *)dummy_buf;
  nWritten   = 0;
  nRemaining = nBytes;

  while(1) {
    ret = write(sd, &buf[nWritten], nRemaining);
  
    if(ret <= 0)
      break;

    nWritten   += ret;
    nRemaining -= ret;

    if(nRemaining == 0)
      break;
  }
  return ret;
}

 
//Returns index in client_table array of client id supplied 
int get_index(int id, int count) {
	int i;
	for(i=0;i<count;i++) {
		if(clients[i].client_id == id) return i;
	}
	return -1;
}

//Returns index in client_table array of fd supplied 
int get_id(int fd, int count) {
	int i;
	for(i=0;i<count;i++) {
		if(clients[i].tcp_socket == fd) return clients[i].client_id;
	}
	return -1;
}

void udp_init()
{
    struct sockaddr_in name;
    int ucast_addr = 128 << 24 | 220 << 16 | 221 << 8 | 1; //(128.220.221.11)

    /* socket for receiving (udp) */
    client_sock = socket(AF_INET, SOCK_DGRAM, 0);  
    if (client_sock<0) {
        perror("Ucast: socket");
        exit(1);
    }

    name.sin_family = AF_INET;  
    name.sin_addr.s_addr = htonl(ucast_addr); 
    name.sin_port = htons(CLIENT_DATA_PORT);

    if ( bind( client_sock, (struct sockaddr *)&name, sizeof(name) ) < 0 ) {
        perror("Ucast: bind");
        exit(1);
    }

  }


