#include "stdio.h"

int main(){
	printf("Hi");
	return 0;
}
