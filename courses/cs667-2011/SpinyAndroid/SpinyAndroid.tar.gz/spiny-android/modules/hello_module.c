#include "linux/module.h"		/*needed for all modules*/
#include "linux/kernel.h"		/*required for printk*/

/*to refrain from tainting the kernel*/
MODULE_LICENSE("GPL");

int init_module(void){

	printk( KERN_INFO "Hello World \n" );

	return 0;
}


void cleanup_module(void){

	printk(KERN_INFO "\nexiting hello module");
}


