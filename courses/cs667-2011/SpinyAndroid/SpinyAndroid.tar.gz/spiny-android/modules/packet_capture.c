#include "linux/module.h"		/*needed for all modules*/
#include "linux/kernel.h"		/*required for printk*/

#include "linux/netfilter.h"		/*required for netfilter hooks*/
#include "linux/netfilter_ipv4.h"





/*to refrain from tainting the kernel*/
MODULE_LICENSE("GPL");



struct sr_ethernet_hdr
{
#ifndef ETHER_ADDR_LEN
#define ETHER_ADDR_LEN 6
#endif
    uint8_t  ether_dhost[ETHER_ADDR_LEN];    /* destination ethernet address */
    uint8_t  ether_shost[ETHER_ADDR_LEN];    /* source ethernet address */
    uint16_t ether_type;                     /* packet type ID */
} __attribute__ ((packed)) ;


#define ETHERNET_HEADER_LEN sizeof( struct sr_ethernet_hdr )


static struct nf_hook_ops incoming_hook;
static struct nf_hook_ops outgoing_hook;

/*kernel buffer to hold packet*/
static struct sk_buff *sock_buff;
static struct sr_ethernet_hdr mac_header;



unsigned int process_packet( unsigned int hooknum, struct sk_buff *skb /*pointer to pointer to socket kernel buffer*/, const struct net_device *in, const struct net_device *out, int (*okfn)(struct sk_buff *)){

	if( hooknum == NF_INET_LOCAL_IN )
		printk( KERN_INFO "\nin process packet  from hook IN %u:) \n",hooknum );
	else if( hooknum == NF_INET_LOCAL_OUT )
		printk( KERN_INFO "\nin process packet  from hook OUT %u:) \n",hooknum );

	/*get packet*/
	sock_buff = skb;
	
	/*validate packet*/
	if( sock_buff == NULL ){
		printk( KERN_INFO "\nskb NULL :( \n" );
		return NF_ACCEPT;	
	}

	printk( KERN_INFO "\npacket accepted :) \n" );

	printk( KERN_INFO "\nmac len %d",skb->mac_len );


	printk( KERN_INFO "\n len %d",skb->len );
	

	/*fetch raw packet, print mac header*/
	if( skb->mac_header == NULL ){
		printk( KERN_INFO "\nmac header null :(");
		return NF_ACCEPT;

	}

	memcpy( &mac_header, skb->mac_header, ETHERNET_HEADER_LEN );
	//memcpy( &mac_header, skb->data, ETHERNET_HEADER_LEN );

	printk( KERN_INFO "\nmac header fetched :) \n" );

	printk( KERN_INFO "\nether_shost %02x:%02x:%02x:%02x:%02x:%02x :) \n", mac_header.ether_shost[0],mac_header.ether_shost[1],mac_header.ether_shost[2],
		mac_header.ether_shost[3],mac_header.ether_shost[4],mac_header.ether_shost[5] );

	printk( KERN_INFO "\nether_dhost %02x:%02x:%02x:%02x:%02x:%02x :) \n", mac_header.ether_dhost[0],mac_header.ether_dhost[1],mac_header.ether_dhost[2],
		mac_header.ether_dhost[3],mac_header.ether_dhost[4],mac_header.ether_dhost[5] );
	
	
	
	return NF_ACCEPT;



}



int init_module(void){

	printk( KERN_INFO "Hello World \n" );

	/*register for hooks*/

	/*incoming hook init*/
	incoming_hook.list.next = NULL;
	incoming_hook.list.prev = NULL;
	incoming_hook.hook = process_packet;
	//incoming_hook.flush = NULL;
	incoming_hook.pf = PF_INET;
	incoming_hook.priority = NF_IP_PRI_FIRST;
	incoming_hook.hooknum = NF_INET_LOCAL_IN;
	

	/*outgoing hook init*/
	outgoing_hook.list.next = NULL;
	outgoing_hook.list.prev = NULL;
	outgoing_hook.hook = process_packet;
	//outgoing_hook.flush = NULL;
	outgoing_hook.pf = PF_INET;
	outgoing_hook.priority = NF_IP_PRI_FIRST;
	//outgoing_hook.hooknum = NF_INET_LOCAL_OUT;
	outgoing_hook.hooknum = NF_INET_POST_ROUTING;

	/*register incoming and outgoing hooks*/
	nf_register_hook( &incoming_hook );
	nf_register_hook( &outgoing_hook );

	return 0;
}


void cleanup_module(void){

	printk(KERN_INFO "\nexiting hello module");

	/*unregister hooks*/
	nf_unregister_hook( &incoming_hook );
	nf_unregister_hook( &outgoing_hook );
}


