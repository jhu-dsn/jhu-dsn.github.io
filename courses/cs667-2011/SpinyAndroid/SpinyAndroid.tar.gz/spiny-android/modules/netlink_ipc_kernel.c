#include "linux/module.h"		/*needed for all modules*/
#include "linux/kernel.h"		/*required for printk*/

#include "net/sock.h"
#include "linux/netlink.h"
#include "linux/skbuff.h"

#include "linux/string.h"

#include "linux/socket.h"

#define MAX_PAYLOAD 1024
#define NETLINK_NITRO 17


/*to refrain from tainting the kernel*/
MODULE_LICENSE("GPL");

static struct sock *netlink_socket;

static struct net netinet;

//static char buff[MAX_PAYLOAD];	


void nl_data_ready( struct sk_buff *skb ){

	struct nlmsghdr *nlh = NULL;

	printk( KERN_INFO "\ndata ready called\n ");

	if( skb == NULL ){
		printk( KERN_INFO "\nrecvd skb is NULL \n");
		return;	
	}

	nlh = (struct nlmsghdr *)skb->data;

	if( nlh == NULL ){
		printk( KERN_INFO "\nrecvd skb->nlh is NULL \n");
		return;	
	}
	//NLMSG_DATA( nlh ), NLMSG_PAYLOAD
	
	printk( KERN_INFO "\nreceived message from user %s\n",(char *)NLMSG_DATA(nlh));
	

}


int init_module(void){

	printk( KERN_INFO "initializing netlink socket \n" );


	memset( &netinet, 0, sizeof(netinet));

	/*define netlink socket*/
	netlink_socket = netlink_kernel_create( &netinet, NETLINK_ROUTE /*protocol*/, 0, nl_data_ready, NULL, THIS_MODULE /*pointer to invoked function*/ );

	if( netlink_socket == NULL ){
		printk( KERN_INFO "netlink socket creation error \n" );
		
	}
	else
		printk( KERN_INFO "netlink socket created \n" );



	return 0;
}


void cleanup_module(void){

	printk(KERN_INFO "\nexiting hello module\n");

}


