#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <assert.h>
#include <unistd.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <net/ethernet.h>

#include "linux/if_ether.h"
#include "linux/if_packet.h"
#include "sr_protocol.h"
#include "pcap.h"

//SPINES includes
#include "libspines/spines_lib.h"
#include "util/sp_events.h"
#include "util/alarm.h"

#ifndef INET_ADDRSTRLEN
#define INET_ADDRSTRLEN 16
#endif

#ifndef ETHER_ADDR_LEN
#define ETHER_ADDR_LEN 6
#endif

#ifndef MAC_SIZE
#define MAC_SIZE 6
#endif

#define SIZE_ETHERNET 14
#define MAX_PKT_SIZE 65535
#define SP_MAX_PKT_SIZE 100000

static char IP[80];
static char MCAST_IP[80];
static char SP_IP[80];

static int  spinesPort            = 8100;
static int  sendPort              = 8400;           
static int  recvPort              = 8400;
static int  Send_Flag             = 0;
static int  Protocol              = 0;
static int  ttl                   = 255;
static int  verbose_mode          = 1;
static int  reliable_connect      = 1;

/*This function prints ip address in string format*/
void print_ip( uint32_t *ip_address )
{
    char *ip;
    ip = malloc( INET_ADDRSTRLEN );
    struct in_addr ip_addr;
    ip_addr.s_addr = *ip_address;
    inet_ntop( AF_INET, &ip_addr, ip, INET_ADDRSTRLEN );
    printf("ip addr = %s\n",ip);
    free(ip);
}

void print_mac( uint8_t *mac_addr )
{
  printf("\nmac addr =  %02x:%02x:%02x:%02x:%02x:%02x\n",
      mac_addr[0],mac_addr[1],mac_addr[2],mac_addr[3],mac_addr[4],mac_addr[5]);
}


int main(int argc, char *argv[])
{
    pcap_t *handle;     /* Session handle */
    char *dev;      /* The device to sniff on */
    char errbuf[PCAP_ERRBUF_SIZE];  /* Error string */
    struct bpf_program fp;    /* The compiled filter */
    char filter_exp[] = "port 80";  /* The filter expression */
    bpf_u_int32 mask;   /* Our netmask */
    bpf_u_int32 net;    /* Our IP */
    struct pcap_pkthdr header;  /* The header that pcap gives us */
    const u_char *packet;   /* The actual packet */
    int sk, ret;
    int io_ip, io_ifindex;
    uint8_t io_mac[MAC_SIZE];
    uint32_t addr;

    struct ifreq ifr; 
    struct sockaddr_ll to;
    struct sockaddr_in serv_addr;
    
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PCAP~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    /* Define the device */
    dev = "eth1"; //pcap_lookupdev(errbuf);
    printf("dev = %s\n",dev);
    if (dev == NULL) {
      fprintf(stderr, "Couldn't find default device: %s\n", errbuf);
      return(2);
    }
    /* Find the properties for the device */
    if (pcap_lookupnet(dev, &net, &mask, errbuf) == -1) {
      fprintf(stderr, "Couldn't get netmask for device %s: %s\n", dev, errbuf);
      net = 0;
      mask = 0;
    }

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~MAC ADDRESS~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    memset(io_mac,0,MAC_SIZE);
    memset(&ifr,0,sizeof(struct ifreq));
    if ((sk = socket(AF_INET, SOCK_RAW, IPPROTO_RAW)) <= 0) {
      printf("error with creating socket for ifr\n");
      exit(1);
    }
    ifr.ifr_addr.sa_family = AF_INET;
    strcpy(ifr.ifr_name, dev);
    if (ioctl(sk, SIOCGIFADDR, &ifr) != 0) {
      printf("error with IFADDR\n");
      exit(1);
    }
    addr = ((struct sockaddr_in*)&ifr.ifr_addr)->sin_addr.s_addr;
    io_ip = htonl(addr);
    if (ioctl(sk, SIOCGIFINDEX, &ifr) != 0) {
      printf("error with IFINDEX\n");
      exit(1);
    }
    io_ifindex = ifr.ifr_ifindex;
    if (ioctl(sk, SIOCGIFHWADDR, &ifr) != 0) {
      printf("error with IFHWADDR\n");
      exit(1);
    }
    memcpy(io_mac, ifr.ifr_hwaddr.sa_data, MAC_SIZE);
    close(sk);

    /*printf( "ifr_name = %s\n", ifr.ifr_name);
    printf( "iface = %d\n",io_ifindex);
    print_ip(&io_ip);
    print_mac(io_mac);    */

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~SPINES SETUP~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    memcpy(&serv_addr.sin_addr.s_addr,(uint32_t*)(&io_ip),sizeof(uint32_t));
    serv_addr.sin_port = htons(spinesPort);

    print_ip(&serv_addr.sin_addr.s_addr);

    if (spines_init((struct sockaddr*)(&serv_addr)) < 0) {
      printf("spines_init failure\n");
      exit(1);
    }
    

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PCAP~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    /* Open the session in non-promiscuous mode */
    handle = pcap_open_live(dev, BUFSIZ, 0, 1000, errbuf);
    if (handle == NULL) {
      fprintf(stderr, "Couldn't open device %s: %s\n", dev, errbuf);
      return(2);
    }
    /* Compile and apply the filter */
    if (pcap_compile(handle, &fp, filter_exp, 0, net) == -1) {
      fprintf(stderr, "Couldn't parse filter %s: %s\n", filter_exp, pcap_geterr(handle));
      return(2);
    }
    if (pcap_setfilter(handle, &fp) == -1) {
      fprintf(stderr, "Couldn't install filter %s: %s\n", filter_exp, pcap_geterr(handle));
      return(2);
    }

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~MAIN LOOP~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    /* Grab a packet */
    printf("starting packet capture...\n");
    while (1) {
      packet = pcap_next(handle, &header);
      if (packet == NULL) {
        continue;
      }      
  
      struct sr_ethernet_hdr eth_hdr;
      memcpy(&eth_hdr,packet,ETHERNET_HEADER_LEN);
      uint32_t header_type = ntohs( eth_hdr.ether_type );

      struct sr_ip ip_hdr;
      struct sr_tcp_hdr tcp;

      if (header_type == 0x0800) {
        memcpy(&ip_hdr,packet+ETHERNET_HEADER_LEN,IP_HEADER_LEN); 
  
    switch(ip_hdr.ip_p) {
      case IPPROTO_TCP:
        memcpy(&tcp,packet + ETHERNET_HEADER_LEN + IP_HEADER_LEN,TCP_HEADER_LEN);
        if (ntohs(tcp.src_port) == 80) {

          if (memcmp( eth_hdr.ether_shost, eth_hdr.ether_dhost, ETHER_ADDR_LEN ) != 0) {
          /* Print its length */
          printf("Jacked a packet with length of [%d]\n", header.len);
          printf("   Protocol: TCP\n");
          printf("       From: %s\n", inet_ntoa(ip_hdr.ip_src));
          printf("         To: %s\n", inet_ntoa(ip_hdr.ip_dst));
          printf("   src_port = %d,  dst_port = %d\n", ntohs(tcp.src_port), ntohs(tcp.dest_port));

          sk = socket(PF_PACKET, SOCK_DGRAM, htons(ETH_P_IP));
          if (sk < 0) {
            printf("problem creating socket in TCP\n");
            exit(1);
          }    
          memset(&to,0,sizeof(to));
          to.sll_family = AF_PACKET;
          to.sll_protocol = htons(ETH_P_IP);
          to.sll_ifindex = io_ifindex;
          to.sll_halen = MAC_SIZE;
          memcpy(to.sll_addr, io_mac, MAC_SIZE);
          if (bind(sk, (struct sockaddr*) &to, sizeof(to)) < 0) {
            printf("bind failed\n");
            close(sk);
            exit(1);
          }
          ret = sendto(sk, packet+ETHERNET_HEADER_LEN, 
                header.len-ETHERNET_HEADER_LEN, 0, (struct sockaddr*)&to, sizeof(to));
          if (ret < 0) {
            printf("sendto failed\n");
            exit(1);
          }
          close(sk);
          printf("send packet to myself\n");
          printf("\n");
          }
          else {
            printf("i got my own packet\n\n");
          }
        }
        else if (ntohs(tcp.dest_port) == 80) {
          //Forward to spines...
          
        }
        break;
      case IPPROTO_UDP:
        /*printf("   Protocol: UDP\n");*/
        break;
      case IPPROTO_ICMP:
        /*printf("   Protocol: ICMP\n");*/
        break;
      case IPPROTO_IP:
        /*printf("   Protocol: IP\n");*/
        break;
      default:
        /*printf("   Protocol: unknown\n");*/
        break;
    } 
   
  }

      /* And close the session */
  }
    pcap_close(handle);
    return(0);
}



