#include "sys/socket.h"
#include "linux/netlink.h"
#include "string.h"
#include "stdio.h"
#include "stdlib.h"

#include "errno.h"

#define MAX_PAYLOAD 1024
#define NETLINK_NITRO 17

/*source and destination address for IPC communication*/
struct sockaddr_nl src_addr, dest_addr;

/*netlink message header, which would hold the header as well as payload*/
struct nlmsghdr *nlh = NULL;

/*would contain pointer to start of nlh*/
struct iovec iov;

/*the communication socket*/
int sock_fd;

int main(){

	/*create netlink socket*/
	sock_fd = socket( PF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
	if( sock_fd < 0 ){
		printf("\nsocket creation error");
		exit(0);
	}

	printf("\nnetlink socket created");

	/*reset source address struct*/	
	memset( &src_addr, 0, sizeof(src_addr));

	/*fill in source information*/
	src_addr.nl_family = AF_NETLINK;
	src_addr.nl_pid = getpid();
	src_addr.nl_groups = 0;
	
	/*bind source address to socket*/
	if( bind( sock_fd, (struct sockaddr *)&src_addr, sizeof(src_addr) )  < 0){
		printf("\nbind error");
		exit(0);

	};

	
	/*reset and fill destination address structure*/
	memset( &dest_addr, 0, sizeof(dest_addr) );

	dest_addr.nl_family = AF_NETLINK;
	dest_addr.nl_pid = 0;		/*for kernel*/
	dest_addr.nl_groups = 0;	/*unicast*/


	/*create space for header and payload*/
	nlh = (struct nlmsghdr *)malloc( NLMSG_SPACE(MAX_PAYLOAD) );

	/*fill the header*/
	nlh->nlmsg_len = NLMSG_SPACE(MAX_PAYLOAD);
	nlh->nlmsg_pid = getpid();	/*sender address*/
	nlh->nlmsg_flags = 0;

	/*fill in the message payload*/
	strcpy( NLMSG_DATA(nlh), "Hello Kernel :)");
	
	/*prepare iov*/
	iov.iov_base = (void *)nlh;
	iov.iov_len = nlh->nlmsg_len;

	/*eventually, now fill in the message struct*/
	struct msghdr msg;
	memset(&msg, 0, sizeof(msg));
	msg.msg_name = (void *)&dest_addr;
	msg.msg_namelen = sizeof(dest_addr);
	msg.msg_iov = &iov;
	msg.msg_iovlen = 1;

	/*send the message to kernel*/
	int ret = sendmsg(sock_fd, &msg, 0);
	if( ret <= 0 ){
		printf("\nerror sending message %d %s",ret, strerror(errno));	
		exit(0);
	}
	
	printf("\nmessage sent !");
 
	return 0;

}
