#include "stdio.h"
#include "stdlib.h"
#include "assert.h"

#include "sys/types.h"
#include "sys/socket.h"
#include "unistd.h"
#include "sys/select.h"
#include "netinet/in.h"
#include "netdb.h"
#include "net/if.h"
#include "sys/ioctl.h"

#include "linux/if_ether.h"
#include "linux/if_packet.h"
#include "sr_protocol.h"
#include "string.h"

//SPINES includes
#include "libspines/spines_lib.h"
#include "util/sp_events.h"
#include "util/alarm.h"

#ifndef INET_ADDRSTRLEN
#define INET_ADDRSTRLEN 16
#endif

#define MAX_PKT_SIZE 65535
#define SP_MAX_PKT_SIZE 65535

static char IP[80];
static char MCAST_IP[80];
static char SP_IP[80];
static char filename[80];
static int  fileflag;
static int  spinesPort;
static int  sendPort;
static int  recvPort;
static int  Send_Flag;
static int  Protocol;
static int  Group_Address;
static int  ttl;

int BindRawSocketToInterface(char *device, int rawsock, int protocol)
{
  
  struct sockaddr_ll sll;
  struct ifreq ifr;

  bzero(&sll, sizeof(sll));
  bzero(&ifr, sizeof(ifr));
  
  /* First Get the Interface Index  */

  strncpy((char *)ifr.ifr_name, device, IFNAMSIZ);
  if((ioctl(rawsock, SIOCGIFINDEX, &ifr)) == -1)
  {
    printf("Error getting Interface index !\n");
    exit(-1);
  }

  /* Bind our raw socket to this interface */
  sll.sll_family = AF_PACKET;
  sll.sll_ifindex = ifr.ifr_ifindex;
  sll.sll_protocol = htons(protocol); 


  if((bind(rawsock, (struct sockaddr *)&sll, sizeof(sll)))== -1)
  {
    perror("Error binding raw socket to interface\n");
    exit(-1);
  }

  return 1;
   
}

/*This function prints ip address in string format*/
void print_ip( uint32_t *ip_address )
{
    char *ip;
    ip = malloc( INET_ADDRSTRLEN );
    struct in_addr ip_addr;
    ip_addr.s_addr = *ip_address;
    inet_ntop( AF_INET, &ip_addr, ip, INET_ADDRSTRLEN );
    printf("   %s",ip);
    free(ip);
}

int main(){
	/*create a raw socket*/
	int raw_sockfd;

  int fd, ret;
  struct ifreq ifr;

  fd = socket(AF_INET, SOCK_DGRAM, 0);

  /* I want to get an IPv4 IP address */
  ifr.ifr_addr.sa_family = AF_INET;

  /* I want IP address attached to "eth0" */
  strncpy(ifr.ifr_name, "eth1", IFNAMSIZ-1);
  ioctl(fd, SIOCGIFADDR, &ifr);
  close(fd);

  /* display result */
  //printf("%s\n", inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr));
  //fflush(stdout);

	raw_sockfd = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
	if(raw_sockfd < 0){
		printf("\nsocket creation error code %d",raw_sockfd);
		exit(0);
	}
 
  int bindval = BindRawSocketToInterface("eth0",raw_sockfd,ETH_P_ALL);
  if (bindval < 0) {
    printf( "bind failed\n" );
    exit(1);
  }
  /*char name[5] = "hello";
  char test[5];
  printf("initially, name = %s\n", name); 
  ret = write(raw_sockfd,name,5);
  if (ret < 0) {
    printf( "write failed\n" );
    exit(1);
  }

  ret = read( raw_sockfd, test, 5);
  if (ret < 0) {
    printf( "recv failed\n" );
    exit(0);
  }
  printf("ret = %d, got ... %s\n",ret, name);  */


  void *buff = malloc( MAX_PKT_SIZE );
	assert(buff);		

	/*start sniffing packets*/
	while(1){

		ret = recvfrom( raw_sockfd, buff, MAX_PKT_SIZE, 0, NULL, NULL);

		/*check if atleast the ethernet header was read*/
		if( ret < ETHERNET_HEADER_LEN ){
			printf("\ncorrupted packet, ethernet header incomplete");
			free( buff );
			continue;
		}

		/*read ethernet header*/
		struct sr_ethernet_hdr eth_hdr;
		memcpy( &eth_hdr, buff, ETHERNET_HEADER_LEN );
		uint32_t header_type = ntohs( eth_hdr.ether_type );

		/*print ethernet header contents*/
		/*printf("\ndestination mac	%02x:%02x:%02x:%02x:%02x:%02x\n",eth_hdr.ether_dhost[0],eth_hdr.ether_dhost[1],
		eth_hdr.ether_dhost[2],eth_hdr.ether_dhost[3],eth_hdr.ether_dhost[4],eth_hdr.ether_dhost[5]);
		printf("source mac	%02x:%02x:%02x:%02x:%02x:%02x\n",eth_hdr.ether_shost[0],eth_hdr.ether_shost[1],
		eth_hdr.ether_shost[2],eth_hdr.ether_shost[3],eth_hdr.ether_shost[4],eth_hdr.ether_shost[5]);*/
		/*printf("type	%x", header_type);*/
		
    /* IP packets */
    if( header_type == 0x0800 ){

			struct sr_ip ip_hdr;
			memcpy( &ip_hdr, buff + ETHERNET_HEADER_LEN, IP_HEADER_LEN );
     
      //if ( ip_hdr.ip_dst.s_addr == ((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr.s_addr ) {
        // must forward to the application

        if (ip_hdr.ip_p == IPPROTO_TCP) {
          struct sr_tcp_hdr tcp_buff;
          memcpy( &tcp_buff, buff + ETHERNET_HEADER_LEN + IP_HEADER_LEN, TCP_HEADER_LEN );

          if ( ntohs(tcp_buff.src_port) == 80 || ntohs(tcp_buff.dest_port) == 80 ) {
			      printf("\nsource ip	==");
			      print_ip( &(ip_hdr.ip_src.s_addr) );
			      printf("\ndest ip	==");
			      print_ip( &(ip_hdr.ip_dst.s_addr) );
            printf("\n");
            printf("sport = %d, dport = %d\n", ntohs(tcp_buff.src_port), ntohs(tcp_buff.dest_port) );
            fflush(stdout);
          }
        }

      //}

      //else { // forward to spines to the gateway router
      //}
	  }

    /* ARP packet */
		else if( header_type == 0x0806 ){
			
			struct sr_arphdr arp_hdr;

			//memcpy( (struct sr_arphdr *)&arp_hdr, buff + ETHERNET_HEADER_LEN, ARP_HEADER_LEN );
			/*check whether ARP request or reply packet*/
			//unsigned short ar_op = ntohs( arp_hdr.ar_op );
			//if( ar_op == ARP_REQUEST )
			//	printf("\n ARP request packet");
			//else
			//	printf("\n ARP reply packet");
			/*print source and destination ip*/
			//printf("\nsource ip	%s", print_ip( &(arp_hdr.ar_sip.s_addr) ) );
			//printf("\ndest ip	%s", print_ip( &(arp_hdr.ar_tip.s_addr) ) );

		}
		else
			printf("\nunknown type");
			
	}

	free( buff );
	return 0;

}



