#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <assert.h>
#include <unistd.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <net/ethernet.h>

#include "linux/if_ether.h"
#include "linux/if_packet.h"
#include "sr_protocol.h"
#include "pcap.h"

//ALWAYS REQUIRES LIBPCAP library (See makefile)

//SPINES includes
#include "libspines/spines_lib.h"
#include "util/sp_events.h"
#include "util/alarm.h"

#ifndef INET_ADDRSTRLEN
#define INET_ADDRSTRLEN 16
#endif

#ifndef ETHER_ADDR_LEN
#define ETHER_ADDR_LEN 6
#endif

#ifndef MAC_SIZE
#define MAC_SIZE 6
#endif

#define SIZE_ETHERNET 14
#define MAX_PKT_SIZE 65535
#define SP_MAX_PKT_SIZE 100000

#define LOCAL_INTF_NAME "lo"
#define ETH_INTF_NAME "eth1"
#define LOCAL 0
#define ETH 1

static char IP[80];
static char MCAST_IP[80];
static char SP_IP[80];

static int  spinesPort            = 8100;
static int  sendPort              = 8400;           
static int  recvPort              = 8400;
static int  Send_Flag             = 0;
static int  Protocol              = 1;
static int  ttl                   = 255;
static int  verbose_mode          = 1;
static int  reliable_connect      = 1;
pcap_t* pcap_handle[2];
int spines_sk;

/*This function prints ip address in string format*/
void print_ip( uint32_t *ip_address )
{ 
    char *ip;
    ip = malloc( INET_ADDRSTRLEN );
    struct in_addr ip_addr;
    ip_addr.s_addr = *ip_address;
    inet_ntop( AF_INET, &ip_addr, ip, INET_ADDRSTRLEN );
    printf("ip addr = %s\n",ip);
    free(ip);
}

void print_mac( uint8_t *mac_addr )
{
  printf("\nmac addr =  %02x:%02x:%02x:%02x:%02x:%02x\n",
      mac_addr[0],mac_addr[1],mac_addr[2],mac_addr[3],mac_addr[4],mac_addr[5]);
}

int send_raw_ip_pkt(int raw_sk, char *pkt, int bytes)
{
    int ret;
    struct sockaddr_in sin;
    struct sr_ip   *ip;

    ip = (struct sr_ip*)pkt;

    memset(&sin, 0, sizeof(sin));
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = ip->ip_dst.s_addr;

    ret = sendto(raw_sk, pkt, bytes, 0, (struct sockaddr *)&sin, sizeof(sin));
    if (ret <= 0) {
        printf("send_raw_ip_pkt failed\n");
        exit(1);
    } 
    return ret;
}

void process_pcap_pkt(int sk, int port, void *dummy_p) {
  int ret, Wan_sk;
  struct pcap_pkthdr *header;
  const u_char *packet; 
  struct sockaddr_ll to;
  
  ret = pcap_next_ex(pcap_handle[port], &header, &packet);
  if (ret < 0) {
    printf("pcap_next_ex: error\n");
    exit(1);
  }      
  else if(ret == 0) {
    /* Timeout Elapsed */
    return;
  }  
  else {
    struct sr_ethernet_hdr eth_hdr;
    memcpy(&eth_hdr,packet,ETHERNET_HEADER_LEN);
    uint32_t header_type = ntohs( eth_hdr.ether_type );

    struct sr_ip ip_hdr;
    struct sr_tcp_hdr tcp;
    struct sr_udp_hdr udp;

    if (header_type == 0x0800) {
      memcpy(&ip_hdr,packet+ETHERNET_HEADER_LEN,IP_HEADER_LEN); 
  
      switch(ip_hdr.ip_p) {
        case IPPROTO_TCP:
          memcpy(&tcp,packet + ETHERNET_HEADER_LEN + IP_HEADER_LEN,TCP_HEADER_LEN);

          // WE ARE SENDING OUT A WWW PACKET
          if (ntohs(tcp.dest_port) == 80) {
            if (port == ETH) {
              // DO SOME THINGS HERE FOR GENERAL CASE
            }
            
            if (port == LOCAL) { 
              printf("LOCAL  ~~  ");
              printf("Jacked a packet with length of [%d]\n", header->len);
              printf("  From: %s\n", inet_ntoa(ip_hdr.ip_src));
              printf("  To: %s\n", inet_ntoa(ip_hdr.ip_dst));
              printf("  src_port = %d,  dst_port = %d\n", 
                    ntohs(tcp.src_port), ntohs(tcp.dest_port));

              /*Wan_sk = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
              if (Wan_sk < 0) {
                printf("Wan_sk error\n"); 
                exit(1);
              }
              send_raw_ip_pkt(Wan_sk,(char*)(packet+ETHERNET_HEADER_LEN),
                        (int)(header->len-ETHERNET_HEADER_LEN));
              close(Wan_sk);*/

              //ENCAPSULATE THIS PACKET INTO SPINES
              //SPINES_SEND
            }
          }
        
          // WE ARE GETTING BACK A WWW PACKET
          else if (ntohs(tcp.src_port) == 80) {
            if (memcmp( eth_hdr.ether_shost, eth_hdr.ether_dhost, ETHER_ADDR_LEN ) != 0) {
              /* Print its length */
              /*if (port == LOCAL) { printf("LOCAL  ~~  "); }
              if (port == ETH) { printf("ETH  ~~  "); }
              printf("Jacked a packet with length of [%d]\n", header->len);
              printf("  From: %s\n", inet_ntoa(ip_hdr.ip_src));
              printf("  To: %s\n", inet_ntoa(ip_hdr.ip_dst));
              printf("  src_port = %d,  dst_port = %d\n", 
                    ntohs(tcp.src_port), ntohs(tcp.dest_port));*/

              /*if (port == ETH) {
                sk = socket(PF_PACKET, SOCK_DGRAM, htons(ETH_P_IP));
                if (sk < 0) {
                  printf("problem creating socket in TCP\n");
                  exit(1);
                }    
                memset(&to,0,sizeof(to));
                to.sll_family = AF_PACKET;
                to.sll_protocol = htons(ETH_P_IP);
                to.sll_ifindex = io_ifindex;
                to.sll_halen = MAC_SIZE;
                memcpy(to.sll_addr, io_mac, MAC_SIZE);
                if (bind(sk, (struct sockaddr*) &to, sizeof(to)) < 0) {
                  printf("bind failed\n");
                  close(sk);
                  exit(1);
                }
                ret = sendto(sk, packet+ETHERNET_HEADER_LEN, 
                    header.len-ETHERNET_HEADER_LEN, 0, (struct sockaddr*)&to, sizeof(to));
                if (ret < 0) {
                  printf("sendto failed\n");
                  exit(1);
                }
                close(sk);
                printf("send packet to myself\n");*/
              //}
              //printf("\n");
            }
          }

          break;
        case IPPROTO_UDP:
          //if (port == LOCAL) { printf("LOCAL  ~~  \n\n"); }
          //if (port == ETH) { printf("ETH  ~~  \n\n"); }
          /*printf("   Protocol: UDP\n");*/
          break;
        case IPPROTO_ICMP:
          /*printf("   Protocol: ICMP\n");*/
          break;
        case IPPROTO_IP:
          /*printf("   Protocol: IP\n");*/
          break;
        default:
          /*printf("   Protocol: unknown\n");*/
          break;
      } 
    }
  }
} 
      
int main(int argc, char *argv[])
{
    int pcap_skt[2];
    char errbuf[PCAP_ERRBUF_SIZE];  /* Error string */
    struct bpf_program fp;    /* The compiled filter */
    char filter_exp[] = "port 80";  /* The filter expression */
    bpf_u_int32 mask;   /* Our netmask */
    bpf_u_int32 net;    /* Our IP */
    int sk, ret;
    int io_ip, io_ifindex;
    uint8_t io_mac[MAC_SIZE];
    uint32_t addr;

    struct ifreq ifr; 
    struct sockaddr_in host, serv_addr;
     
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~MAC ADDRESS~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    memset(io_mac,0,MAC_SIZE);
    memset(&ifr,0,sizeof(struct ifreq));
    if ((sk = socket(AF_INET, SOCK_RAW, IPPROTO_RAW)) <= 0) {
      printf("error with creating socket for ifr\n");
      exit(1);
    }
    ifr.ifr_addr.sa_family = AF_INET;
    strcpy(ifr.ifr_name, ETH_INTF_NAME);
    if (ioctl(sk, SIOCGIFADDR, &ifr) != 0) {
      printf("error with IFADDR\n");
      exit(1);
    }
    addr = ((struct sockaddr_in*)&ifr.ifr_addr)->sin_addr.s_addr;
    io_ip = htonl(addr);
    if (ioctl(sk, SIOCGIFINDEX, &ifr) != 0) {
      printf("error with IFINDEX\n");
      exit(1);
    }
    io_ifindex = ifr.ifr_ifindex;
    if (ioctl(sk, SIOCGIFHWADDR, &ifr) != 0) {
      printf("error with IFHWADDR\n");
      exit(1);
    }
    memcpy(io_mac, ifr.ifr_hwaddr.sa_data, MAC_SIZE);
    close(sk);

    /*printf( "ifr_name = %s\n", ifr.ifr_name);
    printf( "iface = %d\n",io_ifindex);
    print_ip(&io_ip);
    print_mac(io_mac);    */

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~SPINES SETUP~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    memcpy(&serv_addr.sin_addr.s_addr,(uint32_t*)(&io_ip),sizeof(uint32_t));
    serv_addr.sin_port = htons(spinesPort);

    if (spines_init((struct sockaddr*)(&serv_addr)) < 0) {
      printf("spines_init failure\n");
      exit(1);
    }
   
    spines_sk = spines_socket(PF_SPINES, SOCK_DGRAM, Protocol, NULL);
    if (spines_sk < 0) {
      printf("spines_sk creation error\n");
      exit(1);
    }
    

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PCAP for LOCAL LOOPBACK~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    /* Find the properties for the device */
    if (pcap_lookupnet(LOCAL_INTF_NAME, &net, &mask, errbuf) == -1) {
      fprintf(stderr, "Couldn't get netmask for device %s: %s\n", LOCAL_INTF_NAME, errbuf);
      net = 0;
      mask = 0;
    }
    /* Open the session in non-promiscuous mode */
    pcap_handle[LOCAL]= pcap_open_live(LOCAL_INTF_NAME, BUFSIZ, 0, 1000, errbuf);
    if (pcap_handle[LOCAL] == NULL) {
      fprintf(stderr, "Couldn't open device %s: %s\n", LOCAL_INTF_NAME, errbuf);
      return(2);
    }
    if(pcap_setnonblock(pcap_handle[LOCAL], 1, errbuf) == -1)
    { printf("pcap_setnonblock(): %s\n", errbuf); exit(1); }

    /* Compile and apply the filter */
    if (pcap_compile(pcap_handle[LOCAL], &fp, filter_exp, 0, net) == -1) {
      fprintf(stderr, "Couldn't parse filter %s: %s\n", filter_exp, 
          pcap_geterr(pcap_handle[LOCAL]));
      return(2);
    }
    if (pcap_setfilter(pcap_handle[LOCAL], &fp) == -1) {
      fprintf(stderr, "Couldn't install filter %s: %s\n", 
          filter_exp, pcap_geterr(pcap_handle[LOCAL]));
      return(2);
    }
    pcap_skt[LOCAL] = pcap_get_selectable_fd(pcap_handle[LOCAL]);
    if(pcap_skt[LOCAL] < 0) 
    { printf("Error getting pcap select socket\n"); exit(1); }

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PCAP for LAN (ETH)~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    /* Find the properties for the device */
    if (pcap_lookupnet(ETH_INTF_NAME, &net, &mask, errbuf) == -1) {
      fprintf(stderr, "Couldn't get netmask for device %s: %s\n", ETH_INTF_NAME, errbuf);
      net = 0;
      mask = 0;
    }
    /* Open the session in non-promiscuous mode */
    pcap_handle[ETH]= pcap_open_live(ETH_INTF_NAME, BUFSIZ, 0, 1000, errbuf);
    if (pcap_handle[ETH] == NULL) {
      fprintf(stderr, "Couldn't open device %s: %s\n", ETH_INTF_NAME, errbuf);
      return(2);
    }
    if(pcap_setnonblock(pcap_handle[ETH], 1, errbuf) == -1)
    { printf("pcap_setnonblock(): %s\n", errbuf); exit(1); }

    /* Compile and apply the filter */
    if (pcap_compile(pcap_handle[ETH], &fp, filter_exp, 0, net) == -1) {
      fprintf(stderr, "Couldn't parse filter %s: %s\n", filter_exp, 
          pcap_geterr(pcap_handle[ETH]));
      return(2);
    }
    if (pcap_setfilter(pcap_handle[ETH], &fp) == -1) {
      fprintf(stderr, "Couldn't install filter %s: %s\n", filter_exp, 
          pcap_geterr(pcap_handle[ETH]));
      return(2);
    }
    pcap_skt[ETH] = pcap_get_selectable_fd(pcap_handle[ETH]);
    if(pcap_skt[ETH] < 0) 
    { printf("Error getting pcap select socket\n"); exit(1); }

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~SET UP EVENTS~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    E_init();
    E_attach_fd(pcap_skt[LOCAL], READ_FD, process_pcap_pkt, LOCAL, NULL, LOW_PRIORITY );
    E_attach_fd(pcap_skt[ETH], READ_FD, process_pcap_pkt, ETH, NULL, LOW_PRIORITY );
    E_handle_events();
    return 1;
}

    


