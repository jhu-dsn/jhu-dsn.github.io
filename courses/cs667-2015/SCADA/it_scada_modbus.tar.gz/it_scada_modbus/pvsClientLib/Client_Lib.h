// Client_Lib.h
// JR Charles

#ifndef CLIENT_LIB_H
#define CLIENT_LIB_H

#define NUM_SERVERS 1
#define SERVER_NAMES { "localhost" }
#define SERVER_PORTS { 5050 }

// TODO: structs & functions for voting

#endif
