/*
 * TCP_Wrapper.c contains the definition of the 
 * methods used to read from/write to TCP sockets.
 *
 * Creator: Marco
 * Created: 3/30/2015
 * Last modified: 4/26/2015
 */

int passiveTCPsock(int, int);
int activeTCPsock(const char *, int);
int TCP_Read(int, void *, int);
int TCP_Write(int, void *, int);
