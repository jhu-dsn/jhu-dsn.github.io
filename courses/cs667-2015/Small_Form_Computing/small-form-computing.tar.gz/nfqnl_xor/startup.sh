#! /bin/bash

SRC_IP=""
DST_IP=""
PRG_NAME=""
IPTABLES_COMMAND="iptables -t mangle -I FORWARD"


display_usage(){
	
	echo "This script is used to insert required rules in iptables and start the ssl program"
	echo "\nUsage: $0 [-s <source IP> -d <destination ip> -n <program name>] \n"

}


clean_up(){

echo "cleaning up"
IPTABLE_DEL="iptables -t mangle -D FORWARD 1"
#Flush the iptables - delete previous two rules
$IPTABLE_DEL
$IPTABLE_DEL
}

#Display usage if less than two arguments supplied
if [ $# -le 3 ]
then 
	display_usage
	exit 1
fi



while getopts ":p:s:d:n:h:" OPT; do
	case "${OPT}" in
		p)
			PROTOCOL=${OPTARG};;
		s)
			SRC_IP=${OPTARG};;

		d)
			DST_IP=${OPTARG};;
		n)
			PRG_NAME=${OPTARG};;
		h)
			display_usage
			;;
	esac
done



COMMAND1="iptables -t mangle -I FORWARD -s $SRC_IP -d $DST_IP -j NFQUEUE --queue-num 0" #encrypt - from lan to wan, Dst will be other mchine 
COMMAND2="iptables -t mangle -I FORWARD -s $DST_IP -d $SRC_IP -j NFQUEUE --queue-num 1" #decrypt - wan to lan


echo $COMMAND1
echo $COMMAND2

trap clean_up SIGINT

#insert the rules into iptables 
$COMMAND1
$COMMAND2


#start the program 
$PRG_NAME




