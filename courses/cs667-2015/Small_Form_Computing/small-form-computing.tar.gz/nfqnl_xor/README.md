# Bump-In-The-Wire
On the fly encryption and decryption using two NEXX - 3020H mini routers  with OpenWRT

Should be compiled within the OpenWRT SDK

Necessary pacakges (to be installed on the router) include: iptables-mod-nfqueue kmod-ipt-nfqueue kmod-nfnetlink-queue kmod-nfnetlink libnfnetlink libnetfilter-queue.

Design: use Iptables rules (use mangle tables' forward chain) to send desired packets to the NFQUEUE target. then program will bind to queue and read from file descriptor as packets hit NFQUEUE.
