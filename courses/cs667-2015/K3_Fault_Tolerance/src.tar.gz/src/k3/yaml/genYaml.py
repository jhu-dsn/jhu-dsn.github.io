numBackups = 3
numPeers = 6
numPartitions = 12

peers = [ ["128.220.221.27", 30000], 
          ["128.220.221.27", 30001],
          ["128.220.221.27", 30002],
          ["128.220.221.26", 30000],
          ["128.220.221.26", 30001],
          ["128.220.221.26", 30002] ]

def intToAddr(i):
  return peers[i]

# Assign input data backups
uvBackups = {}
rkBackups = {}

joinPmap = {}
gbPmap = {}

for b in range(numBackups):
  for part in range(numPartitions):
    peer = (part + b) % numPeers
    addr = intToAddr(peer)

    if part not in uvBackups:
        uvBackups[part] = []
    uvBackups[part].append({'addr': addr})

    if part not in rkBackups:
      rkBackups[part] = []
    rkBackups[part].append({'addr': addr})

for part in range(numPartitions):
    peer = part % numPeers
    addr = intToAddr(peer)

    joinPmap[part] = addr
    gbPmap[part] = addr


for i in range(numPeers):
  path = "peer%d.yaml" % i
  with open(path, "w") as f:
    f.write("me: %s\n" % intToAddr(i))
    f.write("master: %s\n" % intToAddr(0))
    f.write("uv_path: tools/ktrace/data/uservisits\n")
    f.write("rk_path: tools/ktrace/data/rankings\n")
    f.write("uv_num: %d\n" % numPartitions)
    f.write("uv_backups:\n")
    for k,v in uvBackups.items():
      f.write("  - {key: %s, value: %s}\n" % (k,v))
    
    f.write("rk_num: %d\n" % numPartitions)
    f.write("rk_backups: \n")
    for k,v in rkBackups.items():
      f.write("  - {key: %s, value: %s}\n" % (k,v))
    
    # Dump pmaps
    f.write("join_num: %d\n" % numPartitions)
    f.write("join_pmap:\n")
    for k,v in joinPmap.items():
      f.write("  - {key: %s, value: %s}\n" % (k,v))
    
    f.write("gb_num: %d\n" % numPartitions)
    f.write("gb_pmap:\n")
    for k,v in gbPmap.items():
      f.write("  - {key: %s, value: %s}\n" % (k,v))
