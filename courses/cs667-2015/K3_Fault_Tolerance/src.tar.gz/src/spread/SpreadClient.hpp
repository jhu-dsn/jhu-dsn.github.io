/* Copyright 2015 damsl
 *
 *  Defines the Spread Client code to run alongside the K3 Event Loop.
 *  The Spread Client performs peer discovery during a startup protocol that waits for all processes to join a public group.
 *  Once all processes have joined, the program begins execution and any subsequent membership changes
 *  are forwarded along to the K3 Applicaton Level as a Message.
 *
 * */

#ifndef SPREADCLIENT_HPP
#define SPREADCLIENT_HPP

#include <stdio.h>
#include <stdlib.h>

#include <algorithm>
#include <cstring>
#include <list>
#include <map>
#include <memory>
#include <iostream>
#include <iterator>
#include <set>
#include <string>
#include <stdexcept>

#include "external/sp.h"
#include "Builtins.hpp"
#include "Context.hpp"

using std::cout;
using std::endl;
using std::list;
using std::set;
using std::shared_ptr;
using std::string;
using std::map;

using K3::__spread_context;


void globalReadMessage(int a, int b, void* c);
void globalTimeout(int a, int b, void* c);

#define MESSAGE_SIZE 1000
#define MAX_PEER_NAME 30
#define READY_MSG 'R'
#define LATE_MSG 'L'
#define SHUTDOWN_MSG 'S'

struct Message {
  char tag;
  char payload[MESSAGE_SIZE - sizeof(char)];
};


struct Ready {
  int membership_id[3];
  int num_local_peers;
  char local_peers[MESSAGE_SIZE - sizeof(char) - 4*sizeof(int)];
};


class SpreadClient {
 private:
  SpreadClient() {}
  SpreadClient(SpreadClient const&) = delete;     // No copies of Singleton
  void operator=(SpreadClient const&) = delete;   // No copies of Singleton

  // Spread configuration
  mailbox      spread_mailbox_;
  bool         spread_connected_ = false;
  string       spread_username_  = "";
  string       spread_connection_str_ = "";
  string       spread_private_group_ = "";
  string       spread_public_group_;
  int          spread_pipein_;
  int          spread_pipeout_;

  // K3 Program State
  int         timeout_ = 0;
  enum class State { INIT, WAITING, READY, STARTED, FINISHED };
  State       program_state_ = State::INIT;
  set<string> all_processes_;
  set<string> current_processes_;
  int         current_membership_id_[3];
  set<string> expecting_ready_;
  set<string> local_peers_;
  map<string, set<string>> peers_by_process_;
  list<shared_ptr<__spread_context>> local_contexts_;

 public:
  static SpreadClient& getInstance();
  bool isConnected();
  bool connect(const string& username, const string& connection_str);
  bool joinGroup(const string& group_name);
  void printSpreadStatus();
  void printProgramStatus();
  void run(const set<string>& all_processes, const set<string>& local_peers,
           const list<shared_ptr<__spread_context>>& contexts);
  void readMessage();
  void onTimeout();
  int  numMissingProcesses();
  void sendReady();
  string currentState();
  void notifyK3();
  void sendShutdown();
  void shutdownK3();
  void terminate();
  void interrupt();
};


#endif  // SPREADCLIENT_HPP
