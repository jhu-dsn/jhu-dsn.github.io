/* Copyright 2015 damsl */

#include <unistd.h>

#include <string>
#include <list>
#include <set>

#include "SpreadClient.hpp"

#define MAX_MESSLEN     102400
#define MAX_VSSETS      10
#define MAX_MEMBERS     100


void globalReadMessage(int _a, int _b, void* _c) {
  SpreadClient& c = SpreadClient::getInstance();
  c.readMessage();
}

void globalTimeout(int code,  void* _c) {
  SpreadClient& c = SpreadClient::getInstance();
  c.onTimeout();
}

void globalStop(int _a, int code, void* _c) {
  SpreadClient& c = SpreadClient::getInstance();
  c.terminate();
}

SpreadClient& SpreadClient::getInstance() {
  static SpreadClient instance;
  return instance;
}

bool SpreadClient::isConnected() { return spread_connected_; }

bool SpreadClient::connect(const string& username,
                           const string& connection_str) {
  if ( spread_connected_ ) {
    string err = "Error: connecting to Spread while already connected";
    std::cout << err << std::endl;
    return false;
  }

  // Initialize
  int ret;
  sp_time connect_timeout;
  connect_timeout.sec = 5;
  connect_timeout.usec = 0;

  if ( username.length() >= MAX_GROUP_NAME ) {
    string err = "Spread error. Requested username longer than MAX_GROUP_NAME";
    throw std::runtime_error(err);
  }

  if ( connection_str.length() >= MAX_GROUP_NAME ) {
    string err = "Spread error. Connection string longer than MAX_GROUP_NAME";
    throw std::runtime_error(err);
  }

  char user[MAX_GROUP_NAME];
  char spread_name[MAX_GROUP_NAME];
  snprintf(user, MAX_GROUP_NAME, "%s", username.c_str());
  snprintf(spread_name, MAX_GROUP_NAME, "%s", connection_str.c_str());

  // Connect
  char private_group[MAX_GROUP_NAME];
  ret = SP_connect_timeout(spread_name, user, 0, 1,
                           &spread_mailbox_, private_group, connect_timeout);

  if ( ret != ACCEPT_SESSION ) {
    SP_error(ret);
    return false;
  }

  // Succesfully connected
  spread_connected_ = true;
  spread_username_ = username;
  spread_connection_str_ = connection_str;
  spread_private_group_ = string(private_group);

  return true;
}

bool SpreadClient::joinGroup(const string& group_name) {
  if ( spread_public_group_ != "" ) {
    std::cout << "Error: cannot join group " << group_name
              << " because there is already a current group: "
              << spread_public_group_ << std::endl;
    return false;
  }

  if ( group_name.length() >= MAX_GROUP_NAME ) {
    throw std::runtime_error("Spread error. Can't join group: name too long.");
  }

  int ret = SP_join(spread_mailbox_, group_name.c_str());

  if ( ret < 0 ) {
    SP_error(ret);
    return false;
  }

  spread_public_group_ = group_name;
  return true;
}

void SpreadClient::printSpreadStatus() {
  using std::cout;
  using std::endl;

  cout << "Spread Client Status:" << endl;

  if ( !spread_connected_ ) {
    cout << "\tNot Connected." << endl;
    return;
  }

  cout << "\tUsername: " << spread_username_ << endl;
  cout << "\tConnection Str: " << spread_connection_str_ << endl;
  cout << "\tPrivate Group: " << spread_private_group_ << endl;

  cout << "\tPublic Group: " << spread_public_group_ << endl;
}

void SpreadClient::printProgramStatus() {
  using std::cout;
  using std::endl;

  switch (program_state_) {
    case State::INIT:
      cout << "Program State: INIT" << endl;
      break;

    case State::WAITING:
      cout << "Program State: WAITING" << endl;
      cout << "Expecting " << this->numMissingProcesses()
           << " more processes" << endl;
      cout << "\t" << "membership id: " << current_membership_id_[0]
           << " " << current_membership_id_[1] << " "
           << current_membership_id_[2] << endl;
      break;

    case State::READY:
      cout << "Program State: READY" << endl;
      cout << "\t" << "membership id: " << current_membership_id_[0]
           << " " << current_membership_id_[1] << " "
           << current_membership_id_[2] << endl;
      break;

    case State::STARTED:
      cout << "Program State: STARTED" << endl;
      cout << "\t" << "membership id: " << current_membership_id_[0]
           << " " << current_membership_id_[1] << " "
           << current_membership_id_[2] << endl;
      break;
  }
}

void SpreadClient::run(const set<string>& all_processes,
                       const set<string>& local_peers,
                       const list<shared_ptr<__spread_context>>& contexts) {
  if ( !this->isConnected() ) {
    string err = "Spread Error: not connected. can't handle events";
    std::cout << err << std::endl;
    return;
  }

  // Stash the set of all processes to wait for
  all_processes_ = all_processes;
  local_peers_ = local_peers;
  local_contexts_ = contexts;
  int pipefd[2];
  if (pipe(pipefd) == -1) {
    perror("pipe error");
    exit(1);
  }
  spread_pipein_ = pipefd[0];
  spread_pipeout_ = pipefd[1];

  E_init();
  E_attach_fd(spread_mailbox_, READ_FD,
              globalReadMessage, 0, NULL, HIGH_PRIORITY);
  E_attach_fd(spread_pipein_, READ_FD, globalStop, 0, NULL, HIGH_PRIORITY);
  std::cout << "Starting event loop and WAITING for other processes"
            << std::endl;

  program_state_ = State::WAITING;

  if ( timeout_ != 0 ) {
    sp_time join_timeout;
    join_timeout.sec = 5;
    join_timeout.usec = 0;

    E_queue(globalTimeout, 0, 0, join_timeout);
  }

  E_handle_events();
}

void SpreadClient::readMessage() {
  // TODO(jbw) all of this should be allocated only once. not at each call.
  char             mess[MAX_MESSLEN];
  char             sender[MAX_GROUP_NAME];
  char             target_groups[MAX_MEMBERS][MAX_GROUP_NAME];
  membership_info  memb_info;
  vs_set_info      vssets[MAX_VSSETS];
  unsigned int     my_vsset_index;
  int              num_vs_sets;
  char             members[MAX_MEMBERS][MAX_GROUP_NAME];
  int              num_groups;
  int              service_type;
  int16            mess_type;
  int              endian_mismatch;
  int              i, j;
  int              ret;

  string msg = "---------Receieved a Message from Spread-------";
  std::cout <<  msg << std::endl;
  std::cout << "Current State: " << this->currentState() << std::endl;

  // Receive a message
  ret = SP_receive(spread_mailbox_, &service_type, sender, 100,
                   &num_groups, target_groups, &mess_type,
                   &endian_mismatch, sizeof(mess), mess);

  // Check for errors
  if ( ret < 0 ) {
    if ( (ret == GROUPS_TOO_SHORT) || (ret == BUFFER_TOO_SHORT) ) {
      service_type = DROP_RECV;
      printf("\n========Buffers or Groups too Short=======\n");
      ret = SP_receive(spread_mailbox_, &service_type, sender, MAX_MEMBERS,
                       &num_groups, target_groups, &mess_type, &endian_mismatch,
                       sizeof(mess), mess);
    }
  }

  if ( ret < 0 ) {
    SP_error(ret);
    throw std::runtime_error("Spread Error.");
  }

  // Membership Change
  if ( Is_membership_mess(service_type) ) {
    ret = SP_get_memb_info(mess, service_type, &memb_info);

    if (ret < 0) {
      printf("BUG: membership message does not have valid body\n");
      SP_error(ret);
      throw std::runtime_error("Spread Error.");
    }

    // Regular membership
    if ( Is_reg_memb_mess(service_type) ) {
      // Update the current set of processes and membership id.
      current_processes_.clear();
      char name[MAX_GROUP_NAME];
      for ( i = 0; i < num_groups; i++ ) {
        printf("\t%s\n", &target_groups[i][0]);
        sscanf(&target_groups[i][0], "#%[^#]s", name);
        current_processes_.insert(string(name));
      }

      current_membership_id_[0] = memb_info.gid.id[0];
      current_membership_id_[1] = memb_info.gid.id[1];
      current_membership_id_[2] = memb_info.gid.id[2];

      if ( program_state_ == State::READY ) {
        string msg = "Membership change in READY state. ";
        std::cout << msg << std::endl;
        if ( this->numMissingProcesses() == 0 ) {
          this->sendReady();
        } else {
          string msg = "Not all members are present. Moving back to WAITING";
          std::cout << msg << std::endl;
          program_state_ = State::WAITING;
        }
      } else if ( program_state_ == State::WAITING ) {
        if ( this->numMissingProcesses() == 0 ) {
          string msg = "All processes are present. Need to send ready message";
          std::cout << msg << std::endl;
          this->sendReady();
        } else {
          std::cout << "Expecting " << this->numMissingProcesses()
                    << " more processes" << std::endl;
        }
      } else if ( program_state_ == State::STARTED ) {
        // TODO(jbw) send a "too late" message on a join here?
        this->notifyK3();
        return;
      } else {
        std::cout << "Received membership change while in unexpected state: "
                  << this->currentState()  << std::endl;
        throw std::runtime_error("Spread error.");
      }
    } else if ( Is_transition_mess(service_type) ) {
      printf("received TRANSITIONAL membership for group %s\n", sender);
    } else if ( Is_caused_leave_mess(service_type) ) {
      printf("received membership message that left group %s\n", sender);
    } else {
      printf("received incorrecty membership message of type 0x%x\n",
             service_type);
    }
  } else if ( Is_regular_mess(service_type) ) {
    mess[ret] = 0;

    char tag = mess[0];
    if ( tag == READY_MSG ) {
      if ( program_state_ == State::STARTED ) {
        // TODO(jbw) send too late?
        std::cout << "Receieved ready signal while in STARTED state. Ignoring."
                  << std::endl;
        return;
      }

      Ready* rdy = reinterpret_cast<Ready *>(&mess[1]);
      if ( rdy->membership_id[0] != current_membership_id_[0]
        || rdy->membership_id[1] != current_membership_id_[1]
        || rdy->membership_id[2] != current_membership_id_[2] ) {
        std::cout << "Rejecting ready message with old membership id"
                  << std::endl;
        return;
      }

      char name[MAX_GROUP_NAME];
      sscanf(sender, "#%[^#]s", name);
      string peer = string(name);

      std::cout << "Receieved ready message from " << peer << std::endl;
      std::cout << "Its peer set is: " << std::endl;

      int num_peers = rdy->num_local_peers;
      set<string> sender_peers;
      char buf[MAX_PEER_NAME];
      for ( int i = 0; i < num_peers; i++ ) {
        int offset = i * MAX_PEER_NAME;
        snprintf(buf, MAX_PEER_NAME, "%s", &rdy->local_peers[offset]);
        sender_peers.insert(string(buf));
        std::cout << buf << std::endl;
      }

      peers_by_process_[peer] = sender_peers;

      if ( program_state_ == State::WAITING ) {
        // Receieved timeout from someone else
        this->sendReady();
        // Program state will move to READY
      }

      if ( program_state_ == State::READY ) {
        expecting_ready_.erase(peer);
        int remaining = expecting_ready_.size();
        std::cout << "Expecting " << remaining
                  << " more ready messages." << std::endl;

        if ( remaining == 0 ) {
          std::cout << "Starting Program with current membership!" << std::endl;
          this->notifyK3();
          program_state_ = State::STARTED;
        }
      } else {
        std::cout << "Receieved ready signal while in unexpected state: "
                  << this->currentState() << std::endl;
        throw std::runtime_error("Spread Error.");
      }
    } else if ( tag == SHUTDOWN_MSG ) {
      std::cout << "Received shutdown message from Spread" << std::endl;
      if ( program_state_ != State::STARTED ) {
	string msg = "Error: received shutdown but program is not STARTED";
        std::cout << msg << std::endl;
      }

      this->shutdownK3();
      program_state_ = State::FINISHED;
    } else {
      std::cout << "Received regular message with unknown tag: "
                << tag << std::endl;
      throw std::runtime_error("Spread Error.");
    }
  } else {
    std::cout << "Receieved unknown message type" << std::endl;
    throw std::runtime_error("Spread Error.");
  }

  this->printProgramStatus();
}

int SpreadClient::numMissingProcesses() {
  // Check how many of the desired processes are present
  list<string> intersect;
  set_intersection(current_processes_.begin(), current_processes_.end(),
                   all_processes_.begin(), all_processes_.end(),
                   std::back_inserter(intersect));
  int cur = intersect.size();
  int all = all_processes_.size();

  return all - cur;
}


// Multicast a "Ready" message to the public group.
// Containing the current membership id and the set of local peers
void SpreadClient::sendReady() {
  // TODO(jbw) Don't allocate at every call
  Message m;
  m.tag = READY_MSG;

  Ready* rdy = reinterpret_cast<Ready *>(m.payload);
  // Set membership id
  rdy->membership_id[0] = current_membership_id_[0];
  rdy->membership_id[1] = current_membership_id_[1];
  rdy->membership_id[2] = current_membership_id_[2];
  int mess_len = sizeof(char) + 3 * sizeof(int);

  // Set local peers
  rdy->num_local_peers = local_peers_.size();
  mess_len += sizeof(int);

  int i = 0;
  for ( const string& peer : local_peers_ ) {
    if ( peer.length() + 1 > MAX_PEER_NAME ) {
      std::cout << "Peer name " << peer << " longer than "
                << MAX_PEER_NAME - 1 << " characters." << std::endl;
      throw std::runtime_error("Spread Error.");
    }
    snprintf(&rdy->local_peers[(MAX_PEER_NAME) * i],
             MAX_PEER_NAME, "%s", peer.c_str());
    i++;
    mess_len += MAX_PEER_NAME;
  }

  if ( mess_len > MESSAGE_SIZE ) {
    std::cout << "Error, ready message too large. Num bytes: "
              << mess_len << std::endl;
    throw std::runtime_error("Spread Error.");
  }

  std::cout << "Sending a Ready message for MembershipID: "
            << rdy->membership_id[0] << " "
            << rdy->membership_id[1] << " "
            << rdy->membership_id[2] << std::endl;

  int ret = SP_multicast(spread_mailbox_, AGREED_MESS,
                         spread_public_group_.c_str(),
                         2, mess_len, reinterpret_cast<char *>(&m));


  if ( ret < 0 ) {
    SP_error(ret);
    throw std::runtime_error("Spread error.");
  }

  expecting_ready_ = all_processes_;
  program_state_ = State::READY;

  // No longer need to fire timeout
  E_dequeue(globalTimeout, 0, 0);
}

string SpreadClient::currentState() {
  switch ( program_state_ ) {
    case State::INIT: return "INIT";
    case State::WAITING: return "WAITING";
    case State::READY: return "READY";
    case State::STARTED: return "STARTED";
  }
}

void SpreadClient::onTimeout() {
  std::cout << "----Receieved Timeout from Spread-----" << std::endl;
  std::cout << "Current State: " << this->currentState() << std::endl;
  std::cout << "Sending ready message due to timeout" << std::endl;
  this->sendReady();
}

void SpreadClient::notifyK3() {
  set<string> all_peers;
  for ( const string& proc : current_processes_ ) {
    auto it = peers_by_process_.find(proc);
    if ( it != peers_by_process_.end() ) {
      for ( const string& peer : it->second ) {
        all_peers.insert(peer);
      }
    } else {
      throw std::runtime_error("Spread error. Process has no associated peers");
    }
  }

  for ( const auto& ctxt : local_contexts_ ) {
    ctxt->__membership(all_peers);
  }
}

void SpreadClient::shutdownK3() {
  set<string> all_peers;
  for ( const string& proc : current_processes_ ) {
    auto it = peers_by_process_.find(proc);
    if ( it != peers_by_process_.end() ) {
      for ( const string& peer : it->second ) {
        all_peers.insert(peer);
      }
    } else {
      throw std::runtime_error("Spread error. Process has no associated peers");
    }
  }

  this->terminate();
  for ( const auto& ctxt : local_contexts_ ) {
    ctxt->__shutdownEngine();
  }
}

void SpreadClient::terminate() {
  if ( spread_connected_ ) {
    E_exit_events();
    SP_disconnect(spread_mailbox_);
    spread_connected_ = false;
  }
}

void SpreadClient::interrupt() {
  write(spread_pipeout_, "\n", 1);
}

void SpreadClient::sendShutdown() {
  Message m;
  m.tag = SHUTDOWN_MSG;
  int mess_len = 1;

  int ret = SP_multicast(spread_mailbox_, AGREED_MESS,
                         spread_public_group_.c_str(),
                         2, mess_len, reinterpret_cast<char *>(&m));

  if ( ret < 0 ) {
    SP_error(ret);
    throw std::runtime_error("Spread error.");
  }
}
