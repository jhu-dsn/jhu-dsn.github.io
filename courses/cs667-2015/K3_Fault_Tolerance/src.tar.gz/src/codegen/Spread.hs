{-# LANGUAGE ViewPatterns #-}
{-# LANGUAGE LambdaCase #-}

-- This Module looks for @:Memberhsip properties attached to
-- a trigger's lambda function. When found, it generates code to 
-- forward messages from the Spread client to the K3 Program Context

module Language.K3.Codegen.CPP.Spread where

import Data.Maybe (isJust)

import Language.K3.Core.Annotation
import Language.K3.Core.Expression
import Language.K3.Core.Declaration

import Language.K3.Codegen.CPP.Preprocessing (idOfTrigger)
import qualified Language.K3.Codegen.CPP.Representation as R

-- If the trigger has the @:Membership property
-- Generate a function that takes a set of strings and
-- converts them to addresses to send to the provided trigger
spread :: K3 Declaration -> [R.Definition]
spread d@(tag -> DTrigger i _ e) =  do
  let functionDefn = R.FunctionDefn (R.Name "__membership") 
                       [("peer_strs", R.Const $ R.Reference $ R.Named $ R.Specialized [R.Named $ R.Name "string"] (R.Name "set"))]
                       (Just $ R.Void)
                       []
                       False
                       [peersDecl, dispatcherDecl, sendCall]
      hasSpreadProperty = \case { EProperty (ePropertyName -> "Membership") -> True; _ -> False }
  if isJust$ e @~ hasSpreadProperty  then [functionDefn] else []
    where 
      -- Convert the strings to addresses and store them in a variable named "peers"
      peersDecl = R.Forward $ R.ScalarDecl (R.Name "peers") 
                    R.Inferred 
                    (Just $ R.Call 
                             (R.Variable $ R.Name "stringsToAddresses") 
                             [R.Variable $ R.Name "peer_strs"]
                    )
      -- Create a message dispatcher "d" containing the addresses 
      messageType  = R.Named $ R.Specialized 
                                 [R.Named $ R.Specialized 
                                              [R.Named $ R.Name "Address"] 
                                              (R.Name "R_addr")
                                 ] 
                                 (R.Name "_Set") 
      dispatcherType = R.Named $ R.Specialized 
                                   [messageType] 
                                   (R.Qualified (R.Name "K3" ) $ R.Name "ValDispatcher")
      dispatcherDecl = R.Forward $ R.ScalarDecl (R.Name "d") 
                         R.Inferred
                         (Just $ R.Call 
                                   (R.Variable $ R.Specialized 
                                                   [dispatcherType]
                                                   (R.Qualified (R.Name "std" ) $ R.Name "make_shared")
                                   ) 
                                  [R.Variable $ R.Name "peers"]
                         )
      --  Send "d" to the the trigger
      sendCall = R.Ignore $ R.Call 
                              (R.Project (R.Variable $ R.Name "__engine") (R.Name "send")) 
                              [ (R.Variable $ R.Name "me") 
                              , R.Variable (R.Name $ idOfTrigger i)
                              , R.Variable (R.Name "d")
                              , R.Variable (R.Name "me")
                              ]
spread _ = []
