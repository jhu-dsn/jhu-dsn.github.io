#!/bin/bash

#$1 = num start, $2 = index start, $3 start with this routing alg, $4 start with this config, $5 ssh url, $6 folder here, $7 compile all or just one

#check to see if you need to pull and compile for all of them
C=$((1))
if [ "$7" == every ]
then
	C=$(($1))
fi
IFS=":" read -a addr <<< "$5"
if [ ! -z "${addr[1]}" ]
then
	port="-p ${addr[1]}"
fi
IFS='#' read -a ssha <<< "${addr[0]}"
#pull, build, and compile
for ((i = 0; i<$C; i++))
do
	ssh ${port} -t "${ssha[0]}$(($i+$2))${ssha[1]}" "cd $6; git pull; make clean; make $3"
done

#launch 
for ((i = 0; i<$1; i++))
do
	xterm -e ssh ${port} -t "${ssha[0]}$(($i+$2))${ssha[1]}" "cd $6; ./server -net $4 -ind $(($i+1)) -s2s 4000 -s2c 4001 -c2s 4002; bash" &
done

