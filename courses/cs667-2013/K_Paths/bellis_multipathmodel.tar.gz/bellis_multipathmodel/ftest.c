#include "commondefs.h"

void usage(int argc, char* argv[], struct sockaddr_in* to) {
	char name[32];
	struct hostent* host;
	while (--argc > 0) {
		argv++;
		if(!strncmp( *argv, "-f", 2)) {
			if (strlen(argv[1]) > 32) {
				printf("funnel ip or hostname is too long\n");
				exit(1);
			}
			sscanf(argv[1], "%s", name);
			host = gethostbyname(name);
			memcpy(&(to->sin_addr.s_addr), host->h_addr_list[0], sizeof(host->h_length));
			argc--;
			argv++;
		} else {
			printf("usage: funnel\n"
				"\t-f <funnel> : the funnel's ip or resolvable hostname (REQUIRED)\n");
		}
		
	}
}

int main(int argc, char* argv[]) {
	struct sockaddr_in to;
	struct sockaddr_in from;
	fd_set mask;
	fd_set dummy_mask,temp_mask;
	int sr, ss;
	int num;
	int size;
	char buffer[DATA_SIZE + 1];
	
	to.sin_family = AF_INET; 
	to.sin_addr.s_addr = htonl(INADDR_LOOPBACK); 
	to.sin_port = htons(FUNNEL_IN_PORT);
	
	from.sin_family = AF_INET; 
	from.sin_addr.s_addr = htonl(INADDR_ANY); 
	from.sin_port = htons(FUNNEL_OUT_PORT);
	
	usage(argc, argv, &to);
	
	sr = socket(AF_INET, SOCK_DGRAM, 0); /* socket for receiving */
	if (sr<0) {
		perror("Couldn't create socket to receive from server");
		exit(1);
	}
	
	if ( bind( sr, (struct sockaddr *)&from, sizeof(from) ) < 0 ) {
		perror("Couldn't bind socket to receive from server");
		exit(1);
	}
	
	ss = socket(AF_INET, SOCK_DGRAM, 0); /* socket for sending */
	if (ss<0) {
		perror("Couldn't create socket to receive from application funneling packets onto model");
		exit(1);
	}
	
	FD_ZERO( &mask );
	FD_ZERO( &dummy_mask );
	FD_SET( sr, &mask );
	FD_SET( (long)0, &mask );
	for (;;) {
		temp_mask = mask;
		num = select( FD_SETSIZE, &temp_mask, &dummy_mask, &dummy_mask, NULL);
		if (num > 0) {
			if ( FD_ISSET( sr, &temp_mask) ) {
				//receiving from server
				size = recv( sr, buffer, DATA_SIZE, 0 );
				buffer[size] = '\0';
				printf("received: %s", buffer);
			} else if ( FD_ISSET( 0, &temp_mask) ) {
				//send to server
				size = read(0, buffer, DATA_SIZE);
				buffer[size] = '\0';
				printf("testing: %s", buffer);
				sendto(ss, buffer, size, 0, (struct sockaddr *)&to, sizeof(to));
			}
		}
	}
}
