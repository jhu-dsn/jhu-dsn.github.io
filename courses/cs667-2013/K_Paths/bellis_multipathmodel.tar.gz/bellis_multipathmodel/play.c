#include "commondefs.h"
#include <sys/time.h>

#define NAME_LEN 100

static int Port;
static char IP[NAME_LEN];
static char Filename[NAME_LEN];

int gethostname(char*,size_t);
static void Usage(int argc, char *argv[]);
static struct timeval addTime( struct timeval t1, struct timeval t2 );
static int compTime( struct timeval t1, struct timeval t2 );

int main(int argc, char *argv[])
{
    FILE                    *fr;
    char                    buf[DATA_SIZE];
    int                     nread, ss, started = 0;
    int                     currBytes, nextBytes;
    struct sockaddr_in      send_addr;
    struct timeval          start, now, timeout;
    struct timeval          currFrame, nextFrame;
    struct hostent          h_ent, *host_ptr;
    //char                    machine_name[256];
    //fd_set                  mask, dummy_mask, temp_mask;

    Usage(argc, argv);

    if((fr = fopen(Filename, "r")) == NULL) {
        perror("playback: fopen");
        exit(1);
    }

    ss = socket(AF_INET, SOCK_DGRAM, 0);
    if (ss<0) {
        perror("playback: socket");
        exit(1);
    }

    send_addr.sin_family = AF_INET; 
    send_addr.sin_port = htons(Port);

    if(strcmp(IP, "") != 0) {
        host_ptr = gethostbyname(IP);
        memcpy( &h_ent, host_ptr, sizeof(h_ent) );
        memcpy( &send_addr.sin_addr.s_addr, h_ent.h_addr_list[0], sizeof(struct in_addr) );
    }
    else {
        send_addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    }

    //FD_ZERO( &mask );
    //FD_ZERO( &dummy_mask );
    //FD_SET( (long)0, &mask ); /* stdin */
    
    /* Initializing the read chain */
    nread = fread(&currFrame, 1, sizeof(currFrame), fr);
    if (nread != sizeof(currFrame)) {
        printf("playback: invalid initial timeval read\n");
        exit(1);
    }
    nread = fread(&currBytes, 1, sizeof(currBytes), fr);
    if (nread != sizeof(currBytes)) {
        printf("playback: invalid initial size read: nread = %d currBytes = %d\n",
                    nread, currBytes);
        exit(1);
    }
    
    /* check for EOF and end of stream markers */
    if (currBytes == 0 && currFrame.tv_sec == 0 && currFrame.tv_usec == 0) {
        printf("playback: no valid initial frame\n");
        exit(1);
    }
    else if (feof(fr)) {
        printf("playback: no valid initial frame\n");
        exit(1);
    }

    /* Read current frame + next frame stats */
    nread = fread(buf, 1, currBytes + sizeof(nextFrame) + sizeof(nextBytes), fr);
    if ((unsigned)nread != currBytes + sizeof(nextFrame) + sizeof(nextBytes) ) {
        printf("playback: invalid initial frame read: nread = %d currBytes = %d\n",
                    nread, currBytes);
        exit(1);
    }
    memcpy( &nextFrame, buf + currBytes, sizeof(nextFrame) );
    memcpy( &nextBytes, buf + currBytes + sizeof(nextFrame), sizeof(nextBytes) );
     
    printf("Starting the Playback... Press ENTER to Stop\n");

    for (;;) {

        //temp_mask = mask;
        gettimeofday( &now, NULL );
        if (started == 0) {
            start = now;
            started = 1;
        }
    
        /* timeout = diffTime( addTime(start,currFrame), now ); */
        timeout = addTime(start,currFrame);
        while ( compTime(timeout,now) ==  1 ) {
            gettimeofday( &now, NULL );
        }
        
        /* Send the current frame */ 
        sendto( ss, buf, currBytes, 0, (struct sockaddr *)&send_addr, sizeof(send_addr) );

        /* Shift next into current */
        currFrame = nextFrame;
        currBytes = nextBytes;

        /* check for EOF and end of stream markers */
        if (currBytes == 0 && currFrame.tv_sec == 0 && currFrame.tv_usec == 0)
            break;
        else if (feof(fr))
            break;

        /* Read current frame + next frame stats */
        nread = fread(buf, 1, currBytes + sizeof(nextFrame) + sizeof(nextBytes), fr);
        if ((unsigned) nread != currBytes + sizeof(nextFrame) + sizeof(nextBytes) ) {
            printf("playback: invalid frame read: nread = %d currBytes = %d\n",
                nread, currBytes);
            exit(1);
        }
        memcpy( &nextFrame, buf + currBytes, sizeof(nextFrame) );
        memcpy( &nextBytes, buf + currBytes + sizeof(nextFrame), sizeof(nextBytes) );

    }

    fclose(fr);
    return 0;
}

static struct timeval addTime( struct timeval t1, struct timeval t2 ) {
    
    struct timeval res;

	res.tv_sec  = t1.tv_sec  + t2.tv_sec;
	res.tv_usec = t1.tv_usec + t2.tv_usec;
	if ( res.tv_usec > 1000000 )
	{
		res.tv_usec -= 1000000;
		res.tv_sec++;
	}

	return res;
}

int compTime( struct timeval t1, struct timeval t2 )
{
	if	( t1.tv_sec  > t2.tv_sec  ) return (  1 );
	else if ( t1.tv_sec  < t2.tv_sec  ) return ( -1 );
	else if ( t1.tv_usec > t2.tv_usec ) return (  1 );
	else if ( t1.tv_usec < t2.tv_usec ) return ( -1 );
	else			      return (  0 );
}


static void Usage(int argc, char *argv[])
{
  /* Setting defaults */
  Port = FUNNEL_IN_PORT;
  strncpy(Filename, "foo", sizeof(Filename));
  strncpy(IP, "", sizeof(IP));

  while( --argc > 0 ) {
    argv++;

    if( !strncmp(argv[0], "-f2a", 4 ) ){
      sscanf(argv[1], "%d", (int*)&Port );
      argc--; argv++;
    } else if( !strncmp(argv[0], "-str", 4 ) ){
      if (strlen(argv[1]) > NAME_LEN) {
        printf("playback: filename too long\n");
        exit(1);
      }
      sscanf(argv[1], "%s", Filename );
      argc--; argv++;
    } else if( !strncmp(argv[0], "-fip", 4 ) ){
      if (strlen(argv[1]) > NAME_LEN) {
        printf("playback: target funnel IP too long\n");
        exit(1);
      }
      sscanf(argv[1], "%s", IP );
      argc--; argv++;
    } else {
        printf( "Usage: play\n"
          "\t[-f2a <port number>] : port on which the funnel is listening to this application, default is %d\n"
          "\t[-fip <address>    ] : address of funnel to send video frames to, default is localhost\n"
          "\t[-str <file name>  ] : path to file for streaming, default  \"foo\"\n", FUNNEL_IN_PORT);
        exit( 0 );
    }
  }
}
