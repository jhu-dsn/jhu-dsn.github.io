#ifndef COMMONDEFS_H
#define COMMONDEFS_H

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <netdb.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/select.h>
#include <sys/time.h>

#define C_LISTENSTO_S_PORT 10101
#define S_LISTENSTO_C_PORT 10102
#define FUNNEL_IN_PORT 10103
#define FUNNEL_OUT_PORT 10104
#define DATA_SIZE 1500
#define FALSE 0
#define TRUE 1
#ifndef INADDR_LOOPBACK
#define INADDR_LOOPBACK ((unsigned long int) 0x7f000001)
#endif /* INADDR_LOOPBACK */

/* header for packets from a client to a server
 */
struct client_to_server_header {
	uint32_t to_addr;
	uint16_t replications;
}__attribute__ ((packed));

/* header for packets from a server to a client
 */
struct server_to_client_header {
	uint32_t from_addr;
}__attribute__ ((packed));

#endif
