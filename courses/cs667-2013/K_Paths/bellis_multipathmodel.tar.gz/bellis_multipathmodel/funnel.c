#include "commondefs.h"

#define ARG_BUF 32
void usage(int argc, 
			char* argv[],
			struct sockaddr_in* to_server,
			struct sockaddr_in* from_server,
			struct sockaddr_in* to_endpoint,
			struct sockaddr_in* from_endpoint,
			struct client_to_server_header* hdr);


int main(int argc, char *argv[]) {
	struct sockaddr_in to_server;
	struct sockaddr_in to_endpoint;
	struct sockaddr_in from_server;
	struct sockaddr_in from_endpoint;
	fd_set mask;
	fd_set dummy_mask,temp_mask;
	char funnel_in[DATA_SIZE + sizeof(struct client_to_server_header) + 1];
	char funnel_out[DATA_SIZE + sizeof(struct server_to_client_header) + 1];
	struct client_to_server_header* fin_hdr = (struct client_to_server_header*) funnel_in;
	//struct server_to_client_header* fout_hdr = (struct server_to_client_header*) funnel_out;
	int sr, fr, ss;
	int num;
	int size;
	//uint32_t funnel_ip;
	
	//get host info
	/*char name[ARG_BUF];
	gethostname(name, ARG_BUF);
	struct hostent* host = gethostbyname(name);
	memcpy(&(funnel_ip), host->h_addr_list[0], sizeof(host->h_addr_list[0]));*/
	
	// set up all the addresses
	to_server.sin_family = AF_INET; 
	to_server.sin_addr.s_addr = htonl(INADDR_LOOPBACK); 
	to_server.sin_port = htons(S_LISTENSTO_C_PORT);
	
	from_server.sin_family = AF_INET; 
	from_server.sin_addr.s_addr = htonl(INADDR_ANY); 
	from_server.sin_port = htons(C_LISTENSTO_S_PORT);
	
	to_endpoint.sin_family = AF_INET; 
	to_endpoint.sin_addr.s_addr = htonl(INADDR_LOOPBACK); 
	to_endpoint.sin_port = htons(FUNNEL_OUT_PORT);
	
	from_endpoint.sin_family = AF_INET; 
	from_endpoint.sin_addr.s_addr = htonl(INADDR_ANY); 
	from_endpoint.sin_port = htons(FUNNEL_IN_PORT);
	
	// adjust based on input
	usage(argc, argv, &to_server, &from_server, &to_endpoint, &from_endpoint, fin_hdr);
	
	// create sockets, bind as necessary
	sr = socket(AF_INET, SOCK_DGRAM, 0); /* socket for receiving */
	if (sr<0) {
		perror("Couldn't create socket to receive from server");
		exit(1);
	}
	
	if ( bind( sr, (struct sockaddr *)&from_server, sizeof(from_server) ) < 0 ) {
		perror("Couldn't bind socket to receive from server");
		exit(1);
	}
	
	fr = socket(AF_INET, SOCK_DGRAM, 0); /* socket for receiving */
	if (fr<0) {
		perror("Couldn't create socket to receive from application funneling packets onto model");
		exit(1);
	}
	
	if ( bind( fr, (struct sockaddr *)&from_endpoint, sizeof(from_endpoint) ) < 0 ) {
		perror("Couldn't bind socket to receive from application funneling packets onto model");
		exit(1);
	}
	
	ss = socket(AF_INET, SOCK_DGRAM, 0); /* socket for sending*/
	if (fr<0) {
		perror("Couldn't create socket for sending");
		exit(1);
	}
	
	FD_ZERO( &mask );
	FD_ZERO( &dummy_mask );
	FD_SET( sr, &mask );
	FD_SET( fr, &mask);
	//FD_SET( (long)0, &mask );
	
	for (;;) {
		temp_mask = mask;
		num = select( FD_SETSIZE, &temp_mask, &dummy_mask, &dummy_mask, NULL);
		if (num > 0) {
			if ( FD_ISSET( sr, &temp_mask) ) {
				//receiving from server
				size = recv( sr, funnel_out, DATA_SIZE, 0 );
				//funnel_out[size] = '\0';
				//printf("funneling out: %s", funnel_out + sizeof(struct server_to_client_header));
				size -= sizeof(struct server_to_client_header);
				sendto( ss, (char*) (funnel_out + sizeof(struct server_to_client_header)), size, 0, (struct sockaddr *)&(to_endpoint), sizeof(to_endpoint));
			
			} else if ( FD_ISSET( fr, &temp_mask) ) {
				//receiving from app
				size = recv( fr, funnel_in + sizeof(struct client_to_server_header), DATA_SIZE, 0 );
				size += sizeof(struct client_to_server_header);
				//funnel_in[size] = '\0';
				//printf("funneling in: %s", funnel_in + sizeof(struct client_to_server_header));
				sendto( ss, (char*) funnel_in, size, 0, (struct sockaddr *)&(to_server), sizeof(to_server));
			}
		}
	}
}

void print_usage(void) {
	printf("usage: funnel\n"
			"\t-dip <address> : address of the destination that all packets that this funnels into the overlay (REQUIRED)\n"
			"\t-rep <number> : number of replications desired (REQUIRED)\n"
			"\t[-a2f <port number>] : port on which funnel listens to app, default is %d\n"
			"\t[-f2a <port number>] : port on which app listens to funnel, default is %d\n"
			"\t[-c2s <port number>] : port on which client listens to server, default is %d\n"
			"\t[-s2c <port number>] : port on which server listens to client, default is %d\n"
			"\t[-sip <address>] : address of the server entry point to the overlay network, default is localhost\n"
			"\t[-aip <address>] : address of the application to which this is funneling data from the servers, default is localhost\n", 
			FUNNEL_OUT_PORT, FUNNEL_IN_PORT, C_LISTENSTO_S_PORT, S_LISTENSTO_C_PORT);
	exit(1);
}

void usage(int argc, 
			char* argv[],
			struct sockaddr_in* to_server,
			struct sockaddr_in* from_server,
			struct sockaddr_in* to_endpoint,
			struct sockaddr_in* from_endpoint,
			struct client_to_server_header* hdr) {
	int num;
	char name[ARG_BUF];
	struct hostent* host;
	
	argc--;
	
	if (argc < 4 || argc % 2 != 0) {
		print_usage();
	}
	
	int dip = FALSE;
	int rep = FALSE;
	
	argv++;
	while (argc > 0) {
		if(!strncmp(argv[0], "-rep", 4)) {
			if (sscanf(argv[1], "%d", &num) < 1) {
				printf("error for -rep: number of replications must be an integer\n");
				exit(1);
			}
			hdr->replications = num;
			rep = TRUE;
		} else if(!strncmp(argv[0], "-dip", 4)) {
			if (strlen(argv[1]) > ARG_BUF) {
				printf("error for -dip: destination ip or hostname is too long\n");
				exit(1);
			}
			sscanf(argv[1], "%s", name);
			host = gethostbyname(name);
			memcpy(&(hdr->to_addr), host->h_addr_list[0], host->h_length);
			dip = TRUE;
		} else if(!strncmp(argv[0], "-a2f", 4)) {
			if (sscanf(argv[1], "%d", &num) < 1) {
				printf("error for -a2f: port for app to listen to funnel must be an integer\n");
				exit(1);
			}
			to_endpoint->sin_port = htons(num);
		} else if(!strncmp(argv[0], "-f2a", 4)) {
			if (sscanf(argv[1], "%d", &num) < 1) {
				printf("error for -f2a: port for funnel to listen to app must be an integer\n");
				exit(1);
			}
			from_endpoint->sin_port = htons(num);
		} else if(!strncmp(argv[0], "-c2s", 4)) {
			if (sscanf(argv[1], "%d", &num) < 1) {
				printf("error for -c2s: port for client to listen to server must be an integer\n");
				exit(1);
			}
			from_server->sin_port = htons(num);
		} else if(!strncmp(argv[0], "-s2c", 4)) {
			if (sscanf(argv[1], "%d", &num) < 1) {
				printf("error for -s2c: port for server to listen to client must be an integer\n");
				exit(1);
			}
			to_server->sin_port = htons(num);
		} else if(!strncmp(argv[0], "-sip", 4)) {
			if (strlen(argv[1]) > ARG_BUF) {
				printf("server ip or hostname is too long\n");
				exit(1);
			}
			sscanf(argv[1], "%s", name);
			host = gethostbyname(name);
			memcpy(&(to_server->sin_addr.s_addr), host->h_addr_list[0], host->h_length);
		} else if(!strncmp(argv[0], "-aip", 4)) {
			if (strlen(argv[1]) > ARG_BUF) {
				printf("application ip or hostname is too long\n");
				exit(1);
			}
			sscanf(argv[1], "%s", name);
			host = gethostbyname(name);
			memcpy(&(to_endpoint->sin_addr.s_addr), host->h_addr_list[0], host->h_length);
		} else {
			print_usage();
		}
		
		argv += 2;
		argc -= 2;
	}
	
	if (!dip || !rep) {
		print_usage();
	}		
			
}
