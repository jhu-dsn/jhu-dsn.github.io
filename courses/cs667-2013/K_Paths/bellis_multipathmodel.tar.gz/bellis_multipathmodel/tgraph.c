#include "graph.h"


void build_graph_from_network(struct graph* graph, struct server* src, struct network* network) {
	graph->src = src;
	graph->network = network;
}

void free_graph(struct graph* graph) {
	graph->src = NULL;
	graph->network = NULL;
}

struct link* get_next_link(struct server* current, struct server* dest, uint32_t memory) {
	struct link* link = current->link_list.next;
	while (link != NULL) {
		if (link->neighbor->id == dest->id || !(memory & (1 << link->neighbor->id))) {
			return link;
		}
		link = link->next;
	}
	
	return (struct link*) NULL;
}

int plan_routes(struct server* dest, struct route* plan, int num_paths, struct graph* graph) {
	struct hop* hop = &(plan->hop_list);
	
	printf("Tring to find route from %i to %i:\n\tCame up with: %i", graph->src->id + 1, dest->id + 1, graph->src->id + 1);
	
	uint32_t memory = 0;
	struct link* link = get_next_link(graph->src, dest, memory);
	struct server* prev = graph->src;
	while (link != NULL) {
		hop->next = (struct hop*) malloc(sizeof(struct hop));
		hop = hop->next;
		hop->next = NULL;
		hop->link = link;
		
		printf("->%i", link->neighbor->id + 1);
		if (link->neighbor->id == dest->id) {
			break;
		}
		
		memory |= (1 << prev->id);
		prev = link->neighbor;
		link = get_next_link(link->neighbor, dest, memory);
	}
	
	printf("\n");
	
	return 1;
}
