#ifndef SERVER_H
#define SERVER_H

#include "network.h"
#include "graph.h"
#include <sys/time.h>


#define MAX_BUFFER 100
#define SERVER_PORT 10100
#define WAIT 10000
#define PRINT 1000

/* header for messages between servers
 */
struct server_header {
	uint16_t dest;		//overlay info
	uint16_t src;
	uint16_t prev;
	uint32_t seq;
	
	uint32_t to_addr;	//client info
	uint32_t from_addr;
	
	uint32_t e_sec; // for packet statistics
	uint32_t e_usec;
}__attribute__ ((packed));

/* struct for internally buffering packets at exit node
 */
struct packet_buffer {
	char* packet;
	struct sockaddr_in dest;
	uint32_t seq;
	int size;
	struct packet_buffer* next;
};

/* struct for interally keeping track of routes that have
 * already been calculated
 */
struct route_plan {
	char* route_info;
	int num_paths;
};

/* struf for internally keeping track of all the state
 * associated with a server
 */
struct protocol_data {
	// model packet info
	struct server* server;
	uint32_t seq_num;
	int num_buffered;
	struct packet_buffer buffer_list;
	
	// cached routing info
	struct route_plan* route_cache;
};

#endif
