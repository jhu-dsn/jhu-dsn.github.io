#include "network.h"
#define BITS 8

/* Calculates how many bytes are needed to represent
 * a this many unique objects in our packet structure.
 */
int size_of_info(int num_things) {
	return (num_things % BITS) ? (num_things / BITS) + 1 : (num_things / BITS);
}

/* Brints out a byte as 1s and 0s
 */
void print_byte(char byte) {
	char c;
	for (int i = 0; i < BITS; i++) {
		c = 1 << i;
		if (byte & c) {
			printf("1");
		} else {
			printf("0");
		}
	}
}

/* Prints out the routing information
 * as a series of bytes.
 */
void print_route_info(char* route_info, struct network* network) {
	for (int i = 0; i < network->info_size; i++) {
		print_byte(route_info[i]);
	}

}

/* Prints out a network, including servers, IP
 * addresses, ids, and links
 */
void print_network(struct network* network) {
	struct link* link;
	for (int i = 0; i < network->num_servers; i++) {
		printf("server %d:\n\tid: %d\n\tip: %x\n\toffset: %d\n\t", i + 1, network->servers[i].id, network->servers[i].ip, network->servers[i].offset);
		print_byte(network->servers[i].byte);
		printf("\n");
		printf("\tneighbors:\n");
		link = network->servers[i].link_list.next;
		while (link != NULL) {
			printf("\t\t%d\n", link->neighbor->id + 1);
			printf("\t\t\t%d: ", link->offset);
			print_byte(link->byte);
			printf("\n");
			link = link->next;
		}
	}
}

/* Finds the link from this source server to the
 * destination.
 */
struct link* find_link(struct server* src, struct server* dest) {
	struct link* found = src->link_list.next;
	while (found != NULL) {
		if (found->neighbor->id == dest->id) {
			break;
		}
		found = found->next;
	}
	
	return found;
}

/*struct server* find_next_hop(char* route_info, struct server* me, struct server* prev) {
	struct link* link = me->link_list.next;
	printf("finding hop after %d\n", me->id);
	while (link != NULL) {
		if (link->neighbor->id != prev->id && route_info[link->offset] & link->byte) {
			printf("FOUND: %d\n", link->neighbor->id);
			return link->neighbor;
		}

		link = link->next;
	}
	
	return NULL;
}*/

/* Prints out the route, including multiple paths, from
 * what is stamped on the packet's routing information
 */
void print_route(char* route_info, struct server* src, struct server* dest) {
	struct link* outer = src->link_list.next;
	struct link* inner;
	struct server* current;
	struct server* prev;
	printf("Routing from %d to %d\n", src->id + 1, dest->id + 1);
	int i = 0;
	while (outer != NULL) {
		if (route_info[outer->offset] & outer->byte) {
			i++;
			printf("\tPath %d: %d->", i, src->id + 1);
			current = outer->neighbor;
			prev = src;
			while (current->id != dest->id) {
				printf("%d->", current->id + 1);
				inner = current->link_list.next;
				while (inner != NULL) {
					if (prev->id != inner->neighbor->id && route_info[inner->offset] & inner->byte) {
						// found the next link
						break;
					}
					inner = inner->next;
				}
				
				if (inner == NULL) {
					// sanity check, should never reach this,
					// but prevents infinite loops if malformed route
					break;
				}
				prev = current;
				current = inner->neighbor;
			}
			printf("%d\n", dest->id + 1);
		}
		outer = outer->next;
	}
}

/* Prints the path traveled by a particular packet
 */
void print_path_traveled(char* traveled_info, char* route_info, struct server* src, struct server* dest) {
	printf("Path Traveled: ");
	struct server* current = src;
	struct server* prev = src;
	struct link* link;
	printf("%d", current->id + 1);
	while (current->id != dest->id) {
		link = current->link_list.next;
		while (link != NULL) {
			if (link->neighbor->id != prev->id && route_info[link->offset] & link->byte && traveled_info[link->neighbor->offset] & link->neighbor->byte) {
				break;
			}
			link = link->next;
		}
		
		if (link == NULL) {
			// sanity check to prevent infinite loops
			// with a malfored travel information
			break;
		}
		prev = current;
		current = link->neighbor;
		printf("->%d", current->id + 1);
	}
	//printf("%d\n", dest->id + 1);
	printf("\n");
	
}

/* Stamps a packet with the given route, including multiple paths
 */
void stamp_with_route(char* route_info, struct route* route, struct network* network) {
	// set all of the routing info to zero
	memset(route_info, 0, network->route_size);
	
	// get the first hop
	struct hop* hop = route->hop_list.next;
	while (hop != NULL) {
		route_info[hop->link->offset] |= hop->link->byte;
		hop = hop->next;
	}
	
	
	/*// doing the if and while statements this way implicitly checks that a route
	// has at least two servers (the start and the end)
	if (hop != NULL) {
		struct link* link;
		while (hop.next != NULL) {
			link = find_link(network->servers[hop->id], network->servers[hop->next->id]);
			route_info[link->offset] |= link->byte;
			hop = hop->next;
		}
	
	}*/
}

/* Adds a link to between servers with two ids
 * in a network
 */
void add_link(int s, int d, int cost, struct network* network) {
	struct server* src = &(network->servers[s]);
	struct server* dest = &(network->servers[d]);
	
	struct link* current = &(src->link_list);
	while (current->next != NULL && current->next->neighbor->id < dest->id) {
		current = current->next;
	}
	
	// add in the new link
	struct link* add = (struct link*) malloc(sizeof(struct link));
	add->neighbor = dest;
	add->cost = cost;
	add->next = current->next;
	current->next = add;
	
	// modify the source's link count
	src->num_links++;
	
}

/* Frees the memory allocated to keep track
 * of a network.
 */
void free_network(struct network* network) {
	struct link* delete;
	for (int i = 0; i < network->num_servers; i++) {
		while (network->servers[i].link_list.next != NULL) {
			delete = network->servers[i].link_list.next;
			network->servers[i].link_list.next = delete->next;
			free(delete);
		}
	}
	free(network->servers);
}

/* Reads a file and builds a network from that
 */
int configure_network(struct network* network, char* config_file) {
	FILE* config = fopen(config_file, "r");
	network->num_links = 0;
	if (config) {
		if (fscanf(config, "%d", &(network->num_servers))) {	
			// allocate space for all the servers
			network->servers = (struct server*) malloc(sizeof(struct server) * network->num_servers);
			network->traveled_size = size_of_info(network->num_servers);
			
			// get all the ip addresses of the servers
			char ip[100];
			int id;
			uint16_t u_id;
			struct server* current;
			struct hostent *host;
			for (uint16_t i = 0; i < network->num_servers && fscanf(config, "%d %s", &id, ip); i++) {
				u_id = (uint16_t) (id - 1);
				current = &(network->servers[u_id]);
				current->id = u_id;
				current->offset = current->id / BITS;
				current->byte = 1 << (current->id % BITS);
				host = gethostbyname(ip);
				memcpy(&(current->ip), host->h_addr_list[0],  host->h_length);
				//current->ip = htonl(inet_pton(AF_INET, (const char*) &ip, &(current->ip)));
				current->link_list.next = NULL;
			}
			
			// get all the links
			int a;
			int b;
			int cost;
			while (fscanf(config, "%d %d %d", &a, &b, &cost) != EOF) {
				a--;
				b--;
				add_link(a, b, cost, network);
				add_link(b, a, cost, network);
				network->num_links++;
			}
			
			// calculate all the link packet setting info
			int unique = 0;
			struct link* link;
			struct link* opposite;
			struct server* src;
			for (int i = 0; i < network->num_servers; i++) {
				src = &(network->servers[i]);
				link = src->link_list.next;
				while (link != NULL) {
					if (src->id < link->neighbor->id) {
						// set this link's edge packet info
						link->offset = unique / BITS;
						link->byte = 1 << (unique % BITS);
						unique++;
					} else {
						// this is the duplicate of the other link
						// copy over the other link's info
						opposite = find_link(link->neighbor, src);
						link->offset = opposite->offset;
						link->byte = opposite->byte;
					}
					
					link = link->next;
				}
			}
		}
		
		fclose(config);
		network->route_size = size_of_info(network->num_links);
		network->info_size = network->route_size + network->traveled_size;
		return TRUE;
	}
	
	return FALSE;
}
