#ifndef FGRAPH_H
#define FGRAPH_H

#include "network.h"
struct fedge;
struct fnode;

/* Represents an edge in a mincost/maxflow
 * graph for a network
 */
struct fedge {
	struct fnode* from;
	struct fnode* to;

	int capacity;
	int flow;
	int cost;
	int is_residual;
	struct fedge* opposite; // the edge that flows in the opposite direction
	
	struct link* link; //NULL if it is a residual/in<->out edge
	struct fedge* next;
	
	struct fedge* sub_next; //used to create a linked list of edges for proposed subgraph
};

/* Represents a node in a mincost/maxflow
 * graph for a network
 */
struct fnode {
	uint16_t id;
	int distance;
	int visited;
	struct fedge* in_edge;
	
	struct fedge edge_list;
	
	struct fnode* prev;
	struct fnode* next;
};

/* A mincost/maxflow graph representation of
 * a network
 */
struct graph {
	struct fnode* src;
	struct fnode* nodes;
	int num_nodes; // number of logical nodes, each represented by 2 fnodes, an in and an out
	
	struct fnode queue;
	struct fedge subgraph;
};
#endif
