#ifndef GRAPH_H
#define GRAPH_H

#include "graphimpl.h"

void build_graph_from_network(struct graph* graph, struct server* src, struct network* network);
void free_graph(struct graph* graph);
int plan_routes(struct server* dest, struct route* plan, int num_paths, struct graph* graph);

#endif
