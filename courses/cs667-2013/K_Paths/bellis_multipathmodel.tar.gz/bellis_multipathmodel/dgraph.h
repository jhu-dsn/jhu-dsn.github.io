#ifndef DGRAPH_H
#define DGRAPH_H

#include "network.h"

struct dnode;
struct dedge;
struct dcandidate;

struct dedge {
	struct dnode* from;
	struct dnode* to;
	
	struct link* link;
	
	struct dedge* next;
};

struct dnode {
	uint16_t id;
	struct dedge* in_edge;
	int distance;
	int visited;
	
	struct dedge edge_list;
	
	struct dnode* prev;
	struct dnode* next;
};

struct graph {
	struct dnode* src;
	
	struct dnode* nodes;
	int num_nodes;
	
	struct dnode queue;
};
#endif
