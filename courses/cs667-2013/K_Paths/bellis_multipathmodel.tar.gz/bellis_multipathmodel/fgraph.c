#include "graph.h"

/* Builds a graph for doing mincost/maxflow calculation of 
 * the a multiple path route with the least cost sum.
 *
 * Each node becomes to logical nodes, one with all the in
 * edges, one with all the out edges, and one edge connecting them.
 * 
 * Each edge is directed and has a residual backwards edge.
 */
void build_graph_from_network(struct graph* graph, struct server* src, struct network* network) {
	// allocate memory
	graph->num_nodes = network->num_servers;
	graph->nodes = (struct fnode*) malloc(sizeof(struct fnode) * graph->num_nodes * 2);
	
	// set source node
	graph->src = &(graph->nodes[src->id + graph->num_nodes]);
	
	// first initialize all the nodes
	struct fnode* in;
	struct fnode* out;
	for (int i = 0; i < graph->num_nodes; i++) {
		in = &(graph->nodes[i]);
		out = &(graph->nodes[i + graph->num_nodes]);
	
		// initialize in node
		in->id = network->servers[i].id;
		in->edge_list.next = NULL;
		
		// initialize out node
		out->id = in->id + graph->num_nodes;
		out->edge_list.next = NULL;
		
	}
	
	// now add all the edges
	struct fnode* to;
	struct fedge* edge;
	struct link* link;
	for (int i = 0; i < graph->num_nodes; i++) {
		in = &(graph->nodes[i]);
		out = &(graph->nodes[i + graph->num_nodes]);
		
		// first add the edges between in and out nodes
		
		// first the forward edge
		edge = (struct fedge*) malloc(sizeof(struct fedge));
		edge->from = in;
		edge->to = out;
		edge->cost = 0;
		edge->link = NULL;
		edge->is_residual = FALSE;
		edge->next = in->edge_list.next;
		in->edge_list.next = edge;
		
		// now the residual edge
		edge = (struct fedge*) malloc(sizeof(struct fedge));
		edge->from = in;
		edge->to = out;
		edge->cost = 0;
		edge->link = NULL;
		edge->is_residual = TRUE;
		edge->next = out->edge_list.next;
		out->edge_list.next = edge;
		
		// now set opposites
		edge->opposite = in->edge_list.next;
		edge->opposite->opposite = edge;
		
		// now add all the out edges
		link = network->servers[i].link_list.next;
		while (link != NULL) {
			to = &(graph->nodes[link->neighbor->id]);
		
			// first the forward edge
			edge = (struct fedge*) malloc(sizeof(struct fedge));
			edge->from = out;
			edge->to = to;
			edge->link = link;
			edge->cost = link->cost;
			edge->is_residual = FALSE;
			edge->next = out->edge_list.next;
			out->edge_list.next = edge;
			
			// now the residual edge
			edge = (struct fedge*) malloc(sizeof(struct fedge));
			edge->from = to;
			edge->to = out;
			edge->link = NULL;
			edge->cost = link->cost;
			edge->is_residual = TRUE;
			edge->next = to->edge_list.next;
			to->edge_list.next = edge;
			
			// now set opposites
			edge->opposite = out->edge_list.next;
			edge->opposite->opposite = edge;
			
			link = link->next;
		}
	
	}
}

/* Frees the memory associated with a graph
 */
void free_graph(struct graph* graph) {
	struct fedge* delete;
	struct fedge* head;
	for (int i = 0; i < (graph->num_nodes * 2); i++) {
		head = &(graph->nodes[i].edge_list);
		while (head->next != NULL) {
			delete = head->next;
			head->next = delete->next;
			free(delete);
		}
	}
	free(graph->nodes);
}

/* Finds a route with the number of paths indicated
 * using mincost/maxflow, or as close as it can
 *
 * Returns the number of plaths it actually found
 */
int plan_routes(struct server* dest, struct route* plan, int num_paths, struct graph* graph) {
	// first set up the flow information
	struct fedge* edge;
	for (int i = 0; i < (graph->num_nodes * 2); i++) {
		edge = graph->nodes[i].edge_list.next;
		while (edge != NULL) {
			if (edge->is_residual) {
				edge->capacity = 0;
			} else {
				edge->capacity = 1;
			}
			
			edge->flow = 0;
			edge->sub_next = NULL;
			
			edge = edge->next;
		}
	}
	
	// blank out the subgraph of path information
	graph->subgraph.sub_next = NULL;
	
	
	// now iterate through multiple dijkstras
	int found = 0;
	int distance;
	int total;
	struct fnode* current;
	struct fnode* queue = &(graph->queue);
	for (int i = 0; i < num_paths; i++) {
		// set up dijkstras information
		for (int i = 0; i < (graph->num_nodes * 2); i++) {
			current = &(graph->nodes[i]);
			current->distance = -1;
			current->in_edge = NULL;
			current->visited = FALSE;
			current->next = NULL;
			current->prev = NULL;
		}
		graph->src->distance = 0;
		
		// set up queue
		queue->next = graph->src;
		queue->prev = graph->src;
		graph->src->next = queue;
		graph->src->prev = queue;
		
		// perform dijkstra
		while (queue->next != queue) {
			current = queue->next;
			/*printf("Printing queue:\n");
			while (current != queue) {
				printf("\t%d: %d\n", current->id, current->distance);
				current = current->next;
			}
			printf("\n");*/
			// remove head of queue
			current = queue->next;
			queue->next = current->next;
			current->next->prev = queue;
			
			// set the visited variable
			current->visited = TRUE;	
			// check to see if you found the destination
			if (current->id == dest->id) {
				break;
			}

			// try to relax edges
			edge = current->edge_list.next;
			distance = current->distance;
			while (edge != NULL) {
				total = distance + edge->cost;
				
				//printf("Considering edge costing %d to %d, which has current distance %d\n", edge->cost, edge->to->id, edge->to->distance);
				// note the additional capacity check, must have room
				// to add a single unit of flow.
				if (edge->capacity > 0 && !edge->to->visited && (edge->to->next == NULL || edge->to->distance > total)) {
					// adjust distance and in edge
					edge->to->distance = total;
					edge->to->in_edge = edge;
					
					// remove from the queue
					if (edge->to->next != NULL) {
						// only null if never in the qeueu
						// if in the queue, the both prev and
						// next must be valid. So only one null
						// check is required
						edge->to->next->prev = edge->to->prev;
						edge->to->prev->next = edge->to->next;
					}
					
					// find the appropriate spot to add to queue
					current = queue->next;
					while (current != queue) {
						if (current->distance >= edge->to->distance) {
							break;
						}
						current = current->next;
					}
					
					// add as the node preceding current
					edge->to->next = current;
					edge->to->prev = current->prev;
					current->prev->next = edge->to;
					current->prev = edge->to;
				}
				edge = edge->next;
			}
		}
		
		// check to see if we actually found an augmenting path
		if (current->id != dest->id) {
			// no other augmenting path to be found
			break;
		}
		
		// note that you found one more disjoint path
		found++;
		
		// add appropriate forward edges to subgraph
		// also adjust flow/capacity on those edges
		edge = current->in_edge;
		while (edge != NULL) {
			edge->flow++;
			edge->capacity--;
			edge->opposite->capacity++;
			
			// check if should add edge to subgraph
			// only had forward, non in<->out edges that aren't
			// already a part of the subgraph
			if (edge->link != NULL && edge->sub_next == NULL) {
				// edge->link != NULL rules out both residual and in<->out edges
				edge->sub_next = graph->subgraph.sub_next;
				graph->subgraph.sub_next = edge;
			}
			
			edge = edge->from->in_edge;	
		}
	}
	//printf("Found a route\n");	
	// convert subgraph to a route plan
	edge = graph->subgraph.sub_next;
	plan->hop_list.next = NULL;
	struct hop* hop;
	while (edge != NULL) {
		//printf("Edge to %d\n", edge->to->id);
		// check that the residual edge isn't cancelling this edge out
		if (edge->flow > edge->opposite->flow) {
			hop = (struct hop*) malloc(sizeof(struct hop));
			hop->link = edge->link;
			hop->next = plan->hop_list.next;
			plan->hop_list.next = hop;
		}
		
		edge = edge->sub_next;
	}
	//printf("returning num paths found\n");	
	return found;
}
