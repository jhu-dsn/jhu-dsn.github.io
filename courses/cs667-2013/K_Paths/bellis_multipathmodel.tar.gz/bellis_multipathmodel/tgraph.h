#ifndef TGRAPH_H
#define TGRAPH_H

#include "network.h"

struct gnode {
	uint16_t dest;
	struct route plan;
	struct gnode* next;
};

struct graph {
	struct server* src;
	struct network* network;
};
#endif
