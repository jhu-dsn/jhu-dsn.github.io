#include "server.h"

/* Struct that keeps track of major data for the server,
 * including network, graph, and server protocol data.
 * Allows the data to be automatically freed at exit
 */
struct {
	struct graph graph;
	int has_graph;
	struct network network;
	int has_network;
	struct protocol_data* cache;
	int max_paths;
	int has_cache;
	char* sbuffer;
	char cbuffer[sizeof(struct server_to_client_header) + sizeof(struct client_to_server_header) + DATA_SIZE];
} data;

/* Clears a route plan and frees all associated memory
 */
void clear_plan(struct route* plan) {
	struct hop* delete_h;
		
	while (plan->hop_list.next != NULL) {
		delete_h = plan->hop_list.next;
		plan->hop_list.next = delete_h->next;
		free(delete_h);
	}
}

/* Called at exit to free all the dynamically associated memory
 */
void cleanup() {
	// free the graph
	if (data.has_graph) {
		free_graph(&(data.graph));
	}
	
	// free all the cached information about other servers
	if (data.has_cache) {
		struct packet_buffer* delete;
		for (int i = 0; i < data.network.num_servers; i++) {
			// delete all buffered packts
			while (data.cache[i].buffer_list.next != NULL) {
				delete = data.cache[i].buffer_list.next;
				data.cache[i].buffer_list.next = delete->next;
				free(delete);
			}
			
			// delete route cache
			for (int j = 0; j < data.max_paths; j++) {
				if (j + 1 == data.cache[i].route_cache[j].num_paths && data.cache[i].route_cache[j].route_info != NULL) {
					free(data.cache[i].route_cache[j].route_info);
				}
			}
			free(data.cache[i].route_cache);
		}
		free(data.cache);
	}
	
	// free the network
	if (data.has_network) {
		free_network(&(data.network));
	}
	
	// free the sender buffer
	if (data.sbuffer != NULL) {
		free(data.sbuffer);
	}
}

/* Returns the route that corresponds best with the desired number of paths.
 * Checks the server's cache of already calculating routes first before asking
 * the graphing algorithm to calculate it.
 */
char* get_route_info(struct protocol_data* server_cache, int want, int max, int* found, struct graph* graph, struct network* network) {
	// sanity checks on the number of desired paths
	if (want <= max) {
		if (want <= 0) {
			want = 1;
		}
	} else {
		want = max;
	}

	int index = want - 1;
	// check if route is already in the cache
	if (server_cache->route_cache[index].route_info != NULL) {
		*found = server_cache->route_cache[index].num_paths; 
		return server_cache->route_cache[index].route_info;
	}
	
	// find the route if it isn't cached
	struct route plan;
	*found = plan_routes(server_cache->server, &plan, want, graph);

	// check if you have found the max number of disjoint paths
	if (*found < want) {
		index = *found - 1;
		// check to see if you already have this cached
		if (server_cache->route_cache[index].route_info == NULL) {
			// if not, cache it
			server_cache->route_cache[index].route_info = (char*) malloc(sizeof(network->route_size));
			stamp_with_route(server_cache->route_cache[index].route_info, &plan, network);
			server_cache->route_cache[index].num_paths = *found;
		}
		
		// propogate the route to all caches corresponding to a
		// higher number of desired paths (since we can't do better than
		// the largest number of disjoint paths)
		for (int i = index + 1; i < max; i++) {
			if (server_cache->route_cache[i].route_info == NULL) {
				server_cache->route_cache[i].route_info = server_cache->route_cache[index].route_info;
				server_cache->route_cache[i].num_paths = server_cache->route_cache[index].num_paths;
			}
		}
	} else {
		// if you haven't found the max number, then just set the cache
		server_cache->route_cache[index].route_info = (char*) malloc(sizeof(network->route_size));
		stamp_with_route(server_cache->route_cache[index].route_info, &plan, network);
		server_cache->route_cache[index].num_paths = *found;
	}
	
	clear_plan(&plan);
	return server_cache->route_cache[index].route_info;
}

/* Takes an internal server packet and prepares it to be forwarded
 * to the destination client with the appropriate headers
 */
int prep_to_client(char* from, char* to, int size, struct network* network) {
	size -= (sizeof(struct server_header) + network->info_size);
	memcpy(to + sizeof(struct server_to_client_header), from + sizeof(struct server_header) + network->info_size, size);
	struct server_to_client_header* c_hdr = (struct server_to_client_header*) to;
	struct server_header* s_hdr = (struct server_header*) from;
	c_hdr->from_addr = s_hdr->from_addr;
	return size + sizeof(struct server_to_client_header);
}

/* Flush the buffer of messages for a particular server. Will either start
 * with the first buffered message and, if it is the next expected message,
 * keep sending each successive message to the appropriate client until it
 * reaches a messsage in the buffer that is not the next in the sequence.
 * Or, it will just flush all the messages, if the maximum number of messages
 * are in the buffer or if an argument tells it to ignore the sequencing.
 * Updates the expected sequence number to the number after the last message
 * flushed
 */
void flush_buffer(struct protocol_data* server, int ss, int force) {
	struct packet_buffer* buffer = &(server->buffer_list);
	struct packet_buffer* sending;
	
	if (!force) {
		force = (server->num_buffered >= MAX_BUFFER);
	}
	
	while (buffer->next != NULL && (force || server->seq_num == buffer->next->seq)) {
		sending = buffer->next;
		sendto( ss, (char*) sending->packet, sending->size, 0, 
                    (struct sockaddr *)&(sending->dest), sizeof(sending->dest) );
		
		// increment the expected sequence number so that the
		// check works for the next thing in the buffer
		server->seq_num = sending->seq + 1;
		server->num_buffered--;
		
		
		// remove this buffer node and free memory
		buffer->next = sending->next;
		free(sending->packet);
		free(sending);
	}
}

/* Adds a packet that is supposed to exit the overlay through
 * this node into a buffer associated with the entry node server.
 */
int add_to_buffer(struct protocol_data* server, char* packet, int size, struct sockaddr_in* dest, struct network* network) {
	struct server_header* s_hdr = (struct server_header*) packet;
	
	// must be space in buffer and must have a seq num
	// strictly greater than the expected
	if (s_hdr->seq > server->seq_num) {
		struct packet_buffer* current = &(server->buffer_list);
		while (current->next != NULL && current->next->seq < s_hdr->seq) {
			current = current->next;
		}
		
		// make sure you aren't adding a duplicate
		if (current->next == NULL || current->next->seq != s_hdr->seq) {
			struct packet_buffer* add = (struct packet_buffer*) malloc(sizeof(struct packet_buffer));
			add->packet = malloc(size - sizeof(struct server_header) - network->info_size + sizeof(struct server_to_client_header));
			add->size = prep_to_client(packet, add->packet, size, network);
			add->seq = s_hdr->seq;
			add->dest = *dest;
			add->next = current->next;
			current->next = add;
			server->num_buffered++;
			return TRUE;
		}
	}
	return FALSE;
}

/* Passes a packet on to the next server in the path
 */
void pass_to_next_server(char* packet, int size, int ss, struct server* me, struct network* network, int num_next, struct sockaddr_in servers) {
	// get the info
	struct server_header* hdr = (struct server_header*) packet;
	struct server* prev = &(network->servers[hdr->prev]);
	char* route_info = packet + sizeof(struct server_header);
	
	// report what you're doing
	/*packet[size] = '\0';
	printf("forwarding message: %s\n", packet + sizeof(struct server_header) + network->info_size);
	printf("routing info: ");
	print_route_info(packet + sizeof(struct server_header), network);
	printf("\n");*/
	
	// set final part of message
	hdr->prev = me->id;
	
	// send to every server that comes next
	struct link* link = &(me->link_list);
	for (int i = 0; i < num_next; i++) {
		while (link->next != NULL) {
			link = link->next;
			if (link->neighbor->id != prev->id && route_info[link->offset] & link->byte) {
				//printf("SENDING TO: %d\n", link->neighbor->id + 1);
				servers.sin_addr.s_addr = link->neighbor->ip;
				sendto(ss, (char*) packet, size, 0, (struct sockaddr *)&(servers), sizeof(servers));
				break;
			}
		}
	}
}

/* Calculate the elapsed time between to timevals
 */
long elapsed_time(struct timeval* start, struct timeval* end) {
	return (end->tv_sec - start->tv_sec) * 1000000 + end->tv_usec - start->tv_usec;
}

/* Print the usage command line
 */
void print_usage(void) {
	printf("usage: server\n"
			"\t-net <file name> : path to configuration file mapping this server's network (REQUIRED)\n"
			"\t-ind <number> : index of this server (REQUIRED)\n"
			"\t[-s2s <port number>] : port on which servers listen to other servers, default is %d\n"
			"\t[-c2s <port number>] : port on which client listens to server, default is %d\n"
			"\t[-s2c <port number>] : port on which server listens to client, default is %d\n",
			SERVER_PORT, C_LISTENSTO_S_PORT, S_LISTENSTO_C_PORT);
	exit(1);
}

/* Parses the command line options
 */
void usage(	int argc, char* argv[],
			struct server** me,
			struct sockaddr_in* to_client,
			struct sockaddr_in* to_server,
			struct sockaddr_in* from_client,
			struct sockaddr_in* from_server) {
	
	argc--;
		
	if (argc < 4 || argc % 2 != 0) {
		print_usage();
	}
	
	int num = 0;
	int index = 0;
	int ind = FALSE;
	
	argv++;
	while (argc > 0) {
		
		if(!strncmp( argv[0], "-ind", 4)) {
			if (sscanf(argv[1], "%d", &index) < 1) {
				printf("error for -ind: server index must be an integer\n");
				exit(1);
			}
			ind = TRUE;
		} else if(!strncmp( argv[0], "-net", 4)) {
			if (!(data.has_network = configure_network(&(data.network), argv[1]))) {
				printf("error for -net: invalid network configuration file");
			}
			data.has_network = TRUE;
		} else if(!strncmp( argv[0], "-s2s", 4)) {
			if (sscanf(argv[1], "%d", &num) < 1) {
				printf("error for -s2s: the port on which servers listen to other servers needs to be an integer\n");
				exit(1);
			}
			to_server->sin_port = htons(num);
			from_server->sin_port = to_server->sin_port;
		} else if(!strncmp( argv[0], "-c2s", 4)) {
			if (sscanf(argv[1], "%d", &num) < 1) {
				printf("error for -c2s: the port on which a client listens to a server needs to be an integer\n");
				exit(1);
			}
			to_client->sin_port = htons(num);
		} else if(!strncmp( argv[0], "-s2c", 4)) {
			if (sscanf(argv[1], "%d", &num) < 1) {
				printf("error for -s2c: the port on which a server listens to a client\n");
				exit(1);
			}
			from_client->sin_port = htons(num);
		}
		
		argv += 2;
		argc -= 2;
	}

	if (data.has_network && ind) {
		if (index < 1 || index > data.network.num_servers) {
			printf("error for -ind: invalid server index");
			exit(1);
		}
		index--;	
		*me = &(data.network.servers[index]);
	} else {
		print_usage();
	}
}

int main(int argc, char* argv[]) {
	//struct sockaddr_in servers;
	struct sockaddr_in client;
	struct sockaddr_in server_recv;
	struct sockaddr_in client_recv;
	struct sockaddr_in server_send;
	struct sockaddr_in from_addr;
	struct timeval timeout;
	struct timeval now, last;
	socklen_t from_len;
	int ss, src, srs;
	int entered, exited;
	int num;
	int bytes;
	fd_set mask;
	fd_set dummy_mask,temp_mask;
	struct server* me;
	uint32_t* seq_nums;
	
	data.has_cache = FALSE;
	data.has_graph = FALSE;
	data.has_network = FALSE;
	data.sbuffer = NULL;

	atexit(cleanup);
	
	//initialize different addresses
	server_send.sin_family = AF_INET; 
	server_send.sin_addr.s_addr = htonl(INADDR_ANY); 
	server_send.sin_port = htons(SERVER_PORT);
	
	server_recv.sin_family = AF_INET; 
	server_recv.sin_addr.s_addr = htonl(INADDR_ANY); 
	server_recv.sin_port = htons(SERVER_PORT);
	
	client_recv.sin_family = AF_INET; 
	client_recv.sin_addr.s_addr = htonl(INADDR_ANY); 
	client_recv.sin_port = htons(S_LISTENSTO_C_PORT);
	
	client.sin_family = AF_INET; 
	client.sin_addr.s_addr = htonl(INADDR_LOOPBACK); 
	client.sin_port = htons(C_LISTENSTO_S_PORT);
	
	//adjust based on input
	usage(argc, argv, &me, &client, &server_send, &client_recv, &server_recv);
	
	// print network and server
	print_network(&(data.network));
	printf("Hello, I am server %d\n", me->id + 1);
	
	// setup the network cache
	data.max_paths = me->num_links;
	data.cache = (struct protocol_data*) malloc(sizeof(struct protocol_data) * data.network.num_servers);
	for (int i = 0; i < data.network.num_servers; i++) {
		data.cache[i].server = &(data.network.servers[i]);
		data.cache[i].seq_num = 0;
		data.cache[i].num_buffered = 0;
		data.cache[i].buffer_list.next = NULL;
		data.cache[i].route_cache = (struct route_plan*) malloc(sizeof(struct route_plan) * data.max_paths);
		for (int j = 0; j < data.max_paths; j++) {
			data.cache[i].route_cache[j].route_info = NULL;
			data.cache[i].route_cache[j].num_paths = 0;
		}
	}
	data.has_cache = TRUE;
	
	// setup the graph
	build_graph_from_network(&(data.graph), me, &(data.network));
	data.has_graph = TRUE;
	int s_buf_size = sizeof(char) * (data.network.info_size + sizeof(struct server_header) + DATA_SIZE);
	data.sbuffer = (char*) malloc(s_buf_size + 1);
	seq_nums = (uint32_t*) malloc(sizeof(uint32_t) * data.network.num_servers);
	memset(seq_nums, 0, sizeof(uint32_t) * data.network.num_servers);
	
	// setup the sockets
	srs = socket(AF_INET, SOCK_DGRAM, 0);  /* socket for receiving (udp) */
	if (srs < 0) {
		perror("Server: server socket");
		exit(1);
	}
	
	if ( bind( srs, (struct sockaddr *) &server_recv, sizeof(server_recv) ) < 0 ) {
		perror("Server: binding server socket");
		exit(1);
	}
	
 	src = socket(AF_INET, SOCK_DGRAM, 0);  /* socket for receiving (udp) */
	if (src < 0) {
		perror("Server: client socket");
		exit(1);
	}
	
	if ( bind( src, (struct sockaddr *) &client_recv, sizeof(client_recv) ) < 0 ) {
		perror("Server: binding client socket");
		exit(1);
	}
	
	ss = socket(AF_INET, SOCK_DGRAM, 0); /* socket for sending (udp) */
	if (ss<0) {
		perror("Rcv: socket");
		exit(1);
	}
	
	
	FD_ZERO( &mask );
	FD_ZERO( &dummy_mask );
	FD_SET( src, &mask );
	FD_SET( srs, &mask );
	FD_SET( (long)0, &mask ); /* stdin */
	struct server_header* s_hdr = (struct server_header*) data.sbuffer;
	struct client_to_server_header* c_hdr = (struct client_to_server_header*) data.cbuffer;
	//struct route* route;
	struct server* next;
	struct timeval temp_time;
	char* route_info;
	//uint32_t address;
	int num_paths;
	int unique;
	entered = 0;
	exited = 0;
	gettimeofday(&last, NULL);
	for (;;) {
		temp_mask = mask;
		timeout.tv_sec = 0;
		timeout.tv_usec = WAIT;
		num = select( FD_SETSIZE, &temp_mask, &dummy_mask, &dummy_mask, &timeout);
		
		gettimeofday(&now, NULL);
		if (num > 0) {
			from_len = sizeof(from_addr);
			if (FD_ISSET(srs, &temp_mask)) {
				// get message from other server
				bytes = recvfrom(srs, (char *) data.sbuffer, s_buf_size, 0, (struct sockaddr *)&from_addr, &from_len );
				
				// stamp packet as having gone through this server
				data.sbuffer[sizeof(struct server_header) + data.network.route_size + me->offset] |= me->byte;
				
				// check if this is the destination server
				if (s_hdr->dest == me->id) {
					// forward to the client
					
					/*data.sbuffer[bytes] = '\0';
					printf("Received for client: %s\n", data.sbuffer + sizeof(struct server_header) + data.network.info_size);*/
					
					// set client address
					if (s_hdr->to_addr == me->ip) {
						client.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
					} else {
						client.sin_addr.s_addr = s_hdr->to_addr;
					}
					unique = FALSE;
					if (s_hdr->seq == data.cache[s_hdr->src].seq_num) {
						// if it's the one we are expecting, send it on
						bytes = prep_to_client(data.sbuffer, data.cbuffer, bytes, &(data.network));
						sendto( ss, (char*) data.cbuffer, bytes, 0, (struct sockaddr *)&(client), sizeof(client));
						//see if this means we can get rid of stuff in the buffer
						data.cache[s_hdr->src].seq_num++;
						flush_buffer(&(data.cache[s_hdr->src]), ss, FALSE);
						last = now;
						unique = TRUE;
					} else {
						// not the one we were expecting
						// try and add it to the buffer
						unique = add_to_buffer(&(data.cache[s_hdr->src]), data.sbuffer, bytes, &client, &(data.network));
						flush_buffer(&(data.cache[s_hdr->src]), ss, FALSE);
					}
					
					// print exit statistics
					if (unique) {
						exited++;
						if (exited >= PRINT) {
							exited = 0;
							temp_time.tv_sec = (long int) s_hdr->e_sec;
							temp_time.tv_usec = (long int) s_hdr->e_usec;
							printf("Packet Trip Time %ld\n", elapsed_time(&temp_time, &now));
							print_path_traveled(data.sbuffer + sizeof(struct server_header) + data.network.route_size, data.sbuffer + sizeof(struct server_header), &(data.network.servers[s_hdr->src]),me);
						}
					}
				} else {
					// pass to the next server
					pass_to_next_server(data.sbuffer, bytes, ss, me, &(data.network), 1, server_send);
				}
			} else if (FD_ISSET(src, &temp_mask)) {
				// forward along server network for client
				bytes = recvfrom(src, (char *) data.cbuffer, sizeof(data.cbuffer), 0, (struct sockaddr *)&from_addr, &from_len ) - sizeof(struct client_to_server_header);
				
				
				// copy the data of the message
				memcpy(data.sbuffer + sizeof(struct server_header) + data.network.info_size, data.cbuffer + sizeof(struct client_to_server_header), bytes);
				
				
				/*data.cbuffer[sizeof(struct client_to_server_header) + 15] = '\0';
				printf("Received: %s\n", data.cbuffer + sizeof(struct client_to_server_header));*/
				
				bytes += sizeof(struct server_header) + data.network.info_size;
				data.sbuffer[bytes] = '\0';
				// set the basic header info
				s_hdr->src = me->id;
				s_hdr->prev = me->id;
				s_hdr->seq = seq_nums[me->id]++;
				//address = htonl(c_hdr->to_addr);
				s_hdr->to_addr = c_hdr->to_addr; //address
				s_hdr->from_addr = me->ip;

				//find topology server exit node
				next = NULL;
				for (int i = 0; i < data.network.num_servers; i++) {
					if (data.network.servers[i].ip == s_hdr->to_addr) {
						next = &(data.network.servers[i]);
						s_hdr->dest = next->id;
						break;
					}
				}
				
				if (next == NULL) {
					printf("I couldn't find a destination node for the IP address that the client specified: %x\n", s_hdr->to_addr);
				} else if (next->id != me->id) {
					// get the routing info
					//clear_plan(&(data.plan));
					//num_paths = plan_routes(next, &(data.plan), c_hdr->replications, &(data.graph));
					// get route info and put on packet
					route_info = get_route_info(&(data.cache[next->id]), c_hdr->replications, data.max_paths, &num_paths, &(data.graph), &(data.network));
					memcpy(data.sbuffer + sizeof(struct server_header), route_info, data.network.route_size);
					// initialize packet statistics
					gettimeofday(&temp_time, NULL);
					s_hdr->e_sec = (uint32_t) temp_time.tv_sec;
					s_hdr->e_usec = (uint32_t) temp_time.tv_usec;
					memset(data.sbuffer + sizeof(struct server_header) + data.network.route_size, 0, data.network.traveled_size);
				
					// print out statistics
					entered++;
					if (entered >= PRINT) {
						entered = 0;
						print_route(route_info, me, &(data.network.servers[next->id]));
					}
					// send the packets
					pass_to_next_server(data.sbuffer, bytes, ss, me, &(data.network), num_paths, server_send);
					/*route = data.plan.route_list.next;
					while (route != NULL) {
						stamp_with_route(data.sbuffer + sizeof(struct server_header), route, &(data.network));
						
						route = route->next;
					}*/
				} else {
					// entry node for overlay is also exit node
					// just pass to client
					
					// set client address
					if (s_hdr->to_addr == me->ip) {
						client.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
					} else {
						client.sin_addr.s_addr = s_hdr->to_addr;
					}
					
					bytes = prep_to_client(data.sbuffer, data.cbuffer, bytes, &(data.network));
					sendto( ss, (char*) data.cbuffer, bytes, 0, (struct sockaddr *)&(client), sizeof(client));
				}	
			} else {
				printf("Error, received from socket we aren't listening on.\n");
				exit(1);
			}
		}
		
		if (elapsed_time(&last, &now) >= WAIT) {
			last = now;
			//printf("Waiting and flushing buffers...\n");
			for (int i = 0; i < data.network.num_servers; i++) {
				flush_buffer(&(data.cache[i]), ss, TRUE);
			}
		}
	}
	
	return 0;
}
