#ifndef NETWORK_H
#define NETWORK_H

#include "commondefs.h"

struct network;
struct server;
struct link;

struct route;

// Functions defined by the networking algorithm
void print_network(struct network* network);
void print_byte(char byte);
void print_route_info(char* route_info, struct network* network);
void print_path_traveled(char* traveled_info, char* route_info, struct server* src, struct server* dest);
void print_route(char* route_info, struct server* src, struct server* dest);
int configure_network(struct network* network, char* config_file);
void free_network(struct network* network);
struct link* find_link(struct server* src, struct server* dest);
void stamp_with_route(char* route_info, struct route* route, struct network* network);
int size_of_route_info(struct network* network);

/* Models a link between to another server
 */
struct link {
	//link info
	struct server* neighbor;
	int cost;
	
	//header info
	int offset;
	char byte;
	
	struct link* next;
};

/* Models a server
 */
struct server {
	// basic info
	uint16_t id;
	uint32_t ip;
	
	// stamping info
	int offset;
	char byte;
	
	int num_links;
	struct link link_list;
};


/* Models a network
 */
struct network {
	int num_servers;
	int num_links;
	struct server* servers;
	int info_size;
	int route_size;
	int traveled_size;
};

/* Models a hop in a route
 */
struct hop {
	struct link* link;
	struct hop* next;
};

/* Models a route as a subgraph of links
 * Links not necessarily in route order
 */
struct route {
	struct hop hop_list;
	struct route* next;
};

#endif

