#include "graph.h"

void build_graph_from_network(struct graph* graph, struct server* src, struct network* network) {
	graph->num_nodes = network->num_servers;
	graph->nodes = (struct dnode*) malloc(sizeof(struct dnode) * graph->num_nodes);
	graph->queue.next = NULL;
	graph->queue.prev = NULL;
	graph->src = &(graph->nodes[src->id]);
	
	struct link* link;
	struct dedge* edge;
	for (int i = 0; i < graph->num_nodes; i++) {
		graph->nodes[i].id = network->servers[i].id;
		link = network->servers[i].link_list.next;
		edge = &(graph->nodes[i].edge_list);
		while (link != NULL) {
			edge->next = (struct dedge*) malloc(sizeof(struct dedge));
			
			edge->next->from = &(graph->nodes[i]);
			edge->next->to = &(graph->nodes[link->neighbor->id]);
			edge->next->link = link;
			
			edge = edge->next;
			link = link->next;
		}
		edge->next = NULL;
	}
}

void free_graph(struct graph* graph) {
	struct dedge* delete;
	struct dedge* head;
	for (int i = 0; i < graph->num_nodes; i++) {
		head = &(graph->nodes[i].edge_list);
		while (head->next != NULL) {
			delete = head->next;
			head->next = delete->next;
			free(delete);
		}
	}
	free(graph->nodes);
}

int plan_routes(struct server* dest, struct route* plan, int num_paths, struct graph* graph) {
	//DIJKSTRA!
	// set up everything
	for (int i = 0; i < graph->num_nodes; i++) {
		graph->nodes[i].visited = FALSE;
		graph->nodes[i].distance = -1;
		graph->nodes[i].in_edge = NULL;
		graph->nodes[i].next = NULL;
		graph->nodes[i].prev = NULL;
	}
	struct dnode* queue = &(graph->queue);
	graph->src->distance = 0;
	queue->next = graph->src;
	queue->prev = graph->src;
	graph->src->next = queue;
	graph->src->prev = queue;
	
	struct dnode* current;
	struct dedge* edge;
	int distance;
	int total;
	while (queue->next != queue) {
		// remove head of queue
		current = queue->next;
		queue->next = current->next;
		current->next->prev = queue;
		
		// set the visited variable
		current->visited = TRUE;
		
		// check to see if you found the destination
		if (current->id == dest->id) {
			break;
		}
		
		// try to relax edges
		edge = current->edge_list.next;
		distance = current->distance;
		while (edge != NULL) {
			printf("Considering edge costing %d to %d, which has current distance %d\n", edge->link->cost, edge->to->id, edge->to->distance);
			total = distance + edge->link->cost;
			if (!edge->to->visited && (edge->to->next == NULL || edge->to->distance > total)) {
				printf("Relaxing!\n");
				// adjust distance and in edge
				edge->to->distance = total;
				edge->to->in_edge = edge;
				
				// remove from the queue
				if (edge->to->next != NULL) {
					// only null if never in the qeueu
					// if in the queue, the both prev and
					// next must be valid. So only one null
					// check is required
					edge->to->next->prev = edge->to->prev;
					edge->to->prev->next = edge->to->next;
				}
				
				// find the appropriate spot to add to queue
				current = queue->next;
				while (current != queue) {
					if (current->distance >= edge->to->distance) {
						break;
					}
					current = current->next;
				}
				
				// add as the node preceding current
				edge->to->next = current;
				edge->to->prev = current->prev;
				current->prev->next = edge->to;
				current->prev = edge->to;

				/*current = queue->next;
				printf("Printing queue:\n");
				while (current != queue) {
					printf("\t%d: %d\n", current->id, current->distance);
					current = current->next;
				}
				printf("\n");*/
				
			}
			edge = edge->next;
		}
	}
	
	if (current->id != dest->id) {
		// couldn't find a route
		return 0;
	}
	
	// translate result of dijkstra's into a route
	plan->hop_list.next = NULL;
	struct hop* hop;
	while (current->id != graph->src->id) {
		hop = (struct hop*) malloc(sizeof(struct hop));
		hop->link = current->in_edge->link;
		hop->next = plan->hop_list.next;
		plan->hop_list.next = hop;
		
		current = current->in_edge->from;
	}
	
	return 1;
}
