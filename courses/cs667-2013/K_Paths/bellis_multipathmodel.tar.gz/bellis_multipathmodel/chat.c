#include "commondefs.h"
#define OPTION_SIZE 3
#define MAX_INPUT (DATA_SIZE + OPTION_SIZE)

int main()
{
	struct sockaddr_in name;
	struct sockaddr_in send_addr;
	int has_dest = FALSE;
	int ss,sr;
	fd_set mask;
	fd_set dummy_mask,temp_mask;
	int bytes;
	int num;
	char input_buf[MAX_INPUT + 1];
	char recv_buf[DATA_SIZE + sizeof(struct server_to_client_header) + 1];
	char send_buf[DATA_SIZE + sizeof(struct client_to_server_header)];
	char char_data[DATA_SIZE + 1];
	struct client_to_server_header* s_hdr = (struct client_to_server_header*) send_buf;
	struct server_to_client_header* r_hdr = (struct server_to_client_header*) recv_buf;

	sr = socket(AF_INET, SOCK_DGRAM, 0); /* socket for receiving */
	if (sr<0) {
		perror("Mcast: socket");
		exit(1);
	}

	name.sin_family = AF_INET;
	name.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
	name.sin_port = htons(C_LISTENSTO_S_PORT);

	if ( bind( sr, (struct sockaddr *)&name, sizeof(name) ) < 0 ) {
		perror("Client: bind");
		exit(1);
	}

	ss = socket(AF_INET, SOCK_DGRAM, 0); /* Socket for sending */
	if (ss<0) {
		perror("Bcast: socket");
		exit(1);
	}

	send_addr.sin_family = AF_INET;
	send_addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);  /* mcast address */
	send_addr.sin_port = htons(S_LISTENSTO_C_PORT);

	char option;
	s_hdr->replications = 1;

	FD_ZERO( &mask );
	FD_ZERO( &dummy_mask );
	FD_SET( sr, &mask );
	FD_SET( (long)0, &mask );	/* stdin */
	for(;;)
	{
		temp_mask = mask;
		num = select( FD_SETSIZE, &temp_mask, &dummy_mask, &dummy_mask, NULL);
		if (num > 0) {
			if ( FD_ISSET( sr, &temp_mask) ) {
				bytes = recv( sr, recv_buf, sizeof(recv_buf) - 1, 0 );
				recv_buf[bytes] = 0;
				printf( "%x: %s", r_hdr->from_addr, recv_buf + sizeof(struct server_to_client_header));
			} else if( FD_ISSET(0, &temp_mask) ) {
				bytes = read(0, input_buf, OPTION_SIZE);
				if (sscanf(input_buf, "-%c ", &option) && (option == 'c' || option == 'r' || option == 'a' || option == 'h')) {
					if (option != 'h') {
						bytes = read(0, input_buf, DATA_SIZE);
					}
					struct hostent* host;
					switch (option) {
						case 'h':
							printf("help:\n\t-h: help and print available commands\n\t-c <ip address/host name>: choose a server to message\n\t-r <number>: choose number of replications/paths\n\t-a <message>: append a message\n");
							break;
						case 'c':
							sscanf(input_buf, "%s", char_data);
							host = gethostbyname(char_data);
							memcpy(&(s_hdr->to_addr), host->h_addr_list[0], sizeof(host->h_length));
							has_dest = TRUE;
							//s_hdr->to_addr = (uint32_t) htonl(inet_pton(AF_INET, (const char*) data, &(s_hdr->to_addr)));
							break;
						case 'r':
							sscanf(input_buf, "%d", (int*) &(s_hdr->replications));
							printf("Number of replications set to %d\n", s_hdr->replications);
							//s_hdr->replications = (uint16_t) atoi(data);
							break;
						case 'a':
						default:
							if (has_dest) {
								memcpy(send_buf + sizeof(struct client_to_server_header), input_buf, bytes);
								sendto(ss, send_buf, bytes + sizeof(struct client_to_server_header), 0, (struct sockaddr *)&send_addr, sizeof(send_addr));
								while (bytes == DATA_SIZE) {
									// check if there is more to be sent
									bytes = read(0, send_buf + sizeof(struct client_to_server_header), DATA_SIZE);
									if (bytes > 0) {
										sendto(ss, send_buf, bytes + sizeof(struct client_to_server_header), 0, (struct sockaddr *)&send_addr, sizeof(send_addr));
									}
								}
							} else {
								printf("Use -c to choose a destination first\n");
							}
							break;
					}
				} else {
					// get rid of extra, unprocessed input
					while (bytes == DATA_SIZE) {
						bytes = read(0, input_buf, DATA_SIZE);
					}
				}
			}
		}
	}

	return 0;

}
