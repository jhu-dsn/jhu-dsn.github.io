package com.jhu.ads.controller;

public interface Constants {

	public static String WOWZA_SERVER_LIST_TAG = "WowzaServersList";
	public static String WOWZA_SERVER_TAG = "WowzaServer";
	public static String WOWZA_SERVER_ID_TAG = "Id";
	public static String WOWZA_SERVER_IP_TAG = "Ip";
	public static String WOWZA_SERVER_STREAMING_PORT_TAG = "StreamingPort";
	public static String WOWZA_SERVER_MAX_CAPACITY_TAG = "MaxCapacity";
	
	public static String WOWZA_MEDIA_SERVER_TAG = "WowzaMediaServer";
	public static String WOWZA_SERVER_COUNT_TAG = "ConnectionsCurrent";

}
