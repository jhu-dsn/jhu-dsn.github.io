#!/bin/bash

## See LICENSE for copyright and licensing information

# Set some error reporting stuff
set -e
set -u

if [ $(whoami) = "root" ]
then
  echo "Running as root is not supported."
  exit 1
fi


source ./config.example

#set work directory
WD="/home/fenghuan/dsn-tor"

PIDDIR="$WD/pid"

