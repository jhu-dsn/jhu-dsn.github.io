"""Empty init file to ensure documentation for the renderer is created."""

from flow.renderer.pyglet_renderer import PygletRenderer

__all__ = ['PygletRenderer']
