"""Specifies the current version number of Flow."""

__version__ = "0.5.0.dev"
