from flow.core.params import NetParams
from flow.networks.traffic_light_grid import TrafficLightGridNetwork
from flow.core.params import TrafficLightParams

from flow.core.params import SumoParams, EnvParams, InitialConfig, NetParams, \
    InFlows, SumoCarFollowingParams, SumoLaneChangeParams
from flow.core.params import VehicleParams
import numpy as np
from flow.core.experiment import Experiment
#from flow.envs.ring.accel import AccelEnv, ADDITIONAL_ENV_PARAMS
from flow.envs.traffic_light_grid import TrafficLightGridEnv#, ADDITIONAL_ENV_PARAMS
from flow.envs import TrafficLightGridPOEnv

from flow.controllers import GridRouter, SimCarFollowingController
from flow.core.params import InFlows

from examples.train import run_model_stablebaseline

from flow.core import rewards
from flow.utils.registry import env_constructor
from stable_baselines.common.vec_env import DummyVecEnv, SubprocVecEnv

def gen_edges(col_num, row_num):
    """Generate the names of the outer edges in the grid network.
    Parameters
    ----------
    col_num : int
        number of columns in the grid
    row_num : int
        number of rows in the grid
    Returns
    -------
    list of str
        names of all the outer edges
    """
    edges = []

    # build the left and then the right edges
    for i in range(col_num):
        edges += ['left' + str(row_num) + '_' + str(i)]
        edges += ['right' + '0' + '_' + str(i)]

    # build the bottom and then top edges
    for i in range(row_num):
        edges += ['bot' + str(i) + '_' + '0']
        edges += ['top' + str(i) + '_' + str(col_num)]

    return edges

def get_outside_edges(rows, cols):
  edges = []
  for i in range(rows):
    edges.append("bot{}_0".format(i))
    edges.append("top{}_{}".format(i, cols))
  for j in range(cols):
    edges.append("left{}_{}".format(rows, j))
    edges.append("right0_{}".format(j))
  return edges


inner_length = 100
long_length = 100
short_length = 100
n = 2 # rows
m = 2 # columns
num_cars_left = 10
num_cars_right = 10
num_cars_top = 10
num_cars_bot = 10
tot_cars = (num_cars_left + num_cars_right) * m \
    + (num_cars_top + num_cars_bot) * n

grid_array = {"short_length": short_length, "inner_length": inner_length,
              "long_length": long_length, "row_num": n, "col_num": m,
              "cars_left": num_cars_left, "cars_right": num_cars_right,
              "cars_top": num_cars_top, "cars_bot": num_cars_bot}

tl_logic = TrafficLightParams(baseline=False)

nodes = ["center0", "center1", "center2", "center3"]
#phases = [{"duration": "31", "state": "GGGrrrGGGrrr"},
#           {"duration": "6", "state": "yyyrrryyyrrr"},
#           {"duration": "31", "state": "rrrGGGrrrGGG"},
#           {"duration": "6", "state": "rrryyyrrryyy"}]
phases = ["GGGGrrrrGGGGrrrr","yyyyrrrryyyyrrrr","rrrrGGGGrrrrGGGG","rrrryyyyrrrryyyy"]
phases1lane = ['GGGrrrGGGrrr','yyyrrryyyrrr','rrrGGGrrrGGG','rrryyyrrryyy']

durations = [{"duration": "31", "state": "GGGrrrGGGrrr"},
          {"duration": "6", "state": "yyyrrryyyrrr"},
          {"duration": "31", "state": "rrrGGGrrrGGG"},
          {"duration": "6", "state": "rrryyyrrryyy"}]

for node_id in nodes:
    tl_logic.add(node_id, tls_type="static", programID="1", offset=None, phases=durations)

#for node_id in nodes:
#    tl_logic.add(node_id, tls_type="static", programID="1", offset=None, phases=phases)


additional_net_params = {"grid_array": grid_array, "speed_limit": 35,
                         "horizontal_lanes": 1, "vertical_lanes": 1,
                         "traffic_lights": True}

from flow.controllers.routing_controllers import GridRouter
from flow.controllers.lane_change_controllers import SimLaneChangeController

vehicles=VehicleParams()
#vehicles.types=["human"]
#vehicles.add("human",
#             acceleration_controller=(IDMController, {}),
#             routing_controller=(GridRouter, {}),
#             num_vehicles=tot_cars)
vehicles.add("human",
   acceleration_controller=(SimCarFollowingController, {}),
   #lane_change_controller=(SimLaneChangeController, {}),
   #lane_change_params=SumoLaneChangeParams(lane_change_mode='aggressive'),
  car_following_params=SumoCarFollowingParams(
       speed_mode="right_of_way"))

initial_config = InitialConfig(
    spacing='custom')

inflows = InFlows()
p = .15
for edge in get_outside_edges(n, m):
  if edge[0] == 'l' or edge[0] == 'r':
      inflows.add(veh_type="human",
              edge=edge,
              vehs_per_hour=500 * 18 / 10,
              #probability=p,
              depart_lane="random",
              depart_speed="random",
              color="white")
  else:
      inflows.add(veh_type="human",
              edge=edge,
              vehs_per_hour=1000 * 2 / 10,
              #probability=p,
              depart_lane="random",
              depart_speed="random",
              color="white")




net_params = NetParams(inflows = inflows, additional_params=additional_net_params)
"""
network = TrafficLightGridNetwork(name="grid",
                            vehicles=vehicles,
                            net_params=net_params,
                            initial_config=initial_config,
                            traffic_lights=tl_logic)
"""

# STATIC TRAFFIC LIGHTS

#tl_logic = TrafficLightParams(baseline=False)
#for node in nodes:
# tl_logic.add(node, phases=phases, programID=1)

sim_params = SumoParams(sim_step=0.1, render=False, restart_instance=True)

#print(ADDITIONAL_ENV_PARAMS)
ADDITIONAL_ENV_PARAMS = {'switch_time': 2.0, 'tl_type': 'controlled', 'discrete': False, 'num_observed': 2, 'target_velocity': 50, 'phase':phases}
env_params = EnvParams(additional_params=ADDITIONAL_ENV_PARAMS)

flow_params = dict(
    exp_tag='RL_lights',
    env_name=TrafficLightGridPOEnv,
    network=TrafficLightGridNetwork,
    simulator='traci',
    sim=sim_params,
    env=env_params,
    net=net_params,
    veh=vehicles,
    initial=initial_config,
    tls=tl_logic
)

# number of time steps
flow_params['env'].horizon = 3000
# rollout_size should be multiple of 4
# model = run_model_stablebaseline(flow_params, rollout_size=60, num_steps=1000)
# #print(dir(model))

# flow_params['sim'].render = True
# env = env_constructor(params=flow_params, version=0)()
# # The algorithms require a vectorized environment to run
# eval_env = DummyVecEnv([lambda: env])
# obs = eval_env.reset()
# reward = 0
# for _ in range(flow_params['env'].horizon):
#     action, _states = model.predict(obs)
#     obs, rewards, dones, info = eval_env.step(action)
#     reward += rewards
# print('the final reward is {}'.format(reward))

exp = Experiment(flow_params)
#to see possible routes
#print(exp.env.network.specify_routes(net_params))

# run the sumo simulation
_ = exp.run(1, convert_to_csv=False)
#print("average delay is:", rewards.min_delay_unscaled(exp.env))

#-17411.324
