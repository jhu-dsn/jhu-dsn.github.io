"""Empty init file to ensure that the examples documentation builds."""
