This is the documentation folder for flow documentation.

Idea: fill this folder with instructions and links for 
how to write documentation.

Preliminary content: a link to the Dropbox Paper page
I wrote concerning an [introduction to documentation](https://paper.dropbox.com/doc/introduction-to-documentation-K4b8Bm3ukikqaKx7LAU9w)
