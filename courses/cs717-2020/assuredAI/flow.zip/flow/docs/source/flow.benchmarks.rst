flow.benchmarks package
=======================

Submodules
----------

flow.benchmarks.bottleneck0 module
----------------------------------

.. automodule:: flow.benchmarks.bottleneck0
    :members:
    :undoc-members:
    :show-inheritance:

flow.benchmarks.bottleneck1 module
----------------------------------

.. automodule:: flow.benchmarks.bottleneck1
    :members:
    :undoc-members:
    :show-inheritance:

flow.benchmarks.bottleneck2 module
----------------------------------

.. automodule:: flow.benchmarks.bottleneck2
    :members:
    :undoc-members:
    :show-inheritance:

flow.benchmarks.figureeight0 module
-----------------------------------

.. automodule:: flow.benchmarks.figureeight0
    :members:
    :undoc-members:
    :show-inheritance:

flow.benchmarks.figureeight1 module
-----------------------------------

.. automodule:: flow.benchmarks.figureeight1
    :members:
    :undoc-members:
    :show-inheritance:

flow.benchmarks.figureeight2 module
-----------------------------------

.. automodule:: flow.benchmarks.figureeight2
    :members:
    :undoc-members:
    :show-inheritance:

flow.benchmarks.grid0 module
----------------------------

.. automodule:: flow.benchmarks.grid0
    :members:
    :undoc-members:
    :show-inheritance:

flow.benchmarks.grid1 module
----------------------------

.. automodule:: flow.benchmarks.grid1
    :members:
    :undoc-members:
    :show-inheritance:

flow.benchmarks.merge0 module
-----------------------------

.. automodule:: flow.benchmarks.merge0
    :members:
    :undoc-members:
    :show-inheritance:

flow.benchmarks.merge1 module
-----------------------------

.. automodule:: flow.benchmarks.merge1
    :members:
    :undoc-members:
    :show-inheritance:

flow.benchmarks.merge2 module
-----------------------------

.. automodule:: flow.benchmarks.merge2
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: flow.benchmarks
    :members:
    :undoc-members:
    :show-inheritance:
