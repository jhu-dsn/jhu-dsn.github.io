# Bandwidth Measurement

An Android application aimed towards testing real time capabilities over 5G networks. It integrates [cellular-measurement](https://github.com/jerrychen017/cellular-measurement) to measure cellular bandwidth and network latency. It also includes interactive functionality to test real-time interactivity. 

## How to run
* Install the app with Android Studio
