rm config/currentView
./runscripts/smartrun.sh bftsmart.demo.microbenchmarks.ThroughputLatencyServer $1 1000 16 16 0
