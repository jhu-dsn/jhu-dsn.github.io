./runscripts/smartrun.sh bftsmart.demo.microbenchmarks.ThroughputLatencyClient 1 1001 $1 16 1000 0 1 0
