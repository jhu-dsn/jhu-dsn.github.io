/*
Copyright (C) 2017 Semester.ly Technologies, LLC

Semester.ly is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Semester.ly is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/

import { connect } from 'react-redux';
import SideBar from '../side_bar';
import {
  getActiveTimetable,
  getCurrentSemester,
  getDenormCourseById,
  getCoursesFromSlots,
} from '../../reducers/root_reducer';
import {
    fetchCourseInfo,
    showFinalExamsModal,
    togglePeerModal,
    triggerTextbookModal,
} from '../../actions/modal_actions';
import {
    addOrRemoveCourse,
    addOrRemoveOptionalCourse,
    loadTimetable,
    addComment,
} from '../../actions/timetable_actions';
import { deleteTimetable, duplicateTimetable, deleteAdvisingTimetable } from '../../actions/user_actions';
import { getCourseShareLink } from '../../constants/endpoints';

const mapStateToProps = (state) => {
  const timetable = getActiveTimetable(state);
  const coursesInTimetable = getCoursesFromSlots(state, timetable.slots);
  const mandatoryCourses = getCoursesFromSlots(state, timetable.slots.filter(
    slot => !slot.is_optional));
  const optionalCourses = state.optionalCourses.courses.map(cid => getDenormCourseById(state, cid));
  return {
    semester: getCurrentSemester(state),
    semesterIndex: state.semester.current,
    examSupportedSemesters: state.semester.exams,
    coursesInTimetable,
    mandatoryCourses,
    optionalCourses,
    advisingTimetables: state.advisor.advisingTimetables,
    savedTimetables: state.userInfo.data.timetables,
    courseToColourIndex: state.ui.courseToColourIndex,
    courseToClassmates: state.classmates.courseToClassmates,
    avgRating: timetable.avg_rating,
    isCourseInRoster: courseId => timetable.slots.some(s => s.course === courseId),
    hasLoaded: !state.timetables.isFetching,
    getShareLink: courseCode => getCourseShareLink(courseCode, getCurrentSemester(state)),
    comments: state.timetables.comments,
    tt_id: state.timetables.items[0].id !== undefined ? state.timetables.items[0].id : -1,
  };
};


const SideBarContainer = connect(
    mapStateToProps,
  {
    fetchCourseInfo,
    removeCourse: addOrRemoveCourse,
    removeOptionalCourse: addOrRemoveOptionalCourse,
    launchPeerModal: togglePeerModal,
    launchTextbookModal: triggerTextbookModal,
    duplicateTimetable,
    deleteTimetable,
    deleteAdvisingTimetable,
    launchFinalExamsModal: showFinalExamsModal,
    loadTimetable,
    addComment,
  },
)(SideBar);

export default SideBarContainer;
