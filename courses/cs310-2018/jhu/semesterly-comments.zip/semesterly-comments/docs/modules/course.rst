Courses App
===========

The courses app deals with the accesing course information, the sharing of courses, and the rendering of the course/all course pages.

Views
~~~~~
.. automodule:: courses.views
    :members:

Utils
~~~~~
.. automodule:: courses.utils
    :members:

Serializers
~~~~~~~~~~~
.. automodule:: courses.serializers
    :members: