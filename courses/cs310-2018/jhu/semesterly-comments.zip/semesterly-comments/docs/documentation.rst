Backend Documentation
=====================

.. toctree::
   :maxdepth: 2

   modules/timetable
   modules/course
   modules/student
   modules/searches
   modules/exams
   modules/agreement
   modules/e2e   
   modules/helpers   
   modules/authpipe