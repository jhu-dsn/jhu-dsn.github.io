.. _design:

Design/Branding Guidelines
==========================

Fonts & Colors
~~~~~~~~~~~~~~
.. image:: guidelines_Page_1.png
   :alt: Guidelines 1 
   :align: center

Logo Usage
~~~~~~~~~~
.. image:: guidelines_Page_2.png
   :alt: Guidelines 2
   :align: right

Logos
~~~~~
You can download `logos and favicon files here <https://drive.google.com/open?id=0BzXL0vLjAYlLcGhHWlIyYUZBcmc>`_