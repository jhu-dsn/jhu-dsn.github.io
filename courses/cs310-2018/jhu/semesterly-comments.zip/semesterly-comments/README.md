<p align="center"><a href="https://semester.ly" target="_blank"><img width="100"src="https://semester.ly/static/img/logo2.0-32x32.png"></a></p>
<p align="center"><a href="https://semester.ly" target="_blank"><img width="200" src="http://i.imgur.com/9mMP9bY.png"/></a></p>

<p align="center">
  <a href="https://travis-ci.com/noahpresler/semesterly"><img src="https://travis-ci.com/noahpresler/semesterly.svg?token=4y9SYQsb7pCqAsUpdN2F&branch=master"></a>
  <a href="https://www.gnu.org/licenses/gpl-3.0"><img src="https://img.shields.io/badge/License-GPL%20v3-blue.svg"/></a>
   <a href="https://github.com/noahpresler/semesterly/pulls"><img src="https://img.shields.io/badge/PRs-welcome-brightgreen.svg"/></a>
   <a href="http://semesterly.readthedocs.io/en/latest/"><img src="https://readthedocs.org/projects/docs/badge/?version=latest"/></a>
  <a href="https://travis-ci.org/noahpresler/semesterly/"><img src="https://travis-ci.org/noahpresler/semesterly.svg?branch=master"/></a>
</p>

<p align="center">
Read the docs and learn more: http://semesterly.readthedocs.io/en/latest/
</p>

<p align="center"><img src="http://i.imgur.com/G543QPJ.jpg"></p>

## License

Copyright 2017, Semester.ly Technologies, LLC

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
