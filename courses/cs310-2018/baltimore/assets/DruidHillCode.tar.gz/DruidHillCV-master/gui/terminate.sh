#!/bin/bash
echo “Terminating process…”
pkill -f multitracking_tensor.py


