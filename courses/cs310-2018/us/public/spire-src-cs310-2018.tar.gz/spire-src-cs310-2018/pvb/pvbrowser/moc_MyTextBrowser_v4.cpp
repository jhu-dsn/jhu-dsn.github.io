/****************************************************************************
** Meta object code from reading C++ file 'MyTextBrowser_v4.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "MyTextBrowser_v4.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MyTextBrowser_v4.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MyTextBrowser[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      20,   15,   14,   14, 0x0a,
      42,   15,   14,   14, 0x0a,
      66,   63,   14,   14, 0x0a,
      89,   14,   14,   14, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MyTextBrowser[] = {
    "MyTextBrowser\0\0link\0slotLinkClicked(QUrl)\0"
    "slotUrlChanged(QUrl)\0ok\0slotLoadFinished(bool)\0"
    "slotPRINTER()\0"
};

void MyTextBrowser::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MyTextBrowser *_t = static_cast<MyTextBrowser *>(_o);
        switch (_id) {
        case 0: _t->slotLinkClicked((*reinterpret_cast< const QUrl(*)>(_a[1]))); break;
        case 1: _t->slotUrlChanged((*reinterpret_cast< const QUrl(*)>(_a[1]))); break;
        case 2: _t->slotLoadFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->slotPRINTER(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MyTextBrowser::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MyTextBrowser::staticMetaObject = {
    { &QWebView::staticMetaObject, qt_meta_stringdata_MyTextBrowser,
      qt_meta_data_MyTextBrowser, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MyTextBrowser::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MyTextBrowser::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MyTextBrowser::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MyTextBrowser))
        return static_cast<void*>(const_cast< MyTextBrowser*>(this));
    return QWebView::qt_metacast(_clname);
}

int MyTextBrowser::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWebView::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
