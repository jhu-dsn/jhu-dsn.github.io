/****************************************************************************
** Meta object code from reading C++ file 'qwtwidgets.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "qwtwidgets.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qwtwidgets.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MyQwtScale[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_MyQwtScale[] = {
    "MyQwtScale\0"
};

void MyQwtScale::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData MyQwtScale::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MyQwtScale::staticMetaObject = {
    { &QwtScaleWidget::staticMetaObject, qt_meta_stringdata_MyQwtScale,
      qt_meta_data_MyQwtScale, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MyQwtScale::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MyQwtScale::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MyQwtScale::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MyQwtScale))
        return static_cast<void*>(const_cast< MyQwtScale*>(this));
    return QwtScaleWidget::qt_metacast(_clname);
}

int MyQwtScale::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QwtScaleWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_MyQwtThermo[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_MyQwtThermo[] = {
    "MyQwtThermo\0"
};

void MyQwtThermo::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData MyQwtThermo::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MyQwtThermo::staticMetaObject = {
    { &QwtThermo::staticMetaObject, qt_meta_stringdata_MyQwtThermo,
      qt_meta_data_MyQwtThermo, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MyQwtThermo::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MyQwtThermo::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MyQwtThermo::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MyQwtThermo))
        return static_cast<void*>(const_cast< MyQwtThermo*>(this));
    return QwtThermo::qt_metacast(_clname);
}

int MyQwtThermo::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QwtThermo::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_MyQwtKnob[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      17,   11,   10,   10, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MyQwtKnob[] = {
    "MyQwtKnob\0\0value\0slotValueChanged(double)\0"
};

void MyQwtKnob::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MyQwtKnob *_t = static_cast<MyQwtKnob *>(_o);
        switch (_id) {
        case 0: _t->slotValueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MyQwtKnob::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MyQwtKnob::staticMetaObject = {
    { &QwtKnob::staticMetaObject, qt_meta_stringdata_MyQwtKnob,
      qt_meta_data_MyQwtKnob, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MyQwtKnob::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MyQwtKnob::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MyQwtKnob::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MyQwtKnob))
        return static_cast<void*>(const_cast< MyQwtKnob*>(this));
    return QwtKnob::qt_metacast(_clname);
}

int MyQwtKnob::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QwtKnob::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}
static const uint qt_meta_data_MyQwtCounter[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      20,   14,   13,   13, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MyQwtCounter[] = {
    "MyQwtCounter\0\0value\0slotValueChanged(double)\0"
};

void MyQwtCounter::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MyQwtCounter *_t = static_cast<MyQwtCounter *>(_o);
        switch (_id) {
        case 0: _t->slotValueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MyQwtCounter::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MyQwtCounter::staticMetaObject = {
    { &QwtCounter::staticMetaObject, qt_meta_stringdata_MyQwtCounter,
      qt_meta_data_MyQwtCounter, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MyQwtCounter::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MyQwtCounter::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MyQwtCounter::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MyQwtCounter))
        return static_cast<void*>(const_cast< MyQwtCounter*>(this));
    return QwtCounter::qt_metacast(_clname);
}

int MyQwtCounter::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QwtCounter::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}
static const uint qt_meta_data_MyQwtWheel[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      18,   12,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MyQwtWheel[] = {
    "MyQwtWheel\0\0value\0slotValueChanged(double)\0"
};

void MyQwtWheel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MyQwtWheel *_t = static_cast<MyQwtWheel *>(_o);
        switch (_id) {
        case 0: _t->slotValueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MyQwtWheel::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MyQwtWheel::staticMetaObject = {
    { &QwtWheel::staticMetaObject, qt_meta_stringdata_MyQwtWheel,
      qt_meta_data_MyQwtWheel, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MyQwtWheel::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MyQwtWheel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MyQwtWheel::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MyQwtWheel))
        return static_cast<void*>(const_cast< MyQwtWheel*>(this));
    return QwtWheel::qt_metacast(_clname);
}

int MyQwtWheel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QwtWheel::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}
static const uint qt_meta_data_MyQwtSlider[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      19,   13,   12,   12, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MyQwtSlider[] = {
    "MyQwtSlider\0\0value\0slotValueChanged(double)\0"
};

void MyQwtSlider::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MyQwtSlider *_t = static_cast<MyQwtSlider *>(_o);
        switch (_id) {
        case 0: _t->slotValueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MyQwtSlider::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MyQwtSlider::staticMetaObject = {
    { &QwtSlider::staticMetaObject, qt_meta_stringdata_MyQwtSlider,
      qt_meta_data_MyQwtSlider, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MyQwtSlider::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MyQwtSlider::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MyQwtSlider::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MyQwtSlider))
        return static_cast<void*>(const_cast< MyQwtSlider*>(this));
    return QwtSlider::qt_metacast(_clname);
}

int MyQwtSlider::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QwtSlider::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}
static const uint qt_meta_data_MyQwtDial[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      17,   11,   10,   10, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MyQwtDial[] = {
    "MyQwtDial\0\0value\0slotValueChanged(double)\0"
};

void MyQwtDial::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MyQwtDial *_t = static_cast<MyQwtDial *>(_o);
        switch (_id) {
        case 0: _t->slotValueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MyQwtDial::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MyQwtDial::staticMetaObject = {
    { &QwtDial::staticMetaObject, qt_meta_stringdata_MyQwtDial,
      qt_meta_data_MyQwtDial, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MyQwtDial::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MyQwtDial::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MyQwtDial::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MyQwtDial))
        return static_cast<void*>(const_cast< MyQwtDial*>(this));
    return QwtDial::qt_metacast(_clname);
}

int MyQwtDial::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QwtDial::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}
static const uint qt_meta_data_MyQwtAnalogClock[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      24,   18,   17,   17, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MyQwtAnalogClock[] = {
    "MyQwtAnalogClock\0\0value\0"
    "slotValueChanged(double)\0"
};

void MyQwtAnalogClock::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MyQwtAnalogClock *_t = static_cast<MyQwtAnalogClock *>(_o);
        switch (_id) {
        case 0: _t->slotValueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MyQwtAnalogClock::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MyQwtAnalogClock::staticMetaObject = {
    { &QwtAnalogClock::staticMetaObject, qt_meta_stringdata_MyQwtAnalogClock,
      qt_meta_data_MyQwtAnalogClock, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MyQwtAnalogClock::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MyQwtAnalogClock::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MyQwtAnalogClock::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MyQwtAnalogClock))
        return static_cast<void*>(const_cast< MyQwtAnalogClock*>(this));
    return QwtAnalogClock::qt_metacast(_clname);
}

int MyQwtAnalogClock::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QwtAnalogClock::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}
static const uint qt_meta_data_MyQwtCompass[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      20,   14,   13,   13, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MyQwtCompass[] = {
    "MyQwtCompass\0\0value\0slotValueChanged(double)\0"
};

void MyQwtCompass::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MyQwtCompass *_t = static_cast<MyQwtCompass *>(_o);
        switch (_id) {
        case 0: _t->slotValueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MyQwtCompass::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MyQwtCompass::staticMetaObject = {
    { &QwtCompass::staticMetaObject, qt_meta_stringdata_MyQwtCompass,
      qt_meta_data_MyQwtCompass, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MyQwtCompass::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MyQwtCompass::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MyQwtCompass::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MyQwtCompass))
        return static_cast<void*>(const_cast< MyQwtCompass*>(this));
    return QwtCompass::qt_metacast(_clname);
}

int MyQwtCompass::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QwtCompass::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
