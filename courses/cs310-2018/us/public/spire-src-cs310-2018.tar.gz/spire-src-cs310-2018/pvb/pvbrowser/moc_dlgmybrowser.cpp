/****************************************************************************
** Meta object code from reading C++ file 'dlgmybrowser.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "dlgmybrowser.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'dlgmybrowser.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_dlgMyBrowser[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      14,   13,   13,   13, 0x0a,
      25,   13,   13,   13, 0x0a,
      36,   13,   13,   13, 0x0a,
      50,   13,   13,   13, 0x0a,
      63,   13,   13,   13, 0x0a,
      78,   74,   13,   13, 0x0a,
      99,   74,   13,   13, 0x0a,
     127,  121,   13,   13, 0x0a,
     159,  153,   13,   13, 0x0a,
     201,  198,   13,   13, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_dlgMyBrowser[] = {
    "dlgMyBrowser\0\0slotBack()\0slotHome()\0"
    "slotForward()\0slotReload()\0slotFind()\0"
    "url\0slotUrlChanged(QUrl)\0slotLinkClicked(QUrl)\0"
    "title\0slotTitleChanged(QString)\0reply\0"
    "slotUnsupportedContent(QNetworkReply*)\0"
    "ok\0slotLoadFinished(bool)\0"
};

void dlgMyBrowser::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        dlgMyBrowser *_t = static_cast<dlgMyBrowser *>(_o);
        switch (_id) {
        case 0: _t->slotBack(); break;
        case 1: _t->slotHome(); break;
        case 2: _t->slotForward(); break;
        case 3: _t->slotReload(); break;
        case 4: _t->slotFind(); break;
        case 5: _t->slotUrlChanged((*reinterpret_cast< const QUrl(*)>(_a[1]))); break;
        case 6: _t->slotLinkClicked((*reinterpret_cast< const QUrl(*)>(_a[1]))); break;
        case 7: _t->slotTitleChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 8: _t->slotUnsupportedContent((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 9: _t->slotLoadFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData dlgMyBrowser::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject dlgMyBrowser::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_dlgMyBrowser,
      qt_meta_data_dlgMyBrowser, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &dlgMyBrowser::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *dlgMyBrowser::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *dlgMyBrowser::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_dlgMyBrowser))
        return static_cast<void*>(const_cast< dlgMyBrowser*>(this));
    return QWidget::qt_metacast(_clname);
}

int dlgMyBrowser::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
