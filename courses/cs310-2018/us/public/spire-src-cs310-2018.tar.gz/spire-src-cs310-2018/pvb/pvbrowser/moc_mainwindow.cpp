/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MyScrollArea[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_MyScrollArea[] = {
    "MyScrollArea\0"
};

void MyScrollArea::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData MyScrollArea::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MyScrollArea::staticMetaObject = {
    { &QScrollArea::staticMetaObject, qt_meta_stringdata_MyScrollArea,
      qt_meta_data_MyScrollArea, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MyScrollArea::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MyScrollArea::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MyScrollArea::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MyScrollArea))
        return static_cast<void*>(const_cast< MyScrollArea*>(this));
    return QScrollArea::qt_metacast(_clname);
}

int MyScrollArea::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QScrollArea::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_MyThread[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      14,   10,    9,    9, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_MyThread[] = {
    "MyThread\0\0ind\0dataReady(int)\0"
};

void MyThread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MyThread *_t = static_cast<MyThread *>(_o);
        switch (_id) {
        case 0: _t->dataReady((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MyThread::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MyThread::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_MyThread,
      qt_meta_data_MyThread, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MyThread::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MyThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MyThread::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MyThread))
        return static_cast<void*>(const_cast< MyThread*>(this));
    return QThread::qt_metacast(_clname);
}

int MyThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}

// SIGNAL 0
void MyThread::dataReady(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
static const uint qt_meta_data_MainWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       6,   14, // classinfo
      27,   26, // methods
       1,  161, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // classinfo: key, value
      50,   11,
      97,   58,
     148,  109,
     227,  157,
     242,  232,
     259,  255,

 // slots: signature, parameters, type, tag, flags
     293,  276,  275,  275, 0x0a,
     325,  255,  275,  275, 0x0a,
     346,  342,  275,  275, 0x0a,
     364,  275,  275,  275, 0x0a,
     380,  275,  275,  275, 0x0a,
     394,  275,  275,  275, 0x0a,
     410,  275,  275,  275, 0x0a,
     424,  275,  275,  275, 0x0a,
     437,  275,  275,  275, 0x0a,
     452,  275,  275,  275, 0x0a,
     465,  275,  275,  275, 0x0a,
     478,  275,  275,  275, 0x0a,
     491,  275,  275,  275, 0x0a,
     503,  275,  275,  275, 0x0a,
     514,  275,  275,  275, 0x0a,
     529,  275,  275,  275, 0x0a,
     543,  275,  275,  275, 0x0a,
     559,  275,  275,  275, 0x0a,
     575,  275,  275,  275, 0x0a,
     592,  275,  275,  275, 0x0a,
     605,  275,  275,  275, 0x0a,
     613,  275,  275,  275, 0x0a,
     630,  624,  275,  275, 0x0a,
     650,  275,  275,  275, 0x0a,
     663,  275,  275,  275, 0x0a,
     679,  275,  275,  275, 0x0a,
     706,  703,  275,  275, 0x0a,

 // properties: name, type, flags
     255,  725, 0x0a095002,

       0        // eod
};

static const char qt_meta_stringdata_MainWindow[] = {
    "MainWindow\0{5a22176d-118f-4185-9653-9f98958a6df8}\0"
    "ClassID\0{2df735ba-da4f-4fb7-8f35-b8dfbf8cfd9a}\0"
    "InterfaceID\0{449de213-f8bd-4d2e-a2cf-eab407c03245}\0"
    "EventsID\0"
    "pvbrowser/pv:pvb:pvbrowser:Interactive web applications and HMI/SCADA\0"
    "MIME\0pvbrowser\0ToSuperClass\0url\0"
    "DefaultProperty\0\0edit,tool,status\0"
    "slotEditToolStatus(int,int,int)\0"
    "slotUrl(QString)\0ind\0dataReceived(int)\0"
    "slotReconnect()\0slotTimeOut()\0"
    "slotWhatsThis()\0slotFileOpt()\0"
    "slotWindow()\0slotStorebmp()\0slotGohome()\0"
    "slotLogbmp()\0slotLogpvm()\0slotPrint()\0"
    "slotCopy()\0slotEditmenu()\0slotToolbar()\0"
    "slotStatusbar()\0slotMaximized()\0"
    "slotFullscreen()\0slotManual()\0about()\0"
    "slotExit()\0index\0slotTabChanged(int)\0"
    "slotNewTab()\0slotDeleteTab()\0"
    "slotBusyWidgetTimeout()\0pm\0"
    "snapshot(QPixmap&)\0QString\0"
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MainWindow *_t = static_cast<MainWindow *>(_o);
        switch (_id) {
        case 0: _t->slotEditToolStatus((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 1: _t->slotUrl((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->dataReceived((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->slotReconnect(); break;
        case 4: _t->slotTimeOut(); break;
        case 5: _t->slotWhatsThis(); break;
        case 6: _t->slotFileOpt(); break;
        case 7: _t->slotWindow(); break;
        case 8: _t->slotStorebmp(); break;
        case 9: _t->slotGohome(); break;
        case 10: _t->slotLogbmp(); break;
        case 11: _t->slotLogpvm(); break;
        case 12: _t->slotPrint(); break;
        case 13: _t->slotCopy(); break;
        case 14: _t->slotEditmenu(); break;
        case 15: _t->slotToolbar(); break;
        case 16: _t->slotStatusbar(); break;
        case 17: _t->slotMaximized(); break;
        case 18: _t->slotFullscreen(); break;
        case 19: _t->slotManual(); break;
        case 20: _t->about(); break;
        case 21: _t->slotExit(); break;
        case 22: _t->slotTabChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 23: _t->slotNewTab(); break;
        case 24: _t->slotDeleteTab(); break;
        case 25: _t->slotBusyWidgetTimeout(); break;
        case 26: _t->snapshot((*reinterpret_cast< QPixmap(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MainWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow,
      qt_meta_data_MainWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MainWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 27)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 27;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        _id -= 1;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: slotUrl(*reinterpret_cast< QString*>(_v)); break;
        }
        _id -= 1;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 1;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
QT_END_MOC_NAMESPACE
